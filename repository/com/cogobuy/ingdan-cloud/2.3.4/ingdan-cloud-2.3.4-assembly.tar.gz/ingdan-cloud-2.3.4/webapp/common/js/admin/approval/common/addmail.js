
/**
 * 添加邮件
 * @param container
 */
function completemail(container){
	$.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findAllUser"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.userList != null){
            	var input = $("#"+container).find("#sendMail");
                input.autocomplete(data.userList, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-3'>邮箱</span> <span class='col-4'>英文名</span></div>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-3'>"+row.userMail+"</span> <span class='col-4'>"+row.enName+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.enName;
                    },
                    formatResult: function(row) {
                        return row.enName;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                	input.parent(".addemail").find("input[type=hidden]").remove();
                	var inputstr = "<input type=\"hidden\" userenname=\""+data.enName+"\" usermail=\""+data.userMail+"\"/>";
                	input.parent(".addemail").append(inputstr);
                	//新邮件列表样式不同，需要增加
                	input.parent(".consignee-add").find("input[type=hidden]").remove();
                	input.parent(".consignee-add").append(inputstr);
                }).bind("unmatch", function() {/**没有匹配时**/
                	input.val("");
                	input.parent(".addemail").find("input[type=hidden]").remove();
                	input.parent(".consignee-add").find("input[type=hidden]").remove();
                });
            }
        }
    });
	
	$("#"+container).find("#addEMail").click(function(){
		addmail(container);
	});
	
}


function addmail(container){
	var button = $("#"+container).find("#addEMail");
	if(button.parent(".addemail").find("input[type=hidden]").length){
		var enName = button.parent(".addemail").find("input[type=hidden]").attr("userenname");
		var userMail = button.parent(".addemail").find("input[type=hidden]").attr("usermail");
		var mailList = $("#"+container).find("#mailList");
		if(mailList.find("input[type=checkbox][value="+userMail+"]").length){
			mailList.find("input[type=checkbox][value="+userMail+"]").attr("checked",true);
		}else{
			var labelstr = "<label><input type=\"checkbox\" name=\"mails\" tag=\"sendmail_mail\"" +
			" value=\""+userMail+"\" checked=\"true\" />"+enName+"</label>";
			mailList.append(labelstr);
		}
		button.parent(".addemail").find("input[type=text]").val("");
		button.parent(".addemail").find("input[type=hidden]").remove();
	}
	//新邮件列表
	if(button.parent(".consignee-add").find("input[type=hidden]").length){
		var enName = button.parent(".consignee-add").find("input[type=hidden]").attr("userenname");
		var userMail = button.parent(".consignee-add").find("input[type=hidden]").attr("usermail");
		var mailList = $("#"+container).find("#mailList");
		if(mailList.find("input[type=checkbox][value="+userMail+"]").length){
			mailList.find("input[type=checkbox][value="+userMail+"]").attr("checked",true);
		}else{
			var labelstr = "<label for=\""+userMail+"\"><input type=\"checkbox\" id=\""+userMail+"\" name=\"mails\" tag=\"sendmail_mail\"" +
			" value=\""+userMail+"\" checked=\"true\" />"+enName+"</label>";
			mailList.append(labelstr);
		}
		button.parent(".consignee-add").find("input[type=text]").val("");
		button.parent(".consignee-add").find("input[type=hidden]").remove();
	}
}