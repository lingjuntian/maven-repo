/* 添加一行 */
$("tr input").click(function(){
	var $tr = $(this).parents("tr");
	if($tr.nextAll().length==0){
		addTr($tr);
	}
});
/*删除一行*/
$(".del-text").click(function(){
	var $obj = $(this).parents("tr");
	var $length = $obj.parents("tbody").find("tr").length;
	if($length<2){
		dialog("请最少保留1行","warning",false,2);
		return false;
	}
	delTr($obj);
});
/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.attr("hide","show");
	$copyTr.show();
	$tr.after($copyTr);
}
/* 删除行 */
function delTr($obj){
	$obj.validationEngine('hidePrompt');
	$obj.remove();
}