$(function () {
	$("#info_change_submit").click(function(){
		subimtEditForm("info_form");
	});
	
	$("#nature_change_submit").click(function(){
		subimtEditForm("nature_form");
	});
	
	$("#other_change_submit").click(function(){
		subimtEditForm("other_form");
	});
	
	$("#internal_change_submit").click(function(){
		var error = $("#internal_form").validationEngine('validate');
		if(error){
			subimtEditForm("internal_form");
		}
	});
	
	$("#attr_change_submit").click(function(){
		var infoId = $(this).attr("taginfoid");
		window.location = "/approval/customerAccount_edit?customerAccountId="+infoId;
	});
	
	$("#customerAccountEdit_submit").click(function(){
		$("#customerAccountEdit_submit").hide();
		$("#customerAccountEdit_form").ajaxSubmit(function(returnStr){
	        if (returnStr == "error") {
	        	dialog("数据保存错误，请稍后重试！","unsuccess",true,1);	
	        	$("#customerAccountEdit_submit").show();
	        	return;
	        } else{
	            dialog("成功！","success",true,1);	 
		        setTimeout(function(){window.location = "/approval/customerAccount_index";},1000);	        
	        }
	  });
	});
});

/**
 * 提交确认页面修改表单
 * @param formId
 */
function subimtEditForm(formId){
	$("#"+formId).ajaxSubmit(function(returnStr){
		if (returnStr == "personerror") {
        	dialog("该业务员对应角色配置有误，请重新选择","unsuccess",true,2);	
        	return;          
        }
        if (returnStr == "error") {
        	dialog("数据保存错误，请稍后重试！","unsuccess",true,1);	 
        	return;
        } else{
            dialog("成功！","success",true,1);	 
	        setTimeout(function(){window.location = "/approval/customerAccount_edit?customerAccountId="+returnStr;},1000);	        
        }
  });
}