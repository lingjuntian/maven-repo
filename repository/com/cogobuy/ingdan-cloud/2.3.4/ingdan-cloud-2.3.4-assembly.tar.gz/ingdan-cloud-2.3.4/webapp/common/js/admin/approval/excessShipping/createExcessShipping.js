$(function() {
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
        var haveDetail=detailValidata(); /*验证填写的账单是否存在详细列表*/
		if(error&&haveDetail){
			countData(); /* 统计数量、金额合计等 */
			copyValueToConfig();/* 将新建页面的数值写入确认页面 */
			getEmailList();/* 获取邮件发送列表 */
			copyFileList();/*上传附件公用*/
			$("#write").hide();/*显示确认页面，隐藏新建页面*/
			$("#confirm").show();
			
		}

	});
	/* 点击上一步 */
	$("#previous").click(function() {
		switchPageForConfirm();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#excessShippingForm").append(inputStr);
    		}
    	});
    	$("#submit").hide();
    	$("#excessShippingForm").attr("action","/approval/excessShipping_create");
		$("#excessShippingForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/excessShipping_show?esMain.id="+id;},1000);	  
			}else if(type == "inventoryCode"){
				$("#submit").show();
				dialog("存货编码["+id+"]在对应账套中不存在，请重新选择","unsuccess",true,2);
			}else if(type == "cost"){
				$("#submit").show();
				dialog("存货编码["+id+"]对应成本价为空或为0，请重新选择","unsuccess",true,2);
			}else{
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
	});
	
});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#excessShippingForm").validationEngine('validate');
}

/* 统计数量、金额合计等 */
function countData() {
	/* 总数量 */
	var totalQuantity = 0;
	/* 无税总额 */
	var totalSum = 0;
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		totalQuantity = add(totalQuantity, changeNum($tr.find("input[tdTag=quantity]").val()));
		totalSum = add(totalSum, changeNum($tr.find("input[tdTag=sum]").val()));
	}
	$("#totalQuantity").val(changeTwoDecimal(totalQuantity));
	$("#totalSum").val(changeFourDecimal(totalSum));
}


/* 获取邮件发送列表 */
function getEmailList() {
	var personEmail = $("#personEmail").val();
	var licensecode = $("#licensecode").val();
	var url = "/approval/excessShipping_showConfirmMail?esMain.personEmail="+personEmail+"&esMain.licensecode="+licensecode;
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#submit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else if(nodeNoApprovalUser){
			$("#submit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else{
			$("#submit").show();
		}
	});
}


/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/*清空头部*/
	$("div[tag=confirmHead] span[id$=_confirm]").text("");
	/*清空客户名称的title*/
	$("#customerFullName_confirm").attr("title","");
	/*清空备注*/
	$("#remark_confirm").text("");
	/*清空列表*/
	$("#cdlcode_confirm").text("");
	$("#detailListTbody_confirm").empty();
	/*######################头部 BEGIN*/
	/*账套*/
	$("#ledger_confirm").text($("#ledger").val());
	/*客户名称*/
	$("#customerFullName_confirm").text($("#customerFullName").val());
	$("#customerFullName_confirm").attr("title",$("#customerFullName").val());
	/*币种*/
	$("#currencyName_confirm").text($("#currencyName").val());
	/*业务员*/
	$("#personName_confirm").text($("#personName").val());
	/* 申请日期 */
	$("#approval_confirm").text(GetTodayDateStr());
    /*发货单号*/
    $("#cdlcode_confirm").text($("#cdlcode").val());
	/*######################头部  END*/
	/*######################详情列表BEGIN*/
	/*详情*/
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		var trString = "<tr><td class=\"first supplier-model\"><div>"+$tr.find("input[tdTag=inventoryCode]").val()+"</div></td>"
			+ "<td class=\"material-number\"><div>"+$tr.find("input[tdTag=customerInventoryCode]").val()+"</div></td>"
			+ "<td class=\"product-desc\"><div>"+$tr.find("input[tdTag=inventoryName]").val()+"</div></td>"
			+ "<td class=\"quantity\"><div>"+fmoney(changeNum($tr.find("input[tdTag=quantity]").val()),0)+"</div></td>"
			+ "<td class=\"price price1\"><div>"+fmoney(changeNum($tr.find("input[tdTag=unitPrice]").val()),6)+"</div></td>"
			+ "<td class=\"last price price2\"><div>"+fmoney(changeNum($tr.find("input[tdTag=sum]").val()),4)+"</div></td></tr>";
		$("#detailListTbody_confirm").append(trString);
	}
	/*合计行*/
	var totalString = "<tr class=\"total\"><td class=\"first supplier-model\"><div></div></td>"
			+ "<td class=\"material-number\"><div></div></td>"
			+ "<td class=\"product-desc\"><div>总计：</div></td>"
			+ "<td class=\"quantity\"><div>"+fmoney($("#totalQuantity").val(),0)+"</div></td>"
			+ "<td class=\"price price0\"><div></div></td>"
			+ "<td class=\"last price price2\"><div>"+fmoney($("#totalSum").val(),4)+"</div></td></tr>";
	$("#detailListTbody_confirm").append(totalString);
	/*######################详情列表END*/
	/*######################备注 BEGIN*/
	$("#remark_confirm").text($("#remark").val());
	/*######################备注 END*/
}


/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").hide();
	$("#write").show();
}

function detailValidata(){
    var trs=$("#detailListTbody").find("tr");
    if(trs.size()>0){
        return true;
    }
    dialog("请填写存在列表详细的发货单号！");
    return false;
}

