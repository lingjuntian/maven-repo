var pass;
$(function () {
	var disanfang = $("#disanfang").val();
	if(disanfang == '1'){//需提供第三方附件
		pass = false;
	}else{   //不需提供
		pass = true;
	}
	
	$("#foundedTime").click(function(){
		WdatePicker();
	});
	
	/* 信息修改 */
	$(".edit-text").click(function(){
		var $id = $(this).attr("href");
		var $obj = $(this).parents(".form-customer-account").find("[sameName='formBox']");
		var $textObj = $(this).parents(".form-customer-account").find(".edit-text");
		var $isHidden = $($id).is(":hidden");
		if($isHidden){
			$obj.slideUp("slow");
			$($id).slideDown("slow");
			$textObj.text("取消修改");
		}else{
			$obj.slideDown("slow");
			$($id).slideUp("slow");
			$textObj.text("修改");
			$("body").find("input").validationEngine('hidePrompt');
		}
		return false;
	});
	
	/*附件下载*/
	$("a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
  		return false;
	});
	

	/* 需要开增值税发票 */
	$(".is-vat-li .input-checkbox").click(function(){
		if($(this).attr("checked")){
			$("#bankInfo").removeClass("none");
		}else{
			$("#bankInfo").addClass("none");
		}
	});
	
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=show]").val($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=id]").val($(this).attr("vid"));
		return false;
	});
	
	/*保存修改(第2,3,4步)*/
	$("button[formId]").click(function(){
		var formId =  $(this).attr("formId");
		var error = $("#"+formId).validationEngine('validate');
		var step = $(this).attr("step");
		if(step=="three"){
			var property = validatorCheckbox("property", 1, "property");
			var type = validatorCheckbox("type", 1, "type");
			error = error && property && type;
		}else if(step=="four"){
			var deliveryPlace = validatorCheckbox("deliveryPlace", 1, "deliveryPlace");
			var deliveryType = validatorCheckbox("deliveryType", 1, "deliveryType");
			var deliveryCompany = validatorCheckbox("deliveryCompany", 1, "deliveryCompany");
			error = error && deliveryPlace && deliveryType && deliveryCompany;
		}
		if(error){
			$(this).hide();
			$("#"+formId).ajaxSubmit(function(returnStr){
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					$("#confirmId").val(id);
	        	    $("#confirmForm").submit();
				}else{
					$(this).show();
					dialog(returnStr,"unsuccess",true,2);
				}
				return false;
			});
		}
	});
	/*保存修改(附件)*/
	$("#attachmentButton").click(function(){
		var fileName =$("#deliveryCompanyFileName").val();
		if(pass == false && fileName == ''){
			//提示需要提供附件
			$("#deliveryCompanyFileName").validationEngine("showPrompt","必须上传", "error", "", true);
			return false;
		}
		$(this).hide();
		$("#confirmForm").submit();
	});
	
	//确认提交
    $("#allSubmit").click(function(){
    	var fileName =$("#deliveryFileName").attr("srcName");
		if(pass == false && fileName == ''){
			//提示需要提供附件
			$("#tishiShow").validationEngine("showPrompt","必须上传", "error", "", true);
			return false;
		}
		
    	//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#allForm").append(inputStr);
    		}
    	});
    	$("#allSubmit").hide();
		$("#allForm").ajaxSubmit(function(returnStr){
			if(returnStr == "nameOrLNo"){
				dialog("客户名称或执照号已经存在","unsuccess",true,1);
			}else{
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					dialog("成功！","success",true,1);
					setTimeout(function(){window.location = "/approval/caApproval_show?infoId="+id;},1000);	  
				}else{
					$("#allSubmit").show();
					dialog(returnStr,"unsuccess",true,2);
				}
			}
	        return false;
		});
    });
});
function fileDownLoad($obj){
	$("#fileNameDownId").val($obj.attr("fileName"));
	$("#srcNameDownId").val($obj.attr("srcName"));
	$("#fileDownloadForm").submit();
}

/*删除文件*/
function deleteFile(infoId,fileTag) {
	var data = {
		"infoId" : infoId,
		"fileTag" : fileTag
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/caApproval_deleteFile"),
		data : data,
		success : function(returnStr) {
			if(returnStr == "error"){
	        	dialog("删除失败","unsuccess",true,1);	    
			}else{
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					dialog("删除成功","success",true,1);
					$("#confirmId").val(id);
	        	    $("#confirmForm").submit();
				}
			}
			return false;
		}
	});
}
$(window).load(function () {
	/*检测流程类型是否存在*/
	var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
	/*检测流程节点是否都有审批人*/
	var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
	if(subCodeNotExisted){
		$("#allSubmit").hide();
		dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,10);
		return false;
	}else if(nodeNoApprovalUser){
		$("#allSubmit").hide();
		dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,10);
		return false;
	}else{
		$("#allSubmit").show();
	}
});