/**
 * crm 客户添加js
 */

$(function(){
	 /*增加验证*/
    $("#contactChName,#position,#contactCus,#role").addClass("validate[required]");
    $("#contactPhone").addClass("validate[required,custom[mobile]]");
    $("#contactEmail").addClass("validate[required,custom[email]]");
    $("#tel").addClass("validate[custom[phoneNumber]]");
    $("#qq").addClass("validate[custom[number]]");

	/**
	 * 点击保存按钮
	 */
    $("#btn-save-contact").click(function(){
    	var isPass=validationInput();
    	if(isPass){
    		$("#btn-save-contact").hide();
    		$("#savecontactForm").attr("action","/crm/contact_save");
    		$("#savecontactForm").ajaxSubmit(function(returnStr) {
    			var type = returnStr.split("_")[0];
    			var id = returnStr.split("_")[1];
    			if (type == "success") {
    				dialog("成功","success",true,1);
    				setTimeout(function(){window.location="/crm/contact_show?contact.id="+id;},1000);	  
    			}else {
    				$("#saveBtn").show();
    				dialog(returnStr,"unsuccess",true,2);
    			}	
    	        return false;
    		});
    	}
    });
    /* 验证输入 */
    function validationInput() {
    	return $("#savecontactForm").validationEngine('validate');
    };
    
    /**
     * 公司自动补全contactCus
     */ 
	 customerAutoComplete($("#contactCus"));
	
	/*客户自动匹配*/
	function customerAutoComplete($input){
		    $input.autocomplete(encodeURI("/crmAjax/customer_findCusTop8"), {
	        //**加自定义表头**//*
	        minChars: 0,
	        width: 430,
	        matchContains: "true",
	        autoFill: false,
	        dataType: 'json',
	        parse: function(data) {  
	            var rows = [];  
	            if(data == null || data.customers == null){
	            	return rows;
	            }
	            for(var i=0; i<data.customers.length; i++){    
	                rows[rows.length] = {    
	                    data:data.customers[i],              
	                    value:data.customers[i].chName,     
	                    result:data.customers[i].chName   
	                };  
	            }  
	            return rows;  
	        }, 
	        formatItem: function(row, i, max) {
	            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"</div>";
	        },
	        formatMatch: function(row, i, max) {
	            return row.chName;
	        }
		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
		    	$(this).val("");
		    	$("#contactCid").val("");
		    	$(this).val(data.chName);
		    	$("#contactCid").val(data.id);
		    }).bind("unmatch", function() {//**没有匹配时**//*
		    	$(this).val("");
		    	$("#contactCid").val("");
		    });
	}
	
	conatctAutoComplete($("#contactChName"));
	/*联系人自动匹配*/
 	function conatctAutoComplete($input){
 		     //  var cid=$("proCustomerId").val();
 		    $input.autocomplete(encodeURI("/crmAjax/contact_findContactByName"), {
 	        //**加自定义表头**//*
 		    tableHead: "<div> <span class='col-3' style='width:300px'>为您找到如下联系人信息,点击直接添加为我的联系人</div>",
 	        minChars: 2,
 	        width: 330,
 	       //  extraParams:{cid:$("proCustomerId").val()}, 
 	        matchContains: "true",
 	        autoFill: false,
 	        dataType: 'json',
 	        parse: function(data) {  
 	            var rows = [];  
 	            if(data == null || data.contacts == null){
 	            	return rows;
 	            }
 	            for(var i=0; i<data.contacts.length; i++){    
 	                rows[rows.length] = {    
 	                    data:data.contacts[i],              
 	                    value:data.contacts[i].chName,     
 	                    result:data.contacts[i].chName   
 	                };  
 	            }  
 	            return rows;  
 	        }, 
 	        formatItem: function(row, i, max) {
 	            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"--"+row.phone+"--"+row.customerName+"</div>";
 	        },
 	        formatMatch: function(row, i, max) {
 	            return row.chName;
 	        }
 		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
 		    	dialog("您确定要添加"+"\""+data.chName+"\"为您的联系人吗？",null,true,null,function(){
		    		$.ajax({
		    			url:"/crm/contact_addAccess",
		    			method:'GET',
		    			data:{conid:data.id},
		    			success:function(returnStr){
		        			var type = returnStr.split("_")[0];
		        			var id = returnStr.split("_")[1];
		        			if (type == "success") {
		        				dialog("成功","success",true,1);
		        				var str="/crm/contact_show?contact.id="+id;
		        				setTimeout(function(){window.location = str;},1000);	  
		        			}else {
		        				dialog(returnStr,"unsuccess",true,2);
		        			}	
		        	        return false;
		    			}
		    		});
		    	});
 		    }).bind("unmatch", function() {//**没有匹配时**//*
 		    	
 		    });
 	}
	
	
});