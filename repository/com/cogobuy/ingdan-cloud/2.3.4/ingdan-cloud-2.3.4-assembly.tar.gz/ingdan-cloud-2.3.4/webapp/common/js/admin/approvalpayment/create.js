$(function () {	
	//绑定下拉事件
	bindselect();
	bindBankList();
	/*产品线 多选的请情况下，点击清空时间*/
	$("#pLinesUl .input-checkbox").live("click",function(){
		clearTime();
	});
	
	/*入库单全选*/
	$("#selectPurchaseAll").click(function(){
		if($(this).attr("checked")){
			$("#purchaseUL").find("input").attr("checked",true);
		}else{
			$("#purchaseUL").find("input").attr("checked",false);
		}
		calculateSum();
		var purchaseNum = $("#purchaseUL").find("input[checked=true]").size();
		if(purchaseNum>0){
			$("#numSpan").text("共选择"+purchaseNum+"个");
		}else{
			$("#numSpan").text("请选择");
		}
		
	});
	
	/*绑定查询事件*/
	$("#datetime1").click(function(){
		WdatePicker({onpicked:function(){recordCodes();},maxDate:getMinValue($('#datetime2').val(), GetTodayDateStr())});
	});
	
	$("#datetime2").click(function(){
		WdatePicker({onpicked:function(){recordCodes();},minDate:$('#datetime1').val(), maxDate:GetTodayDateStr()});
	});
	
	$("#dateForecast").click(function(){
		WdatePicker();
	});
	
	/*付款单信息*/
	$("#inventoryClass").addClass("validate[required]");
	$("#vendorName").addClass("validate[required]");
	$("#bankAccount").addClass("validate[required]");
	$("#bankName").addClass("validate[required]");
	$("#sumprice").addClass("validate[required,custom[amount]]");
	/*银行信息增加*/
	$("#vendorBank_unit").addClass("validate[required]");
	$("#vendorBank_bank").addClass("validate[required]");
	$("#vendorBank_account").addClass("validate[required]");
	
	$("#vendorBankName").addClass("validate[required]");
	
	$("#payCompanyName").addClass("validate[required]");
	$("#payCompanyId").addClass("validate[required]");
	
	$("#dateForecast").addClass("validate[required]");
	//inventory auto complete
	inventoryClass();

    /*取消*/
	$("#passButton").click(function () {
		for (var i = 0; i < $("form input.input-text").length; i++) {
			$("form input.input-text:eq(" + i + ")").validationEngine("hidePrompt");
			$("#vendorBank_unit").val("");
	      	$("#vendorBank_bank").val("");
	      	$("#vendorBank_account").val("");
		}
	});
    $(".close").click(function () {
        for (var i = 0; i < $("form input.input-text").length; i++) {
            $("form input.input-text:eq(" + i + ")").validationEngine("hidePrompt");
            $("#vendorBank_unit").val("");
	      	$("#vendorBank_bank").val("");
	      	$("#vendorBank_account").val("");
        }
    });
    
    $("#addVendorBank").click(function(){
    	var error = $("#addVendorBankForm").validationEngine('validate');
    	var unit = $("#vendorBank_unit").val();
    	var bank = $("#vendorBank_bank").val();
    	var account = $("#vendorBank_account").val();
    	if(error){
    		$("#addVendorBankForm").ajaxSubmit(function(returnStr){
    			var type = returnStr.split("_")[0];
				if (type == "success") {
		          $("#pselect").text(bank+"："+account);
		          $("#bankAccount").val(account);
		          $("#vendorBankName").val(unit);
		          $("#bankName").val(bank);
		          var listr = "<li><a href=\"#\" bankAccount=\""+account+"\" vendorBankName=\""+unit+"\" bankName=\""+bank+"\">" + bank+"："+account+"</a></li>";
		          $("#optionsList").append(listr);
		          bindBankList();//绑定填充账号操作
		          $(".close").trigger("click");
		          $("#vendorBank_unit").val("");
		      	  $("#vendorBank_bank").val("");
		      	  $("#vendorBank_account").val("");
		          return;
		        }else{
		        	dialog(returnStr,"error",true,1);
		        }
		  });
    	}
    });
    /**
     * 确认
     */
    $("#confirmButton").click(function(){
    	var error1 = $("#createForm").validationEngine('validate');
    /*	var error2 = true;
    	
    	var purchaseNum = $("#purchaseUL").find("input[checked=true]").size();
    	if(purchaseNum<1){
    		error2 = false;
    		$("#numSpan").validationEngine('showPrompt', '至少选择一个入库单', 'error', "", true);
    	}*/
    	if(error1){
    		$("#confirmDepartment").text($("#bussinessUnit").val()+"——" + $("#department").val());
    		$("#confirmLedger").text($("#ledger").val());
    		$("#confirmPayCompany").text($("#payCompanyName").val());
    		var needBankBill = $('input[type=radio][name=payment.needBankBill][checked]').val();
    		var billText = "需要";
    		if(needBankBill=="0"){
    			billText = "不"+billText;
    		}
    		var currency = $('input[type=radio][name=payment.currency][checked]').val();
    		$("span[id^=curFlag]").text(getCurrencyFlag(currency));
    		$("#confirmNeedBankBill").text(billText);
    		var type = $('input[type=radio][name=payment.type][checked]').val();
    		$("input[type=radio][name=confirmType][value="+type+"]").attr("checked",true); //付款单类型
    		$("#confirmVendorBankName").text($("#vendorBankName").val());//收款单位
    		$("#confirmBankName").text($("#bankName").val());//开户行
    		$("#confirmBankAccount").text($("#bankAccount").val());//银行账号
    		var paymentType = $('input[type=radio][name=payment.paymentType][checked]').val();
    		$("input[type=checkbox][name=confirmPaymentType]").attr("checked",false);
    		$("input[type=checkbox][name=confirmPaymentType][value="+paymentType+"]").attr("checked",true);//付款方式
    		$("#confirmProductName").text($("#productName").val());//品种
    		$("#confirmQuantity").text($("#quantity").val());//数量
    		$("#confirmUnitprice").text($("#unitprice").val());//单价
    		$("#confirmSumprice").text($("#sumprice").val());//金额
    		$("#dateForecastCon").val($("#dateForecast").val()); //预计付款时间
    		lowToUpper($("#sumprice").val());
    		$("#confirmNotes").text($("#notes").val());//备注
    		$("#confirmNotes").append("<p>付款公司："+$("#payCompanyName").val()+"</p>"); 
    		
    		$("#createDiv").hide();
    		$("#flowUl").show();
    		copyFileList();//copy attachment list
    		loadPaymentMail($("#approvalType").val(),$("#parent").val());
    		if($("#supplyChainFinance:checked").length > 0){
    			$("#scf_Confirm").show();
    		}else{
    			$("#scf_Confirm").hide();
    		}
    		$("#confirmDiv").show();
    		$("#goTopButton").trigger("click");
    	}
    });
    /**
     * 返回
     */
    $("#backButton").click(function(){
    	$("#flowUl").hide();
    	$("#confirmDiv").hide();
    	$("#createDiv").show();
    });
    
//    var isSubmit = false;
    
    /**
     * 提交付款单
     */
    $("#createButton").click(function(){
//    	if (isSubmit) {
//    		return;
//    	}
//    	isSubmit = true;
    	//把隐藏的名字去掉，以防提交 
    	$("#purchaseCopy").find("input").attr("name",""); 
    	//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#createForm").append(inputStr);
    		}
    	});
    	  
		$("#createForm").ajaxSubmit(function(returnStr){
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功！","success",true,1);
				setTimeout(function(){window.location = "/payment/payment_show?id="+id;},1000);
				return;
			}else{
				dialog(returnStr,"unsuccess",true,1);
				return;
			}
		});
    });
    
    currencyClick();
});

/*
 * 填充供应商对应账号
 */
function paddingAccount(vendorid, isClick){
	$.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findVendorBack?vendorid="+vendorid),
        dataType:"json",
        success:function(data, textStatus){
        	if(isClick){
    			clearAccount();
    		}
            if(data != null){
            	if(data.payee != null){
            		$("#vendorBankName").val(data.payee);
            		unEditPayee();
            	}else{
            		editPayee();
            	}
            	if(data.bankList != null && data.bankList.length >0){//填充账号
            		$.each(data.bankList,function(n,value) {
            			var index = n+1;
            			 var listr = "<li class='clearfix'><label for='vb"+index+"'><input type='radio' bank='"+value.bank+"' account='"+value.account+"' id='vb"+index+"' value='' /><span class='abank'>"
            			 			+value.bank+"</span><span class='account'>"+value.account+"</span> </label></li>";
            	           $("#optionsList").append(listr);
            	     });
            		$("#accountDiv").show();
            		bindBankList();//绑定填充账号操作
            	}else{
            		$("#accountDiv").hide();
            	}
            }
        }
    });
}

function addAccount(){
	var vendorId = $("#vendorId").val()+"";
	if(""==vendorId||"undefined"==vendorId){
		dialog("请选择供应商！","unsuccess",true,2);
		return ;
	}
	var bank = $("#bankName_add").val();
	if(""==bank||"undefined"==bank){
		dialog("请输入开户行！","unsuccess",true,2);
		return ;
	}
	var account = $("#bankAccount_add").val()+"";
	if(""==account||"undefined"==account){
		dialog("请输入账号！","unsuccess",true,2);
		return ;
	}
	$.ajax({
        type:"GET",
        url:encodeURI("/payment/payment_addBank"),
        dataType:"json",
        data:{"vendorBank.vendorId":vendorId,"vendorBank.bank":bank,"vendorBank.account":account},
        success:function(returnStr){
        	if(returnStr == "0"){
        		var n = $("#optionsList li").length+1;
        		var listr = "<li class='clearfix'><label for='vb'"+n+"><input type='radio' bank='"+bank+"' account='"+account+"' id='vb"+n+"' value='' /><span class='abank'>"
        		+bank+"</span><span class='account'>"+account+"</span> </label></li>";
        		$("#optionsList").append(listr);
        		$("#accountDiv").show();
        		bindBankList();//绑定填充账号操作
        	}else{
        		dialog(returnStr,"unsuccess",true,2);
        	}
        }
    });
}

function unEditPayee(){
	$("#payee_edit").show();
	$("#payee_cancel").hide();
	$("#vendorBankName").attr("readonly","readonly");
	$("#vendorBankName").addClass("disabled");
}
function editPayee(){
	$("#payee_edit").hide();
	$("#payee_cancel").show();
	$("#vendorBankName").attr("readonly",false);
	$("#vendorBankName").removeClass("disabled");
	$("#vendorBankName").select();
	$("#addPayee").val("add");
}
/**
 * 绑定填充账号操作
 */
function bindBankList(){
	$("input[id^=vb]").unbind("click");
	$("input[id^=vb]").bind("click",function(){
		$("input[id^=vb]").attr("checked",false);
		$("#bankAccount").val($(this).attr("account"));
		$("#bankName").val($(this).attr("bank"));
		$(this).attr("checked",true);
		return ;
	});
}

function currencyClick(){
	$("input[name='payment.currency']").bind("click",function(){
		$("input[name='payment.currency']").attr("checked",false);
		$("input[name='payment.currencyId']").val($(this).attr("curId"));
		$(this).attr("checked",true);
		return;
	});
}

/*
 *清楚已经填充的供应商账号 
 */
function clearAccount(){
	$("#optionsList").empty();
}
/*
 * 清空开始时间
 * */
function clearTime(){
	$('#datetime1').val("");
	$('#datetime2').val("");
	clearPayRecord();
}

/*
 * 清空入库单列表
 * */
function clearPayRecord(){
	$("#numSpan").text("");
	$("#purchaseUL").empty();
}

function lowToUpper(num){
	if(!/^\d*(\.\d*)?$/.test(num)){
		
	}else{
		var UPPER = new Array("零","壹","贰","叁","肆","伍","陆","柒","捌","玖");
		var num_array = ("" + num).split(".");
		var defStr="零";
		/*小数位*/
		if(num_array[1] != null && num_array[1].length > 0){
			if(num_array[1].length < 2){
				$("#jiao").text(UPPER[num_array[1].charAt(0)]);
				$("#fen").text(defStr);
			}else{
				$("#jiao").text(UPPER[num_array[1].charAt(0)]);
				$("#fen").text(UPPER[num_array[1].charAt(1)]);
			}
		}else{
			$("#jiao").text(defStr);
			$("#fen").text(defStr);
		}
		/*整数位*/
		if(num_array[0] != null && num_array[0].length > 0){
			var intstr = "";
			if(num_array[0].length < 8){
				var temp = "";
				for(var i=0; i < 8 - num_array[0].length; i++){
					temp = temp + "0";
				}
				intstr = temp + num_array[0];
			}else{
				intstr = num_array[0].substring(num_array[0].length - 8);
			}
			$("#qianwan").text(UPPER[intstr.charAt(0)]);
			$("#baiwan").text(UPPER[intstr.charAt(1)]);
			$("#shiwan").text(UPPER[intstr.charAt(2)]);
			$("#wan").text(UPPER[intstr.charAt(3)]);
			$("#qian").text(UPPER[intstr.charAt(4)]);
			$("#bai").text(UPPER[intstr.charAt(5)]);
			$("#shi").text(UPPER[intstr.charAt(6)]);
			$("#ge").text(UPPER[intstr.charAt(7)]);
		}else{
			$("#qianwan").text(defStr);
			$("#baiwan").text(defStr);
			$("#shiwan").text(defStr);
			$("#wan").text(defStr);
			$("#qian").text(defStr);
			$("#bai").text(defStr);
			$("#shi").text(defStr);
			$("#ge").text(defStr);
		}
		
	}
}

function inventoryClass(){
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findInventoryClassList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.list != null){
				$("#inventoryClass").autocomplete(data.list, {
					/**加自定义表头**/
					tableHead: "<div><span >产品线</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span >" + row.name + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.name;
					},
					formatResult: function(row) {
						return row.name;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#inventoryClassId").val(data.id);
				}).bind("unmatch",function(){
					$("#inventoryClassId").val("");
				});
			}
		}
	}); 
}


function getCurrencyFlag(currencyName){
	var flag = "";
	if(null == currencyName || "" == currencyName || "undefined" == currencyName){
		flag = "¥";
	}else{
		if(currencyName == "人民币"){
			flag = "¥";
		}else if(currencyName == "美元"){
			flag = "$";
		}else if(currencyName == "港元"||currencyName == "港币"){
			flag = "HK$";
		}else if(currencyName == "欧元"){
			flag = "€";
		}else if(currencyName == "日元"){
			flag = "¥";
		}else if(currencyName == "澳元"){
			flag = "AU$";
		}else{
			flag = "¥";
		}
	}
	return flag;
}
/*查询入库单号*/
function recordCodes(){ 
	var startDate = $.trim($("#datetime1").val()).substr(0,10);
	var endDate =  $.trim($("#datetime2").val()).substr(0,10);
	var ledger = $.trim($("#ledger").val());
	var vendorCode = $.trim($("#vendorCode").val());
	if(startDate==''||endDate==''||ledger==''||vendorCode==''){
		return false;
	}
	//查询样式改变
	$("#waitDisable").addClass("disabled");
	$("#numSpan").text("正在加载...");
	$("#waitSpan").show();
	
	var buId = $("#buId").val();		//判断产品线是多选还是单选
	if(buId != 1 && buId != 8){  //产品线单选
		var inventoryClass = $.trim($("#inventoryClass").val()); 
		inventoryClass = changeAtmel(inventoryClass);
		findRecordCodeList(startDate,endDate,ledger,vendorCode,"'"+inventoryClass+"'");
	}else{ //产品线多选
		var inventoryClassStr = "";
		var num= $("#productLineForSelect").find("input[checked=true]").size();
		for(var i=0;i<num;i++){
			var pl = $("#productLineForSelect").find("input[checked=true]").eq(i);
			pl = changeAtmel(pl);
			if(i==num-1){
				inventoryClassStr = inventoryClassStr + "'"+pl.attr("plName")+"'" ;
			}else{
				inventoryClassStr = inventoryClassStr +"'"+ pl.attr("plName")+"'," ;
			}
		}
		findRecordCodeList(startDate,endDate,ledger,vendorCode,inventoryClassStr);
	}  
}
//Atmel需要特殊处理
function changeAtmel(inventoryClass){
	if(inventoryClass == 'Atmel（NC）' ||inventoryClass == 'Atmel（SC）'){
		inventoryClass ='Atmel';
	}
	return inventoryClass;
}
/*
 * 查询入库单*/
function findRecordCodeList(startDate,endDate,ledger,vendorCode,inventoryClass){
	if(startDate != null && endDate != null && ledger != null && vendorCode!= null && inventoryClass !=null){
		$.ajax({
	        type:"GET",
	        url:encodeURI("/adminajax/findRecordCodeList?ledger="+ledger+"&startDate="+startDate+"&endDate="+endDate+"&vendorCode="+vendorCode+"&inventoryClass="+inventoryClass),
	        dataType:"json",
	        success:function(data, textStatus){
	            if(data != null){
	            	//清空入库单
	            	$("#purchaseUL").empty();
	            	$("#purchasePrice").val("");
	            	$("#selectPurchaseAll").attr("checked",false);
	            	var recordCodeList = data.recordCodeList;
	            	for(var i=0;i<recordCodeList.length;i++){
	            		var recordCode = recordCodeList[i];
		            	$copyLi = $("#purchaseCopy").clone(true);
		            	$copyLi.attr("id","");
		            	$copyLi.find("input").attr("data-amount",recordCode.sum).val(recordCode.recordCode);
		            	$copyLi.find("span").attr("title",recordCode.recordCode).text(recordCode.recordCode);
		            	$copyLi.find("input").bind("click",function(){
		            		checkboxBind();
		            	});
		            	$copyLi.show();
		            	$("#purchaseUL").append($copyLi);
	            	}
	            	//查询样式改变
	            	$("#waitDisable").removeClass("disabled");
	            	if(recordCodeList.length>0){
	            		$("#numSpan").text("请选择");
	            	}else{
	            		$("#numSpan").text("没有相关入库单");
	            	}
	            	$("#waitSpan").hide();
	            }
	        }
	    });
	} 
}
/*给入库单的 checkbox绑定click事件:决定全选是否勾上，计算和；"共选择XX个"样式那边控制*/
function checkboxBind(){
	var isAll = true ;
	$(".purchase-receipt-select .options-item input:checkbox").each(function(index, element) {
		if(!$(this).attr("checked")){
			isAll = false;
		}
		$("#selectPurchaseAll").attr("checked",isAll);
	});
	calculateSum();
}
/*计算入库单总金额*/
function calculateSum(){  
	var $amount = 0;
	$("#purchaseUL").find("input[checked=true]").each(function(index, element) {
		var num =Number($(this).attr("data-amount")); //偶尔会有负数
		$amount =add($amount,num);
	}); 
	$("#purchasePrice").val(changeTwoDecimal($amount));
}

function loadPaymentMail(approvalType,parent){
	var url = "/approval/pmtAppr_emailList?approvalType="+ approvalType + "&parent="+parent;
	var buId = $("#buId").val()+"";
	var ledger = $("#ledger").val()+"";
	var productLineId = $("#inventoryClassId").val()+"";
	var accountType = $('input[name="payment.accountType"]:checked').val();
	var salesId = $("#personId").val()+"";
	if(buId!="undefined"){
		url+="&buId="+buId;
	}
	if(ledger!="undefined"){
		url+="&ledger="+ledger;
	}
	if(productLineId!="undefined"){
		url+="&pls="+productLineId;
	}
	$("input[name='pLines']").each(function(){
		if($(this).attr("checked")){
			var pl = $(this).val().split(":")[0];
			url+="&pls="+pl;
		}
	});
	
	if(accountType != "undefined"){
		url +="&accountType="+accountType;
	}
	
	if(salesId != "undefined"){
		url+="&salesId="+salesId;
	}
	if($("#supplyChainFinance:checked").length > 0){
		url = url + "&supplyChainFinance="+$("#supplyChainFinance").val();
	}
	
	$("#mailList").load(encodeURI(url), function(){
		
	});
}
