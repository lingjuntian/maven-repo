var autoCompleteUserList;
$(function() {
	/*问题处理人员自动匹配*/
	userAutoComplete();
	
	/*添加协作人*/
	$("input[tdTag=name][addlinetag=salesteam]").click(function(){
		var $p = $(this).parents("p");
		if($p.nextAll().length==0){
			$copyp = $("#salesTeamHide").clone(true);
			$copyp.removeAttr("id");
			$copyp.removeAttr("style");
			$p.after($copyp);
			addUserAutoComplete($copyp.find("input[tdTag=name]"));
		}
	});
	/*删除协作人*/
	$(".icon-del[deltag=salesteam]").click(function(){
		var $obj = $(this).parents("p");
		var $length = $("#salesTeam").find("p").length;
		if($length<2){
			promptMessage($("#salesTeamPromptMessage"),"请最少保留1行",2);
			return false;
		}
		delObj($obj);
	});
	
	/*添加可推广型号*/
	$("input[tdTag=code][addlinetag=detaillist]").click(function(){
		var $section = $(this).parents("section");
		if($section.nextAll().length==0){
			$copysection = $("#detailListHide").clone(true);
			$copysection.removeAttr("id");
			$copysection.removeAttr("style");
			$section.after($copysection);
		}
	});
	
	
	
	/*删除可推广型号*/
	$(".icon-del[deltag=detaillist]").click(function(){
		var $obj = $(this).parents("section");
		var $length = $("#detailList").find("section").length;
		if($length<2){
			promptMessage($("#detailListPromptMessage"),"请最少保留1行",2);
			return false;
		}
		delObj($obj);
	});
});


/**
 * 设置问题处理人员自动匹配
 */
function userAutoComplete(){
	$.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findAllUser"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.userList != null){
            	autoCompleteUserList = data.userList;
            	addUserAutoComplete($("#salesTeam").find("input[initializeAuto=true]"));
            	addpm();
            }
        }
    });
}


/**
 * 问题处理人员自动匹配
 * @param container
 */
function addUserAutoComplete($input){
    if(autoCompleteUserList != null){
    	$input.autocomplete(autoCompleteUserList, {
            /**加自定义表头**/
            tableHead: "<div> <span class='col-3'>英文名</span><span class='col-4'>邮箱</span></div>",
            minChars: 0,
            width: 350,
            matchContains: "true",
            autoFill: false,
            formatItem: function(row, i, max) {
                return "<div style='height: 40px;font-size: 15px;'>"+row.enName+"<br/>"+row.userMail+"</div>";
            },
            formatMatch: function(row, i, max) {
                return row.enName;
            },
            formatResult: function(row) {
                return row.enName;
            }
        }).result(function(e,data,value,sec){/**加选中后的回调函数**/
        	$(this).parents("p").find("[tdTag=name]").val("");
        	$(this).parents("p").find("[tdTag=userMail]").val("");
        	$(this).parents("p").find("[tdTag=id]").val("");
        	$(this).parents("p").find("[tdTag=name]").val(data.enName);
    		$(this).parents("p").find("[tdTag=userMail]").val(data.userMail);
    		$(this).parents("p").find("[tdTag=id]").val(data.id);
        }).bind("unmatch", function() {/**没有匹配时**/
        	$(this).parents("p").find("[tdTag=name]").val("");
        	$(this).parents("p").find("[tdTag=userMail]").val("");
        	$(this).parents("p").find("[tdTag=id]").val("");
        });
    }
}

/* 删除对象 */
function delObj($obj){
	$obj.remove();
}

/* 整理表格，去空行 */
function cleanSalesTeam() {
	var $pNum = $("#salesTeam").find("p").size();
	for ( var i = $pNum-1; i >= 0; i--) {
		var $p = $("#salesTeam").find("p").eq(i);
		if ($.trim($p.find("input[tdTag=name]").val()) == "") {
			$p.remove();
		}
	}
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForSalesTeam() {
	var $firstName = "salesTeam";
	var $ps = $("#salesTeam").find("p");/* 获取所有p */
	for ( var i = 0; i < $ps.size(); i++) {
		var numtag = "[" + i + "]";
		var $p = $ps.eq(i);
		var $inputNum = $p.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $p.find("input").eq(j);
			$input.attr("id", $firstName + $input.attr("tdTag") + numtag);
			$input.attr("name", $firstName + numtag + "." + $input.attr("tdTag"));
		}
	}
}

/* 整理表格，去空行 */
function cleanDetail() {
	var $sectionNum = $("#detailList").find("section").size();
	for ( var i = $sectionNum-1; i >= 0; i--) {
		var $section = $("#detailList").find("section").eq(i);
		if ($.trim($section.find("input[tdTag=code]").val()) == ""
			&&$.trim($section.find("input[tdTag=productLine]").val()) == ""
				&&$.trim($section.find("input[tdTag=quantity]").val()) == "") {
			$section.remove();
		}
	}
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForDetail() {
	var $firstName = "detailList";
	var $sections = $("#detailList").find("section");/* 获取所有section */
	for ( var i = 0; i < $sections.size(); i++) {
		var numtag = "[" + i + "]";
		var $section = $sections.eq(i);
		var $inputNum = $section.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $section.find("input").eq(j);
			$input.attr("id", $firstName + $input.attr("tdTag") + numtag);
			$input.attr("name", $firstName + numtag + "." + $input.attr("tdTag"));
		}
	}
}

/**
 * 添加pm
 * @param container
 */
function addpm(){
    if(autoCompleteUserList != null){
        $("#pminput").autocomplete(autoCompleteUserList, {
            /**加自定义表头**/
        	tableHead: "<div> <span class='col-3'>英文名</span><span class='col-4'>邮箱</span></div>",
            minChars: 0,
            width: 350,
            matchContains: "true",
            autoFill: false,
            formatItem: function(row, i, max) {
                return "<div style='height: 40px;font-size: 15px;'>"+row.enName+"<br/>"+row.userMail+"</div>";
            },
            formatMatch: function(row, i, max) {
                return row.enName;
            },
            formatResult: function(row) {
                return row.enName;
            }
        }).result(function(e,data,value,sec){/**加选中后的回调函数**/
        	var listr = "<label><input type=\"checkbox\" name=\"pmList\" checked=\"checked\" value=\""+data.userMail+"\" /> "+data.enName+"</label>";
		 	$("#pmlist").append(listr);
		 	$("#pminput").val("");
        }).bind("unmatch", function() {/**没有匹配时**/
        });
    }
}