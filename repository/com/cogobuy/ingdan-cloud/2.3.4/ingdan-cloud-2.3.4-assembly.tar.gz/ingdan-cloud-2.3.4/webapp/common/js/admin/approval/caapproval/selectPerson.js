$(function () {
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/custAApproval_findAllErpPerson"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.erpperson != null){
            	$("#person_show").autocomplete(data.erpperson, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-1'>姓名</span><span class='col-2'>邮箱</span></div>",
                    minChars: 0,
                    width:350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-1'>"+row.ADUserName+"</span><span class='col-2'>"+row.ADUserEmail+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.ADUserName +" "+ row.ADUserEmail;
                    },
                    formatResult: function(row) {
                        return row.ADUserName;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                	$("#person_show").val(data.ADUserName);
                	$("#person_id").val(data.ADUserEmail);
                }).bind("unmatch", function() {/**没有匹配时**/
                	$("#person_show").val("");
                	$("#person_id").val("");
                });
            }
        }
    });
});