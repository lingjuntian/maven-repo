var communicationCode = $("#communicationCode").val(); //通讯费Code
var entertainCode = $("#entertainCode").val(); //招待费Code
var trafficCode = $("#trafficCode").val(); //交通费Code

$(function(){	
	/*给表绑定计算*/
	$("#trafficTable").find("tr[sjc=sjc] input").bind("blur",function(){ //私家车 自动计算
		var kilometer = changeNum($(this).parents("tr").find("input[name*=kilometer]").val());
		var subsidy = changeNum($(this).parents("tr").find("input[name*=subsidy]").val());
		var subSum = multiply(kilometer,subsidy);
		var bridgeFees = changeNum($(this).parents("tr").find("input[name*=bridgeFees]").val());
		var parkingFees = changeNum($(this).parents("tr").find("input[name*=parkingFees]").val());
		var sum = add(add(bridgeFees,parkingFees),subSum);
		$(this).parents("tr").find("input[name*=sum]").val(sum);
	});
	
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		var $id = $(this).attr("vid");
		var $show = $(this).attr("vshow");
		var $rate = $(this).attr("vrate");
		$(this).parents(".options-select").find("input[tag=id]").val($id);
		$(this).parents(".options-select").find("input[tag=show]").val($show);
		$(this).parents(".options-select").find("input[tag=rate]").val($rate);
		var $selecttag = $(this).attr("selecttag");
		$("li ["+$selecttag+"]").hide();
		$("li ["+$selecttag+"="+$id+"]").show();
		$(this).validationEngine('hidePrompt');
		return false;
	});
	
	$(".transport-select .options a").click(function(){
		$(this).parents("tr").find("input").unbind("blur");//解除绑定
		if($.trim($(this).attr("vsub"))==""){//出私家车以外
			if($(this).parents("tr").find(".amount").find("input").attr("readonly")== false){//由私家车改来
				$(this).parents("tr").find(".amount").find("input").val("");
			}
			$(this).parents("tr").find(".amount").find("input").attr("readonly",true).addClass("disabled");
			$(this).parents("tr").find(".subtotal").find("input").attr("readonly",false).removeClass("disabled");

		}else{ //私家车
			$(this).parents("tr").find(".amount").find("input").attr("readonly",false).removeClass("disabled");
			$(this).parents("tr").find(".subtotal").find("input").attr("readonly",true).addClass("disabled");
			$(this).parents("tr").find(".subsidy").find("input").attr("readonly",true).addClass("disabled").val($(this).attr("vsub"));
			//添加验证
			$(this).parents("tr").find("input[id*=kilometer]").addClass("validate[custom[positiveNumber]]");
			$(this).parents("tr").find("input[id*=bridgeFees]").addClass("validate[custom[positiveNumber]]");
		    $(this).parents("tr").find("input[id*=parkingFees]").addClass("validate[custom[positiveNumber]]");
		    
			$(this).parents("tr").find("input").bind("blur",function(){ //私家车 自动计算
				var kilometer = changeNum($(this).parents("tr").find("input[name*=kilometer]").val());
				var subsidy = changeNum($(this).parents("tr").find("input[name*=subsidy]").val());
				var subSum = multiply(kilometer,subsidy);
				var bridgeFees = changeNum($(this).parents("tr").find("input[name*=bridgeFees]").val());
				var parkingFees = changeNum($(this).parents("tr").find("input[name*=parkingFees]").val());
				var sum = add(add(bridgeFees,parkingFees),subSum);
				$(this).parents("tr").find("input[name*=sum]").val(sum);
			});
		}
	});

	//初始化时模拟点击BU，使其出现对应的Dep列表
	var buId = $("#buId").val();
	$("#buList").find("a[vid="+buId+"]").trigger("click");
	var costBuId = $("#costBuId").val();
	$("#costBuList").find("a[vid="+costBuId+"]").trigger("click");
	
	/* 日期控件*/
	$("[tag=date]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');},maxDate: GetTodayDateStr()});
	});
    
	 //上一步
    $("#upStep").click(function(){
    	//清空下一步列表
    	$("#costBody").find("tr[deleteFlag=yes]").remove();
    	$("#trafficBody").find("tr[deleteFlag=yes]").remove();
    	$("#ticketTable").empty();
    	//隐藏的Collect表单清空
    	$("#collectDiv").empty(); 
    	//清除住宿限制和提示
    	$("#prompt").text("");
		
		$("#trafficShow").hide();
		$("#twoStep").hide();
		$("#oneStep").show();
    });
    
    
    //下一步
    $("#nextStep").click(function(){
    	cleanPage();
    	validateFunction();
    	var error1 = $("#historyForm").validationEngine('validate'); 	
		if(error1){
			count();
			var totalSum = multiply($("#totalSum").val(),$("#rate").val());//原币种*汇率，折算成人民币
			$("#creditForm").ajaxSubmit(function(returnStr){//取回可用额度
				if(returnStr == "error"){
					dialog("用户的费用额度设置有误，请联系管理员","unsuccess",true,1);
				}else{
					var type = returnStr.split("_")[0];
					var credit = returnStr.split("_")[1];
					if (type == "success") {
						var overtake = FloatSub(totalSum,credit);
						if(overtake <= 0){
							copyStyle();//复制表格 取回邮件列表
							$("#oneStep").hide();
							$("#twoStep").show();
							copyFileList();  
							return false;
						}else{
							/* 超额提示 */
							$("#prompt").text("您本月申请的报销费用超额"+overtake+"元，无法提交！您可以：");
							pagePopup(".popup-cost-approval-new",true);
							return false;
						}
					}
				}
			});
		}
		return false;
    });
    
  //备份草稿
    $("#backup").click(function(){
    	cleanPage();
    	//去掉复制用的tr
    	$("#historyForm").find("tr[hide=hide]").remove();
    	$("#historyForm").attr("action","/approval/costSave_create");
    	$("#backupId").attr("name","costApproval.backupId");
    	$("#historyForm").ajaxSubmit(function(returnStr){
			if(returnStr == "error"){
				dialog("数据库异常，请联系管理员或稍后再试","unsuccess",true,1);
			}else{
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					$("#backupId").val(id);
					dialog("草稿保存成功","success",true,1);
					$("#goTopButton").click();
				}
			}
			//补回隐藏的复制用的tr
			$detailTr = $("#copyForDetail").clone(true);
			$detailTr.attr("id","");
			$detailThead = $("#theadForDetail");
			$detailThead.append($detailTr);
			
			$trafficTr = $("#copyForTraffic").clone(true);
			$trafficTr.attr("id","");
			$trafficThead = $("#theadForTraffic");
			$trafficThead.append($trafficTr);
			
			//action地址改回
			$("#historyForm").attr("action","/approval/createCost_create");
	        return false;
		});
    	return false;
    });
    
});

function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}

function cleanPage(){
	//取消所有验证（其实是针对表格中填了数据又去掉的情况）
	$("#historyForm").validationEngine("hideAll");

	//整理2个表格,去空行
	cleanTbody($("#costTable"));
	cleanTbody($("#trafficTable"));
	//改名
	changeName();
}

/*计算和*/
function count(){
	//隐藏的Collect表单清空
	$("#collectDiv").empty(); 
	
	/*交通费以外的其他明细 （计算每月 各类和 ，额度）*/
	var rowNum =$("#costTable").children("tr").size();
	var collectNum = 0; // collect计数
	var totalSum1 = 0;  //
	for(var i = 0;i < rowNum; i++){
		$tr = $("#costTable").children("tr").eq(i);
    	var code = $tr.find("[name*=dailyCostCode]").val();
    	var name = $tr.find("[name*=dailyCostName]").val();
    	var sum = $tr.find("[name*=sum]").val();
    	if(sum != null && sum !=''){
	    	//计算和
	    	var has = $("#collectDiv").find("div[collectTag="+code+"]").size();
	    	if(has>0){//有，则修改和
	    		$div = $("#collectDiv").find("div[collectTag="+code+"]").eq(0);
	    		var oldSum = $div.find("[name*=sum]").val();
	    		$div.find("[name*=sum]").val(add(oldSum,sum));
	    	}else{//没有，则插入
	    		$copyDiv = $("#collectCopy").clone(true);
	    		$copyDiv.attr("id","");
	    		$copyDiv.attr("collectTag",code);
	    		$copyDiv.find("[name*=dailyCostCode]").val(code);
	    		$copyDiv.find("[name*=dailyCostName]").val(name);
	    		$copyDiv.find("[name*=sum]").val(sum);
	    		//Collect改名
	    		var inputNum = $copyDiv.find("input").size();
				for(var v = 0; v < inputNum; v++){
		    		var $input = $copyDiv.find("input").eq(v);
					var name = $input.attr("name");
					var before= $.trim(name.split(".")[0]);
						var obefore =  $.trim(before.split("[")[0]); //避免重复添加[下标]
					var after= $.trim(name.split(".")[1]);
					var all = obefore+"["+collectNum+"]"+"."+after;
					$input.attr("name",all);
				}
				$("#collectDiv").append($copyDiv);
	    		collectNum++;
	    	};
    	}
    	totalSum1 = add(totalSum1,sum);
	}
	
   /*交通明细*/
	var rowN = $("#trafficTable").children("tr").size();
	var totalSum2 = 0; 
	for(var i = 0;i < rowN; i++){
		$tr = $("#trafficTable").children("tr").eq(i);
		var value = $tr.find("[name*=sum]").val();
		totalSum2 = add(totalSum2,value);
	}
	if(totalSum2>0){
		//插入Collect
		$copyDiv = $("#collectCopy").clone(true);
		$copyDiv.attr("id","");
		$copyDiv.attr("collectTag",trafficCode);
		$copyDiv.find("[name*=dailyCostCode]").val(trafficCode);
		$copyDiv.find("[name*=dailyCostName]").val("交通费");
		$copyDiv.find("[name*=sum]").val(totalSum2);
		//Collect改名
		var inputN = $copyDiv.find("input").size();
		for(var v = 0; v < inputN; v++){
			var $input = $copyDiv.find("input").eq(v);
			var name = $input.attr("name");
			var before= $.trim(name.split(".")[0]);
				var obefore =  $.trim(before.split("[")[0]); //避免重复添加[下标]
			var after= $.trim(name.split(".")[1]);
			var all = obefore+"["+collectNum+"]"+"."+after;
			$input.attr("name",all);
		}
		$("#collectDiv").append($copyDiv);
	}
		
	//总和
	var totalSum = add(totalSum1,totalSum2);
	$("#totalSum").val(totalSum);
}



//复制
function copyStyle(){
	//取回邮箱
	fillMaillList();
	
	var trCopy;
	var rowNum;
	var costBuName = $("#costBuName").val();
	var costDepartmentName = $("#costDepartmentName").val();
	var currencyName = $("#currencyName").val();
	
	//报销明细 复制，计算和，计算各类额度
	rowNum =$("#costTable").children("tr").size();
	for(var i = 0;i < rowNum; i++){
		$tr = $("#costTable").children("tr").eq(i);
        trCopy = $("#costCopy").clone(true);
    	trCopy.find("[flag=one]").text($tr.find("[name*=date]").val()); //日期
	    trCopy.find("[flag=two]").text(costBuName); //费用BU
	    trCopy.find("[flag=three]").text(costDepartmentName); //费用部门
	    trCopy.find("[flag=six]").text(currencyName);//币种
    	trCopy.find("[flag=four]").text($tr.find("[name*=dailyCostName]").val()); //用途
    	trCopy.find("[flag=five]").text($tr.find("[name*=description]").val()); //注释
    	trCopy.find("[flag=seven]").text(fmoney($tr.find("[name*=sum]").val(),2));//金额
    	trCopy.attr("id", "");
    	trCopy.attr("deleteFlag", "yes");
    	$("#costBody").append(trCopy);
    	trCopy.show();
	}
	
	//交通明细
	rowNum =$("#trafficTable").children("tr").size();
	if(rowNum>1 ||(rowNum==1 && !checkEmptyTr($("#trafficTable").children("tr").eq(0))) ){//如果没有填交通明细，则不显示
		$("#trafficShow").show();
		for(var i = 0;i < rowNum; i++){
			$tr = $("#trafficTable").children("tr").eq(i);
	        trCopy = $("#trafficCopy").clone(true);
	    	trCopy.find("[flag=one]").text($tr.find("[name*=date]").val()); //日期
		    trCopy.find("[flag=two]").text($tr.find("[name*=transportName]").val()); //交通工具
		    trCopy.find("[flag=three]").text($tr.find("[name*=customerName]").val()); //客户名称
	    	trCopy.find("[flag=four]").text($tr.find("[name*=toPlace]").val()); //目的地
	    	trCopy.find("[flag=five]").text($tr.find("[name*=kilometer]").val()); //公里数
	    	trCopy.find("[flag=six]").text(fmoney($tr.find("[name*=bridgeFees]").val(),2));//路桥费
	    	trCopy.find("[flag=seven]").text(fmoney($tr.find("[name*=parkingFees]").val(),2));//停车费
	    	trCopy.find("[flag=eight]").text(fmoney($tr.find("[name*=subsidy]").val(),2));//私车补贴
	    	trCopy.find("[flag=nine]").text(fmoney($tr.find("[name*=sum]").val(),2));//合计
	    	trCopy.attr("id", "");
	    	trCopy.attr("deleteFlag", "yes");
	    	$("#trafficBody").append(trCopy);
	    	trCopy.show();
		}
	}
	
	//插入单据
	var typeNum = $("#collectDiv").find("div").size();//有多少种类型
	var relRow = typeNum+2; //有内容的行数
	var allRow;
	var rowSpan;
	var insertRows;
	if(relRow>6){
		if (relRow%2 ==0) { //偶数
			allRow = relRow;
			rowSpan = allRow/2;
			insertRows = allRow-2;
		}else{ //奇数
			allRow = relRow+1;
			rowSpan = allRow/2;
			insertRows = allRow-2;
		}
	}else{
		allRow = 6;
		rowSpan= 3;
		insertRows = 4;
	}
	//插入头
	var upTr = $("#upTr").clone(true);
	upTr.attr("id","");
	$("#ticketTable").append(upTr);
	upTr.show();
	//插入各类别
	for(var i=1;i<=insertRows;i++){
		if(i==(insertRows/2+1)){
			var downTr = $("#downTr").clone(true);
			if(i<=typeNum){
				var div = $("#collectDiv").find("div").eq(i-1);
				var name = div.find("[name*=dailyCostName]").val();
				var value = div.find("[name*=sum]").val();
				downTr.find("[NameTag=NameTag]").text(name);
				downTr.find("[valueTag=valueTag]").text(fmoney(value,2));
			}else{
				downTr.find("[NameTag=NameTag]").text("");
				downTr.find("[valueTag=valueTag]").text("");
			}
			downTr.attr("id","");
			$("#ticketTable").append(downTr);
			downTr.show();
		}else{
			var midTr = $("#midTr").clone(true);
			if(i<=typeNum){
				var div = $("#collectDiv").find("div").eq(i-1);
				var name = div.find("[name*=dailyCostName]").val();
				var value = div.find("[name*=sum]").val();
				midTr.find("[NameTag=NameTag]").text(name);
				midTr.find("[valueTag=valueTag]").text(fmoney(value,2));
			}else{
				midTr.find("[NameTag=NameTag]").text("");
				midTr.find("[valueTag=valueTag]").text("");
			}
			midTr.attr("id","");
			$("#ticketTable").append(midTr);
			midTr.show();
		}
	}
	//插入 合计
	var sumTr = $("#sumTr").clone(true);
	sumTr.attr("id","");
	sumTr.find("[valueTag=valueTag]").text(fmoney($("#totalSum").val(),2));
	$("#totalSumCopy").text(fmoney($("#totalSum").val(),2));
	$("#ticketTable").append(sumTr);
	sumTr.show();
	//插入总计
	var totalTr = $("#totalTr").clone(true);
	totalTr.attr("id","");
	$("#ticketTable").append(totalTr);
	totalTr.show();
	lowToUpper($("#totalSum").val());
	
	$("#ticketTable").find("td[rowSpanTag=rowSpanTag]").attr("rowspan",rowSpan);
	
	$("#ccDepartment").text($("#buName").val()+"_"+$("#departmentName").val());//部门
	var createDate = new Date();//申请日期
	$("#cYear").text(createDate.getFullYear());
	$("#cMonth").text(createDate.getMonth()+1);
	$("#cDay").text(createDate.getDate());
	
	$("#ccName1").text($("#createUserName").val());
	$("#ccName2").text($("#createUserName").val());

	$("[currencyFlag=currencyFlag]").text(currencyName);

}

function changeName(){
	var tbodyNum = $("#tbodys tbody").size();
	//alert("tbody个数："+tbodyNum);
	for(var i = 0; i < tbodyNum; i++){
		var $tbody = $("#tbodys tbody").eq(i);
		var trNum = $tbody.children("tr").size();
		for(var j = 0; j < trNum; j++){
			var $tr = $tbody.children("tr").eq(j);
			var tdNum = $tr.children("td").size();
			for(var k = 0; k < tdNum; k++){
				var $td =  $tr.children("td").eq(k);
				var inputNum = $td.find("input").size();
				//alert("input个数："+inputNum);
				for(var v = 0; v < inputNum; v++){
					var $input = $td.find("input").eq(v);
					var name = $input.attr("name");
					var before= $.trim(name.split(".")[0]);
						var obefore =  $.trim(before.split("[")[0]); //避免重复添加[下标]
					var after= $.trim(name.split(".")[1]);
					var all = obefore+"["+j+"]"+"."+after;
					$input.attr("name",all);
					var id = $input.attr("id");
					var idBefore= $.trim(id.split("_")[0]);
					var  idNew = idBefore+"_"+j;
					$input.attr("id",idNew); //改Id,验证时使用
				};
			};
		};
	};
}
//整理表格，去空行，至少保留一行
function cleanTbody(tbody){
	var trNum = tbody.find("tr").size();
	for(var i = trNum; i >= 0; i--){
		trNum = tbody.find("tr").size();
		var tr = tbody.find("tr").eq(i);
		if(checkEmptyTr(tr)){
			if(trNum > 1){ 
				//clearTrTips(tr);取消验证
				tr.remove();
			};
		};
	};
}
//验证空行
function checkEmptyTr(tr){
	var inputNum = tr.find("input").size();
	var flag = true; //为空
	for(var i=0;i<inputNum;i++){
		var input = tr.find("input").eq(i);
		if($.trim(input.val())!="" && $.trim(input.val())!="请选择"){
			flag = false; //不为空
			//不为空时为这行添加验证（交通明细试用）
			tr.find("input[id*=trafficDate]").addClass("validate[required]");
			//tr.find("input[id*=trafficTransport]").addClass("validate[required]");
			tr.find("input[id*=trafficSumId]").addClass("validate[required,custom[positiveNumber]]");
			//主表添加验证
			tr.find("input[id*=date]").addClass("validate[required]");
			tr.find("input[id*=dailyCostName]").addClass("validate[required]");
			tr.find("input[id*=sum]").addClass("validate[required,custom[positiveNumber]]");
			tr.find("input[id*=description]").addClass("validate[required]");
			break;
		};
		//为空行，去掉验证
		tr.find("input[id*=trafficDate]").removeClass("validate[required]");
		//tr.find("input[id*=trafficTransport]").removeClass("validate[required]");
		tr.find("input[id*=trafficSumId]").removeClass("validate[required,custom[positiveNumber]]");
		tr.find("input[id*=date]").removeClass("validate[required]");
		tr.find("input[id*=dailyCostName]").removeClass("validate[required]");
		tr.find("input[id*=sum]").removeClass("validate[required,custom[positiveNumber]]");
		tr.find("input[id*=description]").removeClass("validate[required]");
	}
	return flag;
}
/* 添加一行 */
$("tr input").click(function(){
	var $tr = $(this).parents("tr");
	if($tr.nextAll().length==0){
		addTr($tr);
	};
});

$(".del-text").click(function(){
	var $obj = $(this).parents("tr");
	var $length = $obj.parents("tbody").find("tr").length;
	if($length<2){
		dialog("请最少保留1行","warning",false,2);
		return false;
	}
	delTr($obj);
});
/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.attr("hide","show");
	$copyTr.show();
	$tr.after($copyTr);
}
/* 删除行 */
function delTr($obj){
	$obj.remove();
	$obj.validationEngine('hidePrompt');
}
function getCurrencyFlag(currencyName){
	var flag = "";
	if(null == currencyName || "" == currencyName || "undefined" == currencyName){
		flag = "¥";
	}else{
		if(currencyName == "人民币"){
			flag = "¥";
		}else if(currencyName == "美元"){
			flag = "$";
		}else if(currencyName == "港元"||currencyName == "港币"){
			flag = "HK$";
		}else if(currencyName == "欧元"){
			flag = "€";
		}else if(currencyName == "日元"){
			flag = "¥";
		}else if(currencyName == "澳元"){
			flag = "AU$";
		} else if (currencyName == "台币") {
			flag = "TWD";
		}else{
			flag = "¥";
		}
	}
	return flag;
}
function lowToUpper(num){
	if(!/^\d*(\.\d*)?$/.test(num)){
		
	}else{
		var UPPER = new Array("零","壹","贰","叁","肆","伍","陆","柒","捌","玖");
		var num_array = ("" + num).split(".");
		var defStr="零";
		/*小数位*/
		if(num_array[1] != null && num_array[1].length > 0){
			if(num_array[1].length < 2){
				$("[jiao=jiao]").text(UPPER[num_array[1].charAt(0)]);
				$("[fen=fen]").text(defStr);
			}else{
				$("[jiao=jiao]").text(UPPER[num_array[1].charAt(0)]);
				$("[fen=fen]").text(UPPER[num_array[1].charAt(1)]);
			}
		}else{
			$("[jiao=jiao]").text(defStr);
			$("[fen=fen]").text(defStr);
		}
		/*整数位*/
		if(num_array[0] != null && num_array[0].length > 0){
			var intstr = "";
			if(num_array[0].length < 7){
				var temp = "";
				for(var i=0; i < 7 - num_array[0].length; i++){
					temp = temp + "0";
				}
				intstr = temp + num_array[0];
			}else{
				intstr = num_array[0].substring(num_array[0].length - 7);
			}
			$("[baiwan=baiwan]").text(UPPER[intstr.charAt(0)]);
			$("[shiwan=shiwan]").text(UPPER[intstr.charAt(1)]);
			$("[wan=wan]").text(UPPER[intstr.charAt(2)]);
			$("[qian=qian]").text(UPPER[intstr.charAt(3)]);
			$("[bai=bai]").text(UPPER[intstr.charAt(4)]);
			$("[shi=shi]").text(UPPER[intstr.charAt(5)]);
			$("[ge=ge]").text(UPPER[intstr.charAt(6)]);
		}else{
			$("[baiwan=baiwan]").text(defStr);
			$("[shiwan=shiwan]").text(defStr);
			$("[wan=wan]").text(defStr);
			$("[qian=qian]").text(defStr);
			$("[bai=bai]").text(defStr);
			$("[shi=shi]").text(defStr);
			$("[ge=ge]").text(defStr);
		}
		
	}
}
//取回数值，没有值的为0
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}

function validateFunction(){
	$("#createUserName").addClass("validate[required]");
	$("#createUserId").addClass("validate[required]");
	
	$("#buName").addClass("validate[required]");
	$("#buId").addClass("validate[required]");
	
	$("#departmentName").addClass("validate[required]");
	$("#departmentId").addClass("validate[required]");
	
	$("#regionName").addClass("validate[required]");
	$("#regionId").addClass("validate[required]");
	
	$("#currencyName").addClass("validate[required]");
	$("#currencyId").addClass("validate[required]");
}