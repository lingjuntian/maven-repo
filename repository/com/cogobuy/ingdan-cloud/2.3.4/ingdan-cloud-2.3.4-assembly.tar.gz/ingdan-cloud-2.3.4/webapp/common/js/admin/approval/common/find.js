/**
 * 根据BU查找账套,并填充selectId对应的select值
 * @param buId
 * @param selectId
 */
function findLedgerByBuForSelect(buId, selectId){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/findLedgerByBu?buId="+buId),
        dataType:"json",
        success:function(data, textStatus){
        	clearSelect(selectId,"ledger");
            if(data != null){
            	if(data.ledgerList != null){//动态填充流程
            		$.each(data.ledgerList,function(n,value) { 
           			 	var listr = "<li><a href=\"#\" tagN=\"ledger\" tagValue=\""+value+"\" vhidden=\""+value+"\">"+value+"</a></li>";
           			 	$("#"+selectId).append(listr);
           	     	});
            		bindselect();
            	}
            }
        }
    });
}

/**
 * 根据BU,账套查找对应的产品线,并填充产品线列表
 * @param buId
 * @param ledger
 * @param selectId
 */
function findProductLineByBuAndLedgerForSelect(buId, ledger ,selectId){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/findProductLineByBuAndLedger?buId="+buId+"&ledgerList="+ledger),
        dataType:"json",
        success:function(data, textStatus){
        	clearSelect(selectId);
            if(data != null){
            	if(data.productLineList != null){//动态填充流程
            		$.each(data.productLineList,function(n,value) { 
            			var listr = "<li><a href=\"#\" tagValue=\""+value.id+"\" vhidden=\""+value.name+"\">"+value.name+"</a></li>";
            			$("#"+selectId).append(listr);
           	     	});
            		bindselect();
            	}
            }
        }
    });
}

/**
 * @param id  清空select
 */
function clearSelect(id, tag){
	$("#"+id).empty();
	$("#"+id).append("<li><a href=\"#\" tagN=\""+tag+"\" tagValue=\"\" vhidden=\"请选择\">请选择</a></li>");
	$("#"+id).parents(".options-select").find(".select").find("span").text("请选择");
	$("#"+id).parents(".options-select").find("input").val("");
}

/**
 * 绑定方法
 */
function bindselect(){
	$(".options-select .options a").unbind("click");
	$(".options-select .options a").bind("click",function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input").val($(this).attr("tagValue"));
		$(this).parents(".options-select").find("input[id$=Id]").val($(this).attr("tagValue"));
		$(this).parents(".options-select").find("input[id$=Id]").val($(this).attr("labelId"));
		if($(this).attr("tagN") == "bu"){
			$("#personId").val("");
			$("#person").val("");
			$("#inventoryClass").val("");
			$("#inventoryClassId").val(""); 
			findLedgerByBuForSelect($(this).attr("tagValue"),"ledgerForSelect");
		}
		if($(this).attr("tagN") == "ledger"){
			findProductLineByBuAndLedgerForSelect($("#buId").val(),$(this).attr("tagValue"),"productLineForSelect");
		}
		$(this).parents(".options-select").find(".options").hide();
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	});
}
