/**
 * 审核通过
 * @param parent
 */
//隐藏保存按钮
$(function(){$("[tdTag='save']").hide();});

  function updatePrice(e){
      //隐藏修改按钮
      $("[tdTag=update]").hide();
      //影藏审批按钮
      $("#pass").hide();
      //获得当前行
      var $tr=$(e).closest("tr");
      var detailId=$tr.find("[tdTag=detailId]").val();
      //将当前行的实际金额变为可填写
      var $input="<input type='text'style='width: 50px' id='realPrice' name='detail.realPrice' maxlength='7' class='input-text'/>"+
                   "<input type='hidden' tdTag='realSumPrice' id='realSumPrice' name='detail.realSumPrice'/>"+
                    "<input type='hidden' name='detail.id' value='"+detailId+"'/>";
      $tr.find("[tdTag=save]").show();
      $tr.find("[tdTag=realPrice]").html($input);
  }

  function save(e){
      //验证填写数据
      var $form= $("#updateDetaliForm");
      $form.find("[name=detail.realPrice]").addClass("validate[required,custom[amountSixPoint]]");
      var $error=$form.validationEngine('validate');
      if($error==true){
          //获得当前行
          var $tr=$(e).closest("tr");
         //计算当前行总价
          /*数量*/
          var quantity = changeNum($tr.find("[tdTag=quantity]").text());
          /*实际单价*/
          var  realPrice=changeNum($("#realPrice").val());
          var  realSumPrice=multiply(quantity,realPrice);
          $("#realSumPrice").val(realSumPrice);
          //计算实际价格合计
           var realSum=calTaxSum();
          //ajax提交修改的数据
          $form.attr("action","/approval/itProject_updateDetail");
          //隐藏保存按钮，防止重复提交
          $("[tdTag='save']").hide();
          //异步提交数据
          $form.ajaxSubmit(function(returnStr){
              if(returnStr=="success"){
                  dialog("成功", "success", true, 2);
                  //获得当前行
                  //将所有跟新数据写入页面
                  var realPriceHtml="<div>"+realPrice+"</div>";
                  var realSumPricehtml="<div>"+realSumPrice+"</div>";
                  $tr.find("[tdTag=realPrice]").html(realPriceHtml);
                  $tr.find("[tdTag=realSumPrice]").html(realSumPricehtml);
                  $("#realSumShow").text(realSum);
                  //显示所有修改按钮
                  $("[tdTag=update]").show();
                  //显示审批按钮
                  $("#pass").show();
                  return true;
              }else{
                  //提交失败，显示该行保存按钮，用户可重新提交
                  $tr.find("[tdTag=save]").show();
                  dialog(returnStr, "unsuccess", true, 2);
                  return false;
              }

          });
      }
}
//计算总价
    function calTaxSum(){
        var  $trs=$("#tbody").find("tr");
        var sum=0;
        var realPrice=0;
        var quantity=0;
        for(var i=0;i<$trs.size()-1;i++ ){
            var $tr = $trs.eq(i);
            quantity=$tr.find("[tdTag=quantity]").text();
            if($tr.find("[tdTag=realPrice]").text()!=''){
                realPrice = changeNum($tr.find("[tdTag=realPrice]").text());
            }else{
                realPrice=changeNum($("#realPrice").val())
            }
            /*总价*/
            sum=multiply(quantity,realPrice)+sum;
        }
        $("#realSum").val(sum);
        return sum;
    }

/*取回数值，没有值的为0*/
function changeNum(num){
    if($.trim(num)==''){
        return 0;
    }
    return $.trim(num);
}


/*
 * it仓管审批通过前检查是否填写了所有设备的实际价格
 */
 function full_realPrice(){
	 var $trs=$("#tbody").find("tr");
		for(var i=0;i<$trs.size()-1;i++){
			var $tr=$trs.eq(i);
			if($.trim($tr.find("[tdTag=realPrice]").text())==null||$.trim($tr.find("[tdTag=realPrice]").text())==""){
				return false;
			}	
		}
		return true;	 
 }

  /*
   * it经理审批通过之前检查
   */
  function it_approval(parent,parentId,returnUrl) {
  	if(full_realPrice()){
  	  flowApproval.approval(parent,parentId,returnUrl);
  	}else{
  		 dialog("it部门检查/供应商节点需填写所有的实际价格才能通过的噢！");
  	}
  		
  } 


