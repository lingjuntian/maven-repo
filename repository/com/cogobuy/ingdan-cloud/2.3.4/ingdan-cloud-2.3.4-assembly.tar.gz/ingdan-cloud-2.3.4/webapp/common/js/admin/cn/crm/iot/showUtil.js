/**
 * iot 编辑业务机会相关JS
 */
$(function(){
    autoCheckBok();//业务机会选框自动选中
    erpCusAutoComplete($("#erpCus"));
    completUser($("#erpUser"));
    customerAutoComplete($("#iotcusName"));
    //点击业务机会编辑
    $("#editBusiness").click(function(){
        var cid=$("#customerId").val();
        if(cid==null||cid==""||cid=="undifine"){
            dialog("在编辑业务机会前，必须得有客户先！","unsuccess",true,null);
            return;
        }
        $(".businessInput").attr('readonly','').css({'border':'1px solid #ccc'});
        // 修改input框聚焦时的border-color
        $(".businessInput").attr('readonly','').focus(function(){
            $(this).css({'border-color':'#03A1E8'});
        });
        $(".businessInput").attr('readonly','').blur(function(){
            $(this).css({'border-color':'#ccc'});
        });
        var str1 = '<td colspan="4" class="btn-td"><a href="javascript:void(0)" title="保存" id="updateBuisnessBut"   class="btn-save">保存</a><a href="#" title="保存" class="cancel">取消</a></td>';
        $("#editBusiness").parent().replaceWith(str1);
        //显示业务机会编辑框
        $("#buinissTbody").show();
        $("#productLine").show();
        $("#buinissShowTbody").hide();

    });


    //点击业务机会提交按钮
    $("#updateBuisnessBut").live('click',function(){
        //数据验证
        if(busValidationInput()==false){return false;}
        var cid=$("#customerId").val();
        $("#updateBuisnessBut").hide();
        //封装表单
        addBuinesstoForm(cid);
        //所有验证通过
        $("#businessUpdate").attr("action","/crm/customer_updateBusChance");
        $("#businessUpdate").ajaxSubmit(function(returnStr) {
            var type = returnStr.split("_")[0];
            if (type == "success") {
                dialog("成功","success",true,1);
                setTimeout(function(){window.location.reload(true);},1000);
            }else {
                //$("#btn-save-contact").show();
                dialog(returnStr,"unsuccess",true,2);
            }
            return false;
        });

    });


    //显示时将产品线重新布局
    if($("#producLineHide").val()!=null&&$("#producLineHide").val().trim()!=""){
        var proLine=$("#producLineHide").val().split(";");
        var trStr=""
        $.each(proLine,function(i,data){
            trStr+="<tr><td colspan='3'>"
            trStr+=data;
            trStr+="</td></tr>"
        }) ;
        $("#proLineTr").after(trStr);
        //alert(trStr);
    }

});


//自动勾选业务机会框
function autoCheckBok(){
    //编辑状态时 勾选已有的业务机会
    var $busTr=$("#buinissShowTbody").find("tr[tdTag=business]");
    for(var i=0;i<$busTr.size();i++){
        var buType=$busTr.eq(i).find("[tdTag=businessType]").text().trim();
        var buDes=$busTr.eq(i).find("[tdTag=businessDes]").text().trim();
        var haveBus=$busTr.eq(i).find("[tdTag=haveBusiness]").text().trim();
        if(buType=='APP开发'){
            $("#appbusBok").attr("checked","checked");
            $("#appbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#appbusSel").attr("selected","selected");
            }else{
                $("#appbusSelNo").attr("selected","selected");
            }
        }if(buType=='ODM/OEM需求'){
            $("#omoeBok").attr("checked","checked");
            $("#omoeIpt").val(buDes);
            if(haveBus=='有'){
                $("#omoeSel").attr("selected","selected");
            }else{
                $("#omoeSelNo").attr("selected","selected");
            }
        }if(buType=='开发工具'){
            $("#utilbusBok").attr("checked","checked");
            $("#utilbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#utilbusSel").attr("selected","selected");
            }else{
                $("#utilbusSelNo").attr("selected","selected");
            }
        } if(buType=='硬要采'){
            $("#qijianbusBok").attr("checked","checked");
            $("#qijianbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#qijianbusSel").attr("selected","selected");
            }else{
                $("#qijianbusSelNo").attr("selected","selected");
            }
        } if(buType=='硬蛋Link服务'){
            $("#linkbusBok").attr("checked","checked");
            $("#linkbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#linkbusSel").attr("selected","selected");
            }else{
                $("#linkbusSelNo").attr("selected","selected");
            }
        } if(buType=='产品方案开发'){
            $("#fnbusBok").attr("checked","checked");
            $("#fnbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#fnbusSel").attr("selected","selected");
            }else{
                $("#fnbusSelNo").attr("selected","selected");
            }
        } if(buType=='微信硬件认证需求'){
            $("#weixinbusBok").attr("checked","checked");
            $("#weixinbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#weixinbusSel").attr("selected","selected");
            }else{
                $("#weixinbusSelNo").attr("selected","selected");
            }
        } if(buType=='企业金融'){
            $("#jrbusBok").attr("checked","checked");
            $("#jrbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#jrbusSel").attr("selected","selected");
            }else{
                $("#jrbusSelNo").attr("selected","selected");
            }
        }  if(buType=='QQ物联接入需求'){
            $("#qqlinkBok").attr("checked","checked");
            $("#qqlinkbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#qqlinkSel").attr("selected","selected");
            }else{
                $("#qqlinkSelNo").attr("selected","selected");
            }
        } if(buType=='管理软件和服务'){
            $("#glbusBok").attr("checked","checked");
            $("#glbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#glbusSel").attr("selected","selected");
            }else{
                $("#glbusSelNo").attr("selected","selected");
            }
        }if(buType=='参加线下活动'){
            $("#joinbusBok").attr("checked","checked");
            $("#joinbusIpt").val(buDes);
            if(haveBus=='有'){
                $("#joinbusSel").attr("selected","selected");
            }else{
                $("#joinbusSelNo").attr("selected","selected");
            }
        }if(buType=='销售渠道对接'){
            $("#salebusBok").attr("checked","checked");
            $("#salebusIpt").val(buDes);
            if(haveBus=='有'){
                $("#salebusSel").attr("selected","selected");
            }else{
                $("#salebusSelNo").attr("selected","selected");
            }
        }if(buType=='微软云服务器'){
            $("#azurebusBok").attr("checked","checked");
            $("#azurebusIpt").val(buDes);
            if(haveBus=='有'){
                $("#azurebusSel").attr("selected","selected");
            }else{
                $("#azurebusSelNo").attr("selected","selected");
            }
        }if(buType=='参加硬蛋展会'){
            $("#indDanExhBox").attr("checked","checked");
            $("#indDanExhIpt").val(buDes);
            if(haveBus=='有'){
                $("#indDanExhSel").attr("selected","selected");
            }else{
                $("#indDanExhSelNo").attr("selected","selected");
            }
        }if(buType=='产品出口服务'){
            $("#proExitBok").attr("checked","checked");
            $("#proExitIpt").val(buDes);
            if(haveBus=='有'){
                $("#proExitSel").attr("selected","selected");
            }else{
                $("#proExitSelNo").attr("selected","selected");
            }
        }if(buType=='国内销售服务'){
            $("#domSaleBok").attr("checked","checked");
            $("#domSaleIpt").val(buDes);
            if(haveBus=='有'){
                $("#domSaleSel").attr("selected","selected");
            }else{
                $("#domSaleSelNo").attr("selected","selected");
            }
        }if(buType=='线上线下推广'){
            $("#lineExtBok").attr("checked","checked");
            $("#lineExtIpt").val(buDes);
            if(haveBus=='有'){
                $("#lineExtSel").attr("selected","selected");
            }else{
                $("#lineExtSelNo").attr("selected","selected");
            }
        }if(buType=='硬蛋体验厅发布会'){
            $("#ingdanRoomBok").attr("checked","checked");
            $("#ingdanRoomIpt").val(buDes);
            if(haveBus=='有'){
                $("#ingdanRoomSel").attr("selected","selected");
            }else{
                $("#ingdanRoomSelNo").attr("selected","selected");
            }
        } if(buType=='硬蛋CONSULTING服务'){
            $("#ingdanConsultingBox").attr("checked","checked");
            $("#ingdanConsultingIpt").val(buDes);
            if(haveBus=='有'){
                $("#ingdanConsultingSel").attr("selected","selected");
            }else{
                $("#ingdanConsultingSelNo").attr("selected","selected");
            }
        }   if(buType=='云服务'){
            $("#couldSerBok").attr("checked","checked");
            $("#couldSerIpt").val(buDes);
            if(haveBus=='有'){
                $("#couldSerSel").attr("selected","selected");
            }else{
                $("#couldSerSelNo").attr("selected","selected");
            }
        }if(buType=='产品线'){
            $("#probusBok").attr("checked","checked");
            $("#probusIpt").val(buDes);
            //$("#productLine").show();
            var proLineStr=$("#producLineHide").val();
            if(haveBus=='有'){
                $("#probusSel").attr("selected","selected");
            }else{
                $("#probusSelNo").attr("selected","selected");
            }
            if(proLineStr!=null&&proLineStr!=""){
                //存在产品线的情况，自动勾选具体产品线
                var proLines=proLineStr.split(";")
                $.each(proLines,function(i,poductLine){
                    var proLine=poductLine.split(":");
                    if(proLine[0].trim()=='MCU/MPU'){
                        var proLineDetail=proLine[1].split(",");
                        $.each(proLineDetail,function(i,mcu){
                            if(mcu.trim()=="Broadcom"){
                                $("#mcuBroadcom").attr("checked","checked");
                            }if(mcu.trim()=="Intel"){
                                $("#mcuIntel").attr("checked","checked");
                            }if(mcu.trim()=="Freescale"){
                                $("#mcuFreescale").attr("checked","checked");
                            }if(mcu.trim()=="Atmel"){
                                $("#mcuAtmel").attr("checked","checked");
                            }if(mcu.trim()=="GD"){
                                $("#mcuGD").attr("checked","checked");
                            }if(mcu.trim()=="Allwin"){
                                $("#mcuAllwin").attr("checked","checked");
                            }
                        });
                    } if(proLine[0].trim()=='WirelessIC'){
                        var proLineDetail=proLine[1].split(",");
                        $.each(proLineDetail,function(i,ic){
                            if(ic.trim()=="Broadcom"){
                                $("#icBroadcom").attr("checked","checked");
                            }if(ic.trim()=="Atmel"){
                                $("#icAtmel").attr("checked","checked");
                            }if(ic.trim()=="Quantic"){
                                $("#icQuantic").attr("checked","checked");
                            }if(ic.trim()=="NXP"){
                                $("#icNXP").attr("checked","checked");
                            }if(ic.trim()=="Skyworth"){
                                $("#icSkyworth").attr("checked","checked");
                            }
                        });
                    }if(proLine[0].trim()=='Sensor'){
                        var proLineDetail=proLine[1].split(",");
                        $.each(proLineDetail,function(i,sensor){
                            if(sensor.trim()=="Invensense"){
                                $("#senInvensense").attr("checked","checked");
                            }if(sensor.trim()=="AKM"){
                                $("#senAKM").attr("checked","checked");
                            }if(sensor.trim()=="BOSCH"){
                                $("#senBOSCH").attr("checked","checked");
                            }if(sensor.trim()=="Freescale"){
                                $("#senFreescale").attr("checked","checked");
                            }
                        });
                    }if(proLine[0].trim()=='Memory'){
                        var proLineDetail=proLine[1].split(",");
                        $.each(proLineDetail,function(i,mcu){
                            if(mcu.trim()=="Sandisk"){
                                $("#memSandisk").attr("checked","checked");
                            }if(mcu.trim()=="Winbond"){
                                $("#memWinbond").attr("checked","checked");
                            }if(mcu.trim()=="GD"){
                                $("#memGD").attr("checked","checked");
                            }if(mcu.trim()=="Atmel"){
                                $("#memAtmel").attr("checked","checked");
                            }
                        });
                    }if(proLine[0].trim()=='WirelessModule'){
                        var proLineDetail=proLine[1].split(",");
                        $.each(proLineDetail,function(i,mcu){
                            if(mcu.trim()=="Broadlink"){
                                $("#wmBroadlink").attr("checked","checked");
                            }if(mcu.trim()=="AMPAK"){
                                $("#wmAMPAK").attr("checked","checked");
                            }if(mcu.trim()=="MXCHIP"){
                                $("#wmMXCHIP").attr("checked","checked");
                            }if(mcu.trim()=="Huawei"){
                                $("#wmHuawei").attr("checked","checked");
                            }if(mcu.trim()=="Balanstech"){
                                $("#wmBalanstech").attr("checked","checked");
                            }if(mcu.trim()=="Ingdan"){
                                $("#wmIngdan").attr("checked","checked");
                            }
                        });
                    }if(proLine[0].trim()=='Power'){
                        var proLineDetail=proLine[1].split(",");
                        $.each(proLineDetail,function(i,mcu){
                            if(mcu.trim()=="SGMICRO"){
                                $("#pwSGMICRO").attr("checked","checked");
                            }if(mcu.trim()=="NXP"){
                                $("#pwNXP").attr("checked","checked");
                            }if(mcu.trim()=="HTC"){
                                $("#pwHTC").attr("checked","checked");
                            }if(mcu.trim()=="AOS"){
                                $("#pwAOS").attr("checked","checked");
                            }if(mcu.trim()=="Linear"){
                                $("#pwLinear").attr("checked","checked");
                            }
                        });
                    }if(proLine[0].trim()=='Others'){
                        var proLineDetail=proLine[1].split(",");
                        $.each(proLineDetail,function(i,mcu){
                            if(mcu.trim()=="Panasonic"){
                                $("#otPanasonic").attr("checked","checked");
                            }if(mcu.trim()=="Samsung"){
                                $("#otSamsung").attr("checked","checked");
                            }
                        });
                    }
                })
            }

        }
    }
}


//封装选中的产品线
/**
 * 格式  产品线分类1：产品线1，产品线2；产品线分类2：产品线1，产品线2；
 *
 */
function producttionDetail(){

    var proVal="";

    //MCU/MPU类产线
    var $mcuCheckBox=$("#mcuProLine").find("input");
    var mcu="";
    $.each($mcuCheckBox,function(){
        if($(this).attr("checked")==true){
            mcu+=$(this).val();
            mcu+=",";
        }
    });
    if(mcu!=""){mcu=mcu.substring(0,mcu.length-1);mcu+=";";proVal+="MCU/MPU:";proVal+=mcu;}

    //Wireless IC类产线
    var $icCheckBox=$("#icProLine").find("input");
    var ic="";
    $.each($icCheckBox,function(){
        if($(this).attr("checked")==true){
            ic+=$(this).val();
            ic+=",";
        }
    });
    if(ic!=""){ic=ic.substring(0,ic.length-1);ic+=";";proVal+="WirelessIC:";proVal+=ic;}


    //Sensor类产线
    var $sensorCheckBox=$("#sensorProLine").find("input");
    var sensor="";
    //alert($sensorCheckBox.size());
    $.each($sensorCheckBox,function(){
        if($(this).attr("checked")==true){
            sensor+=$(this).val();
            sensor+=",";
        }
    });
    if(sensor!=""){sensor=sensor.substring(0,sensor.length-1);sensor+=";";proVal+="Sensor:";proVal+=sensor;}


    //Sensor类产线
    var $memoryCheckBox=$("#memoryProLine").find("input");
    var memory="";
    $.each($memoryCheckBox,function(){
        if($(this).attr("checked")==true){
            memory+=$(this).val();
            memory+=",";
        }
    });
    if(memory!=""){memory=memory.substring(0,memory.length-1);memory+=";";proVal+="Memory:";proVal+=memory;}


    //Power类产线
    var $powerProLine=$("#powerProLine").find("input");
    var power="";
    $.each($powerProLine,function(){
        if($(this).attr("checked")==true){
            power+=$(this).val();
            power+=",";
        }
    });
    if(power!=""){power=power.substring(0,power.length-1);power+=";";proVal+="Power:";proVal+=power;}

    //Wireless Module类产线
    var $moduleProLine=$("#moduleProLine").find("input");
    var module="";
    $.each($moduleProLine,function(){
        if($(this).attr("checked")==true){
            module+=$(this).val();
            module+=",";
        }
    });
    if(module!=""){module=module.substring(0,module.length-1);module+=";";proVal+="WirelessModule:";proVal+=module;}

    //Wireless Module类产线
    var $othersProLine=$("#othersProLine").find("input");
    var others="";
    $.each($othersProLine,function(){
        if($(this).attr("checked")==true){
            others+=$(this).val();
            others+=",";
        }
    });
    if(others!=""){others=others.substring(0,others.length-1);others+=";";proVal+="Others:";proVal+=others;}
    return proVal;
}

//业务机会数据验证
function busValidationInput(){
    //1.验证前四个是否必选
    if($("#qijianbusBok").attr("checked")==false){dialog("请勾选元器件采购机会","unsuccess",true,2); return false;}
    if($("#azurebusBok").attr("checked")==false){dialog("请勾选微软云需求机会","unsuccess",true,2); return false;}
    //if($("#linkbusBok").attr("checked")==false){dialog("请勾选供应链机会","unsuccess",true,2); return false;}
    if($("#probusBok").attr("checked")==false){dialog("请勾选产品线机会和相应的产品线","unsuccess",true,2); return false;}

    //2.如果勾选了业务机会，必须选择有无业务机会
    var $checkBokType=$("#buinissTbody").find("[tdTag=buinissType]");
    for(var j=0;j<$checkBokType.size();j++){
        if($($checkBokType[j]).attr("checked")==true){
            //勾选了业务机会
            var $tr=$($checkBokType[j]).closest("tr");
            var $busSelect=$tr.find("select");
            //检查是否有勾选业务机会  但是没有选择业务机会是否有无
            if($busSelect.val()==null||$busSelect.val()==""){
                var busName=$($checkBokType[j]).closest("td").text();
                dialog("请选择“"+busName+"”的业务机会","unsuccess",true,2);
                return false;
            }
        }
    }

    //如果选择了产品线有业务机会的话，要勾选具体产品线
    if($("#probusSelVal").val()=="1"){
        var $produCheckBox=$("#proLineTable").find("input");
        for(var i=0;i<$produCheckBox.size();i++){
            if($produCheckBox.eq(i).attr("checked")==true){
                return true;
            }
        }
        dialog("请勾选具体产品线","unsuccess",true,2); return false;
    }
                return true;
}

//提交更改封装业务机会到表单
function addBuinesstoForm(cid){
    var $checkBokType=$("#buinissTbody").find("[tdTag=buinissType]");
    var str="<input type='hidden' name='customer.id' value='"+cid+"' />";
    var i=0;
    //便利业务checkbox
    $.each($checkBokType,function(){
        //判断业务机会单选框是否选中
        if($(this).attr("checked")==true){
            var $tr=$(this).closest("tr");
            var $disInput=$tr.find("[tdTag=discription]");
            var $haveChange=$tr.find("select").val();
            //判断是否为产品线
            if($(this).attr("id")=='probusBok'){
                //产品线业务机会选框选中
                //遍历产品线选框
                var proLineVal=producttionDetail();
                var inputstr="<input type='hidden' value='"+$(this).val()+"' name='customer.businessChances["+i+"].chanceName'/>"+
                    "<input type='hidden' value='"+$disInput.val()+"' name='customer.businessChances["+i+"].description'>"+
                    "<input type='hidden' value='"+$haveChange+"' name='customer.businessChances["+i+"].haveChance'>";
                //产品线选择有机会时才保存详细产
                if($haveChange=="1"){
                    inputstr=inputstr+"<input type='hidden' value='"+proLineVal+"' name='customer.businessChances["+i+"].chanceDetail'>";
                }
            }else{
                //非产品线业务机会框选中
                var inputstr="<input type='hidden' value='"+$(this).val()+"' name='customer.businessChances["+i+"].chanceName'/>"+
                    "<input type='hidden' value='"+$haveChange+"' name='customer.businessChances["+i+"].haveChance'>"+
                    "<input type='hidden' value='"+$disInput.val()+"' name='customer.businessChances["+i+"].description'>";
            }
            i=i+1;
            str+=inputstr;
        }
    });
    $("#businessUpdate").append(str);

}

/*ERP自动匹配*/
function erpCusAutoComplete($input){
    $input.autocomplete(encodeURI("/erpsupportajax/erpsupport_iotfindErpCus"), {
        //**加自定义表头**//*
        minChars: 1,
        width: 430,
        matchContains: "true",
        autoFill: false,
        dataType: 'json',
        parse: function(data) {
            var rows = [];
            if(data == null || data.erpCustomers == null){
                return rows;
            }
            for(var i=0; i<data.erpCustomers.length; i++){
                rows[rows.length] = {
                    data:data.erpCustomers[i],
                    value:data.erpCustomers[i].cusName,
                    result:data.erpCustomers[i].cusName
                };
            }
            return rows;
        },
        formatItem: function(row, i, max) {
            return "<div style='height: 20px;font-size: 12px;'>"+row.cusName+"(编码："+row.cusCode+")</div>";
        },
        formatMatch: function(row, i, max) {
            return row.cusName;
        }
    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
        $(this).val(data.cusName);
        $("#erpCusCode").val(data.cusCode);
    }).bind("unmatch", function() {//**没有匹配时**//*
        $(this).val("");
        $("#erpCusCode").val("");
    });
}


/*自动ERP用户*/
function completUser(input,inputId){
    $.ajax({
        type:"GET",
        url:encodeURI("/erpsupportajax/erpsupport_iotfindErpUser"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.erpUsers != null){
                //var input = $("#"+container);
                input.autocomplete(data.erpUsers, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-3'>名字</span>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-3'>"+row.cuser_Name+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.cuser_Name;
                    },
                    formatResult: function(row) {
                        return row.cuser_Name;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                input.val(data.cuser_Name);
                    $("#erpUserId").val(data.cuser_Id);
                }).bind("unmatch", function() {/**没有匹配时**/
                input.val("");
                    $("#erpUserId").val("");
                });
            }
        }
    });
}

/*客户自动匹配*/
function customerAutoComplete($input){
    $input.autocomplete(encodeURI("/crmAjax/customer_findCusTop8"), {
        //**加自定义表头**//*
        minChars: 0,
        width: 430,
        matchContains: "true",
        autoFill: false,
        dataType: 'json',
        parse: function(data) {
            var rows = [];
            if(data == null || data.customers == null){
                return rows;
            }
            for(var i=0; i<data.customers.length; i++){
                rows[rows.length] = {
                    data:data.customers[i],
                    value:data.customers[i].chName,
                    result:data.customers[i].chName
                };
            }
            return rows;
        },
        formatItem: function(row, i, max) {
            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"</div>";
        },
        formatMatch: function(row, i, max) {
            return row.chName;
        }
    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
        $(this).val("");
        $(this).val(data.chName);
        $("#customerID").val(data.id);
        $("#province").val(data.province);
        $("#city").val(data.regional);
        $("#address").val(data.address);
        $("#cusWebsite").val(data.website);
    }).bind("unmatch", function() {//**没有匹配时**//*
        $(this).val("");
        $("#customerID").val("");
        $("#province").val("");
        $("#city").val("");
        $("#address").val("");
        $("#cusWebsite").val("");
    });
}

