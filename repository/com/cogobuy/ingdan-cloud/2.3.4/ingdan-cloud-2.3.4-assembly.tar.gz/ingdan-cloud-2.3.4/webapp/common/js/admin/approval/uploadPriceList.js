$(function(){
	/*$("#tableHead th").each(function(){
		var otherName = $(this).find("[id^=otherName]").val();
		for(var i = 0; i < $(this).find(".correspond a").size(); i++){
			var $a = $(this).find(".correspond a:eq(" + i + ")");
			if(otherName != "" && otherName == $a.attr("vhidden")){
				$(this).find("input[id^=name]").val($a.attr("vhidden"));
				$(this).find("[id^=attrName]").val($a.attr("labelId"));
			}
		}
	});*/
	
	resetRowNO();
	initTrEvents();
	$("#submit").click(function(){
		save();
		return false;
    });
    ajaxInventory("table", "inventoryCode");
    /*$(".col-list a").click(function(){
		$(this).parents(".relative").find(".notmatch").text($(this).text());
		$(this).parents(".relative").find("input[id^=name]").val($(this).attr("vhidden"));
		$(this).parents(".relative").find("input[id^=attrName]").val($(this).attr("labelId"));
		$(this).parents(".relative").find(".notmatch").validationEngine('hidePrompt');
		var $th = $(this).parents("th"); 
		var len = $th.siblings().size();
		if($(this).attr("vhidden") != ""){
			for(var i = 0; i < len; i++){
				var $thOther = $th.siblings().eq(i);
				if($(this).attr("vhidden") == $thOther.find("input[id^=name]").val()){
					$thOther.find("input[id^=name]").val("");
					$thOther.find("[id^=attrName]").val("");
					$thOther.find("[id^=nameSpan]").text($thOther.find("[id^=otherName]").val());
				}
			}
		}
		if($th.siblings())
		$(this).parents(".correspond").removeClass("hover");
	});*/
});

function save(){
	
	/*var error = true;
	$("#tableHead th").each(function(){
		if($(this).find("input[id^=name]").val() == "" && $(this).find("[id^=nameSpan]").text() != "无"){
			$(this).find("[id^=nameSpan]").validationEngine("showPrompt", "请选择系统中对应的列名，如果没有对应的列名，请选无", 'error', "", true);
			error = false;
		}
	});
	
	if(!error){
		window.scrollTo(0, 0);
		return ;
	}*/
	var error1 = checkPartNo("table", true);
	var error2 = $("#form").validationEngine('validate');
	showLineTips("table", "inventoryCode");

	if(error1 && error2 == true){
		$("#form").ajaxSubmit(function(returnStr){
	        if (returnStr == "success") {
	          dialog("成功！","success",true,1);
		      setTimeout(function(){window.location = "/approval/salesInquiry_priceList"},1000);	        
	        } else if(returnStr == "error"){
	         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
	        }
	      });
	}
}

function resetRowNO(){
	var len = $("#table tr").size();

	for(var i = len - 1; i >= 0; i--){
		var name = "priceLists[" + i + "].";
		var tr = $("#table tr").eq(i);
		
		
		var j = 0;
		tr.find("input").each(function(){
			if($("#attrName" + j).val() != ""){
				$(this).attr("name", name + $("#attrName" + j).val());
				$(this).attr("id", $("#attrName" + j).val() + i);
			}
			j++;
		});
	    //tr.find("#unitPrice" + i).addClass("validate[required,max[10000000],custom[positiveNumber]]");
	    //tr.find("#currency" + i).addClass("validate[required]");
	    tr.find("#unitPrice" + i).addClass("validate[required,max[10000000],custom[number]]");
	    tr.find("#package_" + i).addClass("validate[max[10000000],custom[integer]]");
	    tr.find("#inventoryCode" + i).addClass("validate[required]");
	    tr.find("#currency" + i).addClass("validate[required]");
	}

   	if($("#table tr").size() >= 2){
  	   $("#table tr").find(".del").show();
    }else{
      $("#table tr").find(".del").hide();
    }
    
	$("#form").validationEngine('detach');
   	$("#form").validationEngine('attach');
}

/**初始化行事件**/
function initTrEvents(){
	$("[id^=add]").click(function(){
    	addTr(this);
    	return false;
    });
    $("[id^=del]").click(function(){
    	moveTr(this);
    	return false;
    });
}

//添加行的方法
function addTr(object){ 	
	var tr = $("#copyTr").clone(true);	
	tr.attr("id", "");				
    tr.insertAfter($(object).parents("tr"));
    tr.show();
    resetRowNO();
	setInventoryCodeAutoComplete(tr.find("[id^=inventoryCode]"));
	$("#form").validationEngine('hide');
}

/**删除行时消除原有的提示信息**/
function clearTrTips(tr){
	tr.find("[id*=inventoryCode]").validationEngine('hidePrompt');
	tr.find("[id*=unitPrice]").validationEngine('hidePrompt');
	tr.find("[id*=currency]").validationEngine('hidePrompt');
	tr.find("[id*=package_]").validationEngine('hidePrompt');
}

function autoCompleteInventory(data, $tr){
	clearInventory($tr);
	$tr.find("[id^=inventoryCode]").val(data.partNo);
	$tr.find("[id^=inventoryName]").val(data.cinvName);
}

function clearInventory($tr){
	$tr.find("[id^=inventoryName]").val("");
}

function checkEmptyTr(tr){
	if(tr.find("[id^=inventoryCode]").val() == "" &&
		tr.find("[id^=unitPrice]").val() == "" &&
		tr.find("[id^=supplierName]").val() == "" &&
		tr.find("[id^=currency]").val() == "" &&
		tr.find("[id^=package_]").val() == "" &&
		tr.find("[id^=inventoryName]").val() == ""){
			return true;
		}
	return false;	
}