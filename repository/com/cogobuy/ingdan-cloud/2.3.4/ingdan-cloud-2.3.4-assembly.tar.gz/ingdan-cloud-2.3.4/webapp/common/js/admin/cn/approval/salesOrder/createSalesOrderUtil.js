var autoCompleteInventoryList;
$(function() {
	/*增加验证*/
	$("#ledger,#customerFullName,#purchaseOrderNo,#personName,#currencyName,#currencyCode,#maker,[tdTag=inventoryCode]").addClass("validate[required]");
	$("#exchangeRate,#taxRate,[tdTag=taxUnitPrice],[tdTag=unitPrice]").addClass("validate[required,custom[amountSixPoint]]");
	$("[tdTag=quantity]").addClass("validate[required,custom[creditLimit]]");
	/* 模拟select下拉列表选择值 */
	optionsaBind();
	/*客户名称自动匹配*/
	customerAutoComplete();
	/*存货编码*/
	addInventoryAutoComplete($("#detailListTbody").find("input[tdTag=inventoryCode]"));
	/*业务员列表自动匹配*/
	autoCompletePerson();
	/*增加日期控件*/
	$("input[tdTag=expectDate]").click(function() {
		WdatePicker();
	});
	$("input[tdTag=expectDate][newTag=newTag]").val(GetTodayDateStr());
	/*增加显示提交按钮*/
	$(document).keydown(function(event){ 
		 if (event.ctrlKey && event.keyCode == 122) {
			 $("#submit").show();
		 }
	});
	/* 添加一行 */
	$("tr input").click(function(){
		var $tr = $(this).parents("tr");
		if($tr.nextAll().length==0){
			addTr($tr);
		}
	});
	/*删除一行*/
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $length = $obj.parents("tbody").find("tr").length;
		if($length<2){
			dialog("请最少保留1行","warning",false,2);
			return false;
		}
		delTr($obj);
	});
	/*绑定根据税率 ,含税单价  算无税单价 、合计*/
	$("#taxRate").bind("change",function(){ 
		/* 税率 */
		var taxRate = changeNum($("#taxRate").val());
		var $trs = $("#detailListTbody").find("tr");
		for ( var i = 0; i < $trs.size(); i++) {
			var $tr = $trs.eq(i);
			/*含税单价*/
			var taxUnitPrice = changeNum($tr.find("input[tdTag=taxUnitPrice]").val());
			if(taxUnitPrice != 0){
				/*无税单价*/
				var unitPrice = FloatDiv(taxUnitPrice*100,add(100,taxRate));
				$tr.find("input[tdTag=unitPrice]").val(changeSixDecimal(unitPrice));
				calTaxSum($tr);
			}
		}
	});
	/*绑定根据含税单价、税率 算无税单价、合计*/
	$("input[tdTag=taxUnitPrice]").bind("change",function(){ 
		/* 税率 */
		var taxRate = changeNum($("#taxRate").val());
		/*含税单价*/
		var taxUnitPrice = changeNum($(this).parents("tr").find("input[tdTag=taxUnitPrice]").val());
		/*无税单价*/
		var unitPrice = FloatDiv(multiply(taxUnitPrice,100),add(100,taxRate));
		$(this).parents("tr").find("input[tdTag=unitPrice]").val(changeSixDecimal(unitPrice));
		calTaxSum($(this).parents("tr"));
	});
	/*绑定根据无税单价、税率 算含税单价、合计*/
	$("input[tdTag=unitPrice]").bind("change",function(){ 
		/* 税率 */
		var taxRate = changeNum($("#taxRate").val());
		/*无税单价*/
		var unitPrice = changeNum($(this).parents("tr").find("input[tdTag=unitPrice]").val());
		/*含税单价*/
		var taxUnitPrice = multiply(unitPrice,FloatDiv(add(100,taxRate),100));
		$(this).parents("tr").find("input[tdTag=taxUnitPrice]").val(changeSixDecimal(taxUnitPrice));
		calTaxSum($(this).parents("tr"));
	});
	/*绑定数量每条详情的合计*/
	$("input[tdTag=quantity]").bind("change",function(){ 
		calTaxSum($(this).parents("tr"));
	});
	/*制单人自动匹配*/
	autoCompleteMaker();
	
	/*IOT相关项目提示*/
	autoCompleteIOT();
	
	/*复制：模拟点击 客户名称；Bu（获取部门列表）*/
	var orderId = $("#copyTag").val();
	if(orderId != null && orderId != ""){
		var cusCode = $("#customerCode").val();
		/*根据选择的客户、账套加载 对应产品线、收付款协议、账期*/
		setPLAndPCAndCP(cusCode);
		/*部门列表*/
		var buId = $("#buId").val();
		$("[buTag="+buId+"]").parent("li").show();
	}
});

/*计算行含税总和、税额等*/
function calTaxSum($tr){
	/*数量*/
	var quantity = changeNum($tr.find("input[tdTag=quantity]").val());
	/*含税单价*/
	var taxUnitPrice = changeNum($tr.find("input[tdTag=taxUnitPrice]").val());
	/*无税单价*/
	var unitPrice = changeNum($tr.find("input[tdTag=unitPrice]").val());
	/*含税总额*/
	var taxSum = multiply(quantity,taxUnitPrice);
	/*无税总额*/
	var sum = multiply(quantity,unitPrice);
	/*税额*/
	var tax = FloatSub(taxSum,sum);
	$tr.find("input[tdTag=taxSum]").val(changeFourDecimal(taxSum));
	$tr.find("input[tdTag=sum]").val(changeFourDecimal(sum));
	$tr.find("input[tdTag=tax]").val(changeFourDecimal(tax));
}

/*绑定下拉选项*/
function optionsaBind(){
	$(".options-select .options a").unbind("click");
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=show]").val($(this).attr("vshow"));
		var $vid = $(this).attr("vid");
		$(this).parents(".options-select").find("input[tag=id]").val($vid);
		var $selectTag = $(this).attr("selectTag");
		/*当改变账套时，需要重新加载页面*/
		if($selectTag == 'ledger'){ 
			autoFillCurrency($(this).attr("vshow"));
			autoFillSaleType($(this).attr("vshow"));
			autoFillShipType($(this).attr("vshow"));
			autoFillPayType($(this).attr("vshow"));
			$("#customerFullName").val("");
			$("#customerShortName").val("");
			$("#customerCode").val("");
			$("#licensecode").val("");
			$("#personName").val("");
			$("#personCode").val("");
			$("#depCode").val("");
			$("#personEmail").val("");
		}
		/*当选择币种时，需要填充汇率值*/
		if($selectTag == 'currency'){ 
			$("#exchangeRate").val($(this).attr("vnflat"));
			if($.trim($(this).attr("vshow")) == '人民币' || $.trim($(this).attr("vshow")) == 'RMB'){
				if($("#ledger").val() == "151"){
					$("#taxRate").val(0);
				}else{
					$("#taxRate").val(17);
				}
			}else{
				$("#taxRate").val(0);
			}
		}
		if($("#saleType").val()=="S7"){
			$("#taxRate").val("7");
		}
		/*当改变产品线时，需要重新加载收付款协议、账期*/
		if($selectTag == 'pl'){
			$("#payConditionName").val( $(this).attr("vpcn"));
			$("#payConditionCode").val( $(this).attr("vpcc"));
			$("#creditPeriod").val( $(this).attr("vcp"));
		}
		$(this).parents(".options-select").find("input[tag=show]").validationEngine('hidePrompt');
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	});
}

/*根据账套自动填充币种*/
function autoFillCurrency($ledger){
	$("#currencyNameS").text("请选择");
	$("#currencyName").val("");
	$("#currencyCode").val("");
	$("#exchangeRate").val(0);
	$("#taxRate").val(0);
	$("#currencyListUl").empty();
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/salesOrderApproval_findCurrencyListByLedger?ledger="+$ledger),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null){
            	if(data.list != null){//动态填充流程
            		$.each(data.list,function(n,value) {
            			var nflat = value.nflat;
            			if(nflat == null){
            				nflat = "";
            			}
	           			var listtr = "<li><a href=\"#\" selectTag=\"currency\" vnflat=\""+nflat+"\" " +
	           			 	"vid=\""+value.code+"\" vshow=\""+value.name+"\" title=\""+value.name+"\">"+value.name+"</a></li>";
	           			$("#currencyListUl").append(listtr);
	           			optionsaBind();
           	     	});
            	}
            }
        }
    });
} 

/*根据账套自动填充销售类型*/
function autoFillSaleType($ledger){
	$("#saleTypeS").text("请选择");
	$("#saleType").val("");
	$("#saleTypeCode").val("");
	$("#saleTypeListUl").empty();
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/salesOrderApproval_findSaleTypeListByLedger?ledger="+$ledger),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null){
            	if(data.list != null){//动态填充流程
            		$.each(data.list,function(n,value) {
            			var listtr = "<li><a href=\"#\" vid=\""+value.erpSaleTypeCode+"\" vshow=\""+value.erpSaleTypeName+"\"" +
            					" title=\""+value.erpSaleTypeName+"\">"+value.erpSaleTypeName+"</a></li>";
	           			$("#saleTypeListUl").append(listtr);
	           			optionsaBind();
           	     	});
            	}
            }
        }
    });
} 

/*根据账套自动填充发货方式*/
function autoFillShipType($ledger){
	$("#shippingTypeS").text("请选择");
	$("#shippingType").val("");
	$("#shippingTypeCode").val("");
	$("#shippingTypeListUl").empty();
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/salesOrderApproval_findShipTypeListByLedger?ledger="+$ledger),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null){
            	if(data.list != null){//动态填充流程
            		$.each(data.list,function(n,value) {
            			var listtr = "<li><a href=\"#\" vid=\""+value.erpShipCode+"\" vshow=\""+value.erpShipName+"\"" +
            					" title=\""+value.erpShipName+"\">"+value.erpShipName+"</a></li>";
	           			$("#shippingTypeListUl").append(listtr);
	           			optionsaBind();
           	     	});
            	}
            }
        }
    });
} 

/*根据账套自动填充付款方式*/
function autoFillPayType($ledger){
	$("#payTypeS").text("请选择");
	$("#payType").val("");
	$("#payTypeCode").val("");
	$("#payTypeListUl").empty();
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/salesOrderApproval_findPayTypeListByLedger?ledger="+$ledger),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null){
            	if(data.list != null){//动态填充流程
            		$.each(data.list,function(n,value) {
            			var listtr = "<li><a href=\"#\" vid=\""+value.erpPayStyleCode+"\" vshow=\""+value.erpPayStyleName+"\"" +
            					" title=\""+value.erpPayStyleName+"\">"+value.erpPayStyleName+"</a></li>";
	           			$("#payTypeListUl").append(listtr);
	           			optionsaBind();
           	     	});
            	}
            }
        }
    });
} 

/*客户名称自动匹配*/
function customerAutoComplete(){
	$("#customerFullName").autocomplete(encodeURI("/approvalajax/salesOrderApproval_findCustomerList"), {
		/**加自定义表头**/
		tableHead: "<div><span style='width:40%' class='col-1'>客户编码</span> <span style='width:58%' class='col-2'>客户名称</span></div>",
		minChars: 0,
		width: 310,
		cacheLength: 1,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		onBegin: function(options) { //修改--用于动态改变ledger的值
            options.extraParams.ledger= $("#ledger").val();
            return options;
        },
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.customerList == null){
            	return rows;
            }
            for(var i=0; i<data.customerList.length; i++){    
                rows[rows.length] = {    
                    data:data.customerList[i],              //下拉框显示数据格式   
                    value:data.customerList[i].cusName,     //选定后实际数据格式  
                    result:data.customerList[i].cusName   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span  style='width:40%' class='col-1'>" + row.cusCode + "</span> " + "<span style='width:58%' class='col-2'>" + row.cusName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.cusCode+row.cusName;
		},
		formatResult: function(row) {
			return row.cusName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		clearCustomerInfo();
		$("#customerShortName").val(data.cusAbbName);
		$("#customerFullName").val(data.cusName);
		$("#customerCode").val(data.cusCode);
		$("#licensecode").val(data.licensecode);
		/*根据选择的客户、账套加载 对应产品线、收付款协议、账期*/
		setPLAndPCAndCP(data.cusCode);
	}).bind("unmatch", function(){
		clearCustomerInfo();
	});
}

/*清空因客户加载的数据*/
function clearCustomerInfo(){
	$("#customerFullName").val("");
	$("#customerShortName").val("");
	$("#customerCode").val("");
	$("#licensecode").val("");
	$("#productLineUl_create").empty();
	$("#productLineName").val("");
	$("#productLineNameS").text("请选择");
	$("#payConditionName").val("");
	$("#payConditionCode").val("");
	$("#creditPeriod").val("");
	$("#customerFullName").validationEngine('hidePrompt');
}

/*根据选择的客户、账套加载 对应产品线、收付款协议、账期*/
function setPLAndPCAndCP(customerCode){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/salesOrderApproval_findPLAndPCAndCP?ledger=" + $("#ledger").val()+"&customerCode="+customerCode),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null){
            	if(data.cptList != null){//动态填充流程
            		$.each(data.cptList,function(n,value) {
            			var listr = "<li><a href=\"#\" selectTag=\"pl\" vpcn=\""+value.periodType+"\" vpcc=\""+value.periodTypeCode+"\" vcp=\""+value.periodDays+"\" vshow=\""+value.productLine+"\">"+value.productLine+"</a></li>";
           			 	$("#productLineUl_create").append(listr);
	           			optionsaBind();
           	     	});
            		/*模拟点击第一个*/
            		$("#productLineUl_create").find("li:first a").trigger("click");
            	}
            }
        }
    });
}

/*增加存货编码自动匹配*/
function addInventoryAutoComplete($input){
	$input.autocomplete(encodeURI("/approvalajax/salesOrderApproval_findInventoryList"), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>存货编码</span> <span class='col-2'>存货名称</span></div>",
		minChars: 0,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		onBegin: function(options) { //修改--用于动态改变ledger的值
            options.extraParams.ledger= $("#ledger").val();
            options.extraParams.customerCode= $("#customerCode").val();
            return options;
        },
		//extraParams: {ledger:$("#ledger").val(),customerCode:$("#customerCode").val()},
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.inventoryList == null){
            	return rows;
            }
            for(var i=0; i<data.inventoryList.length; i++){    
                rows[rows.length] = {    
                    data:data.inventoryList[i],              //下拉框显示数据格式   
                    value:data.inventoryList[i].invCode,    //选定后实际数据格式  
                    result:data.inventoryList[i].invCode   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.invCode + "</span> " + "<span class='col-2'>" + row.invName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.invCode + row.invName;
		},
		formatResult: function(row) {
			return row.invCode;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		clearTr($(this).parents("tr"));
		$(this).parents("tr").find("[tdTag=inventoryCode]").val(data.invCode);
		$(this).parents("tr").find("[tdTag=cusInvName]").val(data.erpCusInvName);
		$(this).parents("tr").find("[tdTag=eccn]").val(data.eccnNo);
		if(data.mpq != null){
			$(this).parents("tr").find("[tdTag=mpq]").val(data.mpq);
		}
		$(this).parents("tr").find("[tdTag=productLineName]").val(data.unionName);
		$(this).parents("tr").find("[tdTag=customerInventoryCode]").val(data.erpCusInvCode);
		$(this).parents("tr").find("[tdTag=inventoryName]").val(data.invName);
		$(this).parents("tr").find("[tdTag=cost]").val(data.cost);
	}).bind("unmatch", function(){
		clearTr($(this).parents("tr"));
	});
}

/*加载业务员的自动匹配功能*/
function autoCompletePerson(){
	$("#personName").autocomplete(encodeURI("/approvalajax/salesOrderApproval_findPersonList"), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>业务员(名称|CODE)</span><span  class='col-2'>业务员部门</span><span  class='col-3'>业务员Email</span></div>",
		minChars: 0,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		onBegin: function(options) { //修改--用于动态改变ledger的值
            options.extraParams.ledger= $("#ledger").val();
            return options;
        },
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.personList == null){
            	return rows;
            }
            for(var i=0; i<data.personList.length; i++){    
                rows[rows.length] = {    
                    data:data.personList[i],              //下拉框显示数据格式   
                    value:data.personList[i].erpPersonName,     //选定后实际数据格式  
                    result:data.personList[i].erpPersonName   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.erpPersonName+ " | " + row.erpPersonCode + "</span>"+ "<span class='col-2'>" + row.erpDeptName + "</span>"+ "<span class='col-3'>" + row.erpPersonEmail + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.erpPersonName + " | " + row.erpPersonCode + " | " + row.erpPersonEmail;
		},
		formatResult: function(row) {
			return row.erpPersonName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$("#personName").val(data.erpPersonName);
		$("#personCode").val(data.erpPersonCode);
		$("#depCode").val(data.erpDepCode);
		$("#personEmail").val(data.erpPersonEmail);
		$("#personName").validationEngine('hidePrompt');
	}).bind("unmatch", function(){
		$("#personName").val("");
		$("#personCode").val("");
		$("#depCode").val("");
		$("#personEmail").val("");
	});
}

/*制单人自动匹配*/
function autoCompleteMaker(){
	$.ajax({
		type:"GET",
		url:encodeURI("/erpsupportajax/cooperative_findErpUser"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.erpUserListAjax != null){
				$("#maker").autocomplete(data.erpUserListAjax, {
					/**加自定义表头**/
					tableHead:  "<div><span class='col-1'>制单人</span> <span class='col-2'>部门</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span class='col-1'>" + row.cuser_Name + "</span> " + "<span class='col-2'>" + row.cdept + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.cuser_Name;
					},
					formatResult: function(row) {
						return row.cuser_Name;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#maker").val(data.cuser_Name);
					$("#maker").validationEngine('hidePrompt');
				}).bind("unmatch", function(){
					$("#maker").val("");
				});
			}
		}
	});
}

/*根据客户找出相关的IOT项目*/
function autoCompleteIOT(){
	$("#iotNo").autocomplete(encodeURI("/approvalajax/salesOrderApproval_findIOTProjectList"), {
		/**加自定义表头**/
		//tableHead: "<div><span class='col-4'>项目ID</span><span>项目名称</span><span>公司名称</span></div>",
		tableHead: "<div><span class='col-1'>项目编号</span><span class='col-2'>公司名称</span>",
		minChars: 8,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		//onBegin: function(options) { //修改--用于动态改变ledger的值
        //    options.extraParams.iotNo = $("#iotNo").val();
        //    return options;
        //},
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.iotProjectList == null){
            	return rows;
            }
            for(var i=0; i<data.iotProjectList.length; i++){    
                rows[rows.length] = {    
                    data:data.iotProjectList[i],              //下拉框显示数据格式   
                    value:data.iotProjectList[i].iotId,     //选定后实际数据格式  
                    result:data.iotProjectList[i].iotId   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			//return "<span class='col-1'>" + row.iotId+ "</span>"+ "<span>" + row.projectName + "</span>"+ "<span>" + row.customerName + "</span>";
			return "<span class='col-1'>" + row.iotId+ "</span>"+ "<span class='col-2'>" + row.customerName + "</span>";
		},
		formatMatch: function(row, i, max) {
			//return row.iotId + " | " + row.projectName + " | " + row.customerName;
			return row.iotId + " | " + row.customerName;
		},
		formatResult: function(row) {
			return row.iotId;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$("#iotNo").val(data.iotId);
//		$("#personCode").val(data.erpPersonCode);
//		$("#depCode").val(data.erpDepCode);
//		$("#personEmail").val(data.erpPersonEmail);
//		$("#personName").validationEngine('hidePrompt');
	}).bind("unmatch", function(){
		$("#iotNo").val("");
//		$("#personName").val("");
//		$("#personCode").val("");
//		$("#depCode").val("");
//		$("#personEmail").val("");
	});
}

/*清除行的数据*/
function clearTr($tr){
	$tr.find("input[filterNull!=true]").val("");
	$tr.find("[tdTag=inventoryCode]").validationEngine('hidePrompt');
}

/*取回数值，没有值的为0*/
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}

/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.removeAttr("hide");
	$copyTr.removeAttr("style");
	$copyTr.find("input[tdTag=expectDate]").val(GetTodayDateStr());
	var $trs = $("#detailListTbody").find("tr");
	$copyTr.find("input[tdTag=item]").val($trs.size()+1);
	$tr.after($copyTr);
	addInventoryAutoComplete($copyTr.find("input[tdTag=inventoryCode]"));
}
/* 删除行 */
function delTr($obj){
	$obj.validationEngine('hidePrompt');
	$obj.remove();
}

/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
	var $trNum = $tbody.find("tr").size();
	for ( var i = $trNum-1; i >= 0; i--) {
		$trNum = $tbody.find("tr").size();
		var $tr = $tbody.find("tr").eq(i);
		if (checkEmptyTr($tr)) {
			if ($trNum > 1) {
				$tr.remove();
			}
		}
	}
}

/* 验证空行 */
function checkEmptyTr($tr) {
	var $inputNum = $tr.find("input").size();
	var flag = true; // 为空
	for ( var i = 0; i < $inputNum; i++) {
		var $input = $tr.find("input[filterNull!=true]").eq(i);
		if ($.trim($input.val()) != "") {
			flag = false; // 不为空
			break;
		}
	}
	return flag;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
	var $trs = $tbody.find("tr");/* 获取所有tr */
	var firstName = "salesOrder.orderDetails";/* 前缀名称 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $inputNum = $tr.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $tr.find("input").eq(j);
			$input.attr("id", $input.attr("tdTag") + numtag);
			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
		}
		$tr.find("input[tdTag=sub_index]").val(i);
		$tr.find("input[tdTag=rowNo]").val(i+1);
	}
}

/*用于上传文件使用*/
function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}

/*验证输入数量是否为最小包装的整数倍*/
function checkQuantity(field, rules, i, options){
	var quantity = field.val();
	var mpq = field.parents("tr").find("input[tdTag=mpq]").val();
	if(mpq!=0){
		if(!isInteger(parseInt(quantity)/parseInt(mpq))){
			return "*请输入MPQ的整数倍";
		}
	}
}
//判断是否为非负整数
function isInteger(num){
    return /^\+?[1-9][0-9]*$/.test(num);
}