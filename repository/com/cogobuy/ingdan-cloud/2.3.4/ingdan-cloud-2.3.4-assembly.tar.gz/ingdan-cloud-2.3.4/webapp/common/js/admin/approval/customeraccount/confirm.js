$(function () {
	$("#info_change_submit").click(function(){
		subimtConfirmForm("info_form");
	});
	
	$("#nature_change_submit").click(function(){
		subimtConfirmForm("nature_form");
	});
	
	$("#other_change_submit").click(function(){
		subimtConfirmForm("other_form");
	});
	
	$("#internal_change_submit").click(function(){
		var error = $("#internal_form").validationEngine('validate');
		if(error){
			subimtConfirmForm("internal_form");
		}
	});
	
	$("#attr_change_submit").click(function(){
		var infoId = $(this).attr("taginfoid");
		window.location = "/approval/customerAccount_confirm?customerAccountId="+infoId;
	});
	
	$("#customerAccountConfirm_submit").click(function(){
		$("#customerAccountConfirm_submit").hide();
		$("#customerAccountConfirm_form").ajaxSubmit(function(returnStr){
	        if (returnStr == "error") {
	        	dialog("数据保存错误，请稍后重试！","unsuccess",true,1);	 
	        	$("#customerAccountConfirm_submit").show();
	        	return;
	        } else{
	            dialog("成功！","success",true,1);	 
		        setTimeout(function(){window.location = "/approval/customerAccount_show?customerAccountId="+returnStr;},1000);	        
	        }
	  });
	});
});

/**
 * 提交确认页面修改表单
 * @param formId
 */
function subimtConfirmForm(formId){
	$("#"+formId).ajaxSubmit(function(returnStr){
		if (returnStr == "personerror") {
        	dialog("该业务员对应角色配置有误，请重新选择","unsuccess",true,2);	
        	return;          
        }
        if (returnStr == "error") {
        	dialog("数据保存错误，请稍后重试！","unsuccess",true,1);	 
        	return;
        } else{
            dialog("成功！","success",true,1);	 
	        setTimeout(function(){window.location = "/approval/customerAccount_confirm?customerAccountId="+returnStr;},1000);	        
        }
  });
}