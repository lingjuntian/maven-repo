$(function() {
	$("#adduserid,#pDate,#addusername").addClass("validate[required]");
	$("#pAmountBorrow,#pAmountReturn").addClass("validate[required,custom[amount]]");
	
	/*表格修饰*/
	$(".table-list > table").decorateList();
	
	/*日期*/
	$("#datetime1").click(function(){
		WdatePicker({maxDate:$('#datetime2').val()});
	});
	$("#datetime2").click(function(){
		WdatePicker({minDate:$('#datetime1').val()});
	});
	$("#pDate").click(function(){
		WdatePicker();
	});
	
	/**查询**/						
	$("#selectButton").click(function(){
		 $("#selectForm").submit();
	});
	
	/*绑定回车事件*/
    $("#userName").keydown(function(event){
        if (event.keyCode == 13) {	  				
			$("#selectForm").submit();
		}
    });
	
    /*取消修改,增加*/
	$("[closeTag=close]").click(function(){
		$(".popup-mask,.popup-cost-approval-add-borrow-money").hide();
		$("body").validationEngine('hidePrompt');
		return false;
	});
    
	/* 添加 */
	$(".add-text").click(function(){
		$("#pDate").val("");
		$("#addusername").val("");
		$("#adduserid").val("");
		$("#pAmountBorrow").val("");
		$("#pAmountReturn").val("");
		$("#pRemark").val("");
		$("#bmId").val("");
		$("#title").text("添加记录");
		$("#add").text("添加");
		$("#addForm").attr("action","/approval/borrowMoney_add");
		pagePopup(".popup-cost-approval-add-borrow-money",true);
	});
	
	/* 显示修改框 */
	$(".edit-text").click(function(){
		var $obj = $(this).parents("tr");
		var $id = $obj.find("input[type=hidden][tdTag=id]").val();
		var $date = $obj.find("input[type=hidden][tdTag=date]").val();
		var $userId = $obj.find("input[type=hidden][tdTag=userId]").val();
		var $userName = $obj.find("input[type=hidden][tdTag=userName]").val();
		var $remark = $obj.find("input[type=hidden][tdTag=remark]").val();
		var $borrow = $obj.find("input[type=hidden][tdTag=borrow]").val();
		var $repayment = $obj.find("input[type=hidden][tdTag=repayment]").val();
		
		$("#pDate").val($date);
		$("#addusername").val($userName);
		$("#adduserid").val($userId);
		
		$("#pAmountBorrow").val($borrow);
		$("#pAmountReturn").val($repayment);
		$("#pRemark").val($remark);
		$("#bmId").val($id);
		
		$("#addForm").attr("action","/approval/borrowMoney_change");
		$("#title").text("修改记录");
		$("#add").text("保存");
		pagePopup(".popup-cost-approval-add-borrow-money",true);
	});
	
	/*提交修改或增加*/
	$("#addOrUpdate").click(function(){
		var formError = $("#addForm").validationEngine('validate');
		if(formError){
			$(".popup-mask,.popup-cost-approval-add-borrow-money").hide();
			$("#addForm").ajaxSubmit(function(returnStr){
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					$("#selectForm").submit();
				}else if(returnStr == 'inputIllegal'){
					dialog("数据错误", "unsuccess", true, 2);
				}else{
					dialog("服务器繁忙，请联系管理员或稍后再试", "unsuccess", true, 2);
				}
				return false;
			});
		}
	});
	
	/* 删除 */
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $id = $obj.find("input[type=hidden][tdTag=id]").val();
		var data = {
			"bm.id" : $id
		};
		if(confirm("确定删除")){
			$.ajax({
				type : "GET",
				url : encodeURI("/approval/borrowMoney_delete"),
				data : data,
				success : function(returnStr) {
					if (returnStr == 'success') {
						dialog("成功", "success", true, 2);
						$("#selectForm").submit();
					}else if(returnStr == 'inputIllegal'){
						dialog("数据错误", "unsuccess", true, 2);
					}else{
						dialog("服务器繁忙，请联系管理员或稍后再试", "unsuccess", true, 2);
					}
				}
			});
		}
	});
	
	/*恢复*/
	$(".recover-text").click(function(){
		var $obj = $(this).parents("tr");
		var $id = $obj.find("input[type=hidden][tdTag=id]").val();
		var data = {
			"bm.id" : $id
		};
		if(confirm("确定恢复")){
			$.ajax({
				type : "GET",
				url : encodeURI("/approval/borrowMoney_recover"),
				data : data,
				success : function(returnStr) {
					if (returnStr == 'success') {
						dialog("成功", "success", true, 2);
						$("#selectForm").submit();
					}else if(returnStr == 'inputIllegal'){
						dialog("数据错误", "unsuccess", true, 2);
					}else{
						dialog("服务器繁忙，请联系管理员或稍后再试", "unsuccess", true, 2);
					}
				}
			});
		}
	});
	
	/*自动匹配用户*/
	userAutoComplete();
});

/*自动匹配用户*/
function userAutoComplete(){  
    $.ajax({  
        type:"GET",  
        url:encodeURI("/approvalajax/findAllUser"),  
        dataType:"json",  
        success:function(data, textStatus){  
            if(data != null && data.userList != null){  
                $("#addusername").autocomplete(data.userList, {  
                    /**加自定义表头**/  
                    tableHead: "<div><span style='width:40%' class='col-1'>名称</span> <span style='width:58%' class='col-2'>邮箱</span></div>",  
                    minChars: 0,  
                    width: 310,  
                    matchContains: "true",  
                    autoFill: false,  
                    formatItem: function(row, i, max) {  
                        return "<span  style='width:40%' class='col-1'>" + row.name + "</span> " + "<span style='width:58%' class='col-2'>" + row.userMail + "</span>";  
                    },  
                    formatMatch: function(row, i, max) {  
                        return row.name+row.nickName+row.enName;  
                    },  
                    formatResult: function(row) {  
                        return row.name;  
                    }  
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/  
                    $("#addusername").val(data.name);  
                    $("#adduserid").val(data.id);  
                }).bind("unmatch", function(){  
                	$("#addusername").val("");  
                    $("#adduserid").val("");
                });  
            }  
        }  
    });   
}  