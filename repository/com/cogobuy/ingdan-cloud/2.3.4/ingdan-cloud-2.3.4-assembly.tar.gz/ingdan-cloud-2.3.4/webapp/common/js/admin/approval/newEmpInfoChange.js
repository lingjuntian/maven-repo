$(document).ready(function() { 
	
	$("[name=empInfoChange.changeType]").click(function() {
		$("[name^=empInfoChange]").validationEngine('hidePrompt');
		var selected=$("input[name='empInfoChange.changeType']:checked").val();
		if (selected=='入职'){
			$("#form1 [name=empInfoChange.joinDate]").addClass("validate[required]");
			$("#form1 [name=empInfoChange.changeDate]").removeClass("validate[required]");
			$("#form1 [name=empInfoChange.oldRole]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldCompany]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldBranch]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldDept]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldCostCompany]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldSupervisorName]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=changeOrleave]").hide();
			$("#form1 [name=change]").hide();
			$("#form1 [name=join]").show();
			
		}
		if (selected=='离职'){
			$("#form1 [name=empInfoChange.changeDate]").addClass("validate[required]");
			$("#form1 [name=empInfoChange.joinDate]").removeClass("validate[required]");
			$("#form1 [name=empInfoChange.oldRole]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldCompany]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldBranch]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldDept]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldCostCompany]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldSupervisorName]").removeClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=changeOrleave]").show();
			$("#form1 [name=change]").hide();
			$("#form1 [name=join]").hide();
		}
		if (selected=='异动'){
			$("#form1 [name=empInfoChange.changeDate]").addClass("validate[required]");
			$("#form1 [name=empInfoChange.oldRole]").addClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldCompany]").addClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldBranch]").addClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldDept]").addClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldCostCompany]").addClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.oldSupervisorName]").addClass("validate[required,minSize[2],maxSize[50]]");
			$("#form1 [name=empInfoChange.joinDate]").removeClass("validate[required]");
			$("#form1 [name=changeOrleave]").show();
			$("#form1 [name=change]").show();
			$("#form1 [name=join]").hide();
		}
	});
	/* 日期控件 */
	$("#joinDate").click(function() {
		WdatePicker();
	});
	$("#changeDate").click(function() {
		WdatePicker();
	});
	$("[name=empInfoChange.employeeNo]").click(function() {$("[name=empInfoChange.employeeNo]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.name]").click(function() {$("[name=empInfoChange.name]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.postion]").click(function() {$("[name=empInfoChange.postion]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.role]").click(function() {$("[name=empInfoChange.role]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.company]").click(function() {$("[name=empInfoChange.company]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.branch]").click(function() {$("[name=empInfoChange.branch]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.dept]").click(function() {$("[name=empInfoChange.dept]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.costCompany]").click(function() {$("[name=empInfoChange.costCompany]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.supervisorName]").click(function() {$("[name=empInfoChange.supervisorName]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.joinDate]").click(function() {$("[name=empInfoChange.joinDate]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.changeDate]").click(function() {$("[name=empInfoChange.changeDate]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.oldRole]").click(function() {$("[name=empInfoChange.oldRole]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.oldCompany]").click(function() {$("[name=empInfoChange.oldCompany]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.oldBranch]").click(function() {$("[name=empInfoChange.oldBranch]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.oldDept]").click(function() {$("[name=empInfoChange.oldDept]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.oldCostCompany]").click(function() {$("[name=empInfoChange.oldCostCompany]").validationEngine('hidePrompt');});
	$("[name=empInfoChange.oldSupervisorName]").click(function() {$("[name=empInfoChange.oldSupervisorName]").validationEngine('hidePrompt');});
	 
	
	$("#form1 [name=empInfoChange.employeeNo]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.name]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.postion]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.role]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.company]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.branch]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.dept]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.costCompany]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.supervisorName]").addClass("validate[required,minSize[2],maxSize[50]]");
	$("#form1 [name=empInfoChange.remark]").addClass("validate[maxSize[500]]");
	
//	$("#newProjectForm [name=project_reUserReportID]").addClass("validate[required]");
	$("#form1").validationEngine({
		validationEventTriggers : "blur", //触发的事件  validationEventTriggers:"keyup blur",  
		inlineValidation : false,// 是否即时验证，false为提交表单时验证,默认true
		success : false,// 为true时即使有不符合的也提交表单,false表示只有全部通过验证了才能提交表单,默认false
		promptPosition : "topRight" //提示所在的位置，topLeft, topRight, bottomLeft,  centerRight, bottomRight 
	});
	/** 提交表单 * */
	$("#FormButton").click(function(){
		$("[name^=empInfoChange]").validationEngine('hidePrompt');
		
		var selected=$("input[name='empInfoChange.changeType']:checked").val();
		if(selected==null){
			alert("请选择更变类型!");
			return false;
		}
		$("#form1").submit();
	});
	 
	  

});
  