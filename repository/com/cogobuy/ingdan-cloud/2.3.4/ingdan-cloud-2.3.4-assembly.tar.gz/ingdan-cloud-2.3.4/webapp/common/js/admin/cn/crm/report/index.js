$(function(){
    /**
     * 全选
     */
    $("#allSelChe").click(function(){
        if($("#allSelChe").attr("checked")){
            $(".selCheck").attr("checked",true);
        }else{
            $(".selCheck").attr("checked",false);
        }

    });

});