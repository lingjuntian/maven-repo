/**
 * crm 权限JS
 */
$(function() {
	// 弹窗-添加共享人
	$(".permis-btn-addperople").click(function(event) { // 点击添加，显示元素
		var e = window.event || event; // 兼容写法，可以直接使用return false代替
		if (e.stopPropagation) {
			e.stopPropagation();
		} else {
			e.cancelBubble = true;
		}
		$('.permission .div-lookfor,.permission .share-aside-2').hide(); // 在这里显示对方之前先隐藏
		$('.permission .div-shareperple,.permission .share-aside').show();
	});
	$(".permis-btn-lookfor").click(function(event) {
		var e = window.event || event;
		if (e.stopPropagation) {
			e.stopPropagation();
		} else {
			e.cancelBubble = true;
		}
		$('.permission .div-shareperple,.permission .share-aside').hide();
		$('.permission .div-lookfor,.permission .share-aside-2').show();
	});
	
	// 点击取消按钮
	$('.div-shareperple .close').click(function(event) { 
		$('.permission .div-shareperple,.permission .share-aside').hide();
	});
	$('.div-lookfor .close').click(function(event) {
		$('.permission .div-lookfor,.permission .share-aside-2').hide();
	});
	
	// 点击添加按钮后，隐藏元素 -- 增加共享人
	$('.div-shareperple .actions .button').click(function(event) { 
		var $name = $("#addShareUserName").val();
		var $id = $("#addShareUserId").val();
		if($name.length==0 || $id.length == 0){
			dialog("共享人为空", "unsuccess", true, 2);
			return false;
		}
		$('.permission .div-shareperple,.permission .share-aside').hide();
		var data = {
			"assignUserId" : $id,
			"assignUserName" : $name
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/crm/assign_saveShare"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("增加成功", "success", true, 2);
					window.location.reload();
				} else {
					dialog(returnStr, "unsuccess", true, 2);
				}
			}
		});
	});
	
	// 点击添加按钮后，隐藏元素 -- 增加查看人
	$('.div-lookfor .actions .button').click(function(event) {
		var $name = $("#addRequireUserName").val();
		var $id = $("#addRequireUserId").val();
		if($name.length==0 || $id.length == 0){
			dialog("查看人为空", "unsuccess", true, 2);
			return false;
		}
		$('.permission .div-lookfor,.permission .share-aside-2').hide();
		var data = {
			"assignUserId" : $id,
			"assignUserName" : $name
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/crm/assign_saveRequire"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("增加成功", "success", true, 2);
					window.location.reload();
				} else {
					dialog(returnStr, "unsuccess", true, 2);
				}
			}
		});
	});
	
	//取消
	$('a[tag="cancel"]').click(function(event) {
		var data = {
			"assignId" : $(this).attr("assignId")
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/crm/assign_cancel"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("取消成功", "success", true, 2);
					window.location.reload();
				} else {
					dialog(returnStr, "unsuccess", true, 2);
				}
			}
		});
	});
		
	//增加自动匹配功能
	completUser("addShareUserName");
	completUser("addRequireUserName");
	
	$('.permission .div-shareperple,.permission .share-aside').click(function(event) {
		return false; // return false阻止冒泡，代替浏览器兼容检测冒泡事件的写法
	});
	$('.permission .div-lookfor,.permission .share-aside-2').click(function(event) { // 阻止点击document中的弹窗位置，把弹窗隐藏
		var e = window.event || event;
		return false;
	});

	$(document).click(function() { // 点击页面空白，隐藏弹窗
		$('.permission .div-shareperple,.permission .share-aside,.permission .div-lookfor,.permission .share-aside-2').hide();
	});
});

/*自动匹配用户*/
function completUser(container){
	$.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findAllUser"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.userList != null){
            	var input = $("#"+container);
                input.autocomplete(data.userList, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-3'>中文名</span> <span class='col-4'>英文名</span></div>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-3'>"+row.name+"</span> <span class='col-4'>"+row.enName+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.name+row.enName;
                    },
                    formatResult: function(row) {
                        return row.name;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                	input.val(data.name);
                	input.parent("div[tag='addDiv']").find("input[type=hidden]").val(data.id);
                }).bind("unmatch", function() {/**没有匹配时**/
                	input.val("");
                	input.parent("div[tag='addDiv']").find("input[type=hidden]").val("");
                });
            }
        }
    });
}