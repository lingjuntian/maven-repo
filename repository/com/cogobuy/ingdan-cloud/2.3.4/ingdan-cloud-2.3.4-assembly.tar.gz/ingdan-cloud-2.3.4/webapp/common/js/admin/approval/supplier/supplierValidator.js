$(function () {
	//BU
	$("#buId").addClass("validate[required]");
	//LEDGER
	$("#ledger").addClass("validate[required]");
	//PRODUCTLINE
	$("#productLineId").addClass("validate[required]");
});
