$(function(){
	
	erpCusAutoComplete($("#erpCus"));
	completUser($("#erpUser"));
    /**
     * 省市级联
     */
    //$("#provincesOption").bind('click',addCity);
    $(".provincesOption").click(function(){
       var id=$(this).attr("tdTag");
       var provinceName=this.text;
       $("#cityshow").text("城市");
       $("#province").val(provinceName);
       $("#city").val("");
       $("#citys").empty();
        $.ajax({
            method:'get',
            url:"/crmAjax/customer_findCityByProvince",
            data:{pid:id},
            dataType:'json',
            success:function(data){
                //alert(data.cityList.length);
                var option="";
                for( var i=0;i<data.cityList.length;i++){
                    option+= "<li><a class='citys' href='#' vhidden=''>"+data.cityList[i]+"</a></li>"
                }
                $("#citys").append(option);
                $(".citys").click(function(){
                    var cityName=this.text;
                    $("#cityshow").text(cityName);
                    $("#city").val(cityName);
                });
            }
        });

    });

    //分类下框
    $(".classifyOption").click(function(){
        $("#classify").val(this.text);
    });
    //进展下框
    $(".progressOption").click(function(){
        $("#progress").val(this.text);
    });

    //联盟成员下框
    $(".isAllianceOption").click(function(){
        if(this.text=='是'){
            $("#isAlliance").val(1);
        }else{
            $("#isAlliance").val(0);
        }
    });
    //角色下框
    $(".positionOption").click(function(){
        $("#position").val(this.text);
    });
    $(".marketOption").click(function(){
    	$("#market").val(this.text);
    });
    $(".saleTypeOption").click(function(){
    	$("#saleType").val(this.text);
    });
    //参与活动多选框
    function activity(){
        var $activitys=$("#activitys").find("input");
        var activityVla="";
        for(var i= 0;i<$activitys.size();i++){
            var $input=$activitys.eq(i);
            if($input.attr("checked")==true){
                activityVla=activityVla+$input.val()+";";
            }
        }
        if(activityVla==""){return false;}
        $("#inAcyivity").val(activityVla);
        return true;
    }


    //数据验证
    $("#iotProjectName,#classify,#customerName,#conChName,#position").addClass("validate[required]");
    $("#contactPhone").addClass("validate[required,custom[mobile]]");
    $("#contactEmail").addClass("validate[required,custom[email]]");
    $("#tel").addClass("validate[custom[phoneNumber]]");
    $("#qq").addClass("validate[custom[number]]");

    //ajax 提交表单
    //执行保存
    $("#addIotBut").click(function(){
        var isPass=validationInput();
        if(isPass){
            $("#addIotBut").hide();
            $("#iotForm").attr("action","/crm/iot_save");
            $("#iotForm").ajaxSubmit(function(returnStr) {
                var type = returnStr.split("_")[0];
                var id = returnStr.split("_")[1];
                if (type == "success") {
                     dialog("成功","success",true,1);
                    var str="/crm/iot_show?iot.id="+id;
                    setTimeout(function(){window.location = str;},1000);
                }else {
                    $("#addIotBut").show();
                    dialog(returnStr,"unsuccess",true,2);
                }
                return false;
            });
        }
    });

    /* 验证输入 */
    function validationInput() {
        if($("#iotForm").validationEngine('validate')==false){return false;};
        if(activity()==false){
            dialog("请至少选择一个参加的活动","unsuccess",true,2);
            return false;
        }
            return true;
    };
     
    customerAutoComplete($("#customerName"));
});


/*客户自动匹配*/
function customerAutoComplete($input){
	    $input.autocomplete(encodeURI("/crmAjax/customer_findCusTop8"), {
        //**加自定义表头**//*
        minChars: 0,
        width: 430,
        matchContains: "true",
        autoFill: false,
        dataType: 'json',
        parse: function(data) {  
            var rows = [];  
            if(data == null || data.customers == null){
            	return rows;
            }
            for(var i=0; i<data.customers.length; i++){    
                rows[rows.length] = {    
                    data:data.customers[i],              
                    value:data.customers[i].chName,     
                    result:data.customers[i].chName   
                };  
            }  
            return rows;  
        }, 
        formatItem: function(row, i, max) {
            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"</div>";
        },
        formatMatch: function(row, i, max) {
            return row.chName;
        }
	    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
	    	$(this).val("");
	    	$(this).val(data.chName);
	    	$("#customerID").val(data.id);
	    	$("#province").val(data.province);
	    	$("#city").val(data.regional);
	    	$("#address").val(data.address);
	    	$("#website").val(data.website);
	    }).bind("unmatch", function() {//**没有匹配时**//*
	    	$(this).val("");
	    	$("#customerID").val("");
	    	$("#province").val("");
	    	$("#city").val("");
	    	$("#address").val("");
	    	$("#website").val("");
	    });
}



/*ERP自动匹配*/
function erpCusAutoComplete($input){
	    $input.autocomplete(encodeURI("/erpsupportajax/erpsupport_iotfindErpCus"), {
        //**加自定义表头**//*
        minChars: 1,
        width: 430,
        matchContains: "true",
        autoFill: false,
        dataType: 'json',
        parse: function(data) {  
            var rows = [];  
            if(data == null || data.erpCustomers == null){
            	return rows;
            }
            for(var i=0; i<data.erpCustomers.length; i++){    
                rows[rows.length] = {    
                    data:data.erpCustomers[i],              
                    value:data.erpCustomers[i].cusName,     
                    result:data.erpCustomers[i].cusName   
                };  
            }  
            return rows;  
        }, 
        formatItem: function(row, i, max) {
            return "<div style='height: 20px;font-size: 12px;'>"+row.cusName+"(编码："+row.cusCode+")</div>";
        },
        formatMatch: function(row, i, max) {
            return row.cusName;
        }
	    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
	    	$(this).val(data.cusName);
	    	$("#erpCusCode").val(data.cusCode);
	    }).bind("unmatch", function() {//**没有匹配时**//*
	    	$(this).val("");
	    	$("#erpCusCode").val("");
	    });
}



/*自动ERP用户*/
function completUser(input,inputId){
    $.ajax({
        type:"GET",
        url:encodeURI("/erpsupportajax/erpsupport_iotfindErpUser"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.erpUsers != null){
                //var input = $("#"+container);
                input.autocomplete(data.erpUsers, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-3'>名字</span>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-3'>"+row.cuser_Name+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.cuser_Name;
                    },
                    formatResult: function(row) {
                        return row.cuser_Name;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                    input.val(data.cuser_Name);
                    $("#erpUserId").val(data.cuser_Id);
                }).bind("unmatch", function() {/**没有匹配时**/
                    input.val("");
                    $("#erpUserId").val("");
                });
            }
        }
    });
}








