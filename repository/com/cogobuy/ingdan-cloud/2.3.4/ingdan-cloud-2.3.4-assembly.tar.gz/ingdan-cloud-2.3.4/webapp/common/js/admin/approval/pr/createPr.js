$(function() {
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
		if (error) {
			countData(); /* 统计数量、金额合计等 */
			copyValueToConfig();/* 将新建页面的数值写入确认页面 */
			getEmailList();/* 获取邮件发送列表 */
			switchPageForCreate();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
			copyFileList();/*上传附件公用*/
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		switchPageForConfirm();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#prForm").append(inputStr);
    		}
    	});
    	$("#submit").hide();
		$("#prForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/pr_show?prMain.id="+id;},1000);	  
			}else{
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
	});

    clearBusiness();
	completUser("projectManagerName");
});

/*自动匹配用户*/
function completUser(container){
	$.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findAllUser"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.userList != null){
            	var input = $("#"+container);
                input.autocomplete(data.userList, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-3'>中文名</span> <span class='col-4'>英文名</span></div>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-3'>"+row.name+"</span> <span class='col-4'>"+row.enName+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.name+row.enName;
                    },
                    formatResult: function(row) {
                        return row.name;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                	input.val(data.name);
                	input.parent("div[tag='addDiv']").find("input[type=hidden]").val(data.id);
                }).bind("unmatch", function() {/**没有匹配时**/
                	input.val("");
                	input.parent("div[tag='addDiv']").find("input[type=hidden]").val("");
                });
            }
        }
    });
}

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#prForm").validationEngine('validate');
}

/* 统计数量、金额合计等 */
function countData() {
	/* 无税总额 */
	var totalSum = 0;
	var totalQuantity = 0;
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		totalSum = add(totalSum, changeNum($tr.find("input[tdTag=sum]").val()));
		totalQuantity = add(totalQuantity,changeNum($tr.find("input[tdTag=quantity]").val()));
	}
	$("#totalSum").val(changeFourDecimal(totalSum));
	$("#totalQuantity").val(totalQuantity);
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/*清空头部*/
	$("div[tag=confirmHead] span[id$=_confirm]").text("");
	$("#sample_confirm").text("");
	$("#byd_confirm").text("");
	$("#office_confirm").text("");
	$("#salesTag_confirm").text("");
	$("#supplyChainFinance_confirm").text("");
	/*清空备注*/
	$("#remark_confirm").text("");
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*######################头部 BEGIN*/
	/*BU*/
	$("#buName_confirm").text($("#buName").val());
	/*业务员*/
	$("#personName_confirm").text($("#personName").val());
	/*供应商*/
	$("#vendor_confirm").text($("#vendor").val());
	/*币种*/
	$("#currencyName_confirm").text($("#currencyName").val());
	/* PR日期 */
	$("#pr_confirm").text($("#createTime").val());
	/* 账套 */
	$("#ledger_confirm").text($("#hidLedger").val());
	/* 销售订单号 */
	$("#salesOrderNo_confirm").text($("#salesorderno").val());
	/*样品*/
	if($("#sample:checked").length > 0){
		$("#sample_confirm").text("样品");
	}
	/*样品*/
	if($("#byd:checked").length > 0){
		$("#byd_confirm").text("Linear产品线非BYD客户");
	}
	/*业务员标识*/
	if($("#salesTag:checked").length > 0){
		$("#salesTag_confirm").text("业务员标识");
	}
	/*供应链金融业务标识*/
	if($("#supplyChainFinance:checked").length > 0){
		$("#supplyChainFinance_confirm").text("供应链金融业务");
	}
	
	/* 项目经理 */
	if($("#agentPurchasing1:checked").val() == 'Y1') {
		$("#projectManagerName_confirm").text($("#projectManagerName").val());
	} else {
		$("#projectManagerName").val("");
		$("#projectManagerId").val("");
	}

	/*外地办*/
	if($("#office:checked").length > 0){
		$("#office_confirm").text("TECHWING");
	}
	/*######################头部  END*/
	/*######################详情列表BEGIN*/
	/*详情*/
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		$("#plname").val($tr.find("input[tdTag=productLineName]").val());
		var $ncnr_str = "否";
		var $stop_str = "否";
		if($tr.find("input[tdTag=ncnr]:checked").length > 0){
			$ncnr_str = "是";
		}
		if($tr.find("input[tdTag=stop]:checked").length > 0){
			$stop_str = "是";
		}
		var trString = "<tr><td class=\"first supplier-model\"><div>"+$tr.find("input[tdTag=inventoryCode]").val()+"</div></td>" +
				"<td class=\"sl-code\"><div>"+$tr.find("input[tdTag=slCode]").val()+"</div></td>"+
				"<td class=\"quantity\"><div>"+fmoney(changeNum($tr.find("input[tdTag=quantity]").val()),0)+"</div></td>" +
				"<td class=\"price price-istax\"><div>"+fmoney(changeNum($tr.find("input[tdTag=taxUnitPrice]").val()),6)+"</div></td>" +
				"<td class=\"price price-notax\"><div>"+fmoney(changeNum($tr.find("input[tdTag=unitPrice]").val()),6)+"</div></td>"+
				"<td class=\"amount\"><div>"+fmoney(changeNum($tr.find("input[tdTag=sum]").val()),4)+"</div></td>" +
				"<td class=\"quote\"><div>"+$tr.find("input[tdTag=quote]").val()+"</div></td>"+
				"<td class=\"customer-name customer-name-end\"><div class=\"text-overflow\" title=\""+$tr.find("input[tdTag=customer]").val()+"\">"+$tr.find("input[tdTag=customer]").val()+"</div></td>" +
				"<td class=\"customer-name customer-name-purchasing\"><div class=\"text-overflow\" title=\""+$tr.find("input[tdTag=purchaseCus]").val()+"\">"+$tr.find("input[tdTag=purchaseCus]").val()+"</div></td>" +
				"<td class=\"po-number\"><div>"+$tr.find("input[tdTag=cusPono]").val()+"</div></td>" +
				"<td class=\"time\"><div>"+$tr.find("input[tdTag=expectDate]").val()+"</div></td>" +
				"<td class=\"quantity quantity1\">"+fmoney(changeNum($tr.find("input[tdTag=fcMonth1]").val()),0)+"</td>" +
				"<td class=\"quantity quantity2\">"+fmoney(changeNum($tr.find("input[tdTag=fcMonth2]").val()),0)+"</td>" +
				"<td class=\"quantity quantity3\">"+fmoney(changeNum($tr.find("input[tdTag=fcMonth3]").val()),0)+"</td>" +
				"<td class=\"quantity quantity4\">"+fmoney(changeNum($tr.find("input[tdTag=fcMonth4]").val()),0)+"</td>" +
				"<td class=\"ncnr\"><div>"+$ncnr_str+"</div></td>" +
				"<td class=\"last stop\"><div>"+$stop_str+"</div></td></tr>";
		$("#detailListTbody_confirm").append(trString);
	}
	/*合计行*/
	var totalString = "<tr class=\"total\"><td class=\"first supplier-model\"><div>金额小计：</div></td>" +
			"<td class=\"sl-code\"><div></div></td>" +
			"<td class=\"quantity\"><div></div></td>" +
			"<td class=\"price price-istax\"><div></div></td>" +
			"<td class=\"price price-notax\"><div></div></td>" +
			"<td class=\"amount\"><div>"+fmoney($("#totalSum").val(),4)+"</div></td>" +
			"<td class=\"quote\"><div></div></td>" +
			"<td class=\"customer-name\"><div></div></td>" +
			"<td class=\"po-number\"><div></div></td>" +
			"<td class=\"time\"><div></div></td>" +
			"<td class=\"quantity quantity1\"></td>" +
			"<td class=\"quantity quantity2\"></td>" +
			"<td class=\"quantity quantity3\"></td>" +
			"<td class=\"quantity quantity4\"></td>" +
			"<td class=\"ncnr\"><div></div></td>" +
			"<td class=\"last stop\"><div></div></td></tr>";
	$("#detailListTbody_confirm").append(totalString);
	/*######################详情列表END*/
	/*######################备注 BEGIN*/
	$("#remark_confirm").text($("#remark").val());
	/*######################备注 END*/
}

/* 获取邮件发送列表 */
function getEmailList() {
	var buId = $("#buId").val();
	var plName = $("#plname").val();
	var personEmail = $("#personEmail").val();
	var url = "/approval/pr_showConfirmMail?prMain.buId="+buId+"&prMain.productLineName="+plName+"&prMain.personEmail="+personEmail;
	if($("#sample:checked").length > 0){
		url = url + "&prMain.sample="+$("#sample").val();
	}
	if($("#byd:checked").length > 0){
		url = url + "&prMain.byd="+$("#byd").val();
	}
	if($("#office:checked").length > 0){
		url = url + "&prMain.office="+$("#office").val();
	}
	if($("#salesTag:checked").length > 0){
		url = url + "&prMain.salesTag="+$("#salesTag").val();
	}
	if($("#supplyChainFinance:checked").length > 0){
		url = url + "&prMain.supplyChainFinance="+$("#supplyChainFinance").val();
	}
	if($("#condition4:checked").length > 0){
		url = url + "&prMain.condition4="+$("#condition4").val();
	}
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted || nodeNoApprovalUser){
			//用户向后台申请该流程。。。。。

		}	
	});
}

/* 获取销售订单号、且写入页面 */
function getSalesOrderSO() {
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/salesOrder_createSalesOrderNo"),
		success : function(returnStr) {
			$("#salesOrderNo").val(returnStr);
			$("#so_confirm").text(returnStr);
		}
	});
}

/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
function switchPageForCreate() {
	$("#write").hide();
	$("#confirm").show();
}


/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").hide();
	$("#write").show();
}

function clearBusiness() {
	$("#supplyChainFinance").attr('checked', false);
	$("#agentPurchasing").attr('checked', false);
	$("#agentPurchasing1").attr('checked', false);
}

function switchBusiness(checkbox) {
	if(checkbox.checked == true) {
		$("#supplyChainFinance").attr('checked', false);
		$("#agentPurchasing").attr('checked', false);
		$("#agentPurchasing1").attr('checked', false);
		
		checkbox.checked = true;
	}
	
	if($("#agentPurchasing1").is(':checked')) {
		$("#projectManager").show();
	} else {
		$("#projectManager").hide();
	}
	
	if($("#supplyChainFinance").is(':checked')) {
		$("#supplyChainFinance").val("Y");
	} else  {
		$("#supplyChainFinance").val("");
	}
	
	if($("#agentPurchasing").is(':checked')) {
		$("#agentPurchasing").val("Y");
	} else if($("#agentPurchasing1").is(':checked')) {
		$("#agentPurchasing1").val("Y1");
	} else {
		$("#agentPurchasing1").val("");
	}
}