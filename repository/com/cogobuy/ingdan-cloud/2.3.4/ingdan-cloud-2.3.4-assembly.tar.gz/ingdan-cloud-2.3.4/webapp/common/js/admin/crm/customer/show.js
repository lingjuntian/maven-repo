/**
 * crm 客户添加js
 */

$(function(){
	 $(".showHide").hide();
	 var $customerEdit = $('.customer-edit'),
     $customerEditTable = $customerEdit.find('table'),
     $popupTable = $('.popup-box table');
     
	 
	 /**
	  * 显示主营产品列表
	  */
	 var $productList=$("#productVla").find("[tdTag=product]");
	 var $proShow=$("#productShow").find("tr");
	 for ( var i = 0; i < $productList.size(); i++) {
		 var $proDiv=$productList.eq(i);
		 $proShow.eq(i).find("[tdTag=productName]").val($proDiv.find("[tdTag=productName]").val());
		 $proShow.eq(i).find("[tdTag=annualPut]").val($proDiv.find("[tdTag=annualPut]").val());
	 }
	  
	// 客户页面-点击编辑
	$customerEdit.find('.fl .edit').click(function(){ // "编辑"为已创建元素时直接click事件
		$(".showHide").show();
		//$("#addressSel").css({'display':'inline'});
		//$(".showHide").css({'display':'block-inline'});
		$(".editHide").hide();
	     $customerEditTable.find('input,textarea').attr('readonly','').addClass('input-text').css({'border':'1px solid #ccc'});
	     $customerEditTable.find('select option').css({'border':'1px solid #ccc'});
	     // 修改input框聚焦时的border-color
	     $customerEditTable.find('input,textarea').focus(function(){
	         $(this).css({'border-color':'#03A1E8'});
	     });
	     $customerEditTable.find('input,textarea').blur(function(){
	         $(this).css({'border-color':'#ccc'});
	     });
	     var str1 = '<td colspan="8" class="btn-td"><a href="#" title="保存" class="btn-save save">保存</a><a href="#" title="保存" class="cancel">取消</a></td>';
		 	$customerEdit.find('.edit').parent().replaceWith(str1);

	     // select下拉框的隐藏显示
		 $customerEditTable.find('td span span').css({'display':'none'});
	     $customerEditTable.find('select').css({'display':'inline'});
	     $customerEditTable.find('#customerType').css({'display':'block'});
	     $customerEditTable.find('textarea').css({'display':'block'});

        //业务类型
        $("#productLine").show();
        $("#buinissShowTbody").hide();
        $("#buinissTbody").show();

	});
	
     $customerEdit.find('.fl .edit').live('click',function(){      // "编辑"为新创建元素时live绑定事件

	     $customerEditTable.find('input,textarea').attr('readonly','').addClass('input-text').css({'border':'1px solid #ccc'});
	     $customerEditTable.find('select option').css({'border':'1px solid #ccc'});
	
	     // 修改input框聚焦时的border-color
	     $customerEditTable.find('input,textarea').focus(function(){
	         $(this).css({'border-color':'#03A1E8'});
	     });
	     $customerEditTable.find('input,textarea').blur(function(){
	         $(this).css({'border-color':'#ccc'});
	     });
	     var str1 = '<td colspan="8" class="btn-td"><a href="#" title="保存" class="btn-save save">保存</a><a href="#" title="保存" class="cancel">取消</a></td>';
	      $customerEdit.find('.edit').parent().replaceWith(str1);
	     // select下拉框的隐藏显示
	    // $customerEditTable.find('td span span').css({'display':'none'});
	     alert('live创建');
	    // $customerEditTable.find('select,textarea').css({'display':'block'});
	     
	     //区域自动补全
	     //regionAutoComplete($("#regional"));
 });

 $('.customer-edit .fl .cancel').live('click',function(){
	 dialog("您确定要放弃编辑吗？",null,true,null,function(){
         location.reload(true)
	 });
 });


   // 添加联系人
  $('.customer-edit .add-text').click(function(){
     $('.btn-add-customer i').css({'display':'inline'});
     $('.btn-add-customer').removeClass('none');
     $('#mask-div').css({'display':'block','opacity':'0.6'});

      $popupTable.find('input,textarea').focus(function(){       // 当鼠标聚焦或离开时修改边框颜色          
         $(this).css({'border-color':'#03A1E8'});
     });
     $popupTable.find('input,textarea').blur(function(){
         $(this).css({'border-color':'#ccc'});
     });
    
 });

 $('#btn-cancle').click(function(){
	 $("#contactChName").validationEngine('hidePrompt');
	 $("#contactEmail").validationEngine('hidePrompt');
	 $("#contactPhone").validationEngine('hidePrompt');
     $("#position").validationEngine('hidePrompt');
     $(this).parents('.box').css({'z-index':66,'position':'static'});
     $(this).parents(".btn-add-customer").addClass("none");
     $('#mask-div').hide();
 }); 

 //-----------------------------------------------------------------------------------------
 	$("#regional").addClass("validate[required]");//客户编辑验证
 	 // 点击客户页面保存
	$('.customer-edit .fl .save').live('click',function(){
		var isPass=validationInputCustomer();
	 	if(isPass){
	 		$("#update_customer").hide();
	 		$("#updateCustomerForm").attr("action","/crm/customer_update");
	 		$("#updateCustomerForm").ajaxSubmit(function(returnStr) {
	 			var type = returnStr.split("_")[0];
	 			if (type == "success") {
	 				dialog("成功","success",true,1);
	 				setTimeout(function(){var str="/crm/customer_show?customer.id="+$("#customerId").val();window.location.href=str;},1000);	  
	 			}else {
	 				$("#btn-save-contact").show();
	 				dialog(returnStr,"unsuccess",true,2);
	 			}	
	 	        return false;
	 		});
	 	}
	});

	 /*增加验证*/
    $("#contactChName,#province,#city,#address,#MainProductName,#annualPut,#currency,#position,#legalPerson").addClass("validate[required]");
    $("#contactPhone").addClass("validate[required,custom[mobile]]");
    // $("#weixin").addClass("validate[custom[number]]");
    $("#contactEmail").addClass("validate[required,custom[email]]");
    $("#tel").addClass("validate[custom[phoneNumber]]");
    $("#qq").addClass("validate[custom[number]]");
    $("#capital").addClass("validate[custom[numberTen]]");
	/**
	 * 点击添加联系人按钮
	 */
    $("#btn-save-contact").click(function(){
    	var isPass=validationInputContact();
    	if(isPass){
    		$("#btn-save-contact").hide();
    		$("#savecontactForm").attr("action","/crm/contact_save");
    		$("#savecontactForm").ajaxSubmit(function(returnStr) {
    			var type = returnStr.split("_")[0];
    			if (type == "success") {
    				dialog("成功","success",true,1);
    				setTimeout(function(){window.location.reload(true);},1000);
    			}else {
    				$("#btn-save-contact").show();
    				dialog(returnStr,"unsuccess",true,2);
    			}	
    	        return false;
    		});
    	}
    });
    
    /* 联系人验证输入 */
    function validationInputContact() {
    	return $("#savecontactForm").validationEngine('validate');
    };
    
    /* 客户验证输入 */
    function validationInputCustomer() {
    	var chName=$("#chName").val();
    	var enName=$("#enName").val();
    	if(chName==""&&enName==""){
    		dialog("至少要为该公司填写一个名称的噢！","unsuccess",true,null);
    		return false;
    	}
        //当代理产品线选中时，必须至少选择一条产品线
        if($("#probusBok").attr("checked")==true){
            var $productLine=$("#productLine").find("input");
            var i=0;
            $.each($productLine,function(){
                if($(this).attr("checked")==true){
                    i++;
                }
            });
            if(i==0){
                dialog("如果你认为有产品线业务机会的话，至少要勾选一条产品线的呢！","unsuccess",true,null);
                return false;
            }
        }
    	return $("#updateCustomerForm").validationEngine('validate');
    	
    };

	/**
     * 省市级联
     */
    $("#province").change(function(){
    	$("#city").empty();
    	if($("#province").val()==''){return;}
    	$.ajax({
    		method:'GET',
    		url:"/crmAjax/customer_findCityByProvince?pid="+$("#province").val(),
    	    type:'json',
    	    success:function(data){
    	    	var object=JSON.parse(data);
    	    	$.each(object.cityList,function(n,value){
    	    		//$("#city").append(new Option(value,value,true,true));
    	    		$("#city").append("<option value='"+value+"'>"+value+"</option>");
    	    	});
    	    }
    	});
    	
    });


});







