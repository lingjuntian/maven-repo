$(function () {
	$("#contact_change_submit").click(function(){
		subimtConfirmForm("contact_form");
	});
	$("#info_change_submit").click(function(){
		subimtConfirmForm("info_form");
	});
	$("#bank_change_submit").click(function(){
		subimtConfirmForm("bank_form");
	});
	$("#attachment_change_submit").click(function(){
		var infoId = $(this).attr("tagValue");
		if(infoId.length > 0){
			window.location = "/approval/supplierApv_confirm?infoId="+infoId;
		}
	});
	
	$("#supplierConfirm_submit").click(function(){
		$("#supplierConfirm_form").ajaxSubmit(function(returnStr){
	        if (returnStr == "error") {
	        	dialog("数据保存错误，请稍后重试！","unsuccess",true,1);	 
	        	return;
	        } else{
	            dialog("成功！","success",true,1);	 
		        setTimeout(function(){window.location = "/approval/supplierApv_index";},1000);	        
	        }
	  });
	});
});

/**
 * 提交确认页面修改表单
 * @param formId
 */
function subimtConfirmForm(formId){
	$("#"+formId).ajaxSubmit(function(returnStr){
        if (returnStr == "error") {
        	dialog("数据保存错误，请稍后重试！","unsuccess",true,1);	 
        	return;
        } else{
            dialog("成功！","success",true,1);	 
	        setTimeout(function(){window.location = "/approval/supplierApv_confirm?infoId="+returnStr;},1000);	        
        }
  });
}