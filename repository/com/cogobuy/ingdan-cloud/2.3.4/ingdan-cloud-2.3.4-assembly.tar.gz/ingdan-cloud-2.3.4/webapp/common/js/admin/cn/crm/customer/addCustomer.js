/**
 * crm 客户添加js
 */

$(function () {
    /**
     * 添加客户提示
     */
    $(".btn-add-customer").css({'left': ' -421px', 'top': '120px'});
    customerAutoComplete($("#chName"));
    /*客户自动匹配*/
    function customerAutoComplete($input) {
        var info = "";
        var msg = "";
        var iotId = $("#iotId").val();
        if (iotId == null || iotId == "") {
            info = "为您找到以下相关客户，点击直接跟进客户";
            msg = "您确定要跟进";
        } else {
            info = "为您找到以下相关客户，点击直接添加为该IOT客户";
            msg = "您确定要添加iot客户";
        }
        $input.autocomplete(encodeURI("/crmAjax/customer_customerMatch"), {
            /**加自定义表头**/
            tableHead: "<div> <span class='col-3' style='width:300px'>" + info + "</div>",
            minChars: 1,
            width: 350,
            matchContains: "true",
            autoFill: false,
            dataType: 'json',
            parse: function (data) {
                var rows = [];
                if (data == null || data.customerList == null) {
                    return rows;
                }
                for (var i = 0; i < data.customerList.length; i++) {
                    rows[rows.length] = {
                        data: data.customerList[i],
                        value: data.customerList[i].customerName,
                        result: data.customerList[i].customerName
                    };
                }
                return rows;
            },
            formatItem: function (row, i, max) {
                return "<div style='height: 20px;font-size: 12px;'>" + row.customerName + "</div>";
            },
            formatMatch: function (row, i, max) {
                // return row.customerList;
            },
            formatResult: function (row) {
                // return row.customerList;
            }
        }).result(function (e, cus, value, sec) {
            /**加选中后的回调函数**/
            dialog(msg + "\"" + cus.customerName + "\"吗？", null, true, null, function () {
                $.ajax({
                    url: "/crm/customer_addAccess",
                    method: 'GET',
                    data: {cid: cus.cid, iotId: iotId},
                    success: function (returnStr) {
                        var type = returnStr.split("_")[0];
                        var id = returnStr.split("_")[1];
                        if (type == "success") {
                            dialog("成功", "success", true, 1);
                            var str = "/crm/customer_show?customer.id=" + id;
                            setTimeout(function () {
                                window.location = str;
                            }, 1000);
                        } else {
                            $("#saveBtn").show();
                            dialog(returnStr, "unsuccess", true, 2);
                        }
                        return false;
                    }
                });
            });

        }).bind("unmatch", function () {/**没有匹配时**/

        });
    }

    /*增加验证*/
    $("#type,#regional,#classify,#province,#city,#address").addClass("validate[required]");
    $("#salesOfLast,#salesOfNow,#capital,#empNum").addClass("validate[custom[integer]]");
    $("#contactChName,#position").addClass("validate[required]");
    $("#contactPhone").addClass("validate[required,custom[mobile]]");
    $("#contactEmail").addClass("validate[required,custom[email]]");

    /**
     * 点击保存按钮
     */

    $('#saveBtn').click(function () {
        var isPass = validationInput();
        if (isPass) {
            $("#customerName").val($("#chName").val());
            $('.btn-add-customer i').css({'display': 'inline'});
            $('.btn-add-customer').removeClass('none');
            $('#mask-div').css({'display': 'block', 'opacity': '0.6'});
            $('.popup-box').show();
        }
    });


    $('#btn-cancle').click(function () {
        $('#mask-div,.popup-box').hide();
        $("#contactChName").validationEngine('hidePrompt');
        $("#contactEmail").validationEngine('hidePrompt');
        $("#contactPhone").validationEngine('hidePrompt');
        $("#qq").validationEngine('hidePrompt');
        $("#tel").validationEngine('hidePrompt');
    });

    //执行保存
    $("#btn-save-contact").click(function () {
        var isPass = validationInput();
        if (isPass) {
            $("#btn-save-contact").hide();
            $("#addcustomerForm").attr("action", "/crm/customer_save");
            $("#addcustomerForm").ajaxSubmit(function (returnStr) {
                var type = returnStr.split("_")[0];
                var id = returnStr.split("_")[1];
                if (type == "success") {
                    dialog("成功", "success", true, 1);
                    var str = "/crm/customer_show?customer.id=" + id;
                    setTimeout(function () {
                        window.location = str;
                    }, 1000);
                } else {
                    $("#btn-save-contact").show();
                    dialog(returnStr, "unsuccess", true, 2);
                }
                return false;
            });

        }
    });


    /**
     * 省市级联
     */
    $("#province").bind('change', addCity);

    /* 验证输入 */
    function validationInput() {
        var chName = $("#chName").val();
        var enName = $("#enName").val();
        if (chName == "" && enName == "") {
            dialog("请至少为该公司填写一个名称！", "unsuccess", true, null);
            return false;
        }
        return $("#addcustomerForm").validationEngine('validate');
    };


    /**
     * 业务机会 相关
     */
        //点击代理线 ，显示代理产品线
    $("#productLineCheck").click(function () {
        if ($(this).attr("checked") == true) {
            $("#productLine").show();
        } else {
            $("#productLine").hide();
        }
    });

    //查询重复公司
    $("#chName").blur(function () {
        var customerName = $(this).val().trim();
        if ($(this).val().trim() != "") {
            $.ajax({
                method: 'get',
                url: "/crm/customer_haveCustomer",
                data: {'customer.chName': customerName},
                success: function (data) {
                    if (data == 'yes') {
                        $("#haveCusMes").show();
                        $("#saveBtn").hide();
                    } else {
                        $("#haveCusMes").hide();
                        $("#saveBtn").show();
                    }
                }
            });

        }
    });

});


function addCity() {
    $("#city").empty();
    if ($("#province").val() == '') {
        return;
    }
    var $city = $("#city");
    $.ajax({
        method: 'get',
        url: "/crmAjax/customer_findCityByProvince",
        data: {pid: $("#province").val()},
        dataType: 'json',
        success: function (data) {
            //alert(data.cityList.length);
            var option = "";
            for (var i = 0; i < data.cityList.length; i++) {
                option += "<option value='" + data.cityList[i] + "'>" + data.cityList[i] + "</option>";
            }
            $city.append(option);
        }
    });

};








