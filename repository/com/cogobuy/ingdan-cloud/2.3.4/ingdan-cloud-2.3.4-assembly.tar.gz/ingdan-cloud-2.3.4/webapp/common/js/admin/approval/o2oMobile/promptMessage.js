/**
 * 错误提示信息
 * @param promptP 信息提示框
 * @param errorMsg 信息内容
 * @param showTime 显示时间，如果没有时间，则一起显示
 */
function promptMessage($promptP,errorMsg,showTime){
	$promptP.text(errorMsg);
	$promptP.show();
	var isHiddenPrompt = true ;
	if(showTime==undefined || showTime=="" || showTime==false || showTime==null){
		isHiddenPrompt = false;
	}else{
		showTime = showTime*1000 ;
	}
	if(isHiddenPrompt){
		setTimeout(function(){$promptP.hide();},showTime);
	}
}
