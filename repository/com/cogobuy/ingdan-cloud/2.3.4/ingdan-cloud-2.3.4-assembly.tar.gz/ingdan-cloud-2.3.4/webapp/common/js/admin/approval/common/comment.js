var Comment = function(){};
/**
 * @author kentchen
 *
 */
Comment.prototype = {
		
		/**
		 * @param parent
		 * @param parentId
		 */
		add:function(formId){
			var content = $("#"+formId).find('textarea').val();
			if(''==$.trim(content)){
				dialog("请输入评论内容！","unsuccess",true,1);
				return;
			}
			$("#"+formId).ajaxSubmit(function(data,status){
				$("#"+formId).find('textarea').val("");
				var result = eval('(' + data + ')');
				if(result != null){
					$("#"+formId).parent("div").parent("div").find("#commentList").html(result.html);
				}
			});
		},
		
		/**
		 * @param id
		 */
		del:function(parent,parentId,id){
			$.ajax({
			    type:"GET",
			    url:encodeURI("/approvalajax/comment_delete"),
			    data:{"commentId":id,"parent":parent,"parentId":parentId},
			    success:function(data){
			    	var result = eval('(' + data + ')');
					if(result != null){
						$("#user_"+id).parent("li").parent("ul").parent("div").html(result.html);
					}
			    }
			});
		},
		
		reply:function (commentId){
			var content = $("#user_"+commentId).parent("li").parent("ul").parent("div").parent("div");
			content = content.find("#content");
			content.val("@"+$("#user_"+commentId).text());
		}
};

var comment = new Comment();
