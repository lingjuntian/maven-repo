var inventoryList;
var customerList;
var orderList;
$(function(){
	/* 模拟select下拉列表 */
	$(".options-select .select").click(function(event){
		event.stopPropagation();
		$(".popup-tips").fadeOut("slow");
		$(".input-box").css({zIndex:"0"});
		$(this).parents(".input-box").css({zIndex:"88"});
		var optionsObj = $(this).parent(".options-select").find(".options") ;
		$(".options-select .options").hide();
		if(optionsObj.hasClass("none")){
			optionsObj.show();
			optionsObj.removeClass("none")
		}else{
			optionsObj.hide();
			optionsObj.addClass("none")
		}
	})
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vhidden"));
		if($(this).parents(".options-select").find("input[id$=Id]")[0] != null){
			$(this).parents(".options-select").find("input").val($(this).attr("vhidden"));
			$(this).parents(".options-select").find("input[id$=Id]").val($(this).attr("labelId"));
		}else{
			if($(this).parents(".options-select").find("input").val() != $(this).attr("labelId")){
				$(this).parents(".options-select").find("input").val($(this).attr("labelId"));
				addTr(this);
				$(this).parents("tr").remove();
			}
		}
		if($(this).attr("tagN") == "bu"){
			$("#departmentId").val("");
			$("#department").val("");
			$("#personId").val("");
			$("#person").val("");
			$("#inventoryClass").val("");
			$("#inventoryClassId").val(""); 
			ajaxByBu($("#buId").val());
		}		
		$(this).parents(".options-select").find(".options").hide();
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	});
	
	$(".options-select .options,.popup-tips").click(function(event) {
		event.stopPropagation();
	});
	
	$(document).click(function(event) {
		$(".options-select .options").hide();
		$(".options-select .options").addClass("none");
		$(".popup-tips").fadeOut("slow");
	});
	
	$("#inventoryClass").addClass("validate[required]");
    $("#vendor").addClass("validate[required]");
    $("#invoiceDate").addClass("validate[custom[date]]");
    /**订单日期默认为当天的日期，绑定日期控件**/
	if($("#invoiceDate").val() == null || $("#invoiceDate").val() == ""){
		$("#invoiceDate").val(GetTodayDateStr());
	}
	$("#invoiceDate").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}, maxDate:GetTodayDateStr()});
	});

    $("#currencySelect").each(function(){
    	if($(this).find("input[id!=Id]").val() == null || $(this).find("input[id!=Id]").val() == ""){
	    	$(this).find("span").text($(this).find("li:eq(1)").find("a").attr("vhidden"));
	    	$(this).find("input[id!=Id]").val($(this).find("li:eq(1)").find("a").attr("vhidden"));
	    	$(this).find("input[id$=Id]").val($(this).find("li:eq(1)").find("a").attr("labelId"));
    	}
    });

	initTrEvents();
 	resetRowNO();
	
	$("#gotoStep2").click(function(){
    	gotoStep2();
    	return false;
    });
    
    $("#gotoStep1").click(function(){
    	gotoStep1();
    	return false;
    });
	
	$("#submit").click(function(){
		save();
		return false;
    });

	
	/*供应商*/
	$.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findAllVendor"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.vendorList != null){
                $("#vendor").autocomplete(data.vendorList, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-1'>编码</span> <span class='col-2'>名称</span></div>",
                    minChars: 0,
                    width: 310,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-1'>"+row.code+"</span> <span class='col-2'>"+row.name+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.name;
                    },
                    formatResult: function(row) {
                        return row.name;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                    $("#vendor").val(data.name);
                    $("#vendorId").val(data.id);
                }).bind("unmatch", function() {/**没有匹配时**/
                    $("#vendorId").val("");
                });
            }
        }
    });
    
    $("#selectAll").click(function(){
    	if($(this).attr("checked")){
    		$("#table [id=select]").attr("checked",true);
    	}else{
    		$("#table [id=select]").attr("checked",false);
    	}
    });
    
    $("#deleteSelect").unbind("click").click(function(){
    	if($("#table tr input:checked").size() > 0){
    		if (confirm("确定要删除这些行吗?")){
				$("#table tr input:checked").each(function(){
					var tr = $(this).parents("tr");
					tr.remove();
				});
				if($("#table tr").size() == 0){
					$("#saleOrderType,#forecastType").each(function(){
						var tr;
						tr = $(this).clone(true);	
						tr.attr("id", "");				
					    $("#table").append(tr);
					    tr.show();
	
						setInventoryAutoComplete(tr.find("[vhidden=inventoryCode]"), inventoryList);
						setCustomerAutoComplete(tr.find("[vhidden=customerName]"));
						setOrderAutoComplete(tr.find("[vhidden=saleOrderNo]"));
					});
				}
				resetRowNO();
			}
    	}else {
			dialog("请至少选择一项删除！","unsuccess",true,1);
		}
		return false;
    });
    	
   // ajaxInventoryList();
    ajaxCustomerList(); 
    ajaxOrderList();
});

//确认订单，进入下一步
function gotoStep2(){
	
	var error1 = checkPartNo("table");
	var error2 = $("#form").validationEngine('validate');
	showLineTips("table", "inventoryCode");

	if(error1 && error2 == true){
		copyData("form");
		copyTableDataThis("table");
		$("#step1").hide();
		$("#step2").show();
		copyFileList();//copy attachment list
		var url = "/approval/approval_emailList?approvalType="+ $("#approvalType").val() + "&parent=" + $("#parent").val();
		url += "&inventoryClassIdList=" + $("#inventoryClassId").val();
		$("#mailList").load(encodeURI(url), function(){
			
		});
	}
}
function copyTableDataThis(tableId){
	var len = $("#" + tableId + " tr").size();
	$("#" + tableId + "Td tr:gt(0)").remove();
	var totalSum = 0;
	var totalTaxSum = 0;
	var totalPurchaseSum = 0;
	var totalQuantity = 0;
	for(var i = 0; i < len; i++){
		var tr = $("#" + tableId + " tr").eq(i);
		var showTr = $("#" + tableId + "Td tr:eq(0)").clone();
		var j = 0;
		tr.find("input[type=text]").each(function(){
			if(j == 0){
				showTr.find("td:eq(" + j + ") div").text($(this).parents(".options-select").find(".select").find("span").text());
			}else{
				showTr.find("td:eq(" + j + ") div").text($(this).val());
			}
			j++;
		});

		showTr.appendTo("#" + tableId + "Td");
		showTr.show();
		if(i % 2 == 0){
	    	showTr.removeClass("even").removeClass("odd").addClass("even");
	    }
	    else if(i % 2 == 1){
	    	showTr.removeClass("even").removeClass("odd").addClass("odd");
	    }
	}
}
function save(){
	$("#copyTr").remove();
	//$("#orderForm").attr("action", "/admin/orderToken_create");
	$("#form").ajaxSubmit(function(returnStr){
        if (returnStr != "error") {
          dialog("成功！","success",true,1);
	      setTimeout(function(){window.location = "/approval/purchaseRequestApproval_show?id=" + returnStr},1000);	        
        } else if(returnStr == "error"){
         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
        }
      });
}

/**初始化行事件**/
function initTrEvents(){
	$("[id^=add]").click(function(){
    	addTr(this);
    	return false;
    });
    $("[id^=del]").click(function(){
    	moveTr(this);
    	return false;
    });

    $("[id^=expectDate]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}, minDate:GetTodayDateStr()});
	});
	
	$("[id^=unitprice]").unbind("change").change(function(event){
		var tr = $(this).parents("tr");
		$("#table [id^=inventoryCode]").each(function(){
			if($(this).val() == tr.find("[id^=inventoryCode]").val()){
				$(this).parents("tr").find("[id^=unitprice]").val(tr.find("[id^=unitprice]").val());
				changeSumPrice(this);
			}
		});
	});
    
    $("[id^=purchaseQuantity]").unbind("change").change(function(event){
		changeSumPrice(this);
	});
}

function ajaxOrder(saleOrderNo, $tr){
	
	var url = "/adminajax/master_findOrderInfo"
		+ "?saleOrderNo=" + saleOrderNo;
	$.ajax({
		type:"GET",
		url:encodeURI(disposeUrl(url)),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.info != null){
				var detailList = data.info.TOrderDetails;
				var len = detailList.length;
				var $preTr = $tr;
				$("#person").val(data.info.TPerson.personName);
				$("#personId").val(data.info.TPerson.id);
				$("#department").val(data.info.TDepartment.departmentName);
				$("#departmentId").val(data.info.TDepartment.id);
				$("#currency").val(data.info.TCurrency.currencyName);
				$("#currencyId").val(data.info.TCurrency.id);
				$("#currencySelect span").text(data.info.TCurrency.currencyName);
				for(var i = 0; i < len; i++){
					var orderDetail = detailList[i];
					var tr = $("#saleOrderType").clone(true);
					tr.find("[vhidden=inventoryCode]").val(resetNull(orderDetail.partNo));
					tr.find("[vhidden=saleOrderNo]").val(resetNull(data.info.saleOrderNo));
					tr.find("[vhidden=orderId]").val(resetNull(data.info.id));
					tr.find("[vhidden=customerName]").val(resetNull(data.info.TCustomer.fullName));
					tr.find("[vhidden=customerId]").val(resetNull(data.info.TCustomer.id));
					tr.find("[vhidden=unitprice]").val(resetNull(orderDetail.unitPrice));
					tr.find("[vhidden=orderQuantity]").val(resetNull(orderDetail.quantity));
					tr.find("[vhidden=purchaseQuantity]").val(resetNull(orderDetail.quantity));
					tr.find("[vhidden=sumprice]").val(resetNull(orderDetail.sum));
					tr.find("[id=sumprice]").val(resetNull(orderDetail.sum));
					tr.find("[vhidden=expectDate]").val(resetDate(orderDetail.expectDate));
					
					tr.insertAfter($preTr);
					tr.show();
					$preTr = tr;
					setInventoryAutoComplete(tr.find("[vhidden=inventoryCode]"), inventoryList);
					setCustomerAutoComplete(tr.find("[vhidden=customerName]"));
					setOrderAutoComplete(tr.find("[vhidden=saleOrderNo]"));
				}
				
				resetRowNO();
				$tr.remove();
				$("#form").validationEngine('hide');
			}
		}
	});
}
/** 自动计算总价格 **/
function changeSumPrice(object,tax){
   	var tr = $(object).parents("tr");
   	var num = tr.find("[id^=unitprice]").val()*tr.find("[id^=purchaseQuantity]").val();
	tr.find("[id^=sumprice]").val(cutZero(num.toFixed(2)));
}

function resetRowNO(){
	var len = $("#table tr").size();

	for(var i = len - 1; i >= 0; i--){
		var name = "purchaseRequestDetailList[" + i + "].";
		var tr = $("#table tr").eq(i);
		
		tr.find("input").each(function(){
			if($(this).attr("vhidden") != null && $(this).attr("vhidden") != ''){
				$(this).attr("name", name + $(this).attr("vhidden"));
				$(this).attr("id", $(this).attr("vhidden") + i);
			}
		});
		//tr.find("[id*=rowNo]").val(i+1);
		tr.find("#unitprice" + i).addClass("validate[required,max[100000],custom[positiveNumber]]");
	    tr.find("#orderQuantity" + i).addClass("validate[max[10000000],custom[positiveInteger]]");
	    tr.find("#purchaseQuantity" + i).addClass("validate[required,max[10000000],custom[positiveInteger]]");
	    tr.find("#expectDate" + i).addClass("validate[past[" + GetTodayDateStr() + "],custom[date]]");
	}

	if($("#table tr").size() >= 2){
  	   $("#table tr").find(".del").show();
    }else{
      $("#table tr").find(".del").hide();
    }
    
	$("#form").validationEngine('detach');
   	$("#form").validationEngine('attach');
}

function checkEmptyTr(tr){
	if(tr.find("[id^=inventoryCode]").val() == "" &&
		tr.find("[id^=unitprice]").val() == "" &&
		(tr.find("[id^=saleOrderNo]").val() == null || tr.find("[id^=saleOrderNo]").val() == "") &&
		(tr.find("[id^=orderQuantity]").val() == null || tr.find("[id^=orderQuantity]").val() == "") &&
		tr.find("[id^=purchaseQuantity]").val() == "" &&
		(tr.find("[id^=expectDate]").val() == null || tr.find("[id^=expectDate]").val() == "")){
			return true;
		}
	return false;	
}

function ajaxByBu(buId){
	$("#department").unautocomplete();
	$("#person").unautocomplete();
	$("#inventoryClass").unautocomplete();
	/* 部门 */
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/findDepartmentListByBu?buId="+buId),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.departmentList != null){
				$("#department").autocomplete(data.departmentList, {
					/**加自定义表头**/
					tableHead: "<div><span>部门名称</span></div>",
					minChars: 0,
					width: 300,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span>" + row.departmentName + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.departmentName;
					},
					formatResult: function(row) {
						return row.departmentName;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#departmentId").val(data.id);
					$("#department").val(data.departmentName);
				}).bind("unmatch", function(){
					$("#departmentId").val("");
					$("#department").val("");
				}).bind("unautocomplete", function() {              	
            		select.unbind();
            		$input.unbind();
            		$(input.form).unbind(".autocomplete"); 
            		/**当unautocomplete时将select中的数据清空**/
            		cache.flush();
            	});;
			}
		}
	}); 
	/* 业务员 */
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/findPersonListByBu?buId="+buId),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.personList != null){
				$("#person").autocomplete(data.personList, {					
					tableHead: "<div><span>业务员名称</span></div>",
					minChars: 0,
					width: 300,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span>" + row.personName + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.personName;
					},
					formatResult: function(row) {
						return row.personName;
					}
				}).result(function(e,data,value,sec){
					$("#personId").val(data.id);
					$("#person").val(data.personName);
				}).bind("unmatch", function(){
					$("#personId").val("");
					$("#person").val("");
				}).bind("unautocomplete", function() {              	
            		select.unbind();
            		$input.unbind();
            		$(input.form).unbind(".autocomplete"); 
            		/**当unautocomplete时将select中的数据清空**/
            		cache.flush();
            	});;
			}
		}
	}); 
	
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/findProductLineByBu?buId="+buId),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.productLineList != null){
				$("#inventoryClass").autocomplete(data.productLineList, {
					/**加自定义表头**/
					tableHead: "<div><span >产品线</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span >" + row.name + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.name;
					},
					formatResult: function(row) {
						return row.name;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#inventoryClass").val(data.name);	
					$("#inventoryClassId").val(data.id);
					setInventoryAutoComplete($("#table [id^=inventoryCode]"),data.id);					
				}).bind("unmatch",function(){
				//	$("#inventoryClass").val("");
				//	$("#inventoryClassId").val("");
				}).bind("unautocomplete", function() {              	
            		select.unbind();
            		$input.unbind();
            		$(input.form).unbind(".autocomplete"); 
            		/**当unautocomplete时将select中的数据清空**/
            		cache.flush();
            	});;
			}
		}
	}); 
}

 function setInventoryAutoComplete($input, productLineId){
	 $.ajax({
			type:"GET",
			url:encodeURI("/approvalajax/findInventorysByProductLine?productLineId="+productLineId),
			dataType:"json",
			success:function(data, textStatus){
				if(data != null && data.inventoryList != null){	
					inventoryList=data.inventoryList;
					$input.unautocomplete().autocomplete(data.inventoryList, {
						//加自定义表头
						tableHead: "<div><span class='col-1'>产品型号</span> <span class='col-2'>产品类型</span></div>",
						minChars: 0,
						width: 310,
						matchContains: "true",
						autoFill: false,
						formatItem: function(row, i, max) {
							return "<span class='col-1'>" + row.partNo + "</span> " + "<span class='col-2'>" + row.cinvName + "</span>";
						},
						formatMatch: function(row, i, max) {
							return row.partNo;
						},
						formatResult: function(row) {
							return row.partNo;
						}
					}).result(function(e,OneData,value,sec){//加选中后的回调函数
						$(this).parents("tr").find("[id^=inventoryCode]").val(OneData.partNo);
						$(this).parents("tr").find("[id^=inventoryClassId]").val(OneData.inventoryClassId);
						$(this).validationEngine('hidePrompt');
						inventoryList=data.inventoryList;
					}).bind("unmatch",function(){
						$(this).parents("tr").find("[id^=inventoryClassId]").val("");
					}).bind("unautocomplete", function() {              	
	            		select.unbind();
	            		$input.unbind();
	            		$(input.form).unbind(".autocomplete"); 
	            		/**当unautocomplete时将select中的数据清空**/
	            		cache.flush();
	            	});;					
				}
			}
		}); 
		
	}  
 function setInventoryAutoCompleteWithDate($input, inventoryList){
	$input.unautocomplete().autocomplete(inventoryList, {
		//加自定义表头
		tableHead: "<div><span class='col-1'>产品型号</span> <span class='col-2'>产品类型</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.partNo + "</span> " + "<span class='col-2'>" + row.cinvName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.partNo;
		},
		formatResult: function(row) {
			return row.partNo;
		}
	}).result(function(e,data,value,sec){//加选中后的回调函数
		$(this).parents("tr").find("[id^=inventoryCode]").val(data.partNo);
		$(this).parents("tr").find("[id^=inventoryClassId]").val(data.inventoryClassId);
		$(this).validationEngine('hidePrompt');
	}).bind("unmatch",function(){
		$(this).parents("tr").find("[id^=inventoryClassId]").val("");
	}).bind("unautocomplete", function() {              	
		select.unbind();
		$input.unbind();
		$(input.form).unbind(".autocomplete"); 
		/**当unautocomplete时将select中的数据清空**/
		cache.flush();
	});;							
}  
 
//添加行的方法
function addTr(object){ 
	var tr;
	if($(object).parents("tr").find("[id^=type]").val() == 'S'){
		tr = $("#saleOrderType").clone(true);
	}else if($(object).parents("tr").find("[id^=type]").val() == 'B'){
		tr = $("#bufferType").clone(true);
	}else if($(object).parents("tr").find("[id^=type]").val() == 'F'){
		tr = $("#forecastType").clone(true);
	}	
	tr.attr("id", "");				
    tr.insertAfter($(object).parents("tr"));
    tr.show();
    resetRowNO();
    setInventoryAutoCompleteWithDate(tr.find("[id^=inventoryCode]"), inventoryList);
	setCustomerAutoComplete(tr.find("[id^=customerName]"));
	setOrderAutoComplete(tr.find("[id^=saleOrderNo]"));
	$("#form").validationEngine('hide');
}

/**删除行时消除原有的提示信息**/
function clearTrTips(tr){
	tr.find("[id*=inventoryCode]").validationEngine('hidePrompt');
	tr.find("[id*=unitprice]").validationEngine('hidePrompt');
	tr.find("[id*=purchaseQuantity]").validationEngine('hidePrompt');
	tr.find("[id*=orderQuantity]").validationEngine('hidePrompt');
	tr.find("[id*=expectDate]").validationEngine('hidePrompt');
}

function ajaxCustomerList(){
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findCustomerList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.customerList != null){
				customerList = data.customerList;
				setCustomerAutoComplete($("#table [id^=customerName]"));
			}
		}
	}); 
}

function setCustomerAutoComplete($input){
	$input.unautocomplete().autocomplete(customerList, {
		/**加自定义表头**/
		tableHead: "<div><span style='width:40%' class='col-1'>客户编码</span> <span style='width:58%' class='col-2'>客户名称</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span  style='width:40%' class='col-1'>" + row.customerCode + "</span> " + "<span style='width:58%' class='col-2'>" + row.fullName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.fullName;
		},
		formatResult: function(row) {
			return row.fullName;
		}
		/*formatInputResult: function(data){
                 	autoCompleteCustomer(data)					
		},*/
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$(this).parents("tr").find("[id^=customerId]").val(data.id);
	}).bind("unmatch", function(){
		$(this).parents("tr").find("[id^=customerId]").val("");
	});
}

function ajaxOrderList(){
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findOrderList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.list != null){
				orderList = data.list;
				setOrderAutoComplete($("#table [id^=saleOrderNo]"));
			}
		}
	}); 
}

function setOrderAutoComplete($input){
	$input.unautocomplete().autocomplete(orderList, {
		/**加自定义表头**/
		tableHead: "<div><span >销售订单号</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span>" + row[1] + "</span> ";
		},
		formatMatch: function(row, i, max) {
			return row[1];
		},
		formatResult: function(row) {
			return row[1];
		}
		/*formatInputResult: function(data){
                 	autoCompleteCustomer(data)					
		},*/
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$(this).parents("tr").find("[id^=orderId]").val(data[0]);
		ajaxOrder($(this).val(), $(this).parents("tr"));
	}).bind("unmatch", function(){
		$(this).parents("tr").find("[id^=orderId]").val("");
		//ajaxOrder($(this).val(), $(this).parents("tr"));
	});
}