$(function() {
	/**
     * 文件上传
     */
    $("#fileId").change(function(){
    	fileUpload($(this).val(),"");
	});
	 /**
     * 文件下载
     */
	$("a[downFileTag=downFileTag]").click(function(){
		fileDownLoad($(this));
	});
});


function fileUpload(fileName){
	var data = {
			"key" : $("#key").val(),
			"uploadUser.id" : $("#uploadUserId").val(),
			"uploadUser.name" : $("#uploadUserName").val(),
			"fileName" : fileName
		};
	$.ajaxFileUpload({
		url: '/weixinApprovalAjax/attach_addToSession', //用于文件上传的服务器端请求地址
        secureuri: false, //一般设置为false
        fileElementId: 'fileId', //文件上传空间的id属性  <input type="file" id="file" name="file" />
        data: data,
        dataType: 'json', //返回值类型 一般设置为json
        success: function (data, status)  //服务器成功响应处理函数
        {
        	addFile(data.uploadmsg,fileName,"session");
        },
		error: function (data, status)  //服务器失败响应处理函数
	    {
			promptMessage($("#filePromptMessage"),"文件上传失败",3);
	    }
    });
    return false;
}

/*文件下载*/
function fileDownLoad($obj){
	$("#fileNameDownId").val($obj.attr("fileName"));
	$("#srcNameDownId").val($obj.attr("srcName"));
	$("#fileDownloadForm").submit();
}

/**
 * 文件上传显示
 */
function addFile(returnStr, fileName,type){
	var array = returnStr.split("##");
	var attachKey = $("#key").val()+"";
	var delAction = "/weixinApprovalAjax/attach_delFromSession?attachPath="+array[0];
	if(attachKey != 'undefined'){
		delAction += "&key="+attachKey;
	}
	var path = array[0];
	if(type != 'session'){
   		delAction = "/weixinApprovalAjax/attach_delete?id="+array[1];
   	}
	var _fileName = fileName.substring(fileName.lastIndexOf("\\") + 1);
	var liStr = "<p><i class=\"icon1\"></i>" +
					"<a downFileTag='downFileTag' fileName='"+path+"' srcName='"+_fileName+"' href=\"javascript:;\">"+_fileName+"</a>" +
       			"<i class=\"icon-del icon\"></i></p>";
   	$("#fileListDiv").prepend(liStr);
   	bindFileList(delAction);
 	/*重新生成文件上传按钮*/
	var filestr = "<input type=\"file\" name=\"file\" id=\"fileId\" style=\"opacity:0;cursor:pointer;\"/>";
	$("#fileId").remove();
	$("#fileCreate").append(filestr);
	$("#fileId").unbind("change");
	$("#fileId").bind("change",function(){
		fileUpload($(this).val(),type);
	  	return false;
	});
	return;
}


/**
 * 绑定填充文件操作
 */
function bindFileList(delAction){
	$("#fileListDiv i.icon-del").unbind("click");
	$("#fileListDiv i.icon-del").bind("click",function(){
		delFile($(this).parent("p"),delAction);
	  	return false;
	});
	$("#fileListDiv a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}

/**
 * 删除文件
 * @param filePath
 */
function delFile(obj,action){
	$.ajax({
        type:"GET",
        url:encodeURI(action),
        success:function(returnStr){
        	if (returnStr == "2") {
        		$(obj).remove();
        		return;
  	        } else{
  	        	promptMessage($("#filePromptMessage"),"文件删除失败",2);
  	        	return;
  	        }
        }
    });
}
