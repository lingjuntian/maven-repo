var autoCompleteplList;
$(function() {
	$("#bcRegisteredCapital,#bcPaidUpCapital").addClass("validate[custom[amountTen]]");
	/* 注册地点切换 */
	$(".form-company-register-place label").click(function(){
		var $id = $(this).attr("vhidden");
		var $obj = $(this).parents(".form-list-input");
		if($id == "companyHK"){
			$obj.find("[role='companyGuarantee']").show();
			$obj.find("[role='HK']").show();
			$obj.find("[role='CN']").hide();
			$obj.find("[role='change']").each(function(index, element) {
				$(this).find(".label").text($(this).find(".label").attr("data-hk-name"));
			});
		}else{
			$obj.find(".fieldset").show();
			$obj.find("[role='companyGuarantee']").hide();
			$obj.find("[role='HK']").hide();
			$obj.find("[role='CN']").show();
			$obj.find("[role='change']").each(function(index, element) {
				$(this).find(".label").text($(this).find(".label").attr("data-cn-name"));
			});
		}
		$(this).validationEngine('hidePrompt');
	});
	
	/* 需要开增值税发票 */
	$(".is-vat-li .input-checkbox").click(function(){
		if($(this).attr("checked")){
			$("#bankInfo").removeClass("none");
		}else{
			$("#bankInfo").addClass("none");
		}
	});
	
	/*增加日期控件*/
	$("#lastRhpj,#bcLastRhpj").click(function() {
		WdatePicker({maxDate : GetTodayDateStr()});
	});
	$("#licenseValidity,#bcLicenseValidity").click(function() {
		WdatePicker({minDate : GetTodayDateStr()});
	});
	
	
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function() {
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=id]").val($(this).attr("vid"));
		$(this).parents(".options-select").find("input[tag=show]").val($(this).attr("vshow"));
		$(this).validationEngine('hidePrompt');
		return false;
	});
	
	/* 添加一行 */
	$(".add-text").click(function(){
		var $tr = $(this).parents("tr");
		addTr($tr);
	});
	
	/*删除一行*/
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $length = $obj.parents("tbody").find("tr").length;
		if($length<2){
			dialog("请最少保留1行","warning",false,2);
			return false;
		}
		delTr($obj);
	});
	
	/* 自动匹配产品线 */
	setPlAutoComplete();
	
	/* 下一步 */
	$("#nextStep").click(function() {
		var error = validationBaseFrom("form");
		if(error){
			$("#nextStep").hide();
			$("#form").ajaxSubmit(function(returnStr) {
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					$("#nextFormInfoId").val(id);
					selectstep('/approval/caApproval_stepTwo');
				}else{
					$("#nextStep").show();
					dialog(returnStr,"unsuccess",true,2);
				}
				return false;
			});
		}
	});
});

/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.removeAttr("hide");
	$copyTr.removeAttr("style");
	$("#credListTbody").append($copyTr);
	addPlAutoComplete($copyTr.find("input[tdTag=productLine]"));
	addIdAndNameForInput($("#credListTbody"));
}

/* 删除行 */
function delTr($obj){
	$obj.validationEngine('hidePrompt');
	$obj.remove();
	addIdAndNameForInput($("#credListTbody"));
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
	var $trs = $tbody.find("tr");/* 获取所有tr */
	var firstName = "creditList";/* 前缀名称 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $inputNum = $tr.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $tr.find("input").eq(j);
			$input.attr("id", $input.attr("tdTag") + numtag);
			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
		}
	}
}

/*加载产品线*/
function setPlAutoComplete(){
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/custAApproval_findAllErpPL"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.erppl != null){
				autoCompleteplList = data.erppl;
				for(var i=0;i<autoCompleteplList.length;i++)
				{
					if(autoCompleteplList[i].unionName=="Broadcom")
					{
						autoCompleteplList.splice(i,1);
					}
					
					if(autoCompleteplList[i].unionName=="broadcom chipset")
					{
						autoCompleteplList.splice(i,1);
					}
					
				}
				addPlAutoComplete($("#credListTbody").find("input[tdTag=productLine]"));
			}
		}
	});
}

/*增加产品线自动匹配*/
function addPlAutoComplete($input){
	$input.autocomplete(autoCompleteplList, {
		/**加自定义表头**/
		tableHead:  "<div><span class='col-1'>CODE</span> <span class='col-2'>产品线</span></div>",
		minChars: 1,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.unionCode + "</span> " + "<span class='col-2'>" + row.unionName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.unionName;
		},
		formatResult: function(row) {
			return row.unionName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$input.val(data.unionName);
		$input.validationEngine('hidePrompt');
	}).bind("unmatch", function(){
		$input.val("");
	});
}

/*显示相应的选择项*/
$(window).load(function () {
	var companyTypeStr = $("#companyTypeStr").val();
	if(companyTypeStr == 1){
		$("#companyHK").trigger("click");
	}
});