$(function() {
	/*隐藏确定页面*/
	$("#confirm").hide();
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */	
		if (error) {
			switchPageForConfirm();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
            copyValueToConfig();/* 将新建页面的数值写入确认页面 */
            getEmailList();/* 获取邮件发送列表 */
            copyFileList();/*上传附件公用*/
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		$("#confirm").hide();
		$("#write").show();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#dimissionForm").append(inputStr);
    		}
    	});
		
    	$("#submit").hide();
    	$("#dimissionForm").attr("action","/approval/dimission_create");
		$("#dimissionForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/dimission_show?dimissionApproval.id="+id;},1000);	  
			}else {
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}	
	        return false;
			
		});
	});

});


/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#dimissionForm").validationEngine('validate');
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
    /*清空备注*/
	$("#remark_confirm").text("");
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*写值*/
     $("#name_confirm").text($("#name").val());
	 $("#department_confirm").text($("#department").val());
	 $("#position_confirm").text($("#position").val());
	
	 if(($("#Storage").is(':checked'))){
		 $("#storage").val("已归还")
	 }else{
		 $("#storage").val("未归还")
	 }
	 if(($("#Stamp").is(':checked'))){
		 $("#stamp").val("已归还")
	 }else{
		 $("#stamp").val("未归还")
	 }
	 if(($("#FileResource").is(':checked'))){
		 $("#fileResource").val("已归还")
	 }else{
		 $("#fileResource").val("未归还")
	 }
	 if(($("#CustomerResource").is(':checked'))){
		 $("#customerResource").val("已归还")
	 }else{
		 $("#customerResource").val("未归还")
	 }
	 if(($("#MailDuration").is(':checked'))){
		 $("#mailDuration").val("已归还")
	 }else{
		 $("#mailDuration").val("未归还")
	 }
	 if(($("#ReceiveAccounts").is(':checked'))){
		 $("#receiveAccounts").val("已归还")
	 }else{
		 $("#receiveAccounts").val("未归还")
	 }
	 if(($("#DevelopResource").is(':checked'))){
		 $("#developResource").val("已归还")
	 }else{
		 $("#developResource").val("未归还")
	 }
	 if(($("#ReturnSamples").is(':checked'))){
		 $("#returnSamples").val("已归还")
	 }else{
		 $("#returnSamples").val("未归还")
	 }
	 $("#storage_confirm").text($("#storage").val()+","+$("#storageMoney").val())
	 $("#stamp_confirm").text($("#stamp").val()+","+$("#stampMoney").val());
	 $("#fileResource_confirm").text($("#fileResource").val()+","+$("#fileResourceMoney").val());
	 $("#customerResource_confirm").text($("#customerResource").val()+","+$("#customerResourceMoney").val());
	 $("#mailDuration_confirm").text($("#mailDuration").val()+","+$("#mailDurationMoney").val());
	 $("#receiveAccounts_confirm").text($("#receiveAccounts").val()+","+$("#receiveAccountsMoney").val());
	 $("#returnSamples_confirm").text($("#returnSamples").val()+","+$("#returnSamplesMoneyMoney").val());
	 $("#developResource_confirm").text($("#developResource").val()+","+$("#developResourceMoney").val());
	 $("#yszkToker_confirm").text($("#yszkToker").val());
	 $("#kcToker_confirm").text($("#kcToker").val());
	 $("#ypghToker_confirm").text($("#ypghToker").val());
	 $("#mailDurationDay_confirm").text($("#mailDurationDay").val());
		
}

/* 获取邮件发送列表 */
function getEmailList() {
	var url = "/approval/dimission_showConfirmMail";
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#submit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else if(nodeNoApprovalUser){
			$("#submit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else{
			$("#submit").show();
		}
	});
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").show();
	$("#write").hide();
}

