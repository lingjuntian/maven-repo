/**
 * 审核通过
 * @param parent
 */
function approval(parentId,returnUrl) {
   /* 审批通过前检验当前审批人是否sales,如果是salas,审批通过前必须填写超期原因*/
    if($("#nodeCode").val()=='sales'){
        if($("#remark").val()==null||$("#remark").val().replace(/^\s+|\s+$/g,"").length<5){
            dialog("sales必须要填写5字以上的超期原因才能通过审批的噢！");
            return;
        }
      /* 提交超期原因，如果提交失败。则审批不能通过*/
        if(updateRemark()==false){
        	return ;
        } 
    }
    
	var data = {
			"esMain.id" : parentId,
			"mails" : getApprovalMail()
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/excessShipping_approval"),
		data : data,
		success : function(returnStr) {
			if (returnStr == 'success') {
				dialog("成功", "success", true, 2);
				window.location.href = returnUrl;
			} else {
				$(".button-yellow").show();
				dialog(returnStr, "unsuccess", true, 10);
			}
		}
		});
}


/*sct直接审完成*/
function sctApproval(parentId,returnUrl) {  
		var data = {
				"esMain.id" : parentId,
				"mails" : getApprovalMail()
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/approval/excessShipping_sctApproval"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					window.location.href = returnUrl;
				} else {
					$(".button-yellow").show();
					dialog(returnStr, "unsuccess", true, 10);
				}
			}
			});
	}




/*显示隐藏AR明细*/
$(function(){
    $("#hideAR").hide();
    $("#arTable").hide();
    $("#showAR").click(
        function showAR(){
            $("#hideAR").show();
            $("#arTable").show();
            $("#showAR").hide();
        }
    );
    $("#hideAR").click(
        function hideAR(){
            $("#hideAR").hide();
            $("#arTable").hide();
            $("#showAR").show();
        }
    );
    


});

function updateRemark(){
    var remark=$("#remark").val();
    var id=$("#esMainId").val();
    if(remark=null||remark==""){
        dialog("sales必须填写超期原因（回款计划）的噢！");
        return false;
    }
    if(id=null||id==""){
        dialog("id为空！");
        return false;
    }
    
    $.ajax({
        url:encodeURI("/approvalajax/esApproval_updateRemark"),
        data:{esMainId:$("#esMainId").val(),remark:$("#remark").val()},
        type:"post",
        success:function(returnStr){
        	if(returnStr="successnull"){
        		dialog("成功", "success", true, 2);
        		return true;
        	}else{
        		dialog(returnStr, "unsuccess", true, 2);
        		return false;
        	}
        },
        error:function(){
            dialog("请求错误，请联系管理员");
            return false;
        }
    });
}
