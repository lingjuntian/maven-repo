
$(function(){
	//最好不要有中文地址
	//https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxac32306dc03d1f40
	//&redirect_uri=http://weixin.foxsaas.com/bind&response_type=code&scope=snsapi_base&state=128#wechat_redirect",
	var url = location.href.split('#')[0], /*分享的地址*/
        image = "",
        desc = '',//分享描述
        title = ""/*分享标题*/,
        appId = '',
        timestamp = 0,
        nonceStr = '',
        signature = '';
        //alert(url);
        //url = encodeURIComponent(encodeURIComponent(url));
    $.ajax({
        url: "/JsAPI/getWXShare",
        type: "get",
        data: {url:url},
        dataType: 'json',
        success: function (data) {
            url = url;
            image = "http://res.foxsaas.com/msaasdist/images/headimg.jpg";
            title = "邀请你使用赤狐CRM平台";
            desc = "";
            
            appId = data.appId;
            timestamp = data.timestamp;
            nonceStr = data.nonceStr;
            signature = data.signature;
            init();
        },
        error: function (data) {

        }
    });

    function init(){
        //JS-SDK的页面配置信息
        wx.config({
            //debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: appId, // 必填，公众号的唯一标识
            timestamp: timestamp, // 必填，生成签名的时间戳
            nonceStr: nonceStr, // 必填，生成签名的随机串
            signature: signature,// 必填，签名，见附录1
            jsApiList: ['checkJsApi', 'onMenuShareTimeline', 'onMenuShareAppMessage'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
        });
        wx.ready(function () {
            // 在这里调用 API
            // 1 判断当前版本是否支持指定 JS 接口，支持批量判断
            wx.checkJsApi({
                jsApiList: [
                  'getNetworkType',
                  'previewImage'
                ],
                success: function (res) { 
                //	alert("检查成功");
                },
                error: function (res) {
                	
                }
            });
            

            // 2. 分享接口
            //获取“分享到朋友圈”按钮点击状态及自定义分享内容接口
            wx.onMenuShareTimeline({
                title: "赤狐CRM－扫描一张名片，获得一个系统推荐的潜在客户。", // 分享标题
                link: url+"?invitee=yes", // 分享链接
                imgUrl: image, // 分享图标
                trigger: function (res) {
               // 	alert("分享到朋友圈");
                },
                success: function (res) { 
                	
                },
                cancel: function (res) { 
                	
                }
            });

            //获取“分享给朋友”按钮点击状态及自定义分享内容接口
            wx.onMenuShareAppMessage({
                title: "赤狐CRM－扫描一张名片，获得一个系统推荐的潜在客户。",
                desc: "用微信就可以直接扫客户名片，还能获得赤狐推荐的新客户",
                link: url+"?invitee=yes",
                imgUrl: image,
                trigger: function (res) {
               // 	alert("分享给朋友");
                },
                success: function (res) {
                	
                },
                cancel: function (res) {
                	
                },
                fail: function (res) {
                	
                }
            });
                     
        });

    }
 
 });