$(function() {
	var $getVerifyCode = $('#getVerifyCode'),
		$submit_verify = $('#submit_verify'),
		$formTips = $('.form-tips'),
		$msg = $('#msg'),
		formtipsTime = null;

	// 获取手机验证码
	$getVerifyCode.on('click', function() {
		getVerifyCode();
	});

	// 提交
	$submit_verify.on('click', function() {
		submit_verify();
	});

	// $getVerifyCode.addClass('disabled');

	// 获取验证码
	function getVerifyCode() {
		if ($getVerifyCode.hasClass('disabled')) {
			return false;
		}
		$getVerifyCode.addClass('disabled');// 倒计时过程中禁止点击按钮

		var phone = $('#phone').val();

		if (!verifyMobile(phone)) {
			baseEvn.tipShow('请输入正确的手机号码');
			$getVerifyCode.removeClass('disabled');
			return false;
		}

		phone = $('input[name="areaCode"]').val() + phone;

		// var url = '/user/getVerifyCode?mobile=' + phone;
		var url = '/user/getVerifyCode';

		time($getVerifyCode, 60);

		$.ajax({
			type : 'post',
			url : url,
			data: {
				mobile: phone
			},
			success : function(msg) {
				if (msg.type == 'error') {
					if (msg.content == 'error_mobile') {
						baseEvn.tipShow('手机号格式不正确');
					} else if (msg.content == 'CAPTCHA_INTERVAL') {
						baseEvn.tipShow('验证码已经发送,请一分钟后再获取验证码');					
					}else{
						baseEvn.tipShow('未知错误，请联系我们解决');
					}

					time($getVerifyCode, 0);
					$getVerifyCode.removeClass('disabled');

				} else if (msg.type == 'success') {
					baseEvn.tipShow('验证码已经发送，请查收');
				}
			},
			error : function(e) {
				baseEvn.tipShow('出错：' + e);
				time($getVerifyCode, 0);
			}
		});
	}

	// 提交手机及验证码
	function submit_verify() {
		if ($submit_verify.hasClass('disabled')) {
			return false;
		}
		$submit_verify.addClass('disabled');


		var phone = $('#phone').val();
		var VerifyCode = $('#captcha').val();

		if (!verifyMobile(phone)) {
			baseEvn.tipShow('请输入正确的手机号码');
			$submit_verify.removeClass('disabled');
			return false;
		}

		if (VerifyCode.length != 4) {
			baseEvn.tipShow('请输入正确验证码');
			$submit_verify.removeClass('disabled');
			return false;
		}

		phone = $('input[name="areaCode"]').val() + phone;

		$.ajax({
			type : 'post',
			// url : '/user/checkVerifyCode?mobile=' + phone + '&verifyCode=' + VerifyCode,
			url : '/user/checkVerifyCode',
			data: {
				mobile: phone,
				verifyCode: VerifyCode
			},
			success : function(data) {
				if (data == 'checkFail' || data == 'fail') {
					baseEvn.tipShow('验证码错误');
				} else if (data == 'invalid') {
					baseEvn.tipShow('验证码失效');
				} else if (data == 'success') {
					// 验证成功
					window.location.href = '/user/turn';
				} else {
					baseEvn.tipShow(data);
				}

				$submit_verify.removeClass('disabled');
			},
			error : function(e) {
				baseEvn.tipShow('出错：' + e);
				$submit_verify.removeClass('disabled');
			}
		});
	}

	// 倒计时
	function time(o, wait) {// o为按钮的对象，这里是60秒过后，提示文字的改变
		
		wait--;

		if (wait <= 0) {
			o.removeClass('disabled').html('获取验证码');// 改变按钮中value的值

		} else {
			o.addClass('disabled').html(wait + '秒后重新发送');// 改变按钮中value的值

			setTimeout(function() {
				time(o, wait);// 循环调用
			}, 1000);
		}
	}

	// 验证手机号
	function verifyMobile(mobile) {
		// var reg = /^1[3458]\d{9}$/;
		// if (!(reg.test(mobile))) {
		// 	return false;
		// } else {
		// 	return true;
		// }

		return ($.trim(mobile).length > 0) ? true : false;
	}
});

