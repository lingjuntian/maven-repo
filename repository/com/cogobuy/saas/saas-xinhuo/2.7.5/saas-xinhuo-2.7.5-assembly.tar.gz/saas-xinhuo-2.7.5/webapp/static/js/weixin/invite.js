
$(function(){
	//最好不要有中文地址
	//https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxac32306dc03d1f40
	//&redirect_uri=http://weixin.foxsaas.com/bind&response_type=code&scope=snsapi_base&state=128#wechat_redirect",
	var url = location.href.split('#')[0], /*分享的地址*/
        image = "",
        desc = '',//分享描述
        title = ""/*分享标题*/,
        appId = '',
        timestamp = 0,
        nonceStr = '',
        signature = '';
        //alert(url);
        //url = encodeURIComponent(encodeURIComponent(url));
    $.ajax({
        url: "/JsAPI/getWXShare",
        type: "get",
        data: {url:url},
        dataType: 'json',
        success: function (data) {
            url = url;
            image = "http://res.foxsaas.com/msaasdist/images/headimg.jpg";
            title = "邀请你使用赤狐CRM平台";
            desc = "【"+$("#userName").val()+"】邀请你加入【"+$("#companyName").val()+"】";
            
            appId = data.appId;
            timestamp = data.timestamp;
            nonceStr = data.nonceStr;
            signature = data.signature;
            init();
        },
        error: function (data) {

        }
    });

    function init(){
        //JS-SDK的页面配置信息
        wx.config({
            //debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: appId, // 必填，公众号的唯一标识
            timestamp: timestamp, // 必填，生成签名的时间戳
            nonceStr: nonceStr, // 必填，生成签名的随机串
            signature: signature,// 必填，签名，见附录1
            jsApiList: ['onMenuShareTimeline','onMenuShareAppMessage'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
        });


        wx.ready(function () {
            // 在这里调用 API
            // 1 判断当前版本是否支持指定 JS 接口，支持批量判断
            wx.checkJsApi({
                jsApiList: [
                  'getNetworkType',
                  'previewImage'
                ],
                success: function (res) {
                  //alert(JSON.stringify(res));
                },
                error: function (res) {
                    //alert(JSON.stringify(res));
                  }
            });
            

            // 2. 分享接口
            //获取“分享到朋友圈”按钮点击状态及自定义分享内容接口
            wx.onMenuShareTimeline({
                title: desc, // 分享标题
                link: url, // 分享链接
                imgUrl: image, // 分享图标
                success: function (res) { 
                    // 用户确认分享后执行的回调函数
                	$("#pop3").show();
                },
                cancel: function (res) { 
                    // 用户取消分享后执行的回调函数
                }
            });

            //获取“分享给朋友”按钮点击状态及自定义分享内容接口
            wx.onMenuShareAppMessage({
                title: title,
                desc: desc,
                link: url,
                imgUrl: image,
                trigger: function (res) {
                    //alert('用户点击发送给朋友');
                },
                success: function (res) {
                     $("#pop3").show();
                },
                cancel: function (res) {
                     //alert('已取消');
                },
                fail: function (res) {
                    // alert(JSON.stringify(res));
                }
            });

             
        });

    }
 
 });