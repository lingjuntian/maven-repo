
$(function(){
	var $getVerifyCode = $('#getVerifyCode'),
		$submit_verify = $('#joinBtn'),
		$formTips = $('.form-tips'),
		$msg = $('#msg'),
		formtipsTime = null;
	
	var isVerifyOK = false;

	// 获取手机验证码
	$getVerifyCode.on('click', function() {
		getVerifyCode();
	});

	// 提交
	$submit_verify.on('click', function() {
		var staffname = $('#staffname').val();
		if (staffname.length <1) {
			baseEvn.tipShow('请输入你的姓名');
			$submit_verify.removeClass('disabled');
			return false;
		}
		var email = $('#email').val();
		if (email.length <1) {
			baseEvn.tipShow('请输入你的邮箱');
			$submit_verify.removeClass('disabled');
			return false;
		}
		submit_verify();
	});
	
	$('body').on('click', '#msgBtn,#pageCloseBtn', function(){
		wx.closeWindow();
	});
	
	
	// 获取验证码
	function getVerifyCode() {
		if ($getVerifyCode.hasClass('disabled')) {
			return false;
		}
		$getVerifyCode.addClass('disabled');// 倒计时过程中禁止点击按钮

		var _phone = $('#phone').val(),
			_code = $('input[name="code"]').val();

		if (!verifyMobile(_phone)) {
			baseEvn.tipShow('请输入正确的手机号码');
			$getVerifyCode.removeClass('disabled');
			return false;
		}

		time($getVerifyCode, 60);

		$.ajax({
			type : 'post',
			url : '/invite/getVerifyCode',
			data: {
				code: _code,
				mobile: _phone
			},
			success : function(result) {
				if (result.type == 'error') {
					if (result.content == 'error_mobile') {
						baseEvn.tipShow('手机号格式不正确');
					} else if (result.content == 'CAPTCHA_INTERVAL') {
						baseEvn.tipShow('验证码已经发送,请一分钟后再获取验证码');					
					}else{
						baseEvn.tipShow('未知错误，请联系我们解决');
					}

					time($getVerifyCode, 0);
					$getVerifyCode.removeClass('disabled');

				} else if (result.type == 'success') {
					baseEvn.tipShow('验证码已经发送，请查收');
				}
			},
			error : function(e) {
				baseEvn.tipShow('出错：' + e);
				time($getVerifyCode, 0);
			}
		});
	}

	// 提交手机及验证码
	function submit_verify() {
		if ($submit_verify.hasClass('disabled')) {
			return false;
		}
		$submit_verify.addClass('disabled');

		if(isVerifyOK){
			// 验证成功
			join();
			return false;
		}

		var _code = $('input[name="code"]').val(),
			_phone = $('#phone').val(),
			_VerifyCode = $('#captcha').val();

		if (!verifyMobile(_phone)) {
			baseEvn.tipShow('请输入正确的手机号码');
			$submit_verify.removeClass('disabled');
			return false;
		}

		if (_VerifyCode.length != 4) {
			baseEvn.tipShow('请输入正确验证码');
			$submit_verify.removeClass('disabled');
			return false;
		}

		// phone = $('input[name="areaCode"]').val() + phone;

		$.ajax({
			type : 'post',
			// url : '/invite/checkVerifyCode?mobile=' + phone + '&verifyCode=' + VerifyCode,
			url : '/invite/checkVerifyCode',
			data: {
				code: _code,
				mobile: _phone,
				verifyCode: _VerifyCode
			},
			success : function(result) {
				isVerifyOK = false;
				if (result == 'checkFail' || result == 'fail') {
					baseEvn.tipShow('验证码错误');
				} else if (result == 'invalid') {
					baseEvn.tipShow('验证码失效');
				} else if (result == 'success') {
					isVerifyOK = true;
					// 验证成功
					join();
				} else {
					baseEvn.tipShow(result);
				}

				$submit_verify.removeClass('disabled');
			},
			error : function(e) {
				baseEvn.tipShow('出错：' + e);
				$submit_verify.removeClass('disabled');
			}
		});
	}
	
	function join() {
 		var $this = $(this);

        if ($this.hasClass('disabled')) {
            return false;
        }
        $this.addClass('disabled');


        var _mobile = $('input[name="staffMobile"]').val(),
        	_areaCode = $('input[name="code"]').val();

        // $('input[name="staffMobile"]').val(_areaCode + _mobile);

 		$.ajax({
	        type: "POST",
	        url: "/invite/add",
	        data: $("#inviteForm").serialize(),
	        success:function(result){
 				if(result.type == "success"){
					baseEvn.popFun({
                        contentTxt: '成功加入['+ result.args.companyName +']!</br>您的赤狐账号已通过短信发送到您的手机上。',
                        cancelBtn: '',
                        //confirmBtn: '<a href="/user/toBind" id="msgBtn" class="in-btn js-pop-close">确定</a>',
                        confirmBtn: '<a href="http://www.foxsaas.com/login/byWeiXinInvite?userId='+ result.args.userId +'"   class="in-btn js-pop-close">登录赤狐</a>',
                        confirmCallback: function(){
                            
                        }
                    });

                    $('#inviteForm input').val('');
				}else { 
		            if(result.content == "repeat"){
		            	baseEvn.popFun({
	                        contentTxt: '你已经加入到团队了，请勿重复加入',
	                        confirmCallback: function(){
	                            wx.closeWindow();
	                        }
	                    });
		            }else{
		            	baseEvn.tipShow(result.content);
		            }
	            }
	        },
	        error:function(e) {
	            baseEvn.tipShow('提交失败，请稍后重新尝试！');
	        },
            complete: function(){
                $this.removeClass('disabled');
                $('input[name="staffMobile"]').val(_mobile);
            }
        });
	}
	
	// 倒计时
	function time(o, wait) {
		// o为按钮的对象，这里是60秒过后，提示文字的改变
		
		wait--;

		if (wait <= 0) {
			o.removeClass('disabled').html('获取验证码');// 改变按钮中value的值

		} else {
			o.addClass('disabled').html(wait + '秒后重新发送');// 改变按钮中value的值

			setTimeout(function() {
				time(o, wait);// 循环调用
			}, 1000);
		}
	}

	// 验证手机号
	function verifyMobile(mobile) {
		// var reg = /^1[3458]\d{9}$/;
		// if (!(reg.test(mobile))) {
		// 	return false;
		// } else {
		// 	return true;
		// }

		return ($.trim(mobile).length > 0) ? true : false;
	}
 });