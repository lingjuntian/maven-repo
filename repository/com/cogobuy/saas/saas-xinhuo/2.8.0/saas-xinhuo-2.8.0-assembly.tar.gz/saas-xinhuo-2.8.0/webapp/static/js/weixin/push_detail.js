$(function(){
	var uselessAjax = function(id){
		$.ajax({
            url: '/customerPush/useless',
            type:'post',
            data : {id: id},
            success : function(res){
            	//do nothing
            }
        })
	}
	
	var reasonAjax = function($this, id, reason){
		$.ajax({
            url: '/customerPush/reason',
            type:'post',
            data : 
            {
            	id: id,
            	reason: reason
            },
            success : function(res){
                if(res.type == 'success'){
                    $userSurvey.fadeOut();
                }else{
                    alert(res.content);
                }
                $this.removeClass('posting');
            }
        })
	}
	
	var usefullAjax = function($this, id){
		$.ajax({
            url: '/customerPush/usefull',
            type:'post',
            data : {id: id},
            success : function(res){
            	if(res.type="success"){
            		$this.addClass('sel').siblings().hide().parents('.recommend-user-comment').hide();
                	$this.text("已保存为我的客户");
                	$this.parents('.recommend-user-comment').show();
                	window.setTimeout(function(){
                		/*跳转至分享页面*/
                        window.location.href='/share/index';
			        }, 2000);
            	}else{
            		alert(res.content);
            	}
            }
        })
	}
	
	//*********************************点击事件**************************************//
    $('.loading').fadeOut();
	var $commentBox = $('.recommend-user-comment'),
        $userSurvey = $('.user-survey'),
	    $recommendInfo = $('.recommend-client-info');
	
	$recommendInfo.on('click','.web-visit',function(){
		var url = $(this).attr("website");
		if(url.indexOf("http")==0){
			location.href=url;
		}else{
			location.href="//"+url;
		}
		
	});

	/*有用或无用*/
	$commentBox.on('click','.user-tap a',function(){
		var $this = $(this);
		var id = $this.attr("data-id");
        if($this.hasClass('useless')){
            $userSurvey.fadeIn();    
            uselessAjax(id);
        }else{
        	usefullAjax($this, id);
        }

	}) ;

    /*原因切换*/
    $userSurvey.on('click','.reason-list li',function(){
        $(this).addClass('active').siblings().removeClass('active');
    });

    /*用户调查提交*/
    $userSurvey.on('click','.js-submit',function(){
        var $this = $(this);
        /*阻止多次提交*/
        if($this.hasClass('posting')) return false;
        $this.addClass('posting');
        var reason = $userSurvey.find('.reason-list li.active').data('id');
        var id = $userSurvey.attr("data-id");
        reasonAjax($this, id, reason);
        return false;
    });
    
});