var moduleName = 'customer';

(function($){

	var customerEvn = {},
	$wrapper = $('#wrapper'),
	$pageLeft = $('#pageLeft'),
	$contentWrapper = $('#contentWrapper');
	$body = $('body');
	$pop = $('body .pop');
	// 查看详情
	customerEvn.getDetail = function(){

	};


	// 初始化
	customerEvn.init = function(){
		
	// 详情页的tab切换
	$contentWrapper.on('click','.js-detail-nav a',function(){
		var Idx = $(this).index();
		$(this).addClass('active').siblings().removeClass('active');
		$contentWrapper.find('.detail-main .main-item').eq(Idx).addClass('active').siblings().removeClass('active');
		
		var opts = {};
		var datatype=$(this).attr('data-type');
		switch (datatype){
			case 'report':
				opts = {
					url:'/communication/findTab',
					data:{
						type:moduleName,
						dataId: pageDataSet.dataId
					},
					tplId: '#infoDetailReportTpl',
					outputId: 'div.main-item.item-report'
				};
				break;
			case 'data':
				opts = {
					url:'/customer/get',
					data:{
						type:moduleName,
						dataId: pageDataSet.dataId
					},
					tplId: '#infoDetailCustomerTpl',
					outputId: 'div.main-item.item-customer'
				};
				break;
			case 'contact':
				opts = {
					url:'/contacts/findTab',
					data:{
						type:moduleName,
						dataId: pageDataSet.dataId
					},
					tplId: '#infoDetailContactTpl',
					outputId: 'div.main-item.item-contact'
				};
				break;
			case 'chance':
				opts = {
					url:'/opportunity/findTab',
					data:{
						type:moduleName,
						dataId: pageDataSet.dataId
					},
					tplId: '#infoDetailChanceTpl',
					outputId: 'div.main-item.item-chance'
				};
				break;
			case 'service':
				opts = {
					url:'/service/findTab',
					data:{
						type:moduleName,
						dataId: pageDataSet.dataId
					},
					tplId: '#infoDetailServerTpl',
					outputId: 'div.main-item.item-server'
				};
				break;	
			case 'task':
				opts = {
					url:'/customer/findTask',
					data:{
						type:moduleName,
						customerId: pageDataSet.dataId
					},
					tplId: '#infoDetailTaskTpl',
					outputId: 'div.main-item.item-task'
				};
				break;
			default:
				break;
		}
		
		//console.log(opts);
		var tabJqx = baseEvn.ajaxFun(opts);
		tabJqx.done(function(result){
			if (result.type === "success") {
			
				if(datatype === 'report'){
					//单独处理日期格式
					for (var i=0,len = result.args.length;i < len; i++) {
						var commTime = result.args[i].commTime;
						var date = new Date(Date.parse(commTime));
						result.args[i].commTime2 = date.getMonth() + "月" + date.getDay() + "日";
					}
				}
				renderEvn.renderTplV2({
					tplId: opts.tplId,
					outputId: opts.outputId,
					data: result
				});
			}
			
		});
		
	});
	
	// 右侧栏-操作区域-添加
	customerEvn.detailOpt = function(){
		$contentWrapper.on('click','.js-detail-opt a',function(){			
			var type = $(this).attr('data-type'),
				tplId = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'report':
					tplId = '#popAddReportTpl';
					break;
				case 'contact':
					tplId = '#popAddContactTpl';
					break;
				case 'chance':
					tplId = '#popAddChanceTpl';
					break;
				case 'service':
					tplId = '#popAddServicetTpl';
					break;
				case 'del':
					tplId = '#popSingleCustomerTpl';
					break;
				case 'transform':
					tplId = '#popMoveTpl';
					break;
				case 'task':
					tplId = '#popAddtasktTpl';
					break;
			}
			
			// 渲染模板
			if (type){
				renderEvn.renderTpl({
					tplId: tplId,
					outputId: '#contentInfo',
					insetType: 'prepend',
					data:{
						customerId:pageDataSet.dataId,
						customerName:pageDataSet.customerName
					}
				});
				$('#pop').show();
				popEvn.setPopcontentHeight();
			}
			
		});	
	};
	
	// 弹出框-保存（确定）
	customerEvn.saveOpt = function(){
		$pop.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'addCustomer':
					ajaxUrl = '/customer/add';
					break;
				case 'report':
					ajaxUrl = '/communication/add';
					break;
				case 'contact':
					ajaxUrl = '/contacts/add';
					break;
				case 'chance':
					ajaxUrl = '/opportunity/add';
					break;
				case 'service':
					ajaxUrl = '/service/add';
					break;
				case 'del':
					ajaxUrl = '/customer/delete';
					break;
				case 'transform':
					ajaxUrl = '/customer/changeCharge';
					break;
				case 'task':
					ajaxUrl = '/customer/createTask';
					break;
				case 'addMember':
					ajaxUrl = '/customer/addShareEmployee';
					break;
			}
			if(ajaxUrl){
				//表单提交
				var formData = $(this).parents("form:first").serialize();
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});
				formJqx.done(function(result){
					if(result.type=="success"){
						$item.parents('.pop-main').remove();
						$("#pop").hide();
					}else if(result.type=="error"){
						alert(result.content);
					}
				});
			}
		});	
	};
	
	// 右侧栏 - 添加成员
	customerEvn.addRelativeStaff = function(){
		$contentWrapper.on('click','.js-add-staff-btn',function(){
			renderEvn.renderTpl({
				tplId: '#popAddMember',
				outputId: '#pop',
				insetType: 'prepend',
				data:{
					customerId:pageDataSet.dataId,
					customerName:pageDataSet.customerName
				}
			});
			$('#pop').show();
			popEvn.setPopcontentHeight();
		});
	};

	// 左侧操作区 添加按钮显示
	$contentWrapper.on('click','.js-icon-add',function(){
		$contentWrapper.find('.js-detail-opt .sub-menu').addClass('active');
	});

	// 左侧操作区 添加按钮隐藏
	$contentWrapper.on('mouseleave','.js-detail-opt .sub-menu',function(){
		$contentWrapper.find('.js-detail-opt .sub-menu').removeClass('active');
	});

	// 即时编辑保存
	$contentWrapper.on('click','.p-edit',function(){
		$(this).parents('label').addClass('info-edit');
		$(this).parents('label').find('input,textarea').focus();
	});

	// 即时保存 失去焦点保存
	$contentWrapper.on('blur','.info-edit input,.info-edit textarea',function(){
		$(this).parents('label').removeClass('info-edit');
	});

	// 折叠效果

	// 弹出框pop-main清除内容
	$body.on('click','.js-pop-close.pop-clear',function(){
		$(this).parents('.pop-main').remove();
	});
	
	// 弹窗 - 搜索下拉出来
	$body.on('click','.search-fl .js-icon-search',function(){
		var keyword = $(this).parent().find(".search-intxt").val();
		// 加载参与成员
		var searchMemberJqx = baseEvn.ajaxFun({
			url: "user/findByName",
			data: {
				keyWord: keyword
			}
		});
		searchMemberJqx.done(function(result){
			console.log(result);
			renderEvn.renderTpl({
				tplId: '#popFindMember',
				outputId: $pop.find('.search-select-box.search-prev'),
				data: result.args.list
			});
		});
		
		$('.search-fl').toggleClass('active');
	});

	// 表格初始化
	var $grid = gridEvn.init({
		tablewrap: '#saasGrid',
		dataUrl: baseEvn.ajaxUrl.customerList,
		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '客户名称', '客户类型', '电话', '地区', '客户负责人', '创建时间'],
		colModel: [
			{
				name: 'customerName',
				width: 75,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					return '<a data-id="'+ rowObject.customerId +'" customer-name="'+ rowObject.customerName +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'customerType',
				sortable: false,
				width: 90
			},
			{
				name: 'phone',
				sortable: false,
				width: 100
			},
			{
				name: 'area',
				sortable: false,
				width: 80
			},
			{
				name: 'createByName',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	});
	// 弹出框
	this.detailOpt();
	//弹出框的保存
	this.saveOpt();
	// 添加相关成员
	this.addRelativeStaff();
	// 详情页 - 复选框的勾选
	baseEvn.checkboxChange();
	// 弹出框 - 客户搜索下拉，选中后填入框中
	baseEvn.popSearchCheck();
	// 表单右上方新建按钮
	baseEvn.toolbar();
	};


	$(function(){
	customerEvn.init();
	});

})(jQuery);