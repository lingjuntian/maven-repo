(function($){
	var $regForm = $('#regForm'),
		codeTime = null,
		regData = {};

	$(function(){
		// 输入手机号-获取验证码
		// 重新发送验证码-获取验证码
		$regForm.on('click', '.js-btn-phone,.btn-code', function(){
			if($(this).hasClass('btn-disable')){
				return false;
			}
			$(this).addClass('btn-disable');

			// 验证手机
			regData.phone = $('input[name="phone"]').val();

			// 获取验证码
			getCode(regData.phone);
		});

		// 输入验证码-下一步
		$regForm.on('click', '.js-btn-code', function(){
			if($(this).hasClass('btn-disable')){
				return false;
			}
			$(this).addClass('btn-disable');

			// 验证验证码
			regData.authenticode = $('input[name="code"]').val();


			// 发送验证码，验证是否正确
			var jqx = baseEvn.ajaxFun({
				url : '/login/verifyAuthenticode',
				data : regData
			});

			jqx.done(function(result) {
				if(result.type == 'success'){// 切换第三页
					slidePage('.reg-page3');
				}else{
					alert('验证码错误,请重新输入');
				}
			}).fail(function() {
				alert('验证码验证错误，请稍候重试');
			}).always(function() {
				// 切换第三页
			});
		});

		// 输入团队和姓名-注册
		$regForm.on('click', '.js-btn-reg', function(){
			if($(this).hasClass('btn-disable')){
				return false;
			}
			$(this).addClass('btn-disable');

			// 验证团队及姓名
			regData.companyName = $('input[name="company"]').val();
			regData.userName = $('input[name="username"]').val();

			// 发起注册请求
			var jqx = baseEvn.ajaxFun({
				url : '/login/reg',
				data : regData
			});

			jqx.done(function(result) {
				if(result.type == 'success'){// 切换第三页
					slidePage('.reg-page4');
				}else{
					alert('验证码错误,请重新输入');
				}
			}).fail(function() {
				alert('注册失败，请稍候重试');
			}).always(function() {
				// 切换第四页
				 
			});
		
		});
	});

	// 获取手机验证码
	function getCode(phone){
		clearTimeout(codeTime);
		$('.btn-code').addClass('btn-disable');
		setCodeTime($('.btn-code'), 60);

		var jqx = baseEvn.ajaxFun({
			url : '/login/getAuthenticode',
			data : {
				phone : phone
			}
		});

		jqx.done(function() {
			// 切换第二页
			slidePage('.reg-page2');
		}).fail(function() {
			alert('验证码发送异常，请稍候重试');
		}).always(function() {
			// 切换第二页
		});
	};

	// 验证码重新获取倒计时
	function setCodeTime(btnObj, codeNum) {
		codeNum--;

		btnObj.html('重新获取（'+ codeNum +'）');

		codeTime = setTimeout(function() {
			if (codeNum <= 0) {
				clearTimeout(codeTime);

				btnObj.html('获取验证码').removeClass('btn-disable');
			} else {
				setCodeTime(btnObj, codeNum);
			}
		}, 1000);
	};

	// 页面切换
	function slidePage(className){
		$regForm.find(className).addClass('reg-page-active').siblings().removeClass('reg-page-active');
	};
})(jQuery);