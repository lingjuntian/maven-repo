(function($){

$(function(){
	accountEvn.init();
});

var accountEvn = {
	// 切换内容块
	itemSlide: function(className){
		var cln = '.' + className;

		$('#formBox').find(cln).addClass('active').siblings().removeClass('active');
	},
	
	loginPublicFun: function(){
		var $formBox = $('#formBox'),
			formUrl = {
				home: '/',
				phone: '/login/mobileSubmit',
				passwordSublmit: '/login/passwordSubmit',
				authenticodeSubmit: '/login/authenticodeSubmit'
			};

		// 手机号码输入框自动聚焦
		$formBox.find('input[name="phone"]').focus().val($formBox.find('input[name="phone"]').val());
		
		// 输入手机号
		// 光标离开blur，按tab、enter键，下一步按钮,  验证
		$formBox.on('blur', '.login-phone input[name="phone"]', function(){
			accountEvn.phonejustCheck();

		}).on('keydown','.login-phone input[name="phone"]',function(e){
			var $this = $(this);
			var theEvent = window.event || e;
            var code = theEvent.keyCode || theEvent.which;

			if(code == 13 || code == 9){
				accountEvn.phoneCheckFun();
			}else{
				$(this).parent().find('.tips').html('');
			}

		}).on('click','.js-phone-next',function(){
			accountEvn.phoneCheckFun();


			// 埋点记录-输入手机号码-点击下一步
	        logsEvn.init([
	            ['clickBtn', 'loginEnterPhone']
	        ]);
		});

		// 密码登录 - 非首次登陆
		// blur，点击登录按钮，tab、enter
		$formBox.on('blur', '.login-pw .password-box input', function(){
			var errNum = accountEvn.paswordJustCheck();

		}).on('click', '.login-pw .js-btn-login', function() {
			accountEvn.passwordLogin();

			// 埋点记录-非首次登录-点击登录按钮
	        logsEvn.init([
	            ['clickBtn', 'loginBtnLogin']
	        ]);

		}).on('keydown','.login-pw .password-box input',function(e){
			var theEvent = window.event || e;
            var code = theEvent.keyCode || theEvent.which;

			if(code == 13 || code == 9){
				accountEvn.passwordLogin();
			}else{
				$(this).parent().find('.tips').html('');
			}

		}).on("click",".forget-pw",function(){
			// 埋点记录-点击忘记密码按钮
	        logsEvn.init([
	            ['clickBtn', 'loginBtnForget']
	        ]);

			var phone = $.trim($formBox.find('input[name="phone"]').val());

			window.open('/login/forget?phone=' + phone);
		});

		// 验证码登录-首次登录
		// 点击下一步按钮、tab、enter
		$formBox.on('blur', '.login-captcha .in-captcha-box input', function(){
			accountEvn.vcodeJustCheck();
			// console.log('vcode'+accountEvn.vcodeJustCheck());

		}).on('click', '.login-captcha .js-btn-login', function(){
			accountEvn.vcodeLogin();

			// 埋点记录-首次登录-点击登录按钮
	        logsEvn.init([
	            ['clickBtn', 'loginBtnFirstLogin']
	        ]);

		}).on('keydown','.login-captcha .in-captcha-box input',function(e){
			var theEvent = window.event || e;
            var code = theEvent.keyCode || theEvent.which;

			if(code == 13 || code == 9){
				accountEvn.vcodeLogin();
			}else{
				$(this).parent().find('.tips').html('');
			}

		});

		// 选择团队
		$formBox.on('click', '.login-company .js-btn-login', function() {
			// 埋点记录-选择团队-点击登录
	        logsEvn.init([
	            ['clickBtn', 'loginSelectCompanyLogin']
	        ]);

			var $btn = $(this),userId,phoneXhr;

			if($btn.hasClass('in-btn-loading')){
				return false;
			}
			$btn.addClass('in-btn-loading').html('登录中...');


			userId = $formBox.find('.login-company select').val();

			phoneXhr = baseEvn.ajaxFun({
				url : '/login/chooseCompany',
				data : {
					userId: userId
				}
			});

			phoneXhr.done(function(result) {
				if (result) {
					// 跳转到首页
					window.location.href = '/';
				}else{
					$formBox.find('.tips').html('很抱歉我们的服务器出现异常，请稍候重新登录');
				}
			}).fail(function() {
				$formBox.find('.tips').html('很抱歉我们的服务器出现异常，请稍候重新登录');
			}).always(function() {
				$btn.removeClass('in-btn-loading').html('登录');
			});
		});

		// 重新输入手机号
		$formBox.on('click','.js-back-btn',function(){
			// 清空验证码的倒计时和提示信息
			clearTimeout(accountEvn.capTime);
			$formBox.find('.login-captcha-box').find('.tips').html('');
			$formBox.find('.btn-captcha').removeClass('z-cld').html('获取验证码');

			// 输入框的值清空并获取焦点
			$formBox.find('input[name="phone"]').val('').focus();

			accountEvn.itemSlide('login-phone-box');
		});


		// 需要帮助？
		var $helpPop = $('#helpPop');

		$formBox.on('click','.help-tips', function(){
			// 埋点记录-点击需要帮助
	        logsEvn.init([
	            ['clickBtn', 'loginGetHelp']
	        ]);

			$helpPop.fadeIn();

			return false;
		})

		$helpPop.on('click','.js-help-close', function(){
			$helpPop.fadeOut();

			return false;
		});

		$helpPop.on('click','.help-tab a', function(){
			var Idx = $(this).index();

			$(this).addClass('active').siblings().removeClass('active');

			$helpPop.find('.help-item').eq(Idx).addClass('active').siblings().removeClass('active');

			return false;
		});
	},

	/* 手机号验证 */
	phonejustCheck: function(){
		var $formBox = $('#formBox'),
			$this = $('.login-phone input[name="phone"]'),
		    $phone = $formBox.find('input[name="phone"]'),
			phone = $.trim($phone.val()),
			errNum = 0;

			// 验证
			var options = {
				inputObj: $phone,
				required: 1,
				specialChar:'',
				regular: validateEvn.validateRex.phone,
				lengthType: 0,
				minLength: 11,
				maxLength: 11,
				regErrTip:''
			};

			// 光标移开，用户有输入，验证
			$this.parents('form').find('.tips').html('');

			if(!phone){
				errNum++;
				// $phone.focus();
				$this.parents('form').find('.login-phone .tips').html('请输入你的手机');
			}

			if(phone && !validateEvn.validate(options)){
				errNum++;
				// $phone.focus();
				$this.parents('form').find('.login-phone .tips').html('输入的手机号码格式不正确，请检查确认');
			}

			return errNum;
	},

	// 手机号提交
	phoneCheckFun: function(){

		var $formBox = $('#formBox'),
			$btn = $formBox.find('.js-phone-next'),
		    $phone = $formBox.find('input[name="phone"]'),
			phone = $.trim($phone.val()),
			errNum = 0,
			formUrl = {
				home: '/',
				phone: '/login/mobileSubmit'
			};
		
		// 验证
		errNum = accountEvn.phonejustCheck();

		// 验证通过，ajax提交数据
		if(errNum == 0 && !$btn.hasClass('in-btn-loading')){

			$btn.addClass('in-btn-loading').html('验证中...');


			var phoneXhr = baseEvn.ajaxFun({
				url: formUrl.phone,
				data: {
					phone: phone
				}
			});

			phoneXhr.done(function(result){

				$formBox.find('.phone-num').html(phone);

				if (result.registed) {
					if (result.hasPassword) {
						// 密码登陆
						accountEvn.itemSlide('login-pw-box');
						$formBox.find('.login-pw-box .password-box input').focus();

					} else {
						// 首次登录
						accountEvn.itemSlide('login-captcha-box');

						// 发送验证码
						$formBox.find('.btn-captcha').trigger('click');
					}
				} else {
					$phone.focus();
					$formBox.find('.login-phone .tips').html('该手机尚未匹配团队，请联系贵司管理员添加帐号或通过下方入口注册');
				}
			}).fail(function(data) {
				$formBox.find('.login-phone .tips').html('很抱歉我们的服务器出现异常，请稍候重新登录');
			}).always(function(data) {
				$btn.removeClass('in-btn-loading').html('下一步');
			});
		}
	},

	// 密码验证
	paswordJustCheck: function(){
		var $formBox = $('#formBox'),
			$this = $formBox.find('.login-pw .password-box input'),
			$password = $this.parents('.login-pw').find('.password-box input'),
			password = $.trim($password.val()),
			errNum = 0;
		
		// 验证
		$this.parents('.login-pw').find('.tips').html('');
		
		if(!password){
			errNum++;
			$password.val('');
			$this.parents('.login-pw').find('.tips').html('请输入你的密码');
		}
		return errNum;
	},

	// 密码提交
	passwordLogin: function(){
		var that = this;
		var $formBox = $('#formBox'),
			$btn = $formBox.find('.login-pw .js-btn-login'),
			$this = $formBox.find('.login-pw .password-box input'),
			phone = $formBox.find('.login-pw .phone-num').text(),
			$password = $this.parents('.login-pw').find('.password-box input'),
			autoLoginVal = $formBox.find('.login-pw-box input[name="autoLogin"]').prop('checked'),
			password = $.trim($password.val()),
			errNum = 0,
			formUrl = {
				home: '/',
				verifyPassword: '/login/verifyPassword',
			};
		
		// 验证
		errNum = accountEvn.paswordJustCheck();
		
		// 验证通过，ajax提交数据
		if(errNum == 0 && !$btn.hasClass('in-btn-loading')){

			$btn.addClass('in-btn-loading').html('登录中...');

			var phoneXhr = baseEvn.ajaxFun({
				url : formUrl.verifyPassword,
				data : {
					phone : phone,
					password : password,
					autoLogin : autoLoginVal
				}
			});

			phoneXhr.done(function(result) {
				
				if (result.type === 'success') {
					that.hasManyCompanys(phone);
				} else {
					$password.val('').focus();
					$formBox.find('.login-pw .tips').html('输入的密码不正确，请检查确认或点击下方的忘记密码重新设置	');
				}
			}).fail(function() {
				$formBox.find('.login-pw .tips').html('很抱歉我们的服务器出现异常，请稍候重新登录');
			}).always(function() {
				$btn.removeClass('in-btn-loading').html('登录');
			});
		}
	},

	// 验证码验证
	vcodeJustCheck: function(){
		var $formBox = $('#formBox'),
			$this = $('.login-captcha').find('.in-captcha-box input'),
			$vcode = $('.login-captcha').find('.in-captcha-box input'),
			vcode = $.trim($vcode.val()),
			errNum = 0;
			
		// 验证
		if(!vcode){
			errNum++;
			$vcode.val('').focus();
			$this.parents('.login-captcha').find('.tips').html('请输入验证码');
		}

		return errNum;
	},

	// 验证码提交
	vcodeLogin: function(){
		var that = this;
		var $Box = $('#formBox .login-captcha-box'),
			$btn = $Box.find('.js-btn-login'),
			$vcode = $Box.find('.in-captcha-box input'),
			phone = $Box.find('.phone-num').text(),
			vcode = $.trim($vcode.val()),
			autoLoginVal = $Box.find('input[name="autoLogin"]').prop('checked'),
			errNum = 0,
			formUrl = {
				home: '/',
				verifyAuthenticode: '/login/verifyAuthenticode'
			};
		
		// 验证
		errNum = accountEvn.vcodeJustCheck();

		// 验证通过，ajax提交数据
		if(errNum == 0 && !$btn.hasClass('in-btn-loading')){
			$btn.addClass('in-btn-loading').html('登录中...');

			var phoneXhr = baseEvn.ajaxFun({
				url: formUrl.verifyAuthenticode,
				data: {
					phone: phone,
					authenticode : vcode,
					autoLogin : autoLoginVal
				}
			});

			phoneXhr.done(function(result){
				// alert('done');
				if (result.type === 'success') {
						that.hasManyCompanys(phone);
				} else {
					$vcode.val('').focus();
					$Box.find('.tips').html('验证码不正确，请检查确认或点击右侧的获取验证码重新获取');
				}
			}).fail(function() {
				$Box.find('.tips').html('很抱歉我们的服务器出现异常，请稍候重新登录');
			}).always(function() {
				$btn.removeClass('in-btn-loading').html('登录');
			});
		}
	},
	
	// 是否有多个团队
	hasManyCompanys: function(phone){
		var that = this;
		var $formBox = $('#formBox');

		var phoneXhr = baseEvn.ajaxFun({
			url: '/login/hasManyCompanys',
			data: {
				phone: phone
			}
		});

		phoneXhr.done(function(result){
			if (result.type === 'success') {

				var accountId = result.args;
				that.getCompanySelect(accountId);
				
			} else {
				// 跳转到首页
				 $("#toHome").trigger("click");
			}
		}).fail(function() {
			$formBox.find('.tips').html('很抱歉我们的服务器出现异常，请稍候重新登录');
		}).always(function() {
		});
	},

	getCompanySelect: function(accountId) {
		var $formBox = $('#formBox');

		var phoneXhr = baseEvn.ajaxFun({
			url: '/login/getCompanySelect',
			dataType: 'html',
			data: {
				accountId: accountId
			}
		});

		phoneXhr.done(function(result){
			$formBox.find('.login-company-box').html(result);
			accountEvn.itemSlide('login-company-box');
		}).fail(function() {
			$formBox.find('.tips').html('很抱歉我们的服务器出现异常，请稍候重新登录');
		});

	},

	// 获取手机验证码
	getCaptcha : function() {
		var $formBox = $('#formBox');

		// 获取手机验证码
		$formBox.on('click', '.btn-captcha', function() {
			var $box = $('.login-captcha-box'),
				phone = $box.find('.phone-num').text();

			// 埋点记录-点击获取手机验证码
	        logsEvn.init([
	            ['clickBtn', 'loginGetCode']
	        ]);

			// 验证
			if(!$(this).hasClass('z-cld')){
				$(this).addClass('z-cld');
				
				timeOut($(this), 60);

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/getAuthenticode',
					data : {
						phone : phone
					}
				});

				phoneXhr.fail(function() {
					// alert('fail');
					popEvn.confirmFun({
						contentTxt: '验证码发送异常，请稍候重试',
						cancelBtn: '',
						initCallback: function(){
							timeOut($this, 0);
						}
					});
				});
			}else{
				return false;

			}
		});

		// 倒计时
		function timeOut(btnObj, capTimeNum) {

			capTimeNum--;
			btnObj.html(capTimeNum + '秒后重发');

			accountEvn.capTime = setTimeout(function() {
				if (capTimeNum <= 0) {
					clearTimeout(accountEvn.capTime);
					btnObj.html('获取验证码').removeClass('z-cld');
				} else {
					timeOut(btnObj, capTimeNum);
				}
			}, 1000);
		};
	},

	init: function(){
		// 定时器对象-全局变量
		this.capTime = null;
		this.loginPublicFun();
		this.getCaptcha();
	}
};

}(jQuery));
