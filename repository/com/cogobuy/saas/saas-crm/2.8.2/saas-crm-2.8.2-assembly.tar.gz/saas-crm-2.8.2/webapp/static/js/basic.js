// 当前页面数据集合，避免多次加载重复数据
var pageDataSet = {
	// 表格数据
	// 项目详情
	// 模板名称
	tplName: {
		// 详情-拜访报告
		infoDetailReport: '#infoDetailReportTpl',
		// 详情-资料
		infoDetailCustomer: '#infoDetailCustomerTpl',
		// 详情-联系人
		infoDetailContact: '#infoDetailContactTpl',
		// 详情-商机
		infoDetailChance: '#infoDetailChanceTpl',
		// 详情-售后
		infoDetailServer: '#infoDetailServerTpl',
		// 详情-任务
		infoDetailTask: '#infoDetailTaskTpl'
	}
};

// 参数配置
var moduleConfig = {
	// 当前栏目
	activeModule: {}
};


// 公共部分
(function($){

	var baseEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');


	// Ajax请求
	baseEvn.ajaxFun = function(ajaxOpts){
		var opts = $.extend({
			url: '/',
			dataType: 'json',
			method: 'post',
			data: {},
			complete: function(){},
			success: function(){},
			error: function(){}
		}, ajaxOpts);

		var jqxhr = $.ajax(opts);
		

		jqxhr.done(function ( data ) {
			//alert('done');
			if( data == 'LOGIN_TIMEOUT'){
				baseEvn.isLoginTimeout = true;
				window.location.href ='/login';
			}
			// return false;
		}).fail(function ( data ) {
			if( data.responseText == 'LOGIN_TIMEOUT'){
				baseEvn.isLoginTimeout = true;
				window.location.href ='/login';
			}else{
				// popEvn.hint({
				// 	tipsClass: 'pop-tips-warn',
				// 	txt: '请求失败，请稍后重试！'
				// });
			}
				
			// return false;
			//alert('fail');
		}).always(function ( data ) {
			//alert('always');
		});

		return jqxhr;
	};


	// 公共事件
	baseEvn.publicFun = function(){
		// 判断是否点击了详细内容区域
		var clickInfoBox = false;

		// 关闭详情
		$wrapper.on('click',function(){
			if(!clickInfoBox){
				$contentWrapper.find('.content-info').removeClass('active');
			}else{
				clickInfoBox = false;
			}		
		});

		// 点击表格名称-显示详情
		$wrapper.on('click','.js-get-info',function(){
			clickInfoBox = true;
			$contentWrapper.find('.content-info').addClass('active');
		}).on('click','.content-info',function(){
			clickInfoBox = true;
		});


		// 弹出框 - 客户搜索下拉，选中后填入框中
		baseEvn.popSearchCheck();

		// screen下拉框
		baseEvn.screenFun();

		// 日期选择初始化
		$body.on('click','.laydate', function(){
			if(typeof(laydate) != 'undefined'){
				laydate();
			}			
		});
	};

	// 详情页 - 复选框的勾选(弹窗和页面共用)
	baseEvn.checkboxChange = function(){
		$body.on('click','.list-title input',function(){
			$(this).closest('li').addClass('active').find('input').prop('checked','checked');

		});

		$body.on('click','.list-title .js-icon-checked',function(){
			$(this).closest('li').removeClass('active').find('input').prop('checked','');
		});
	};

	// 弹出框 - 客户搜索下拉，选中后填入框中
	baseEvn.popSearchCheck = function(){
		// // 选中
		// $pop.on('click','.box-list .js-list-checked',function(){
		// 	// 添加选中样式
		// 	$(this).toggleClass('active');

		// 	var name = $(this).find('label').text(),
		// 		id = $(this).find('label').attr('for');

		// 	var str = 	'<dt data-id="'+id+'">\
		// 					'+name+' <i class="js-icon-del-search icon-del-search"></i>\
		// 					<input type="hidden" name="toUserId" value="'+id+'">\
		// 				</dt>';
		// 	$(str).insertBefore($(this).closest('.search-fl').find('dl dd'));

		// 	// 选择后，输入框获取焦点并且修改placeholder的值
		// 	if($('.search-fl dt').length > 0){
		// 		$('.search-fl dd').find('.search-intxt').attr('placeholder','');
		// 	}else{
		// 		$('.search-fl dd').find('.search-intxt').attr('placeholder','请输入并选择');
		// 	}
		// 	$('.search-fl dd').find('.search-intxt').focus();
		// 	});

		// 取消
		// $pop.on('click','.box-list .active.js-list-checked,.search-fl .js-icon-del-search',function(){
		// 	var id =$(this).parent().attr('data-id') || $(this).find('label').attr('for');
			
		// 	// 去除checkbox样式
		// 	$('.search-fl .list-title label').each(function(){
		// 		if($(this).attr('for') == id){
		// 			$(this).closest('li').removeClass('active');
		// 		}
		// 	});
		// 	// 去除被选中的内容
		// 	$('.search-fl dt').each(function(){
		// 		if($(this).attr('data-id') == id){
		// 			$(this).remove();
		// 		}
		// 	});

		// 	// 选择后，输入框获取焦点并且修改placeholder的值
		// 	if($('.search-fl dt').length > 0){
		// 		$('.search-fl dd').find('.search-intxt').attr('placeholder','');
		// 	}else{
		// 		$('.search-fl dd').find('.search-intxt').attr('placeholder','请输入并选择');
		// 	}
		// 	$('.search-fl dd').find('.search-intxt').focus();
		// });
	};

	// screen下拉框
	baseEvn.screenFun = function(){
		// screen下拉框
		$contentWrapper.on('click','.js-screen .screen-title',function(){
			$(this).prev('.menu-box').toggleClass('active');
		});

		// 二级菜单切换
		$contentWrapper.on('click','.js-screen .menu-1 li',function(){
			var Idx = $(this).index();

			$(this).addClass('active').siblings().removeClass();
			$(this).closest('.js-screen').find('.menu-2 .menu-2-box').eq(Idx).addClass('active').siblings().removeClass('active');
		});

		// 点击二级菜单后收回
		$contentWrapper.on('click','.js-screen .menu-2-box li',function(){
			$(this).closest('.menu-box').removeClass('active');
		});
	};


	// 初始化
	baseEvn.init = function(){
		baseEvn.publicFun();

		// 表格宽高改变定时器
		var gridWHchange = null;

		// 导航栏伸缩
		$pageLeft.on('click','.js-toggle-btn',function(){
			$wrapper.toggleClass('wrapper-left-hide');
			clearTimeout(gridWHchange);
			gridWHchange = setTimeout(gridEvn.setWidthHeight,300);
		});

		// 浏览器窗口改变
		$(window).on('resize', function(){
			clearTimeout(gridWHchange);
			gridWHchange = setTimeout(gridEvn.setWidthHeight,300);
		});
	};


	$(function(){
		baseEvn.init();
	});


	window.baseEvn = baseEvn;

}(jQuery));



// 模版渲染
(function($){
	var renderEvn = {};

	// 模版渲染
	renderEvn.renderTpl = function(opts){
		var tplOpts = {
			// 选择器
			tplId: '',
			// 选择器
			outputId: '',
			data: {},
			callback: function(){},		

			insetType: 'html'
		},tplObj,outputObj;

		tplOpts = $.extend(tplOpts, opts);

		tplObj = $(tplOpts.tplId);
		outputObj = $(tplOpts.outputId);

		// console.log(tplOpts);

		if(tplOpts.tplId != '' && tplObj.length > 0){
			if(tplOpts.data.args){
				tplOpts.data = tplOpts.data.args;
			}

			for (var k in tplOpts.data){
				// console.log(tplOpts.data[k].length);
				tplOpts.data[k] = tplOpts.data[k] ? tplOpts.data[k] : '暂无';
			};

			// console.log(tplOpts);


			laytpl(tplObj.html()).render(tplOpts.data, function(html){
				//参与成员（#infoSlideStaffTpl） 要显示模板
				if(tplOpts.data.length <= 0 && tplOpts.tplId !='#infoSlideStaffTpl'){
					// 右侧栏 - 任务提醒
					if (tplOpts.tplId == '#infoSlideTaskTpl') {
						outputObj.html('<p class="ctrl-title">任务提醒</p><div class="box-list"><p class="data-null">暂无数据</p></div>');
					}else {
						outputObj.html('<p class="data-null">暂无数据</p>');
					}
				}else if(tplOpts.insetType == 'append'){
					outputObj.append(html);
				}else if(tplOpts.insetType == 'prepend'){
					outputObj.prepend(html);
				}else if(tplOpts.insetType == 'after'){
					outputObj.after(html);
				}else if(tplOpts.insetType == 'before'){
					outputObj.before(html);
				}else{
					outputObj.html(html);
				}
			    
			    if(tplOpts.callback){
			    	tplOpts.callback(outputObj);
			    }
			});
		}		
	};

	window.renderEvn = renderEvn;
}(jQuery));



// 弹出框处理
(function($){
	var popEvn = {
		hintTime: null
	},
		$pop = $('#pop'),
		$popTips = $('#popTips');

	// 弹出框高度适配
	popEvn.setPopcontentHeight = function(){
		setTimeout(function(){
			var mainHeight = $pop.find('.pop-main').height(),
				winHeight = $(window).height() - 100;

			mainHeight = (mainHeight > winHeight) ? winHeight : mainHeight;

			if(mainHeight > winHeight){
				mainHeight = winHeight;

				var maxH = mainHeight - $pop.find('.pop-head').height() - $pop.find('.pop-foot').height();

				$pop.find('.pop-content').height(maxH);
			}

			$pop.animate({
				'opacity': 1
			}).find('.pop-main').css({
				'marginTop': -(mainHeight/2)
			});

		}, 100);
	};

	// 轻提示
	popEvn.hint = function(opts){
		var $popTips = $('#popTips'),
			htmlArr = [];

		clearTimeout(popEvn.hintTime);

		var defaults = {
			tipsClass: '',
			tipsActiveClass: 'pop-tips-active',
			txt: '',
			showTime: 3000
		};

		defaults = $.extend(defaults,opts);

		htmlArr.push('<div class="tips-txt">');
		htmlArr.push('<i></i>');
		htmlArr.push('<p>'+ defaults.txt +'</p>');
		htmlArr.push('</div>');
		htmlArr.push('<a href="javascript:void(0);" class="tips-close js-tips-close">关闭</a>');

		$popTips.attr('class', 'pop-tips '+ defaults.tipsClass).html(htmlArr.join('')).addClass(defaults.tipsActiveClass);

		popEvn.hintTime = setTimeout(function(){
			$popTips.removeClass(defaults.tipsActiveClass);
		},defaults.showTime);
	};

	// 初始化
	popEvn.init = function(opts){
		var defaultOpts = {
			title: '温馨提示',
			tplname: '',
			tpldata: {}
		};

		//popEvn.loadTpl();
	};

	// 打开弹出框
	popEvn.open = function(){
		$pop.css('opacity', 0).show();

		popEvn.setPopcontentHeight();
	};

	// 关闭弹出框
	popEvn.close = function(){
		$pop.fadeOut();
	};


	$(function(){
		popEvn.init();

		// 关闭弹出框
		$pop.on('click', '.js-pop-close, .pop-clear', popEvn.close);

		// 关闭轻提示
		$popTips.on('click', '.js-tips-close', function(){
			$popTips.removeClass('pop-tips-active');
		});


		// 弹出框 - 查看更多
		$pop.on('click','.js-more-btn',function(){
			$(this).closest('.pop-info').find('label').removeClass('hidden');
			$(this).hide();

			popEvn.setPopcontentHeight();
		});
	});


	window.popEvn = popEvn;

})(jQuery);




// 表格处理
(function($){

	var gridEvn = {},
		$contentWrapper = $('#contentWrapper');

	// 加载表格数据
	gridEvn.loadData = function(data){
		var gridJqx = baseEvn.ajaxFun({
			url: gridEvn.opts.dataUrl,
			data: data ? data : {}
		});

		gridJqx.done(function ( jqx ) {
			// console.log(jqx);

			// 存入数据集
			pageDataSet.tableData = jqx;

			// 将获取到的数据args.list转移入rows中
			pageDataSet.tableData.rows = pageDataSet.tableData.args.list;
			// pageDataSet.tableData.args.list = null;

			// 渲染表格数据
	        gridEvn.tableObj[0].addJSONData(pageDataSet.tableData);

	        // 页码
	        gridEvn.initPageToolbar(pageDataSet.tableData);
		}).fail(function ( jqx ) {
			
		}).always(function ( jqx ) {
			
		});
	};

	// 设置表格宽高
	gridEvn.setWidthHeight = function(){
		if(gridEvn.tableObj){
			gridEvn.tableObj.setGridHeight($contentWrapper.find('.content-table').height() - 44);
			gridEvn.tableObj.setGridWidth($contentWrapper.find('.content-table').width());
		}		
	};


	// 判断是否选中行
	gridEvn.isSelectRow = function(){
		var len = gridEvn.tableObj.jqGrid('getGridParam', 'selarrrow').length;
		
		if(len > 0){
			$contentWrapper.find('.table-batch-ctrl').show().find('.num').text(len);
		}else{
			$contentWrapper.find('.table-batch-ctrl').fadeOut(300);
		}
	};


	//分页工具条
	gridEvn.initPageToolbar = function(result){
		var tableToolbarTpl = $('#tableToolbarTpl').html();

		laytpl(tableToolbarTpl).render(result, function(html){
			$('#tableToolbar').html(html);
		});
	};

	// 初始化
	gridEvn.init = function(opts){
		var defaultOpts = {
			dataUrl: '',
			loadtext: '加载中……',
			// 当返回的数据行数为0时显示的信息。只有当属性 viewrecords 设置为ture时起作用
			emptyrecords: '没有数据哦~',

			// 多选框
			multiselect : true,
			multiselectWidth: 80,

			sortable: false,

			// 定义是否要显示总记录数
			// viewrecords: false,
			// 定义了记录信息的位置： left, center, right
			// recordpos: 'left',
			// 显示记录数信息。{0} 为记录数开始，{1}为记录数结束。viewrecords为ture时才能起效，且总记录数大于0时才会显示此信息
			// recordtext: '当前{0}-{1}项，共{2}项',
			// 当执行ajax请求时要干什么
			// disable禁用ajax执行提示
			// enable默认，当执行ajax请求时的提示；
			// block启用Loading提示，但是阻止其他操作
			loadui: 'block',
			// hoverrows: true,
			// width: 900,
			height: 500,
			autowidth: true,
			// height: 300,
			// 默认显示10条
			//rowNum: 10,
			// rowList: [10,20,30],
			// loadonce: true
			jsonReader: {
				root: 'rows',
				// 总页数
				total:'totalCount',
				// 当前页
				page:'pageNo', 
				// 查询出的记录数
				records: 'pageCount',
				repeatitems: false
			}
		};

		gridEvn.opts = $.extend(defaultOpts,opts);

		gridEvn.tableObj = $(gridEvn.opts.tablewrap);

		if(gridEvn.tableObj.length == 0){
			return false;
		}

		// gridEvn.tableObj.setGridParam(gridEvn.opts);
		// gridEvn.tableObj.trigger('reloadGrid');

		// 选中行时触发
		gridEvn.opts.onSelectRow = function(rowid,status){
			if(gridEvn.tableObj.jqGrid('getGridParam', 'selarrrow').length == ($contentWrapper.find('.label-cbox').length - 1)){
				$contentWrapper.find('.label-cbox-all').addClass('label-cbox-checked');
				$contentWrapper.find('#cb_jqGrid').prop('checked', true);
			}else{
				$contentWrapper.find('.label-cbox-all').removeClass('label-cbox-checked');
				$contentWrapper.find('#cb_jqGrid').prop('checked', false);
			}


			gridEvn.isSelectRow();

			// 选中行时回调
			if(gridEvn.opts.onSelectRowCallback){
				gridEvn.opts.onSelectRowCallback(rowid,status);
			}
		};

		// 全选时触发
		gridEvn.opts.onSelectAll = function(aRowids, status){
			// console.log(status);
			if(status){
				$contentWrapper.find('.label-cbox-all').addClass('label-cbox-checked');
			}else{
				$contentWrapper.find('.label-cbox-all').removeClass('label-cbox-checked');
			}

			gridEvn.isSelectRow();

			// 全选时回调
			if(gridEvn.opts.onSelectAllCallback){
				gridEvn.opts.onSelectAllCallback(aRowids, status);
			}
		};

		gridEvn.opts.loadComplete = function(jqx){
			// console.log(jqx);
		};

		// 初始化表格完成后触发
		gridEvn.opts.gridComplete = function(){
			gridEvn.setWidthHeight();
		};

		gridEvn.tableObj.jqGrid(gridEvn.opts);

		gridEvn.loadData();

		return gridEvn.tableObj;
	};	

	$(function(){
		// 点击页码
		$contentWrapper.on("click",'.content-table-toolbar .enable',function(){
			var pageNo = $(this).attr("data-page"),
				data = {
					pageNo: pageNo
				};

			gridEvn.loadData(data);
		});


		// 关闭多选选择操作工具栏
		$contentWrapper.on('click', '.table-batch-ctrl .close', function(){
			gridEvn.tableObj.jqGrid('resetSelection');

			$contentWrapper.find('.label-cbox-all').removeClass('label-cbox-checked');

			gridEvn.isSelectRow();
		});

	});

	window.gridEvn = gridEvn;

})(jQuery);




// 表单验证
(function($){
	window.fValidate = {};

	// 判断是否为空
	fValidate.isNull = function(vOpts){
        if(vOpts.inLen == 0 || vOpts.inVal == ''){
            // console.log(vOpts.inObj.attr('data-null') || vOpts.nullErrTips);
            return {
                isTrue: false,
                Tips: vOpts.inObj.attr('data-null') || ( vOpts.nullErrTips + vOpts.inName )
            };
        }else{
            return {
                isTrue: true,
                Tips: ''
            };
        }
    };

	// 判断长度
	fValidate.isMinmax = function(vOpts){
        // console.log(vOpts.inVal.length);
        if(vOpts.inLen < vOpts.min || vOpts.inLen > vOpts.max){
            // 获取该输入框的长度限制
            var maxLen = vOpts.inObj.attr('data-minmax').split(' ')[1]+'个字';
            
            return {
                isTrue: false,
                Tips: vOpts.inObj.attr('data-minmaxtxt') || (vOpts.inName + vOpts.minmaxErrTips+maxLen)
            };
        }else{
            return {
                isTrue: true,
                Tips: ''
            };
        }
    };
	
	// 正则验证
	fValidate.isRex = function(vOpts){
        // console.log(vOpts.inRex, vOpts.inVal, vOpts.inRex.test(vOpts.inVal));
        if(vOpts.inRex.test(vOpts.inVal)){
            return {
                isTrue: true,
                Tips: ''
            };
        }else{
            
            return {
                isTrue: false,
                Tips: vOpts.inObj.attr('data-rextxt') || (vOpts.inName + vOpts.rexErrTips)
            };            
        }
    };

    // 日期格式化
    fValidate.dateFormat = function(ctime){
		var date = new Date(Date.parse(ctime));
		return (date.getMonth() + 1) + '月' + date.getDay() + '日';
    };

	// 初始化
	fValidate.init = function(Opts, Callback){

        // 默认设置
        var defaults = {
            inObj: null,
            inName: '',
            inVal: null,
            inLen: 0,
            inRex: null,
            inType: null,
            // 判断为空
            isVnull: false,
            nullErrTips: '请输入',
            // 判断长度
            isVminmax: false,
            isVch: false,
            min: 0,
            max: 1,
            minmaxErrTips: '字数应少于',
            // 使用正则
            isVrex: false,
            rexErrTips: '输入的内容格式不正确',

            // 常用正则表达式
            vRex : {
                // 1-9的数字
                integer19 : /^[1-9]\d*$/,
                // 0-9的数字
                integer09 : /^[0-9]\d*$/,
                // 数字
                num : /^\d+(\.\d+)?$/,
                // 邮箱
                email: /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/,
                // （下划线、字母、数字、汉字开头）
                nickname: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/,
                // 密码 6-16位
                password: /^\w{6,20}$/,
                // 电话号码-座机
                tel: /^(\(\d{3,4}\)|\d{3,4}-)?\d{7,8}$/,
                // 手机号码
                phone: /^[1]\d{10}$/,
                // phone: /^(13[0-9]|15[012356789]|17[0-9]|18[0-9]|14[57])[0-9]{8}$/,
                // 特殊字符
                specialChar: /[`~!@#$%^&*-+.<>{}\/'[\]]/im,
                // 网址
                url: /^(https?|ftp|mms):\/\/([A-z0-9_\-]+\.)*[A-z0-9]+\-?[A-z0-9]+\.[A-z]{2,}(\/.*)*\/?/
            }
        };

        var vOpts = $.extend(defaults, Opts);

        // 是否进行验证
        vOpts.isVd = Boolean(vOpts.inObj.attr('data-vd')) || false;
        if(!vOpts.isVd){return false;};


        // 判断验证的规则
        vOpts.isVnull = Boolean(vOpts.inObj.attr('data-nonull')) || false;
        vOpts.isVminmax = Boolean(vOpts.inObj.attr('data-minmax')) || false;
        vOpts.isVrex = Boolean(vOpts.inObj.attr('data-type') || vOpts.inObj.attr('data-rex')) || false;

        // 输入框的名称
        vOpts.inName = vOpts.inObj.attr('data-name') || vOpts.inObj.attr('name');
        // 输入框的值
        vOpts.inVal = $.trim(vOpts.inObj.val());
        // 输入框值的长度， 默认中文占两字符长度
        if(vOpts.isVch){
            vOpts.inLen = vOpts.inVal.match(/[^ -~]/g) == null ? vOpts.inVal.length : vOpts.inVal.length + vOpts.inVal.match(/[^ -~]/g).length;
        }else{
            vOpts.inLen = vOpts.inVal.length;
        }
        // 输入框的类型
        vOpts.inType = vOpts.inObj.attr('data-type');
        // 输入框的正则
        vOpts.inRex =  new RegExp(vOpts.inObj.attr('data-rex') || vOpts.vRex[vOpts.inType]);

        // 验证返回对象
        var backOpts = {
            isTrue: true,
            Tips: ''
        };

        // console.log(backOpts.isTrue && vOpts.isVrex);

        // 判断为空
        if(!vOpts.isVnull){
            backOpts = fValidate.isNull(vOpts);
        }

        // 判断长度
        if(backOpts.isTrue && vOpts.inLen > 0 && vOpts.isVminmax){
            var mimx = vOpts.inObj.attr('data-minmax').split(' ');
            if(mimx.length > 1){
                vOpts.min = ~~(mimx[0] || 0);
                vOpts.max = ~~(mimx[1] || (vOpts.min + 1));
            }

            backOpts = fValidate.isMinmax(vOpts);
        }

        // 使用正则
        if(backOpts.isTrue && vOpts.inLen > 0 && vOpts.isVrex){
            backOpts = fValidate.isRex(vOpts);
        }
        
        backOpts.inObj = vOpts.inObj;

        if(Callback){
            Callback(backOpts);
        }
	};

})(jQuery);






// 搜索选择功能
(function($){
	var $body = $('body');

	$.fn.autoFill = function(options){
		var defaults = {
			// 自动选择输入框的容器
			container: '.dl-box',
			// 发起请求的url
			// url: '../test/ByName.json',
			url: '/user/findByName',
			// 发起请求的data
			data: {},
			// 请求成功后回调
			loadCallBack: null,
			// 是否多选
			isMulti: false,
			// 选中后回调
			selCallBack: null,
			// 是否可新增
			isAdd: true,
			// 容器的层级
			zIndex: 1500,
			// 关闭自动填充框回调
			closeCallBack: null,
			// 选择填充类型-默认为用户
			selTypeName: 'user',
			// 选中项隐藏输入框的name值
			selHiddenInputName: 'toUserId',

			// 自动填充相关class
			autoClassFillBox: '#autoFillBox',
			autoClassPrev: '.js-auto-fill-prev',
			autoClassNext: '.js-auto-fill-next',

			// 模板id
			autoTplName: '#autoFillTpl',

			// 数据存储容器
			selectedData: [],
			// 是否立即打开-页面加载初始化或点击输入框初始化
			isShow: true,
			isCloseFillBox: true
		};

        this.each(function(){
        	var opts = $.extend(defaults, options);

        	opts.$this = $(this);

        	if(opts.$this.attr('data-bind') || opts.$this.length == 0){
        		return false;
        	}

            // 初始化
            init(opts);


            // 清除已选数据-对外方法
            this.clearData = clearData(opts);
        });
    };

    // 初始化
    function init(opts){
    	// console.log(opts);
    	// 判断容器
    	if(opts.container == '' || $(opts.container) == 0){
    		return false;
    	}
    	opts.$container = opts.$this.parents(opts.container);


    	// 插入自动填充容器
    	if($(opts.autoClassFillBox).length == 0){
    		opts.autoClassFillBox += Math.ceil(Math.random()*100000);

    		$body.append('<div id="'+ opts.autoClassFillBox.replace('#', '') +'" class="auto-fill-box"></div>');
    	}
    	opts.$fillBox = $(opts.autoClassFillBox);

    	opts.$this.attr('data-bind', true);

		// 输入框绑定-值改变-发起请求
		opts.$this.on('focus keyup', function(){
			// console.log(opts);
			valChange(opts);
		});

		// 选中列表项
		opts.$fillBox.on('click', 'li', function(){
			selectItem(opts,$(this));
		});

		// 删除已选项
		opts.$container.on('click', '.js-auto-fill-deldt', function(){
			isFillClose(opts);
			delItem(opts,$(this));
		});

		// 上一页 下一页
		opts.$fillBox.on('click', opts.autoClassPrev + ',' + opts.autoClassNext, pageCtrl);


		// 关闭自动填充框
		$body.on('click', function(){
			fillClose(opts);
		});

		// 点击自动填充区域阻止关闭
		$body.on('click', opts.autoClassFillBox + ',' + opts.container, function(){
			isFillClose(opts);
		});

		// 定位自适应
		$(window).on('resize',countPosition);

		// 是否执行加载数据操作
		if(opts.isShow){
			valChange(opts);
		}
    };

	// 请求数据
	function getData(opts){
		if(opts.url == ''){
			return false;
		}

		opts.$fillBox.show();

		// 停止上一次还未完成的ajax请求
		if(opts.jqxhr){
			opts.jqxhr.abort();
		}

		opts.jqxhr = baseEvn.ajaxFun({
			url: opts.url,
			data: opts.data
		});
		
		opts.jqxhr.done(function(result){
			// 判断是否有已选中项
			for (var i = result.args.list.length - 1; i >= 0; i--) {
				result.args.list[i].isActive = '';

				// 是否已被选中
				for (var j = 0, len = opts.selectedData.length; j < len; j++) {
					if(result.args.list[i].userId == opts.selectedData[j].lid){
						result.args.list[i].isActive = 'active';
						continue;
					}
				};
			};


			// 用户或客户
			result.args.dataType = opts.selTypeName;


			// 上一页
			opts.prePage = result.args.prePage;
			// 下一页
			opts.nextPage = result.args.nextPage;
			// 当前页
			opts.totalPage = result.args.totalPage;


			// 渲染模板
			renderEvn.renderTpl({
				tplId: opts.autoTplName,
				outputId: opts.autoClassFillBox,
				data: result.args,
				callback: function(outBox){
					pageInit(outBox,opts);

					countPosition(opts);
				}
			});

			

			// 回调
			if(opts.loadCallBack){
				opts.loadCallBack(result);
			}
		}).fail(function(){

		});
	};

	// 页码初始化
	function pageInit(outBox,opts){
		if(opts.prePage == opts.totalPage){
			outBox.find('.prev').addClass('disable');
		}

		if(opts.nextPage == opts.totalPage){
			outBox.find('.next').addClass('disable');
		}
	};

	// 页码处理
	function pageCtrl(opts){
		var $pageThis = $(this),
			clickPage = opts.nextPage;

		if($pageThis.hasClass('disable')){
			return false;
		}

		if($pageThis.hasClass('prev')){
			clickPage = opts.prePage;
		}

		if(clickPage != opts.totalPage){
			opts.data.pageNo = clickPage;

			getData(opts);
		}
	};

	// 输入框的值改变and获取焦点
	function valChange(opts){
		var $input = opts.$this,
			key = $.trim($input.val());

		// console.log(opts);

		// 阻止相同关键词重复请求
		if(opts.oldKey != key || key == ''){

			opts.oldKey = key;

			opts.data = {
				keyword: key
			};

			getData(opts);
		}

		isFillClose(opts);
	};

	// 计算自动填充的位置
	function countPosition(opts){
		if(opts.$this.length == 0){
			return false;
		}

		var _enterW = opts.$this.outerWidth() - 2,
			_enterH = opts.$this.outerHeight(),
			_enterTop = opts.$this.offset().top,
			_enterLeft = opts.$this.offset().left;

		// console.log(opts.$this);
		opts.$fillBox.css({
			// display: 'block',
			width: _enterW,
			top: _enterTop + _enterH,
			left: _enterLeft,
			zIndex: opts.zIndex
		});
	};

	// 自动填充框关闭判断
	function isFillClose(opts){
		opts.isCloseFillBox = false;

		setTimeout(function(){
			opts.isCloseFillBox = true;
		},300);
	};

	// 关闭自动填充框
	function fillClose(opts){
		if(opts.isCloseFillBox){

			opts.$fillBox.hide();

			// 判断是否有选中值
			if(opts.selectedData.length == 0){
				// alert('请选择');
			}

			// 清空数据

			// 关闭填充框回调
			if(opts.closeCallBack){
				opts.closeCallBack(opts.selectedData);
			}
		}
	};

	// 选中列表项
	function selectItem(opts, liObj){
		var $this = liObj,
			lId = $this.attr('data-id'),
			lName = $this.text(),
			isRepeat = false;

		// 判断是否多选
		if(opts.isMulti){
			// 多选

			// 是否已被选中
			for (var i = 0, len = opts.selectedData.length; i < len; i++) {
				if(lId == opts.selectedData[i].lid){
					isRepeat = opts.selectedData[i];
					break;
				}
			};

			// 判断该条信息是否已选中
			if(isRepeat){
				// 已选
				$this.removeClass('active');
				opts.selectedData.splice($.inArray(isRepeat, opts.selectedData), 1);
			}else{
				// 未选
				$this.addClass('active');
				opts.selectedData.push({lid: lId, lname: lName});
			}
		}else{
			// 单选
			$this.addClass('active').siblings().removeClass('active');
			opts.selectedData.splice(0, opts.selectedData.length);
			opts.selectedData.push({lid: lId, lname: lName});
		}

		opts.$this.val('');

		// 渲染选中值
		outputSelected(opts);
	
		countPosition(opts);

		// 回调
		if(opts.selCallBack){
			opts.selCallBack($this);
		}
	};

	// 删除已选项
	function delItem(opts, liObj){
		var lId = liObj.parent().find('input').val();

		for (var i = 0, len = opts.selectedData.length; i < len; i++) {
			if(lId == opts.selectedData[i].lid){

				liObj.remove();

				opts.selectedData.splice($.inArray(opts.selectedData[i], opts.selectedData), 1);

				outputSelected(opts);

				opts.$fillBox.find('li').each(function(){
					if($(this).attr('data-id') == lId){
						$(this).removeClass('active');
					}
				});
				break;
			}
		};

		countPosition(opts);
	};

	// 清空数据数组
	function clearData(opts){
		opts.selectedData.splice(0, opts.selectedData.length);
	};

	// 渲染已选内容
	function outputSelected(opts){
		var str = '';

		for (var i = 0, len = opts.selectedData.length; i < len; i++) {
			str += '<dt>'+ opts.selectedData[i].lname +'<i class="js-auto-fill-deldt icon-del-search"></i><input type="hidden" name="'+ opts.selHiddenInputName +'" value="'+ opts.selectedData[i].lid +'"></dt>';
		};

		opts.$container.find('dl').html(str);
	};

	// $(function(){
	// 	$body.on('click', '.js-auto-fill-input', function(){
	// 		$(this).autoFill({
	// 			isShow: true
	// 		});
	// 	});

	// 	$('.js-auto-fill-input2').autoFill({
	// 		isMulti: true
	// 	});
	// });


})(jQuery);





// 地址选择器
(function($){
	$.fn.addressEvn = function(options){
		var defaults = {
			// 下拉选择ID
            selId : {
            	province: '#province',
            	city: '#city',
            	county: '#county',
            	town: '#town'
            },
            // 下拉选择默认空值
            selNullVal : {
            	province: '请选择',
            	city: '请选择',
            	county: '请选择',
            	town: '请选择'
            },
            // 下拉选择默认值
            selDefauleVal : {
            	province: '',
            	city: '',
            	county: '',
            	town: ''
            },
            // 下拉选择数据接口
            selDataApi : {
            	province: '',
            	city: '',
            	county: '',
            	town: ''
            }
        };

        this.each(function(){
        	var opts = $.extend(defaults, options);

            // 初始化
            init(opts, $(this));
        });

        // 初始化
        function init(opts, obj){
        	obj.province = obj.find(opts.selId.province);
        	obj.city = obj.find(opts.selId.city);
        	obj.county = obj.find(opts.selId.county);
        	obj.town = obj.find(opts.selId.town);

        	// 事件绑定
        	obj.province.on('change', function(){
        		cityFun(obj, opts);
        	});
        	obj.city.on('change', function(){
        		countyFun(obj, opts);
        	});
        	obj.county.on('change', function(){
        		townFun(obj, opts);
        	});

        	// 省份初始化
        	provinceFun(obj, opts);
        };

        // 获取数据
        function insertOption(dataType, pVal, param){
        	// dataType
        	// pVal
        	// param

        	// $.ajax({

        	// });



			var data = getData(dataType, param),
				i = 0,
				len = data.length,
				str = '',
				d,
				v,
				p;

			for(;i<len; i++) {

				d = data[i][dataType + '_id'];

				v = data[i][dataType + '_name'];

				p = (v == pVal) ? 'selected' : '';

				str += '<option value="' + d + '" '+ p +'>' + v +'</option>';
			};

			return str;
		};

		// 省份
		function provinceFun(obj, opts){
			creatHtml(obj, opts, 'province', 'none');
			cityFun(obj, opts);
		};

		// 城市
		function cityFun(obj, opts){
			creatHtml(obj, opts, 'city', 'province');
			countyFun(obj, opts);
		};

		// 区县
		function countyFun(obj, opts){
			creatHtml(obj, opts, 'county', 'city');
			townFun(obj, opts);
		};

		// 街道
		function townFun(obj, opts){
			creatHtml(obj, opts, 'town', 'county');
		};

		// 省份、城市、区县、街道
		function creatHtml(obj, opts, ntype, ptype){
			var pv = (ptype == 'none') ? [] : obj[ptype].val(),
				nv = '<option value="">'+ opts.selNullVal[ntype] +'</option>';

			if(pv.length == 0 && ptype != 'none') {
				obj[ntype].html(nv);
				showHide(obj, ntype, true);
			}else{
				obj[ntype].html(nv + insertOption(ntype, opts.selDefauleVal[ntype], {ptype: pv}));
				showHide(obj, ntype);
			}
		};

		// 显示或隐藏
		function showHide(Obj, ntype, isHide){
			if(isHide){
				Obj[ntype].addClass('sel-hide ' + ntype + '-hide');
			}else{
				Obj[ntype].removeClass('sel-hide ' + ntype + '-hide');
			}
		};


		// 模拟  获取数据，type 类型，param 参数
		function getData(type, param){
			var data;

			// console.log(param);

			var provinceData = [
				{"province_name":"北京","province_id":"1"},
				{"province_name":"天津","province_id":"2"}
			];

			var cityData = [
				{"city_name":"西城","city_id":"1"},
				{"city_name":"东城","city_id":"2"}
			];

			var countyData = [
				{"county_name":"呼和浩特","county_id":"1"},
				{"county_name":"黄浦","county_id":"2"}
			];

			var townData = [
				{"town_name":"十堰","town_id":"1"},
				{"town_name":"鹰潭","town_id":"2"}
			];


			if(type == 'province'){
				data = provinceData;
			}else if(type == 'city'){
				data = cityData;
			}else if(type == 'county'){
				data = countyData;
			}else{
				data = townData;
			}

			return data;
		}

	};
})(jQuery);