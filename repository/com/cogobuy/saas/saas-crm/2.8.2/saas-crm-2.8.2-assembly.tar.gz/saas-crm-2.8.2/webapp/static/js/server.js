var moduleName = 'server';

moduleConfig.activeModule = {
	moduleName: 'server',

	// 表格
	gridOpts: {
		tablewrap: '#serverGrid',
		dataUrl: '/service/find',
		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '售后', '公司名称', '状态', '服务开始时间', '服务结束时间','重要性', '创建时间'],
		colModel: [
			{
				name: 'title',
				width: 90,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);

					return '<a id="'+ rowObject.serviceId +'" data-id="'+ rowObject.serviceId +'" title="'+ rowObject.title +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'customerName',
				sortable: false,
				width: 80
			},
			{
				name: 'status',
				sortable: false,
				width: 90,
			},
			{
				name: 'postDate',
				sortable: false,
				width: 80,
				sorttype: 'date'
			},
			{
				name: 'finishDate',
				sortable: false,
				width: 80,
				sorttype: 'date'
			},
			{
				name: 'important',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	}
};




(function($){
	var serverEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');


	serverEvn.publicFun = function(){
		
		// 内容折叠展开
		$contentWrapper.on('click','.main-item .box-title',function(){
			if(!$(this).hasClass('up')){
				$(this).addClass('up');
				$(this).siblings('.form-item-list,.box-list').slideUp();
			}else{
				$(this).removeClass('up');
				$(this).siblings('.form-item-list,.box-list').slideDown();
			}
		});
		
		// 点击表格名称-显示详情
		$wrapper.on('click','.js-get-info',function(){
			// 将名称和id保存到全局变量
			var dataId = $(this).attr("data-id");
			var title = $(this).attr("title");
			pageDataSet.dataId = dataId;
			pageDataSet.title = title;
			
			// 详情显示当前售后主题
			$contentWrapper.find('.detail .js-name').html(pageDataSet.title);
			
			var tabNumJqx = baseEvn.ajaxFun({
				url: '/service/findTabNum',
				data:{
					serviceId: dataId
				}
			});
			
			tabNumJqx.done(function(result){
				if (result.type === "success") {
					// 加载左侧tab导航栏
					renderEvn.renderTpl({
						tplId: '#infoTabTpl',
						outputId: '.detail div.detail-nav',
						data: result,
						callback: function(outObj){
							// 详情页tab导航加上active状态
							outObj.find('a').eq(0).addClass('active');
							// 详情页tab内容加上active状态
							$contentWrapper.find('.detail-main .main-item').eq(0).addClass('active').siblings().removeClass('active').html('');
						}
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: '获取导航栏失败'
					});
				}
			});
			
			// 加载左侧售后详情
			var detailJqx = baseEvn.ajaxFun({
				url: '/service/get',
				data:{
					serviceId: dataId
				}
			});
			
			detailJqx.done(function(result){
				if(result.type == "success") {
					renderEvn.renderTpl({
						tplId: '#infoDetailServerTpl',
						outputId: '.detail-main div.item-server',
						data: result
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
			
			// 加载右侧任务提醒
			var taskJqx = baseEvn.ajaxFun({
				url: '/service/findTopRecentTask',
				data: {
					serviceId: dataId
				}
			});

			taskJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoSlideTaskTpl',
					outputId: $contentWrapper.find('.content-info .slide .task'),
					data: result
				});
			}).fail(function(){
			}).always(function(){
			});
			
			// 加载右侧负责人信息
			detailJqx.done(function(result) {
				renderEvn.renderTpl({
					tplId: '#infoSlideLeader',
					outputId: $contentWrapper.find('.content-info .slide .leading'),
					data: result
				});
			}).fail(function(){
			}).always(function(){
			});
			
			// 去除右侧栏参与成员的编辑状态
			$contentWrapper.find('.slide-box.staff').removeClass('active');
			
			// 加载右侧参与成员
			var staffJqx = baseEvn.ajaxFun({
				url: '/service/findShareEmployee',
				data: {
					serviceId : dataId
				}
			});

			staffJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoSlideStaffTpl',
					outputId: $contentWrapper.find('.content-info .slide .staff'),
					data: result
				});
			}).fail(function(){
			}).always(function(){
			});
			

			
		});
		
		// 左侧详情tab切换
		$contentWrapper.on('click','.js-detail-nav a',function() {
			var Idx = $(this).index();

			if($(this).hasClass('active')){
				return false;
			}

			$(this).addClass('active').siblings().removeClass('active');
			$contentWrapper.find('.detail-main .main-item').eq(Idx).addClass('active').siblings().removeClass('active').html('');
			
			var dataType = $(this).attr('data-type');
			// 售后详情tab
			if (dataType === 'data') {
				var detailJqx = baseEvn.ajaxFun({
					url: '/service/get',
					data:{
						serviceId: pageDataSet.dataId
					}
				});
				
				detailJqx.done(function(result){
					if(result.type == "success") {
						renderEvn.renderTpl({
							tplId: '#infoDetailServerTpl',
							outputId: '.detail-main div.item-server',
							data: result
						});
					} else {
						popEvn.hint({
							tipsClass: 'pop-tips-warn',
							txt: result.content
						});
					}
				});
			} else if (dataType === 'customer') {
				// 客户详情tab
				var customerJqx = baseEvn.ajaxFun({
					url: '/customer/findTab',
					data:{
						type: 'service',
						dataId: pageDataSet.dataId
					}
				});
				
				customerJqx.done(function(result){
					if(result.type == "success") {
						renderEvn.renderTpl({
							tplId: '#infoDetailCustomerTpl',
							outputId: '.detail-main div.item-customer',
							data: result,
							callback: function() {
								// 省市选择初始化
								var addressBox = $contentWrapper.find('#editAddressBox');
								var area = addressBox.attr('area');
								var province = addressBox.attr("province");
								var city = addressBox.attr("city");

								addressBox.addressEvn({
									selDefauleVal : {
										area: area,
										province: province,
										city: city
							        }
								});
							}
						});
					} else {
						popEvn.hint({
							tipsClass: 'pop-tips-warn',
							txt: result.content
						});
					}
				});
				
			} else {
				// 任务日程tab
				var taskJqx = baseEvn.ajaxFun({
					url: '/service/findTask',
					data:{
						serviceId: pageDataSet.dataId
					}
				});
				
				taskJqx.done(function(result){
					if(result.type == "success") {
						renderEvn.renderTpl({
							tplId: '#infoDetailTaskTpl',
							outputId: '.detail-main div.item-task',
							data: result
						});
					} else {
						popEvn.hint({
							tipsClass: 'pop-tips-warn',
							txt: result.content
						});
					}
				});
			}
		});
		
		// 右侧操作区-单击事件-出现弹窗
		$contentWrapper.on('click','.js-detail-opt a',function(){
			var type = $(this).attr('data-type'),
				tplId = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'task':
					tplId = '#popAddtaskTpl';
					break;
				case 'transform':
					tplId = '#popTransformTpl';
					break;
				case 'del':
					tplId = '#popSingleServiceDelTpl';
					break;
				default: 
					break;

			}
			
			// 渲染模板
			if (type){
				renderEvn.renderTpl({
					tplId: tplId,
					outputId: '#pop',
					data:{
						serviceId: pageDataSet.dataId,
						serviceName: pageDataSet.title
					},
					callback: function(outObj){
						popEvn.setPopcontentHeight();
						outObj.show();
					}
				});
			}
			
		});	
		
		// 右侧操作区，添加任务目标
		$pop.on('click','#popAddtask .js-pop-save',function(){
			var data = $('#popAddtask').serialize();
			var taskJqx = baseEvn.ajaxFun({
				url: '/service/createTask',
				data: data
			});
			
			taskJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					
					// 刷新任务日程
					var taskJqx = baseEvn.ajaxFun({
						url: '/service/findTask',
						data:{
							serviceId: pageDataSet.dataId
						}
					});
					
					taskJqx.done(function(result){
						if(result.type == "success") {
							renderEvn.renderTpl({
								tplId: '#infoDetailTaskTpl',
								outputId: '.detail-main div.item-task',
								data: result
							});
						} else {
							popEvn.hint({
								tipsClass: 'pop-tips-warn',
								txt: result.content
							});
						}
					});
					
					// 刷新右侧任务提醒
					var taskJqx = baseEvn.ajaxFun({
						url: '/service/findTopRecentTask',
						data: {
							serviceId: pageDataSet.dataId
						}
					});

					taskJqx.done(function(result){
						renderEvn.renderTpl({
							tplId: '#infoSlideTaskTpl',
							outputId: $contentWrapper.find('.content-info .slide .task'),
							data: result
						});
					}).fail(function(){
					}).always(function(){
					});
				
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		
		// 参与成员、转移成员、删除成员
		$body.on('click', '.js-auto-fill-input', function(){
			var searchType = $(this).attr("search-type");
			switch (searchType){
				//成员添加
				case 'addMember':
					$(this).autoFill({
						url: "/user/findByName",
						selTypeName:'user',
						selHiddenInputId:'toUserId',
					//	selHiddenInputName:'toUserName',
						isMulti: true
					});
				break;
				//成员移除
				case 'delMember':
					var formData = $(this).parents("form:first").serialize();
					var formData = formData.substring(7,formData.length).split('&dataId=');
					$(this).autoFill({
						url: "/user/findByNameAndService",
						data: {
							dataId : formData
						},
						selTypeName:'user',
						selHiddenInputId:'toUserId',
					//	selHiddenInputName:'toUserName',
						isMulti: true
					});
				break;
				//转移
				case 'transform':
					$(this).autoFill({
						url: "/user/findByName",
						selTypeName:'user',
						selHiddenInputId:'toUserId',
					//	selHiddenInputName:'toUserName',
						isMulti: false
					});
				break;
				
				case 'customer':
					$(this).autoFill({
						url: '/customer/findPageByName',
						selTypeName: 'customer',
						selHiddenInputId: 'customerId',
						selHiddenInputName: 'customerName'
					});
				break;
				//默认
				default :
					
				break;
			}
		});	
		
		// 右侧操作区，转移负责人
		$pop.on('click','#popTransform .js-pop-save',function(){
			var data = $('#popTransform').serialize();
			var transJqx = baseEvn.ajaxFun({
				url: '/service/changeCharge',
				data: data
			});
			
			transJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 右侧操作区，删除单个售后
		$pop.on('click','#popSingleServiceDel .js-pop-save',function(){
			var data = $('#popSingleServiceDel').serialize();
			var delJqx = baseEvn.ajaxFun({
				url: '/service/delete',
				data: data
			});
			
			delJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					
					// 刷新列表，收起详情页
					$contentWrapper.find('.content-info').removeClass('active');
					var page = $('.toolbar-item.num').find('a.active').text();
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 右侧栏-任务提醒-取消或恢复
		$contentWrapper.on('click','.js-aside-task .list-title i',function(){
			var $li = $(this).closest('li'),
				dataId = $li.attr("data-id"),
				data = null;

			if($(this).closest('li').hasClass('active')) {
				$li.removeClass('active');
				data={
					id : dataId,
					action : 'unfinish'
				};
			} else {
				$li.addClass('active');
				data={
					id : dataId,
					action : 'finish'
				};
			}
			var finishJqx = baseEvn.ajaxFun({
					url:"/service/finishTask",
					data:data
			});

			finishJqx.done(function(result){
				if(result.type=="success"){
					popEvn.hint({
						txt:'操作成功'
					});
				}else if(result.type=="error"){
					popEvn.hint({
						txt: result.content,
						tipsClass: 'pop-tips-warn'
					});
				}
			});
		});
		
		// 右侧栏-添加成员-出现弹窗
		$contentWrapper.on('click','.js-add-staff-btn',function(){
			
			renderEvn.renderTpl({
				tplId: '#popSinAddMemberTpl',
				outputId: '#pop',
				data:{
					serviceId: pageDataSet.dataId
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
		
		// 右侧栏-添加成员（弹窗保存提交）
		$pop.on('click','#popSinAddMember .js-pop-save',function(){
			var data = $('#popSinAddMember').serialize();
			var addJqx = baseEvn.ajaxFun({
				url: '/service/addShareEmployee',
				data: data
			});
			
			addJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					// 加载右侧参与成员
					var staffJqx = baseEvn.ajaxFun({
						url: '/service/findShareEmployee',
						data: {
							serviceId : pageDataSet.dataId
						}
					});

					staffJqx.done(function(result){
						renderEvn.renderTpl({
							tplId: '#infoSlideStaffTpl',
							outputId: $contentWrapper.find('.content-info .slide .staff'),
							data: result
						});
					}).fail(function(){
					}).always(function(){
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 右侧栏-参与成员-编辑保存状态切换
		$contentWrapper.on('click','.js-leading-e',function(){
			$(this).closest('.slide-box.staff').addClass('active');
		});
		
		$contentWrapper.on('click','.js-leading-s',function(){
			$(this).closest('.slide-box.staff').removeClass('active');
		});

		// 右侧栏-参与成员-点击删除-出现弹窗
		$contentWrapper.on('click','.js-staff-d',function(){
			var userId = $(this).siblings("span").attr("data-id"),
				userName = $(this).siblings("span").text(),
				serviceId = pageDataSet.dataId;
		
			renderEvn.renderTpl({
				tplId: '#popDelRelativeStaffTpl',
				outputId: '#pop',
				data:{
					serviceId: serviceId,
					userId: userId,
					userName: userName
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
		
		// 右侧栏-删除成员（弹窗保存提交）
		$pop.on('click','#popDelRelativeStaff .js-pop-save',function(){
			var data = $('#popDelRelativeStaff').serialize();
			var addJqx = baseEvn.ajaxFun({
				url: '/service/deleteShareEmployee',
				data: data
			});
			
			addJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					// 加载右侧参与成员
					var staffJqx = baseEvn.ajaxFun({
						url: '/service/findShareEmployee',
						data: {
							serviceId : pageDataSet.dataId
						}
					});

					staffJqx.done(function(result){
						renderEvn.renderTpl({
							tplId: '#infoSlideStaffTpl',
							outputId: $contentWrapper.find('.content-info .slide .staff'),
							data: result
						});
					}).fail(function(){
					}).always(function(){
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 批量操作区（表格上方）-出现弹窗
		$contentWrapper.on('click','.js-table-batch-ctrl a',function(){
			var columnType = $(this).attr('data-type'),
				actionType = $(this).attr('data-action'),
				tplId='';

			if (columnType == 'server'){
				// 获取选中id
				var dataId = [];
				var $table = $('#serverGrid');
				$table.find('tr[aria-selected="true"]').each(function(){
					dataId.push($(this).find('a').attr('data-id'));
				});
				var remindContent;
				switch (actionType){
					case 'addMember':
						tplId = '#popAddMemberTpl';
						remindContent = '将团队成员添加成为选中的'+dataId.length+'个售后的相关成员：'
						break;
					case 'removeMember':
						tplId = '#popRemoveMemberTpl';
						remindContent = '将以下成员从选中的'+dataId.length+'个售后中移除：'
						break;
					case 'del':
						tplId = '#popMulDelTpl';
						remindContent = '是否确定删除选中的'+dataId.length+'个售后？删除之后，该操作将无法恢复。'
						break;
					case 'transform':
						tplId = '#popMulServiceTransTpl';
						remindContent = '是否将选中的'+dataId.length+'个售后转移给其他负责人？转移成功之后，该操作将无法恢复。'
						break;
				}
			}
			// 渲染模板
			renderEvn.renderTpl({
				tplId: tplId,
				outputId: '#pop',
				data:{
					dataId:dataId,
					remindContent:remindContent
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});

		});
		
		// 批量成员添加（弹窗保存提交）
		$pop.on('click','#popAddMember .js-pop-save',function(){
			var data = $('#popAddMember').serialize();
			var addJqx = baseEvn.ajaxFun({
				url: '/service/addShareEmployee',
				data: data
			});
			
			addJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
	
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		
		// 批量成员移除（弹窗保存提交）
		$pop.on('click','#popRemoveMember .js-pop-save',function(){
			var data = $('#popRemoveMember').serialize();
			var addJqx = baseEvn.ajaxFun({
				url: '/service/deleteShareEmployee',
				data: data
			});
			
			addJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 批量删除售后（弹窗保存提交）
		$pop.on('click','#popMulDel .js-pop-save',function(){
			var data = $('#popMulDel').serialize();
			var addJqx = baseEvn.ajaxFun({
				url: '/service/delete',
				data: data
			});
			
			addJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					
					// 刷新列表，收起详情页
					$contentWrapper.find('.content-info').removeClass('active');
					var page = $('.toolbar-item.num').find('a.active').text();
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 批量转移（弹窗保存提交）
		$pop.on('click','#popMulServiceTrans .js-pop-save',function(){
			var data = $('#popMulServiceTrans').serialize();
			var addJqx = baseEvn.ajaxFun({
				url: '/service/changeCharge',
				data: data
			});
			
			addJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 新增售后-出现弹窗
		$contentWrapper.on('click','.js-toolbar-ctrl .add-server',function(){
			// 渲染模板
			renderEvn.renderTpl({
				tplId: '#popAddServiceTpl',
				outputId: '#pop',
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
		
		// 新增售后（弹窗保存提交）
		$pop.on('click','#popAddService .js-pop-save',function(){
			var data = $('#popAddService').serialize();
			var addJqx = baseEvn.ajaxFun({
				url: '/service/add',
				data: data
			});
			
			addJqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					
					// 刷新列表
					var page = 1;
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 即时编辑保存-出现编辑框
		$contentWrapper.on('click','.p-edit',function(){
			$(this).parents('label').addClass('info-edit');
			$(this).parents('label').find('input,textarea').focus().val($(this).parents('label').find('input,textarea').val());
		});
		
		// 即时保存 失去焦点保存
		$contentWrapper.on('blur','.info-edit input,.info-edit textarea',function(){
			$(this).parents('label').removeClass('info-edit');
		});
		$contentWrapper.on('change','.info-edit select',function(){
			//选取省份不作做保存
			var s_class = $(this).attr('class');
			if(s_class.indexOf('sel-province')>0){
				return;
			}
			if(s_class.indexOf('sel-city')>0){
				var value=$(this).val();
				if(!value){
					return;
				}
			}
			$(this).parents('label').removeClass('info-edit');
		});
		
		//地区编辑保存
		$contentWrapper.on('blur','.form-item-list select.sel-city',function(){
			var city = $(this).val();
			if(!city){
				return;
			}
			var province = $(this).siblings("select").val();
			var $this = $(this);
				dataType=$(this).closest('.item-box').attr("data-type");
				dataId=$(this).closest('.item-box').attr("data-id"),
				pTxt = $this.closest('label').find('p').text();
				data = {
					customerId:dataId,
					province:province,
					city:city
				},
		 		url="/customer/update";
			var jqx = baseEvn.ajaxFun({
						url: url,
						data:data
				});
			jqx.done(function (result){
				if (result.type == 'success'){
					// js修改显示内容
					$this.closest('label').find('p').text(province+" "+city);

					popEvn.hint({
						txt: '操作成功'
					});
				} else if (result.type == 'error') {
					popEvn.hint({
						txt: result.content
					});
				}
			});
		});
		
		//非地区编辑保存
		$contentWrapper.on('blur','.form-item-list input, .form-item-list select, .form-item-list textarea',function(){
			//判断是地区选择则不做保存
			var s_class = $(this).attr('class');
			if(s_class.indexOf('in-sel-area')>0){
				return;
			}
			
			var $this = $(this);
				dataType=$(this).closest('.item-box').attr("data-type");
				dataId=$(this).closest('.item-box').attr("data-id"),
				pTxt = $this.closest('label').find('p').text();
				name=$(this).attr("name"),
				value=$(this).val(),
				data = {},
		 		url='';
			switch(dataType){
				case 'customer':
					data['customerId'] = dataId;
					data[name] = value;
					url="/customer/update";
					break;

				case 'service':
					data['serviceId'] = dataId;
					data[name] = value;
					url="/service/update";
					break;

			}	

			// 当内容变化时，提交修改
			if (pTxt != value){
				var jqx = baseEvn.ajaxFun({
						url: url,
						data:data
					});
				jqx.done(function (result){
					if (result.type == 'success'){
						// js修改显示内容
						$this.closest('label').find('p').text(value);

						popEvn.hint({
							txt: '操作成功'
						});
					} else if (result.type == 'error') {
						popEvn.hint({
							txt: result.content
						});
					}
				});
			} else {
				return false;
			}
		});
		
		
		
		
	};
	
	

	// 初始化
	serverEvn.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		serverEvn.publicFun();
	};

	$(function(){
		serverEvn.init();
	});

})(jQuery);