var moduleName = 'search';

moduleConfig.activeModule = {
	moduleName: 'search',
	searchCustomer: '/search/searchCustomer',
	searchContacts: '/search/searchContacts',
	searchCommunication: '/search/searchCommunication',
	searchOpportunity: '/search/searchOpportunity',
	searchService: '/search/searchService',
	
	// 客户表格
	customerGridOpts: {
		tablewrap: '#customerGrid',
		dataUrl: '',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '客户名称', '客户类型', '电话', '地址', '客户负责人', '创建时间'],
		colModel: [
			{
				name: 'customerName',
				width: 75,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					return '<a data-id="'+ rowObject.customerId +'" customer-name="'+ rowObject.customerName +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'customerType',
				sortable: false,
				width: 90
			},
			{
				name: 'phone',
				sortable: false,
				width: 100
			},
			{
				name: 'address',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					var result = '';
					if(rowObject.province)
						result += rowObject.province+"&nbsp";
					if(rowObject.city)
						result += rowObject.city+"&nbsp";
					if(value)
						result += value;
					return result;
				}
			},
			{
				name: 'chargeUserName',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	},
	
	// 联系人表格
	contactsGridOpts: {
		tablewrap: '#contactGrid',
		dataUrl: '',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '姓名', '公司名称', '职位', '电话', '邮箱', '创建时间'],
		colModel: [
			{
				name: 'name',
				width: 75,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					return '<a data-id="'+ rowObject.contactsId +'" contacts-name="'+ rowObject.name +
					'"customer-id="'+rowObject.customerId+'"customer-name="'+rowObject.customerName+'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'customerName',
				sortable: false,
				width: 90
			},
			{
				name: 'position',
				sortable: false,
				width: 100
			},
			{
				name: 'phone',
				sortable: false,
				width: 80
			},
			{
				name: 'email',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	},
	
	// 拜访报告表格
	reportGridOpts: {
		tablewrap: '#reportGrid',
		dataUrl: '',
		// 默认的排序列
		sortname: 'commTime',
		// 表头名称
		colNames : [ '标题', '日期', '方式', '公司', '客户联系人', '下一步计划时间'],
		colModel: [
			{
				name: 'theme',
				width: 90,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);

					return '<a id="'+ rowObject.id +'" data-id="'+ rowObject.id +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'commTime',
				sortable: false,
				width: 90,
				sorttype: 'date'
			},
			{
				name: 'commType',
				sortable: false,
				width: 75
			},
			{
				name: 'customerName',
				sortable: false,
				width: 80
			},
			{
				name: 'contactsName',
				sortable: false,
				width: 80
			},
			{
				name: 'nextPlanTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	},
	
	// 表格
	chanceGridOpts: {
		tablewrap: '#chanceGrid',
		dataUrl: '',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '项目', '客户名称', '进度', '预计成交金额','预计成交日期','重要性', '负责人', '创建时间'],
		colModel: [
			{
				name: 'project',
				width: 90,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					return '<a data-id="'+ rowObject.opportunityId +'" customer-name="'+ rowObject.project +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'customerName',
				sortable: false,
				width: 120
			},
			{
				name: 'progress',
				sortable: false,
				width: 40
			},
			{
				name: 'amtType',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					var result = '暂无';
					var atype = '';
					if(rowObject.amtType)
						atype = rowObject.amtType;
					if(rowObject.amtRangeBegin)
						result = rowObject.amtRangeBegin+"&nbsp" +atype;
					if(rowObject.amtRangeEnd)
						result = rowObject.amtRangeEnd+"&nbsp" +atype;
					  
					return result;
				}
			},
			{
				name: 'expectedClosingDate',
				sortable: false,
				width: 60
			},
			{
				name: 'important',
				sortable: false,
				width: 60
			},
			{
				name: 'chargeUserName',
				sortable: false,
				width: 60
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	},
	
	// 售后表格
	serviceGridOpts: {
		tablewrap: '#serverGrid',
		dataUrl: '/service/find',
		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '售后', '公司名称', '状态', '服务开始时间', '服务结束时间','重要性', '创建时间'],
		colModel: [
			{
				name: 'title',
				width: 90,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);

					return '<a id="'+ rowObject.serviceId +'" data-id="'+ rowObject.serviceId +'" title="'+ rowObject.title +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'customerName',
				sortable: false,
				width: 80
			},
			{
				name: 'status',
				sortable: false,
				width: 90,
			},
			{
				name: 'postDate',
				sortable: false,
				width: 80,
				sorttype: 'date'
			},
			{
				name: 'finishDate',
				sortable: false,
				width: 80,
				sorttype: 'date'
			},
			{
				name: 'important',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	},

	// 修改成员资料
	findModuleNum: '/search/findModuleNum'
};

(function($){

	var searchEvn = {},
	$wrapper = $('#wrapper'),
	$pageLeft = $('#pageLeft'),
	$contentWrapper = $('#contentWrapper');
	
	
	
	searchEvn.publicFun = function(){
		
	};


	// 初始化
	searchEvn.init = function(){
		var key = $('#wrapper').attr("key");
		var jqx = baseEvn.ajaxFun({
			url: moduleConfig.activeModule.findModuleNum,
			data: {
				key: key
			}
		});

		jqx.done(function(result){
			renderEvn.renderTpl({
				tplId: '#searchNumTpl',
				outputId: '.content-toolbar',
				data: result
			});
		});
		
		var url = moduleConfig.activeModule.searchCustomer +'?key=' + key;
		moduleConfig.activeModule.customerGridOpts.dataUrl = url;
		gridEvn.init(moduleConfig.activeModule.customerGridOpts);
		
		// 详情页的tab切换
		$contentWrapper.on('click','.search-tab a',function(){
			var idx = $(this).index();
			$(this).addClass('active').siblings().removeClass('active');
			$contentWrapper.find('.content-table .table-item').eq(idx).addClass('active').siblings().removeClass('active');
			
			var $grid,
				dataType = $(this).attr("data-type"),
				key = $('#wrapper').attr("key");
			if (dataType == 'customer') {
				var url = moduleConfig.activeModule.searchCustomer +'?key=' + key;
				moduleConfig.activeModule.customerGridOpts.dataUrl = url;
				$grid = gridEvn.init(moduleConfig.activeModule.customerGridOpts);
			} else if(dataType == 'contact'){
				var url = moduleConfig.activeModule.searchContacts +'?key=' + key;
				moduleConfig.activeModule.contactsGridOpts.dataUrl = url;
				$grid = gridEvn.init(moduleConfig.activeModule.contactsGridOpts);
			} else if (dataType == 'report') {
				var url = moduleConfig.activeModule.searchCommunication +'?key=' + key;
				moduleConfig.activeModule.reportGridOpts.dataUrl = url;
				$grid = gridEvn.init(moduleConfig.activeModule.reportGridOpts);
			} else if(dataType == 'chance') {
				var url = moduleConfig.activeModule.searchOpportunity +'?key=' + key;
				moduleConfig.activeModule.chanceGridOpts.dataUrl = url;
				$grid = gridEvn.init(moduleConfig.activeModule.chanceGridOpts);
			} else if (dataType == 'server'){
				var url = moduleConfig.activeModule.searchService +'?key=' + key;
				moduleConfig.activeModule.serviceGridOpts.dataUrl = url;
				$grid = gridEvn.init(moduleConfig.activeModule.serviceGridOpts);
			}
		});

	};
	
	$(function(){
		searchEvn.init();
	});

})(jQuery);