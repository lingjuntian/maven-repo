var moduleName = 'visitReport';

moduleConfig.activeModule = {
	moduleName: 'visitReport',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		dataUrl: '/communication/find',
		// 默认的排序列
		sortname: 'commTime',
		// 表头名称
		colNames : [ '标题', '日期', '方式', '公司', '客户联系人', '下一步计划时间'],
		colModel: [
			{
				name: 'theme',
				width: 90,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);

					return '<a id="'+ rowObject.id +'" data-id="'+ rowObject.id +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'commTime',
				sortable: false,
				width: 90,
				sorttype: 'date'
			},
			{
				name: 'commType',
				sortable: false,
				width: 75
			},
			{
				name: 'customerName',
				sortable: false,
				width: 80
			},
			{
				name: 'contactsName',
				sortable: false,
				width: 80
			},
			{
				name: 'nextPlanTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	},

	// 修改成员资料
	changeMyInfo: '/setting/changeMyInfo',
	// 修改密码
	changePassword: '/setting/changePassword',

	// 添加成员-获取数据
	findRole: '/setting/findCompanyRole',
	// 编辑成员-获取数据
	getEditRole: '/setting/getStaffEditInfo',
	// 添加成员-提交
	addStaffInfo: '/setting/addStaffInfo',
	// 编辑成员-提交
	changeStaffInfo: '/setting/changeStaffInfo',


	// 获取成员目标信息
	getUserTarget: '/setting/getUserTarget',
	// 查找用户
	findByName: '/user/findByName',
	// 设置目标
	addUserTarget: '/setting/addUserTarget',
	// 修改目标
	changeUserTarget: '/setting/changeUserTarget',
	// 模糊查询客户
	findCustomerByName: '/customer/findPageByName',
	// 模糊查询联系人
	findContactsByName: '/contacts/findByCustomerAndName'
};




(function($){
	var visitReportEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');


	visitReportEvn.publicFun = function(){
		
		// 搜索选择功能-客户选择
		$('body').on('click', '.customer.js-auto-fill-input', function(){
			$(this).autoFill({
				url: moduleConfig.activeModule.findCustomerByName,
				selTypeName: 'customer',
				selHiddenInputId: 'customerId',
				selHiddenInputName: 'customerName'
			});
		});
		
		// 搜索选择功能-联系人选择
		$('body').on('click', '.contacts.js-auto-fill-input', function(){
			var $customerResult = $('#customerSearch').siblings('dl').find('dt:first');
			
			if ($customerResult.length == 0) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '请先选择公司'
				});
			}
			var customerId = $customerResult.find('input[name="customerId"]').val();
			
			$(this).autoFill({
				url: moduleConfig.activeModule.findContactsByName,
				selTypeName: 'contacts',
				selHiddenInputId: 'contactsId',
				selHiddenInputName: 'contactsName',
				data: {
					customerId: customerId,
					keyword: ''
				}
			});
		});
		
		// 搜索选择功能-联系人选择-编辑时使用
		$('body').on('click', '.edit-contacts.js-auto-fill-input', function(){
			var $customerResult = $('#editCustomer').find('p');
			
			var customerId = $customerResult.attr("data-id");
			
			$(this).autoFill({
				url: moduleConfig.activeModule.findContactsByName,
				selTypeName: 'contacts',
				selHiddenInputId: 'contactsId',
				selHiddenInputName: 'contactsName',
				data: {
					customerId: customerId,
					keyword: ''
				}
			});
		});

		// 编辑拜访报告
		$contentWrapper.on('click','.js-title-e',function(){
			var communicationId = $(this).attr("data-id");
			var jqx = baseEvn.ajaxFun({
				url: '/communication/findEditCommInfo',
				data:{
					communicationId: communicationId
				}
			});
			
			jqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#popEditReportTpl',
					outputId: '#pop',
					data: result,
					callback: function(){
						popEvn.open();
					}
				});
			});

		});
		
		// 点击表格名称-显示详情
		$wrapper.on('click','.js-get-info',function(){

			var communicationId = $(this).attr("id");

			var jqx = baseEvn.ajaxFun({
				url: '/communication/get',
				data:{
					communicationId: communicationId
				}
			});
			
			jqx.done(function(result){
				if(result.type == "success") {
					renderEvn.renderTpl({
						tplId: '#infoDetailReportTpl',
						outputId: '#contentInfo',
						data: result
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 编辑拜访报告-提交信息
		$pop.on('click','#popEditReport .js-pop-sure',function() {
			$form = $("#popEditReport");
			
			var jqx = baseEvn.ajaxFun({
				url: '/communication/changeComm',
				data: $form.serialize()
			});
			
			jqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 新增拜访报告-弹窗
		$contentWrapper.on('click','.js-toolbar-ctrl a',function(){
			var type = $(this).attr('data-type');
			
			if (type == 'visitReport') {
				
				var jqx = baseEvn.ajaxFun({
					url: '/communication/findCommType'
				});
			}
			
			jqx.done(function(result){
				if(result.type == "success") {
					renderEvn.renderTpl({
						tplId: '#popAddReportTpl',
						outputId: '#pop',
						data: result,
						callback: function() {
							popEvn.open();
						}
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
			

		});
		
		// 新增拜访报告-提交
		$pop.on('click','#popAddReport .js-pop-save',function(){
			$form = $("#popAddReport");
			
			var jqx = baseEvn.ajaxFun({
				url: '/communication/add',
				data: $form.serialize()
			});
			
			jqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 批量删除拜访报告-出现弹窗
		$contentWrapper.on('click','.table-batch-ctrl a.del',function(){
			
			var commList = [];
			var $table = $('#saasGrid');
			
			$table.find('tr[aria-selected="true"]').each(function(){
				commList.push($(this).find('a').attr('data-id'));
			});
			
			var remindContent='是否确定删除选中的'+commList.length+'个拜访报告？<br/>删除之后，该操作将无法恢复。'
			renderEvn.renderTpl({
				tplId: '#popMulCommDelTpl',
				outputId: '#pop',
				data:{
					remindContent: remindContent
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
		
		// 批量删除拜访报告-确定删除
		$pop.on('click','#popMulCommDel a.js-pop-save',function(){
			// 获取选中id
			var dataIds = [];
			var $table = $('#saasGrid');
			
			$table.find('tr[aria-selected="true"]').each(function(){
				dataIds.push($(this).find('a').attr('data-id'));
			});
			
			var jqx = baseEvn.ajaxFun({
				url: '/communication/deleteBatch',
				contentType: "application/json",
				data: JSON.stringify(dataIds)
			});
			
			jqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 单个删除拜访报告-出现弹窗
		$contentWrapper.on('click','.js-title-d.btn-visit-d',function(){
			
			var commId = $(this).attr('data-id'),
				commName = $(this).attr('data-name');
			
			var remindContent='是否确定删除拜访报告【'+ commName +'】？<br/>删除之后，该操作将无法恢复。'
			renderEvn.renderTpl({
				tplId: '#popSingleCommDelTpl',
				outputId: '#pop',
				data:{
					remindContent: remindContent,
					dataId: commId
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
		
		// 删除单个拜访报告
		$pop.on('click','#popSingleCommDel a.js-pop-save',function(){
			var commId = $(this).closest('form').attr('data-id');
			var commIds = [];
			commIds.push(commId);
			
			var jqx = baseEvn.ajaxFun({
				url: '/communication/deleteBatch',
				contentType: "application/json",
				data: JSON.stringify(commIds)
			});
			
			jqx.done(function(result){
				if(result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
			
		});
		
		
	};
	

	// 初始化
	visitReportEvn.init = function(){
		visitReportEvn.publicFun();


		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
	};

	$(function(){
		visitReportEvn.init();
	});

})(jQuery);