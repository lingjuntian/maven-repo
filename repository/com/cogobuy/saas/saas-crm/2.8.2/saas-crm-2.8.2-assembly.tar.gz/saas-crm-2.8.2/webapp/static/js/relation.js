(function($){
	'use strict';

	$(function(){
		relationEvn.init();
	});

	var relationEvn = {
		init: function(){
			this.initPop();
			this.bindEvent();

		},
		
		initPop: function() {
			var that = this;
			$('#addUpper,#addLower').autocomplete({
				autoFocus: false,
				minLength:0,
				source: function(request, response) {
                    $.ajax({
                        url: "/relation/autoCompleteByName",
                        dataType: "json",
                        data: {
                            key: request.term
                        },
                        success: function(data) {
                            response($.map(data, function(item) {
                                return { label: item.name, value: item.name, userId: item.userId }
                            }));
                        }
                    });
                },
                change: function (event, ui) {
                    if (!ui.item) {
                         $(this).val('');
                     }
                },
	　　　　　　　　 select: function(event, ui) {
		 				that.selectUser = ui.item;
	                },
			    messages: {
			        noResults: '',
		        results: function() {}
			    }
			}).focus(function(){
                $(this).autocomplete("search");
                return false;
           });
			
		},
		
		// 绑定事件
		bindEvent: function() {
			var that = this;
			var $main = $(".main");
			var $body = $("body");
			var $pop = $("#pop");
			
			// 出现弹窗-新建上级
			$body.on('click','.js-add-upper',function(){
				that.selectUser = undefined;
				$("#addUpper").val("");
				$pop.fadeIn().find('.pop-add-upper').slideDown().siblings().hide();

			});
			
			// 出现弹窗-新建下级
			$body.on('click','.js-add-lower',function() {
				that.selectUser = undefined;
				$("#addLower").val("");
				$pop.fadeIn().find('.pop-add-lower').slideDown().siblings().hide();
			});
			
			// 出现弹窗-删除确认框
			$main.on('click','.my-account .js-del-btn',function() {
				$pop.addClass('pop-del-mask').fadeIn();
				$('.pop-cf-del').fadeIn();
				var flowId = $(this).parents("tr").attr("flowId");
				var relaId = $(this).parents("tr").attr("relaId");
				if (flowId) {
					that.deleteType = "flow";
					that.flowId = flowId
				} else if (relaId){
					that.deleteType = "relation";
					that.relaId = relaId;
				}

				that.deleteDirection = "upper";


			});
			
			// 出现弹窗-删除确认框
			$main.on('click','.staff-account .js-del-btn',function(){
				$pop.addClass('pop-del-mask').fadeIn();
				$('.pop-cf-del').fadeIn();
				var flowId = $(this).parents("tr").attr("flowId");
				var relaId = $(this).parents("tr").attr("relaId");
				if (flowId) {
					that.deleteType = "flow";
					that.flowId = flowId
				} else if (relaId){
					that.deleteType = "relation";
					that.relaId = relaId;
				}
				
				that.deleteDirection = "lower";

			});
			
			// 删除确认框-确认按钮
			$pop.on('click','.pop-cf-del .z-sel',function(){
				$pop.removeClass('pop-del-mask').hide();
				$('.pop-cf-del').fadeOut();
				if (that.deleteType === "flow") {
					that.deleteRelaFlow();
				} else if (that.deleteType === "relation") {
					that.deleteRelation();
				}

			});
			
			// 删除确认框-取消按钮
			$(".pop-cf-del .js-pop-close").unbind("click");
			$pop.on('click','.pop-cf-del .js-pop-close',function(){
				$pop.removeClass('pop-del-mask').hide();
				$('.pop-cf-del').fadeOut();
			});
			
			// 新增上级-确定按钮
			$pop.on("click",".pop-add-upper .pop-btn.z-sel",function(){
				if (!that.isLock("createLowerUser")) {
					that.createUpperUserFlow();
				}
				
			});
			
			// 新增下级-确定按钮
			$pop.on("click",".pop-add-lower .pop-btn.z-sel",function(){
				if (!that.isLock("createLowerUserFlow")) {
					that.createLowerUserFlow();
				}
			});
			
			// 审核通过，添加上级
			$main.on('click','.my-account .js-confirm-btn',function(){
				
				var $addUser = $(this).parents("tr");
				that.addUser = {
					upperUserId: $addUser.attr("userId"),
					upperUserName: $addUser.attr("userName"),
					flowId: $addUser.attr("flowId")
				};
				if (!that.isLock("addUpperUser")) {
					that.addUpperUser();
				}
			});
			
			// 审核通过，添加下级
			$main.on('click','.staff-account .js-confirm-btn',function(){
				var $addUser = $(this).parents("tr");
				that.addUser = {
					lowerUserId: $addUser.attr("userId"),
					lowerUserName: $addUser.attr("userName"),
					flowId: $addUser.attr("flowId")
				};
				if (!that.isLock("addLowerUser")) {
					that.addLowerUser();
				}
				
			});
			
			// 审核不通过，修改流程状态
			$main.on('click','.my-account .js-disagree-btn',function(){
				that.modifyDirection = "upper";
				that.flowId = $(this).parents("tr").attr("flowId");
				that.modifyStatusNoPass();
			});
			
			// 审核不通过，修改流程状态
			$main.on('click','.staff-account .js-disagree-btn',function(){
				that.modifyDirection = "lower";
				that.flowId = $(this).parents("tr").attr("flowId");
				that.modifyStatusNoPass();
			});

		},
		
		/**
		 * 获取上级列表
		 */
		getUpperUserTable: function() {
			var that = this;
			$.ajax({
			    url: "/relation/getUpperUserTable",
			    dataType: "html",
			    data: {},
			    success: function(data) {
			    	$(".my-relation .my-account table").remove();
			    	$(".my-relation .my-account").append(data);
			    },
                error: function() {
                	alert("获取上级列表失败。");
                },
			    complete: function() {
			    	that.unlock();
			    }
			});	
		},
		
		/**
		 * 获取下级列表
		 */
		getLowerUserTable: function() {
			var that = this;
			$.ajax({
			    url: "/relation/getLowerUserTable",
			    dataType: "html",
			    data: {},
			    success: function(data) {
                	$(".my-relation .staff-account table").remove();
                	$(".my-relation .staff-account").append(data);
			    },
                error: function() {
                	alert("获取下级列表失败。");
                },
			    complete: function() {
			    	that.unlock();
			    }
			});	
		},
		
		/**
		 * 创建上级申请流程-新增上级
		 */
		createUpperUserFlow: function() {
			var that = this;
			var $pop = $("#pop");
			
			if (!that.selectUser) {
				alert("输入姓名后请选择下拉框中的内容后提交");
				return;
			}
			var upperUserId = that.selectUser.userId;
			var upperUserName = that.selectUser.value;
			
			that.lock("createUpperUserFlow");
            $.ajax({
                url: "/relation/createUpperUserFlow",
                dataType: "json",
                data: {
                	upperUserId: upperUserId
                },
                success: function(message) {
                	
                	if (message.type === "success") {
                		$pop.fadeOut().find('.pop-add-upper').slideUp();
                		that.getUpperUserTable();
                	} else {
                		that.unlock();
                		alert(message.content);
                	}

                },
                error: function() {
                	that.unlock();
                	alert("新增上级失败。");
                }
            });			
		},
		
		/**
		 * 创建下级申请流程-新增下级
		 */
		createLowerUserFlow: function() {
			var that = this;
			var $pop = $("#pop");
			
			if (!that.selectUser) {
				$('.pop-add-lower .pop-btn.z-sel').removeAttr('disabled');
				alert("输入姓名后请选择下拉框中的内容后提交");
				return;
			}
			var lowerUserId = that.selectUser.userId;

			that.lock("createLowerUserFlow");
            $.ajax({
                url: "/relation/createLowerUserFlow",
                dataType: "json",
                data: {
                	lowerUserId: lowerUserId
                },
                success: function(message) {
                	
                	if (message.type === "success") {
                		$pop.fadeOut().find('.pop-add-lower').slideUp();
                		that.getLowerUserTable();
                	} else {
                		that.unlock();
                		alert(message.content);
                	}

                },
                error: function() {
                	that.unlock();
                	alert("新增下级失败。");
                }
            });			
		},
		
		/**
		 * 添加下级-同意按钮
		 */
		addUpperUser: function() {
			var that = this;
			var $pop = $("#pop");
			
			that.lock("addUpperUser");
            $.ajax({
                url: "/relation/addUpperUser",
                dataType: "json",
                data: {
                	upperUserId: that.addUser.upperUserId,
                	upperUserName: that.addUser.upperUserName,
                	flowId: that.addUser.flowId
                },
                success: function(message) {
                	if (message.type === "success") {
                		$pop.fadeOut().find('.pop-add-upper').slideUp();
                		that.getUpperUserTable();
                	} else {
                		that.unlock();
                		alert(message.content);
                	}

                },
                error: function() {
                	that.unlock();
                	alert("新增上级失败。");
                }
            });			
		},
		
		/**
		 * 添加下级-同意按钮
		 */
		addLowerUser: function() {
			var that = this;
			var $pop = $("#pop");
			
			that.lock("addLowerUser");
            $.ajax({
                url: "/relation/addLowerUser",
                dataType: "json",
                data: {
                   	lowerUserId: that.addUser.lowerUserId,
                	lowerUserName: that.addUser.lowerUserName,
                	flowId: that.addUser.flowId
                },
                success: function(message) {
                	if (message.type === "success") {
                		$pop.fadeOut().find('.pop-add-upper').slideUp();
                		that.getLowerUserTable();
                	} else {
                		that.unlock();
                		alert(message.content);
                	}

                },
                error: function() {
                	that.unlock();
                	alert("新增上级失败。");
                }
            });	
		},
		
		/**
		 * 审核不通过-修改审核状态
		 */
		modifyStatusNoPass: function(){
			var that = this;
			var $pop = $("#pop");
			
            $.ajax({
                url: "/relation/modifyStatusNoPass",
                dataType: "json",
                data: {
                	flowId: that.flowId
                },
                success: function(message) {
                	if (message.type === "success") {
                		if (that.modifyDirection == "upper") {
                			that.getUpperUserTable();
                		} else if (that.modifyDirection == "lower"){
                			that.getLowerUserTable();
                		}
                	} else {
                		alert(message.content);
                	}

                },
                error: function() {
                	alert("不同意状态修改失败。");
                }
            });	
		},
		
		/**
		 * 删除审核流程
		 */
		deleteRelaFlow: function(){
			var that = this;
			var $pop = $("#pop");
			
            $.ajax({
                url: "/relation/deleteRelaFlow",
                dataType: "json",
                data: {
                	flowId: that.flowId
                },
                success: function(message) {
                	if (message.type === "success") {
                		if (that.deleteDirection == "upper") {
                			that.getUpperUserTable();
                		} else if (that.deleteDirection == "lower"){
                			that.getLowerUserTable();
                		}
                	} else {
                		alert(message.content);
                	}

                },
                error: function() {
                	alert("删除审核流程失败。");
                }
            });		
		},
		
		/**
		 * 删除我的下级-确定按钮
		 */
		deleteRelation: function(){
			var that = this;
			var $pop = $("#pop");
			
            $.ajax({
                url: "/relation/deleteRelation",
                dataType: "json",
                data: {
                	relaId: that.relaId
                },
                success: function(message) {
                	if (message.type === "success") {
                		if (that.deleteDirection == "upper") {
                			that.getUpperUserTable();
                		} else if (that.deleteDirection == "lower"){
                			that.getLowerUserTable();
                		}
                	} else {
                		alert(message.content);
                	}

                },
                error: function() {
                	alert("删除上下级关系失败。");
                }
            });	
		},
		
		/**
		 * 调用ajax方法前，添加锁
		 */
		lock: function(methodName) {
			this.methodName = methodName;
			this.lockFlag = true;
		},
		
		/**
		 * 去掉锁
		 */
		unlock: function() {
			this.lockFlag = false;
		},
		
		/**
		 * 是否上锁。
		 */
		isLock: function(methodName) {
			if (this.methodName === methodName && this.lockFlag) {
				return true;
			} else {
				return false;
			}
		}
	}


}(jQuery));

