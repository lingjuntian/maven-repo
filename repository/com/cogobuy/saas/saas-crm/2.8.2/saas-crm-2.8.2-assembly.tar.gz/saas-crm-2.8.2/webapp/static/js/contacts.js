//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'contacts';

moduleConfig.activeModule = {
	moduleName: 'contacts',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		// dataUrl: '../../pages/test/customerTable.json',
		dataUrl: '/contacts/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '姓名', '公司名称', '职位', '电话', '邮箱', '创建时间'],
		colModel: [
			{
				name: 'name',
				width: 75,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					return '<a data-id="'+ rowObject.contactsId +'" customer-name="'+ rowObject.name +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'customerName',
				sortable: false,
				width: 90
			},
			{
				name: 'position',
				sortable: false,
				width: 100
			},
			{
				name: 'phone',
				sortable: false,
				width: 80
			},
			{
				name: 'email',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	},

	// 详情tab菜单接口
	// infoNav: '../../pages/test/infoTab.json',
	infoNav: '/contacts/infoTab',

	// 详情右侧任务接口
	// infoSlideTask: '../../pages/test/infoSlideTask.json',
	infoSlideTask: '/contacts/findTopUnfinishTask',

	// 详情右侧参与成员接口
	// infoSlideStaff: '../../pages/test/infoSlideStaff.json',
	infoSlideStaff: '/contacts/findShareEmployee',
	// detailItemReport: '../../pages/test/itemReport.json',

	// 拜访报告接口
	// 参数 dataId（id）&type（栏目名称）
	infoReport:	'/communication/findTab',

	// 详情(资料)接口
	// 参数 dataId（id）&type（栏目名称）
	infoDetail: '/contacts/get',

	// 联系人接口
	// 参数 dataId（id）&type（栏目名称）
	infoContacts:	'/contacts/findTab',

	// 商机接口
	// 参数 dataId（id）&type（栏目名称）
	infoChance:	'/opportunity/findTab',

	// 售后接口
	// 参数 dataId（id）&type（栏目名称）
	infoServer:	'/service/findTab',

	// 任务日程接口
	// 参数 customerId（客户id）&type（栏目名称）
	infoTask:	'/contacts/findTask'
};




(function($){
	//4、定义jquery对象
	var customerEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');

	//5、点击列表-显示详情
	function getDetail(){
			var dataId = $(this).attr('data-id');
			
			pageDataSet.dataId = dataId;

			// 判断栏目是否存在
			if(!moduleConfig.activeModule.moduleName){
				return false;
			}

			clickInfoBox = true;
			$contentWrapper.find('.content-info').addClass('active');
			
			//5.1保存客户名称
			pageDataSet.customerName = $(this).attr('customer-name');

			//5.2详情显示当前客户名称
			$contentWrapper.find('.detail .js-name').html(pageDataSet.customerName);

			// console.log(moduleConfig.activeModule);
						
			//5.3加载tab导航
			var navJqx = baseEvn.ajaxFun({
				// url: baseEvn.ajaxUrl.infoNav,
				url: moduleConfig.activeModule.infoNav,
				data: {
					id:dataId
				}
			});

			navJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoNavTpl',
					outputId: $contentWrapper.find('.content-info .detail-nav'),
					data: result,
					callback: function(outObj){
						outObj.find('a').eq(0).addClass('active');
					}
				});
			}).fail(function(){
				// console.log('fail');
			}).always(function(){
				// console.log('aways');
			});
			
			
			//5.4显示拜访报告
			var reportJqx = baseEvn.ajaxFun({
				// url: baseEvn.ajaxUrl.infoSlideTask,
				url: moduleConfig.activeModule.infoReport,
				data: {
					dataId:dataId,
					type:moduleConfig.activeModule.moduleName
				}
			});

			reportJqx.done(function(result){
				//console.log(result);
				renderEvn.renderTpl({
					tplId: '#infoDetailReportTpl',
					outputId: $contentWrapper.find('.content-info .item-report'),
					data: result,
					callback: function(outObj){
						outObj.addClass('active');
					}					
				});
			}).fail(function(){
				 //console.log('fail');
			}).always(function(){
				 //console.log('aways');
			});
			 
 		
			//5.5加载任务提醒
			var taskJqx = baseEvn.ajaxFun({
				// url: baseEvn.ajaxUrl.infoSlideTask,
				url: moduleConfig.activeModule.infoSlideTask,
				data: {
					id:dataId
				}
			});

			taskJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoSlideTaskTpl',
					outputId: $contentWrapper.find('.content-info .slide .task'),
					data: result
				});
			}).fail(function(){
				// console.log('fail');
			}).always(function(){
				// console.log('aways');
			});
			
			//5.6负责人
			var taskJqx = baseEvn.ajaxFun({
				// url:baseEvn.ajaxUrl.customerGet,
				url: moduleConfig.activeModule.infoDetail,
				data:{
					dataId:dataId
				}
			});

			taskJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoSlideLeader',
					outputId: $contentWrapper.find('.content-info .slide .leading'),
					data: result
				});
			}).fail(function(){
				// console.log('fail');
			}).always(function(){
				// console.log('aways');
			});
			
			//5.7加载参与成员
			var staffJqx = baseEvn.ajaxFun({
				// url: baseEvn.ajaxUrl.infoSlideStaff,
				url: moduleConfig.activeModule.infoSlideStaff,
				data: {
					id : dataId
				}
			});

			staffJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoSlideStaffTpl',
					outputId: $contentWrapper.find('.content-info .slide .staff'),
					data: result
				});
			}).fail(function(){
				// console.log('fail');
			}).always(function(){
				// console.log('aways');
			});
	};
	
	//6、列表右上角，新建商机按钮 
	
	//6、添加按钮的绑定
	// 右侧栏-操作区域-添加
	customerEvn.detailOpt = function(){
		$contentWrapper.on('click','.js-detail-opt a',function(){
			var type = $(this).attr('data-type'),
				tplId = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'report':
					tplId = '#popAddReportTpl';
					break;
				case 'contact':
					tplId = '#popAddContactTpl';
					break;
				case 'chance':
					tplId = '#popAddChanceTpl';
					break;
				case 'service':
					tplId = '#popAddServicetTpl';
					break;
				case 'del':
					tplId = '#popSingleCustomerDelTpl';
					break;
				case 'transform':
					tplId = '#popTransformTpl';
					break;
				case 'task':
					//tplId = '#popAddtasktTpl';
					tplId = '#popAddtasktTpl_contacts';
					break;
			}
			
			// 渲染模板
			if (type){
				renderEvn.renderTpl({
					tplId: tplId,
					outputId: '#pop',
					data:{
						customerId:pageDataSet.dataId,
						customerName:pageDataSet.customerName
					},
					callback: function(outObj){
						popEvn.setPopcontentHeight();
						outObj.show();
					}
				});
			}
			
		});	
	};

	 

	// 右侧栏 - 添加成员
	customerEvn.addRelativeStaff = function(){
		$contentWrapper.on('click','.js-add-staff-btn',function(){
			// 每次点击要请求的接口
			var ajaxUrl = '/customer/findCustomerType';

			renderEvn.renderTpl({
				tplId: '#popAddMember',
				outputId: '#pop',
				data:{
					customerId:pageDataSet.dataId,
					customerName:pageDataSet.customerName
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
	};

	// 右侧栏-参与成员删除
	customerEvn.deleteRelativeStaff = function(){
		$contentWrapper.on('click','.js-staff-d',function(){
			renderEvn.renderTpl({
				tplId: '#popDelRelativeStaffTpl',
				outputId: '#pop',
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
	};


	// 详情页 - 单条记录删除
	customerEvn.detailDelTitle = function(){
		$contentWrapper.on('click','.js-title-d',function(){
	
			var id = $(this).closest('.item-box').attr('data-id'),
				name= $(this).closest('.item-box').attr('data-name'),
				deleteType = $(this).attr('deleteType'),
				remindContent = '';
	
			// 根据不同tab，显示不同弹出框
			switch (deleteType){
				case 'delComm':
					remindContent = '是否确定删除选中拜访报告记录['+name+']<br>删除之后，该操作将无法恢复。';
					break;
				case 'delContacts':
					remindContent = '是否确定删除选中联系人记录['+name+']<br>删除之后，该操作将无法恢复。';
					break;
				case 'delOpp':
					remindContent = '是否确定删除选中商机记录['+name+']<br>删除之后，该操作将无法恢复。';
					break;
				case 'delService':
					remindContent = '是否确定删除选中售后记录['+name+']<br>删除之后，该操作将无法恢复。';
					break;
				case 'delService':
					remindContent = '是否确定删除选中商机['+name+']<br>删除之后，该操作将无法恢复。';
					break;
			}
			if (deleteType){
				renderEvn.renderTpl({
					tplId: '#popSingleDelTpl',
					outputId: '#pop',
					data:{
						remindContent:remindContent,
						deleteType: deleteType,
						dataId:id
					},
					callback: function(outObj){
						popEvn.setPopcontentHeight();
						outObj.show();
					}
				});
			}	
		});
	};
 
	// 弹出框-保存（确定）
	customerEvn.saveOpt = function(){
		$pop.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'addCustomer':
					ajaxUrl = '/customer/add';
					break;
				case 'report':
					ajaxUrl = '/communication/add';
					break;
				case 'contact':
					ajaxUrl = '/contacts/add';
					break;
				case 'chance':
					ajaxUrl = '/opportunity/add';
					break;
				case 'service':
					ajaxUrl = '/service/add';
					break;
				case 'del':
					ajaxUrl = '/customer/delete';
					break;
				case 'transform':
					ajaxUrl = '/customer/changeCharge';
					break;
				case 'task':
					ajaxUrl = '/contacts/createTask';
					break;
				case 'addMember':
					ajaxUrl = '/customer/addShareEmployee';
					break;
				case 'topBarAddMember':
					ajaxUrl = '/customer/addShareEmployee';
					break;
				case 'topBarRemoveMember':
					ajaxUrl = '/customer/deleteShareEmployee';
					break;
				case 'MulDel':
					ajaxUrl = '/customer/delete';
					break;
				case 'delContacts':
					ajaxUrl = '/contacts/delete';
					break;
				case 'delOpp':
					ajaxUrl = '/opportunity/delete';
					break;
				case 'delService':
					ajaxUrl = '/service/delete';
					break;
				case 'removeSingleMember':
					ajaxUrl = '/customer/deleteShareEmployee';
					break;
				case 'delComm':
					ajaxUrl = '/communication/delete';
					break;
				
			}
			if(ajaxUrl){
				//表单提交
				var formData = $(this).parents("form:first").serialize();
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});

				formJqx.done(function(result){
					if(result.type=="success"){
						$item.parents('.pop-main').remove();
						$("#pop").hide();

						popEvn.hint({
							txt:'操作成功'
						});
					}else if(result.type=="error"){
						alert(result.content);
					}
				});
			}
		});	
	};
	
	
	// 详情页的tab切换
	function tabDetail(){
		var Idx = $(this).index();

		if($(this).hasClass('active')){
			return false;
		}

		$(this).addClass('active').siblings().removeClass('active');
		$contentWrapper.find('.detail-main .main-item').eq(Idx).addClass('active').siblings().removeClass('active');
		
		var opts = {
				url: moduleConfig.activeModule.infoReport,
				data: {
					type: moduleConfig.activeModule.moduleName,
					dataId: pageDataSet.dataId
				},
				tplId: pageDataSet.tplName.infoReport,
				outputId: $contentWrapper.find('.item-report')
			};
		var datatype = $(this).attr('data-type');

		switch (datatype){
			case 'report':
				break;
			case 'data':
				opts.url = moduleConfig.activeModule.infoDetail,
				opts.tplId = pageDataSet.tplName.infoDetailCustomer,
				opts.outputId = $contentWrapper.find('.item-customer');
				break;
			case 'contact':
				opts.url = moduleConfig.activeModule.infoContacts,
				opts.tplId = pageDataSet.tplName.infoDetailContact,
				opts.outputId = $contentWrapper.find('.item-contact');
				break;
			case 'chance':
				opts.url = moduleConfig.activeModule.infoChance,
				opts.tplId = pageDataSet.tplName.infoDetailChance, 
				opts.outputId = $contentWrapper.find('.item-chance');
				break;
			case 'service':
				opts.url = moduleConfig.activeModule.infoServer,
				opts.tplId = pageDataSet.tplName.infoDetailServer,
				opts.outputId = $contentWrapper.find('.item-server');
				break;	
			case 'task':
				opts.url = moduleConfig.activeModule.infoTask,
				opts.tplId = pageDataSet.tplName.infoDetailTask,
				opts.outputId = $contentWrapper.find('.item-task');
				 
				break;
			default:
				break;
		}
		

		//console.log(opts);
		var tabJqx = baseEvn.ajaxFun(opts);

		tabJqx.done(function(result){
			console.log(result);
			if (result.type === "success") {
			 
				renderEvn.renderTpl({
					tplId: opts.tplId,
					outputId: opts.outputId,
					data: result
				});
			}
		});
	};
	 
	
	 
	 
	// 初始化
	customerEvn.init = function(){

		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		
		// 查看详情
		$wrapper.on('click','.js-get-info',getDetail);
		
		// 详情页的tab切换
		$contentWrapper.on('click','.js-detail-nav a',tabDetail);
		
		// 添加商机
		//$contentWrapper.on('click','.js-toolbar-ctrl a',addChance);
		
		// 弹出框 - 客户搜索下拉框
		$pop.on('click','.box-list .js-list-checked',function(){
			$(this).parents('li').toggleClass('active');
		});
		
		// 弹窗 - 搜索下拉出来（搜索成员）
		$body.on('click','.search-fl .js-icon-search',function(){

			var keyword = $(this).parent().find(".search-intxt").val();

			// 加载参与成员
			var searchMemberJqx = baseEvn.ajaxFun({
			    url: "/user/findByName",

			//	url:'../../pages/test/customerList.json',
				data: {
					keyword: keyword
				}
			});

			searchMemberJqx.done(function(result){

				// console.log(result);
				renderEvn.renderTpl({
					tplId: '#popFindMember',
					outputId: $pop.find('.search-select-box'),
					data: result.args.list
				});

				// 添加上下页的可点击按钮

			}).fail(function(result){
				console.log('fail');
				renderEvn.renderTpl({
					tplId: '#popFindMember',
					outputId: $pop.find('.search-select-box'),
					callback: function(outObj){
						popEvn.setPopcontentHeight();
						outObj.show();
					}
				});
			});
			
			$('.search-fl').toggleClass('active');
		});


		// 左侧操作区 添加按钮显示
		$contentWrapper.on('click','.js-icon-add',function(){
			$contentWrapper.find('.js-detail-opt .sub-menu').addClass('active');
		});

		// 左侧操作区 添加按钮隐藏
		$contentWrapper.on('mouseleave','.js-detail-opt .sub-menu',function(){
			$contentWrapper.find('.js-detail-opt .sub-menu').removeClass('active');
		});

		// 弹出框
		this.detailOpt();
		//弹出框的保存
		this.saveOpt();
		// 添加相关成员
		this.addRelativeStaff();
		// 详情页 - 复选框的勾选
		baseEvn.checkboxChange();
		
		// 相关成员的删除
		this.deleteRelativeStaff();

		// 详情页内的删除
		this.detailDelTitle();

		// table -操作区table-batch-ctrl
		this.tablBatchCtrl();

	};


	$(function(){
		customerEvn.init();
	});

})(jQuery);