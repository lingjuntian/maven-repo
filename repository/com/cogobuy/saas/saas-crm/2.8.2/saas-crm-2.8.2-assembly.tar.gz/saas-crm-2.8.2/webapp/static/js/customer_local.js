/**
 * 1、加载客户界面
 * 1.1、请求获取客户列表
 * 1.1.1 分页导航条
 * 1.2、请求获取客户类型
 * 1.3、请求获取客户分组统计（暂时不做）
 * 1.4、客户转移
 * 1.5、删除客户
 * 1.6、批量设置团队成员（仅负责人）
 *
 * 2、点击请求获取客户详情
 * 2.1 获取拜访报告列表
 * 2.2 获取标签数值
 * 2.3 获取任务提醒（top）
 * 2.4 参与成员
 * 
 * 3、tab点击事件
 * 3.1、查询对应资料tab数据
 * 3.2、查询对应联系人tab数据
 * 3.3、查询对应商机tab数据
 * 3.4、查询对应售后tab数据
 * 3.5、查询对应任务日程tab数据
 * 
 * 4、tab中的操作
 * 4.1、拜访报告编辑
 * 4.2、资料编辑
 * 4.3、联系人编辑
 * 4.4、商机编辑
 * 4.5、售后编辑
 * 4.6、任务日程编辑、确认完成（任务日程添加完成字段）
 * 
 * 5、右侧操作
 * 5.1、新增客户
 * 5.2、新增联系人
 * 5.3、新增商机
 * 5.4、新增售后
 * 5.5、创建任务
 * 5.6、添加参与成员（仅负责人）
 * 5.7、删除参与成员（仅负责人）
 * 
 * 
 * 
 */
 


///** 1.1 请求获取客户列表（含分页导航条） **/
//$.getJSON("/customer/find",function(result){
//	var listtpl = $('#cust_list').html();
//	laytpl(listtpl).render(result, function(html){
//		$('#dataListView').html(html);
//	});
//	
//	var pagetpl = $('#cust_list_page').html();
//	laytpl(pagetpl).render(result, function(html){
//		$('#pageView').html(html);
//	});
//	
//	getCustomerType();
//});


	$.getJSON("/communication/findTab?type="+'customer'+"&dataId="+'B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4',function(result){
		if (result.type === "success") {
			//单独处理日期格式
			var commList = result.args;
			for (var i=0,len = commList.length;i < len; i++) {
				var commTime = commList[i].commTime;
				var date = new Date(Date.parse(commTime));
				commList[i].commTime = date.getMonth() + "月" + date.getDay() + "日";
				
			}
			var infoDetailReportTpl = $('#infoDetailReportTpl').html();
			laytpl(infoDetailReportTpl).render(commList, function(html){
				$('div.main-item.item-report').html(html);
			});
		} else {
			alert(result.content);
		}
	});
	
	$.getJSON("/contacts/findTab?type="+'customer'+"&dataId="+'B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4',function(result){

		if (result.type === "success") {
			var infoDetailContactTpl = $('#infoDetailContactTpl').html();
			laytpl(infoDetailContactTpl).render(result.args, function(html){
				$('div.main-item.item-contact').html(html);
			});
		} else {
			alert(result.content);
		}
	});
	
	$.getJSON("/opportunity/findTab?type="+'customer'+"&dataId="+'B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4',function(result){

		if (result.type === "success") {
			var infoDetailChanceTpl = $('#infoDetailChanceTpl').html();
			laytpl(infoDetailChanceTpl).render(result.args, function(html){
				$('div.main-item.item-chance').html(html);
			});
		} else {
			alert(result.content);
		}
	});
	
	$.getJSON("/service/findTab?type="+'customer'+"&dataId="+'B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4',function(result){
		if (result.type === "success") {
			var infoDetailServerTpl = $('#infoDetailServerTpl').html();
			laytpl(infoDetailServerTpl).render(result.args, function(html){
				$('div.main-item.item-server').html(html);
			});
		} else {
			alert(result.content);
		}
	});
	
	$.getJSON("/customer/findTask?customerId="+'B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4',function(result){
		if (result.type === "success") {
			var infoDetailTaskTpl = $('#infoDetailTaskTpl').html();
			laytpl(infoDetailTaskTpl).render(result.args, function(html){
				$('div.main-item.item-task').html(html);
			});
		} else {
			alert(result.content);
		}

	});


function getDateValue(date) {
	return date.format("yyyy-MM-dd");
}
	
function getDetail(data_id){	
	$.getJSON("/customer/get?id="+data_id,function(result){
		var infotpl = $('#cust_detail_info').html();
		laytpl(infotpl).render(result, function(html){
			$('#dataListView').html(html);
		});
	});
	 
};

function getCustomerType(){

	$.getJSON("/customer/findCustomerType",function(result){
		var customerTypetpl = $('#cust_type').html();
		laytpl(customerTypetpl).render(result, function(html){
			$('#cus_create_type').html(html);
		});
	});
	 
};



/**
* 3、tab点击事件
* 3.1 查询对应的拜访报告tab数据
* 3.2、查询对应资料tab数据
* 3.3、查询对应联系人tab数据
* 3.4、查询对应商机tab数据
* 3.5、查询对应售后tab数据
* 3.6、查询对应任务日程tab数据
* */
function findCommunicationTab(type, dataId) {
	type='customer';
	dataId='B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4';
	$.getJSON("/communication/findTab?type="+type+"&dataId="+dataId,function(result){
		if (result.type === "success") {
			//单独处理日期格式
			var commList = result.args;
			for (var i=0,len = commList.length;i < len; i++) {
				var commTime = commList[i].commTime;
				var date = new Date(Date.parse(commTime));
				commList[i].commTime = date.getMonth() + "月" + date.getDay() + "日";
				
			}
			var infoDetailReportTpl = $('#infoDetailReportTpl').html();
			laytpl(infoDetailReportTpl).render(commList, function(html){
				$('div.main-item.item-report').html(html);
			});
		} else {
			alert(result.content);
		}
	});
}

function findContactsTab(type, dataId) {
	type='customer';
	dataId='B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4';
	$.getJSON("/contacts/findTab?type="+type+"&dataId="+dataId,function(result){

		if (result.type === "success") {
			var infoDetailContactTpl = $('#infoDetailContactTpl').html();
			laytpl(infoDetailContactTpl).render(result.args, function(html){
				$('div.main-item.item-contact').html(html);
			});
		} else {
			alert(result.content);
		}
	});
}


function findOpportunityTab(type, dataId) {
	type='customer';
	dataId='B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4';
	$.getJSON("/opportunity/findTab?type="+type+"&dataId="+dataId,function(result){

		if (result.type === "success") {
			var infoDetailChanceTpl = $('#infoDetailChanceTpl').html();
			laytpl(infoDetailChanceTpl).render(result.args, function(html){
				$('div.main-item.item-chance').html(html);
			});
		} else {
			alert(result.content);
		}
	});
}

function findServiceTab(type, dataId) {
	type='customer';
	dataId='B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4';
	$.getJSON("/service/findTab?type="+type+"&dataId="+dataId,function(result){
		if (result.type === "success") {
			var infoDetailServerTpl = $('#infoDetailServerTpl').html();
			laytpl(infoDetailServerTpl).render(result.args, function(html){
				$('div.main-item.item-server').html(html);
			});
		} else {
			alert(result.content);
		}
	});
}

function findServiceTab(customerId) {
	customerId='B41B2302-1F7A-4EBA-B35B-58CDB0CB11C4';
	$.getJSON("/customer/findTask?customerId="+customerId,function(result){
		if (result.type === "success") {
			var infoDetailTaskTpl = $('#infoDetailTaskTpl').html();
			laytpl(infoDetailTaskTpl).render(result.args, function(html){
				$('div.main-item.item-task').html(html);
			});
		} else {
			alert(result.content);
		}

	});
}




