(function($){
	'use strict';
	
$(function(){
		cluesEvn.init();
});


var cluesEvn = {
		
	init: function(){
		var $list = $('.list');
		
		cluesEvn.slyContent = baseEvn.slyFun('.content-main');
		cluesEvn.slyList = baseEvn.slyFun('.list-main');

		// console.log(cluesEvn.slyList.rel);

		cluesEvn.slyList.on('load move', function(){
			// console.log('123');
		});

		$(window).on('resize', function(){
			// cluesEvn.slyContent.reload();
			// cluesEvn.slyList.reload();
		});

		this.publicFun();
		this.bindEvent();
		this.initCustomer();
	},
	
	publicFun: function(){
		var $main = $('.main');

		// 评论框展开
		$main.on('focus', '.comments textarea', function(){
			var $parents = $(this).parents('.comments-in');

			if($parents.hasClass('comments-hide')){
				$parents.removeClass('comments-hide');

				setTimeout(function(){
					cluesEvn.slyContent.reload();
				},400);
			}
		});
	},

	initCustomer: function() {
		var that = this;

		var $popCustoemr = $('.pop .pop-clues input[name="customerName"]');
		that.customerComplete($popCustoemr);
		
	},
	
	customerComplete: function($customer) {
		var that = this;

		$customer.autocomplete({
			autoFocus: false,
			minLength:0,
			source: function(request, response) {
                $.ajax({
                    url: "/customer/findCustomerByName",
                    dataType: "json",
                    data: {
                        key: request.term
                    },
                    success: function(data) {
                        response($.map(data, function(item) {
                        	return { label: item.customerName, value: item.customerName, customerId: item.customerId }
                        }));
                    }
                });
            },
            
            change: function (event, ui) {
                if (!ui.item) {
                	that.customerId = undefined;
                 }
            },
            
　　　　　　	select: function(event, ui) {
	 			that.customerId = ui.item.customerId;
            },
            
		    messages: {
		        noResults: '',
		        results: function() {}
		    }
		}).focus(function(){
            $(this).autocomplete("search");
            return false;
		});
	},
	
	/**
	 * 绑定事件
	 */
	bindEvent: function() {
		var that = this;
		var $body = $('body'),
			$pop = $('#pop'),
			$main = $('.main');
		
		var $multiSelect = $main.find('.multi-select');
		
		$pop.on('click', '.pop-clues .btn-confirm', function(){
			
			if (!that.isLock("createClue")) {
				
				that.createClue();
			}
		});
		
		// 点击线索列表
		$main.find('.list-item').unbind();
		$main.on('click', '.list-item', function(){
			var $this = $(this);

			// 删除操作栏处于编辑状态的edit-msg类,和让编辑按钮显示
			$main.find('.content-nav .nav-msg').removeClass('edit-msg').removeClass('more-contacts');

			$this.parents('.list-main').find('.list-item').removeClass('active')
			$this.addClass('active');
			$multiSelect.find('.people-box li').remove();
			$main.find('.content .multi-select,.content-nav').removeClass('selected');

			$main.find('.crm').html('<span>线索</span><i>&gt;</i><span>'+ $this.find('.name span').text() +'</span>');
			
			that.clueId = $this.attr('clueId');
			$('.loading-box').addClass('active');
			that.getClueDetail();
			

		});
		
		$main.on('click', '.content-info .info-box .nav-msg a.save', function(){
			if (!that.isLock("modifyClue")) {
				that.modifyClue();
			}
		});
		
		$main.on('click', '.content-info .info-box .nav-msg a.del', function(){
			
			popEvn.confirmFun({
				btnobj: $(this),
				titleTxt: '温馨提示',
				contentTxt: '确认要删除该线索？',

				confirmCallback: function(btnobj){
					that.deleteClue();
				}
			});
			
		});
		
		$main.on('click', '.multi-select .nav-msg a.del', function(){
			popEvn.confirmFun({
				btnobj: $(this),
				titleTxt: '温馨提示',
				contentTxt: '确认要删除选中项？',

				confirmCallback: function(btnobj){
					that.deleteClueBatch();
				}
			});
			
		});
		
		$main.on('click', '.screening form dl.recent dd a', function(){
			that.getClueListByRecentGroup($(this));
			$main.find('.crm').html('<span>线索</span><i>&gt;</i><span>'+ $(this).text() +'</span>');
		});
		
		$main.on('click', '.screening form dl.source dd a', function(){
			that.getClueListBySourceGroup($(this));
			$main.find('.crm').html('<span>线索</span><i>&gt;</i><span>'+ $(this).text() +'</span>');
		});
	},
	
	
	/**
	 * 获取线索列表
	 */
	getClueList: function(callback) {
		var that = this;
		$.ajax({
		    type: 'get',
		    url: '/clue/getClueList' ,
		    dataType: 'html',
		    success: function(data,status){
    			if (status === "success") {
					$('.list-main dl').remove();
			    	$(".list-main").prepend(data);
					if (typeof callback == "function"){
						callback();
					}
    			} else {
					that.unlock();
    				alert("加载线索列表失败。");
    			}
		    },
		    complete: function() {
		    	that.unlock();
		    }
		});
	},
	
	getClueDetail: function(callback) {
		var that = this;
		var $main = $('.main');
		
		$.ajax({
		    type: 'get',
		    url: '/clue/getClueDetail',
		    data:{clueId: that.clueId},
		    dataType: 'html',
		    success: function(data,status){
				$('.loading-box').removeClass('active');
    			if (status === "success") {
					$('.content-info .info-box').remove();
			    	$(".content-info").prepend(data);
			    	$main.find('.default').hide();
			    	cluesEvn.slyContent.reload();
					var $modifyCustomer = $('.content-main form input[name="customerName"]');
					that.customerComplete($modifyCustomer);
					if (typeof callback == "function"){
						callback();
					}
    			} else {
					that.unlock();
    				alert("加载线索详细信息失败。");
    			}
		    },
		    complete: function() {
				$(".loading").removeClass("active");
		    	that.unlock();
		    }
		});
	},
	
	/**
	 * 获取线索列表
	 */
	getNavClueGroup: function() {
		var that = this;
		$.ajax({
		    type: 'get',
		    url: '/clue/getNavClueGroup' ,
		    dataType: 'html',
		    success: function(data,status){
    			if (status === "success") {
					$('.screening').remove();
			    	$(".list").prepend(data);
    			} else {
					that.unlock();
    				alert("加载筛选列表失败。");
    			}
		    },
		    complete: function() {
		    	that.unlock();
		    }
		});
	},
	
	/**
	 * 筛选最新新增
	 */
	getClueListByRecentGroup: function($this) {
		var that = this;
		
		var data= $this.attr("url");
		
		$.ajax({
		    type: 'get',
		    url: '/clue/getClueListByRecentGroup?'+data ,
		    dataType: 'html',
		    success: function(data,status){
    			if (status === "success") {
					$('.list-main dl').remove();
			    	$(".list-main").prepend(data);
    			} else {
					that.unlock();
    				alert("按最近新增加载线索列表失败。");
    			}
		    },
		    complete: function() {
		    	that.unlock();
		    }
		});
	},
	
	/**
	 * 筛选来源
	 */
	getClueListBySourceGroup: function($this) {
		var that = this;
		
		var data= $this.attr("url");
		$.ajax({
		    type: 'get',
		    url: '/clue/getClueListBySourceGroup?' + data ,
		    dataType: 'html',
		    success: function(data,status){
    			if (status === "success") {
					$('.list-main dl').remove();
			    	$(".list-main").prepend(data);
    			} else {
					that.unlock();
    				alert("加载线索列表失败。");
    			}
		    },
		    complete: function() {
		    	that.unlock();
		    }
		});
	},
	
	/**
	 * 新增线索
	 */
	createClue: function() {
		var that = this;
		var $pop = $("#pop");
		var $main = $(".main");
		
		var data= $(".pop-box.pop-clues .info-form").serialize();
		
		if (that.customerId){
			data = data + "&&customerId=" + that.customerId;
			that.customerId = undefined;
		}

		//异步调用服务端，传输对象为user
		this.lock("createClue");
		$.ajax({
		    type: 'post',
		    url: '/clue/createClue' ,
		    dataType: 'json',
		    data: data, 
		    success: function(message){
		    	if (message.type === "success") {
		    		$('.pop').slideUp('1000',function(){
		    			$('.pop-box').slideUp('1000');
		    		});
		    		$main.find('.default').show();
		    		$main.find('.content .multi-select,.content-nav').removeClass('selected');
		    		that.clueId = message.args.clueId;
		    		that.getClueList(function(){
		    			that.getClueDetail(function() {
		    				that.getNavClueGroup();
		    			});
		    			$('.list-main .list-item').each(function(){
		    				if($(this).attr("clueId") === that.clueId) {
		    					$(this).addClass("active");
		    				}
		    					
		    			});
		    		});
		    	} else {
		    		that.unlock();
		    		alert(message.content);
		    	}
		    },
		    error: function(data) {
		    	that.unlock();
		    	alert("新增线索失败。");
		    }
		});
	},
	
	/**
	 * 修改线索
	 */
	modifyClue: function() {
		var that = this;
		var data= $(".content-info .info-form").serialize();
		var clueId = $(".content-info form").attr("clueId");
		data = data + "&clueId=" + clueId;

		if (that.customerId){
			data = data + "&&customerId=" + that.customerId;
			that.customerId = undefined;
		}
		
		//异步调用服务端，传输对象为user
		this.lock("modifyClue");
		$.ajax({
		    type: 'post',
		    url: '/clue/modifyClue' ,
		    dataType: 'json',
		    data: data, 
		    success: function(message){
		    	if (message.type === "success") {
		    		var args = message.args;
		    		
	    			$(".list-main .list-item.active .name span").text(args.title);
	    			that.clueId = clueId;
					that.getClueDetail(function() {
						that.getNavClueGroup();
					});
	    			
		    		
		    	} else {
		    		that.unlock();
		    		alert(message.content);
		    	}
		    },
		    error: function(data) {
		    	that.unlock();
		    	alert("修改线索失败。");
		    }
		});
	},
	
	/**
	 * 删除线索
	 */
	deleteClue: function() {
		var that = this;
		var $main = $('.main');
		var clueId = $(".content-info form").attr("clueId");
		
		$.ajax({
		    type: 'post',
		    url: '/clue/deleteClue' ,
		    dataType: 'json',
		    data: {clueId: clueId}, 
		    success: function(message){
		    	if (message.type === "success") {
		    		that.getClueList(function(){
		    			that.getNavClueGroup();
		    		});
					$main.find('.default').show();
		    	} else {
		    		alert(message.content);
		    	}
		    },
		    error: function(data) {
		    	alert("删除线索失败。");
		    }
		});
	},
	
	/**
	 * 删除线索
	 */
	deleteClueBatch: function() {
		var that = this;
		var $main = $('.main');
		
		var clueIdList = [];
		$('.list-main .list-item.active').each(function(){
			clueIdList.push($(this).attr("clueId"));
		});
		
		$.ajax({
		    type: 'post',
		    url: '/clue/deleteClueBatch' ,
		    dataType: 'json',
		    contentType: "application/json; charset=utf-8",
		    data: $.toJSON(clueIdList), 
		    success: function(message){
		    	if (message.type === "success") {
		    		that.getClueList(function(){
		    			that.getNavClueGroup();
		    		});
		    		$main.find('.default').show();
		    		$main.find('.content .multi-select,.content-nav').removeClass('selected');
		    	} else {
		    		alert(message.content);
		    	}
		    },
		    error: function(data) {
		    	alert("删除线索失败。");
		    }
		});
	},
	
	/**
	 * 调用ajax方法前，添加锁
	 */
	lock: function(methodName) {
		this.methodName = methodName;
		this.lockFlag = true;
	},
	
	/**
	 * 去掉锁
	 */
	unlock: function() {
		this.lockFlag = false;
	},
	
	/**
	 * 是否上锁。
	 */
	isLock: function(methodName) {
		if (this.methodName === methodName && this.lockFlag) {
			return true;
		} else {
			return false;
		}
	}
	

};




}(jQuery));
