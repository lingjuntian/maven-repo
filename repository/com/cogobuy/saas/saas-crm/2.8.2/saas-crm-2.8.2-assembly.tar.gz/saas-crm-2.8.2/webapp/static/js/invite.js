(function($){

$(function(){
	inviteEvn.init();
});

var inviteEvn = {

	addInvite: function() {
		var $formBox = $('#formBox');
		
		$formBox.on('click', '.js-btn-invite', function() {
			var phone = $formBox.find('#phone').val();
			
			if (!phone) {
				alert("手机号为空");
				return;
			}
		
			phone = $formBox.find('input[name="areaCode"]').val() + phone;

			var addxhr = baseEvn.ajaxFun({
				url: '/user/addInvite',
				data: {
					mobile: phone,
					code: $("#code").val(),
					name: $("#name").val(),
					email: $("#email").val(),
					inviter: $("#inviter").val()
				}
			});

			addxhr.done(function(result){
				if (result.type === "success") {
					alert("邀请成员成功");
					setTimeout(function(){
						window.location.href = '/login';
					},2000);
				} else {
					alert(result.content);
				}

			}).fail(function() {
				alert("邀请成员失败");
			});
		});
	},

	// 获取手机验证码
	getCaptcha : function() {
		var $formBox = $('#formBox');

		// 获取手机验证码
		$formBox.on('click', '.btn-code', function() {
			var phone = $formBox.find('#phone').val();
			
			if (!phone) {
				alert("手机号为空");
				return;
			}
			
			
			phone = $formBox.find('input[name="areaCode"]').val() + phone;

			// 埋点记录-点击获取手机验证码
	        logsEvn.init([
	            ['clickBtn', 'loginGetCode']
	        ]);

			// 验证
			if(!$(this).hasClass('z-cld')){
				$(this).addClass('z-cld');
				
				timeOut($(this), 60);

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/getAuthenticode',
					data : {
						phone : phone
					}
				});

				phoneXhr.fail(function() {
					alert('验证码发送异常，请稍候重试');
				});
			}else{
				return false;

			}
		});

		// 倒计时
		function timeOut(btnObj, capTimeNum) {

			capTimeNum--;
			btnObj.html(capTimeNum + '秒后重发');

			inviteEvn.capTime = setTimeout(function() {
				if (capTimeNum <= 0) {
					clearTimeout(inviteEvn.capTime);
					btnObj.html('获取验证码').removeClass('z-cld');
				} else {
					timeOut(btnObj, capTimeNum);
				}
			}, 1000);
		};
	},

	init: function(){
		// 定时器对象-全局变量
		this.capTime = null;
		this.getCaptcha();
		this.addInvite();
	}
};

}(jQuery));
