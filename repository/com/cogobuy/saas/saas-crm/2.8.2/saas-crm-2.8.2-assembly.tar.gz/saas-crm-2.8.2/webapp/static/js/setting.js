var moduleName = 'setting';

moduleConfig.activeModule = {
	moduleName: 'setting',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		// dataUrl: '../../pages/test/staffList.json',
		dataUrl: '/setting/findStaffInfo',
		// 默认的排序列
		sortname: 'staffName',
		// 表头名称
		colNames : ['姓名','手机','邮箱','部门','角色','状态','最近登录时间'],
		colModel: [
			{
				name: 'name',
				width: 80,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);

					return '<a id="'+ rowObject.userId +'" class="js-staff-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'mobile',
				sortable: false,
				width: 80
			},
			{
				name: 'email',
				sortable: false,
				width: 100
			},
			{
				name: 'department',
				sortable: false,
				width: 80
			},
			{
				name: 'roleName',
				sortable: false,
				width: 80
				
			},
			{
				name: 'status',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					if (value == 1) {
						return "禁用";
					} else {
						return "启用";
					}

				}
			},
			{
				name: 'loginTime',
				sortable: false,
				width: 150,
				sorttype: 'date'
			}
		],
		// 选中行
		onSelectRowCallback: function(rowid,status){
			// console.log(rowid);
			var id = $('#saasGrid').jqGrid('getGridParam', 'selrow');

			if (id) {
				// 获取当前选中列的数据
				var ret = $('#saasGrid').jqGrid('getRowData', id);
				// console.log(ret);
			} else {
				// alert("Please select row");
			}
		}
	},

	// 目标管理表格
	planGridOpts: {
		tablewrap: '#planGrid',
		dataUrl: '/setting/findTarget',
		// 默认的排序列
		sortname: 'userName',
		// 表头名称
		colNames : ['姓名','任务周期','任务类型','任务数量'],
		colModel: [
			{
				name: 'userName',
				width: 80,
				sortable: false,
				formatter: function(value, options, rowObject){

					return '<a id="'+ rowObject.userId +'" year="' + rowObject.year + '" class="js-plan-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'cycle',
				width: 80,
				sortable: false,
				formatter: function(value, options, rowObject){
					var str = '',
						targetList = rowObject.targetList;

					for (var i = targetList.length - 1; i >= 0; i--) {
						str += '<div>' + targetList[i].cycle + '</div>';
					};

					return str;
				}
			},
			{
				name: 'moduleType',
				width: 80,
				sortable: false,
				formatter: function(value, options, rowObject){
					var str = '',
						targetList = rowObject.targetList;
					
					for (var i = targetList.length - 1; i >= 0; i--) {
						str += '<div>' + targetList[i].moduleType + '</div>';
					};

					return str;
				}
			},
			{
				name: 'target',
				width: 80,
				sortable: false,
				formatter: function(value, options, rowObject){
					var str = '',
						targetList = rowObject.targetList;
					
					for (var i = targetList.length - 1; i >= 0; i--) {
						str += '<div>' + targetList[i].target + '</div>';
					};

					return str;
				}
			},
		],
		// 选中行
		onSelectRowCallback: function(rowid,status){
			// console.log(rowid);
			var id = $('#saasGrid').jqGrid('getGridParam', 'selrow');

			if (id) {
				// 获取当前选中列的数据
				var ret = $('#saasGrid').jqGrid('getRowData', id);
				// console.log(ret);
			} else {
				// alert("Please select row");
			}
		}
	},

	// 修改成员资料
	changeMyInfo: '/setting/changeMyInfo',
	// 设置密码
	setPassword: '/setting/setPassword',
	// 修改密码
	changePassword: '/setting/changePassword',

	// 添加成员-获取数据
	findRole: '/setting/findCompanyRole',
	// 编辑成员-获取数据
	getEditRole: '/setting/getStaffEditInfo',
	// 添加成员-提交
	addStaffInfo: '/setting/addStaffInfo',
	// 编辑成员-提交
	changeStaffInfo: '/setting/changeStaffInfo',


	// 获取成员目标信息
	getUserTarget: '/setting/getUserTarget',
	// 查找用户
	findByName: '/user/findByKeyName',
	// 设置目标
	addUserTarget: '/setting/addUserTarget',
	// 修改目标
	changeUserTarget: '/setting/changeUserTarget',
	// 获取年选择列表
	findTargetYear: '/setting/findTargetYear',
	// 获取任务目标
	findTarget: '/setting/findTarget',
	// 判断是否已经设置任务目标
	isExistTargets: '/setting/isExistTargets'
	
};

(function($){
	var pageDataSet = {},
		settingEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop');
	
	
	// 成员管理
	settingEvn.staffFun = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);

		// 添加成员-获取相应数据-显示弹出框
		$contentWrapper.on('click', '.js-add-staff', function(){
			var Jqx = baseEvn.ajaxFun({
				url: moduleConfig.activeModule.findRole
			});

			Jqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#popAddStaffTpl',
					outputId: '#pop',
					data: result.args,
					callback: function() {
						popEvn.open();					
					}
				});
			});

		});

		// 编辑成员-获取相应数据-显示弹出框
		$contentWrapper.on('click', '.js-staff-info', function(){
			var userId = $(this).attr('id');
			var Jqx = baseEvn.ajaxFun({
				url: moduleConfig.activeModule.getEditRole,
				data: {
					userId: userId
				}
			});

			Jqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#popEditStaffTpl',
					outputId: '#pop',
					data: result.args,
					callback: function() {
						popEvn.open();
					}
				});
			});
		});
		
		// 添加成员提交按钮
		$pop.on('click', '#popAddStaff .js-pop-save', function(){
			$form = $('#popAddStaff');
			var jqx = baseEvn.ajaxFun({
				url: moduleConfig.activeModule.addStaffInfo,
				data: $form.serialize()
			});
			
			jqx.done(function(result){
				if (result.type === "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					
					// 刷新表格
					var page = $('.toolbar-item.num').find('a.active').text();
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
			
		});
		
		// 编辑成员提交按钮
		$pop.on('click', '#popEditStaff .js-pop-save', function(){
			$form = $('#popEditStaff');
			var jqx = baseEvn.ajaxFun({
				url: moduleConfig.activeModule.changeStaffInfo,
				data: $form.serialize()
			});
			
			jqx.done(function(result){
				if (result.type === "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					
					// 刷新表格
					var page = $('.toolbar-item.num').find('a.active').text();
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
					
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
			
		});
		
		// 删除成员-出现弹窗
		$contentWrapper.on('click','.table-batch-ctrl .del',function(){
			
			var userIdList = [];
			var $table = $('#saasGrid');
			
			$table.find('tr[aria-selected="true"]').each(function(){
				userIdList.push($(this).find('a').attr('id'));
			});
			
			var remindContent='是否确定删除选中的'+userIdList.length+'个成员？删除之后，该操作将无法恢复。'
			renderEvn.renderTpl({
				tplId: '#popMulDelTpl',
				outputId: '#pop',
				data:{
					remindContent: remindContent
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
		
		
		// 确定删除成员
		$pop.on('click','#popMulDel a.js-pop-save',function(){
			
			// 获取选中id
			var userIdList = [];
			var $table = $('#saasGrid');
			
			$table.find('tr[aria-selected="true"]').each(function(){
				userIdList.push($(this).find('a').attr('id'));
			});
			
			var jqx = baseEvn.ajaxFun({
				url: '/setting/deleteBatchUser',
				contentType : 'application/json;charset=utf-8',
				data: JSON.stringify(userIdList)
			});
			
			jqx.done(function(result){
				if (result.type === "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					// 刷新表格
					var page = $('.toolbar-item.num').find('a.active').text();
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		
	};


	// 目标设定
	settingEvn.planFun = function(){
		// 获取年选择列表
		var jqx = baseEvn.ajaxFun({
			url: moduleConfig.activeModule.findTargetYear
		});
		
		jqx.done(function(result){
			renderEvn.renderTpl({
				tplId: '#targetYearTpl',
				outputId: '.content-main .js-screen',
				data: result.args,
				callback: function(obj) {
					var year = $('.content-main .screen-title span').attr('data-year');
					var url =moduleConfig.activeModule.findTarget + '?year=' + year;
					moduleConfig.activeModule.planGridOpts.dataUrl = url;
					gridEvn.init(moduleConfig.activeModule.planGridOpts);
				}
			});
		});
		
		$('body').on('click', '.js-auto-fill-input', function(){
			$(this).autoFill();
		});
		
		// 切换年份
		$contentWrapper.on('click','.js-screen .screen-title',function(){
			$(this).closest('.js-screen').find('.menu-box').addClass('active').find('.menu-2-box').addClass('active');			
		});
		$contentWrapper.on('click','.js-screen .menu-2-box li',function(){
			var year = $(this).find('a').text();
			$(this).closest('.js-screen').find('.screen-title span').text(year+'年').attr('data-year',year);
			
			var url =moduleConfig.activeModule.findTarget + '?year=' + year;
			moduleConfig.activeModule.planGridOpts.dataUrl = url;
			gridEvn.init(moduleConfig.activeModule.planGridOpts);
		});
		
		// 添加任务目标
		$contentWrapper.on('click', '.js-add-plan', function(){
			renderEvn.renderTpl({
				tplId: '#popAddGoalTpl',
				outputId: '#pop',
				callback: function(outObj){
					popEvn.open();
				}
			});
		});

		// 编辑任务目标
		$contentWrapper.on('click', '.js-plan-info', function(){
			var userId = $(this).attr("id"),
				year = $(this).attr("year");
			var jqx = baseEvn.ajaxFun({
				url: moduleConfig.activeModule.getUserTarget,
				data: {
					year: year,
					userId: userId
				}
			});
			
			jqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#popEditGoalTpl',
					outputId: '#pop',
					data: result.args,
					callback: function(){
						popEvn.open();
					}
				});
			});	
		});
		
		// 添加任务目标，点击保存
		$pop.on('click','#popAddGoal .js-pop-save',function(){
			// 判断是否选择了用户
			var user = {},
				userId = $('.search-box dl input[name="toUserId"]').val(),
				userName = $('.search-box dl input[name="toUserName"]').val();

			if (!userId || !userName) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '请选择成员'
				});
				return;
			}
			// 赋值用户信息
			user.userId = userId;
			user.name = userName;
			
			// 赋值年信息
			var year = $('#popAddGoal .in-box.year p').text();
			
			
			
			// 处理目标信息
			var $target = $('#popAddGoal .in-box-subbox.info'); 
			var result = settingEvn.checkTarget($target);
			// 校验目标是否正确
			if (!result.flag) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: result.text
				});
				return;
			}
			
			var targetList=[];
			$target.each(function(i, obj){
				var cycle = $(this).find('.cycle').val();
				var moduleType = $(this).find('.module-type').val();
				var count = $(this).find('input').val();
				
				// 允许一行全部不选择，不做处理
				if (cycle == "unselect" && moduleType == "unselect" && !count) {
					
				} else {

					var target = {};
					target.cycle = cycle;
					target.moduleType = moduleType;
					target.target = count;
					targetList.push(target);
				}
			});
			
			var userTargetVO = {};
			userTargetVO.user = user;
			userTargetVO.year = year;
			userTargetVO.targetList = targetList;
			
			// 放到页面的全局变量中
			pageDataSet.userTargetVO = userTargetVO;

			// 判断用户是否已经创建任务目标
			var isExistJqx = baseEvn.ajaxFun({
				url: moduleConfig.activeModule.isExistTargets,
				data: {
					userId: userId,
					year: year
				}
			});
			
			isExistJqx.done(function(result){
				if (result.type == "success") {
					if (result.args) {
						renderEvn.renderTpl({
							tplId: '#popTargetExistTpl',
							outputId: '#pop',
							data: {
								name: user.name
							},
							callback: function(){
								popEvn.open();
							}
						});
					
					} else {
						// 添加任务目标
						var jqx = baseEvn.ajaxFun({
							url: moduleConfig.activeModule.addUserTarget,
							contentType : 'application/json;charset=utf-8',
							data: JSON.stringify(pageDataSet.userTargetVO)
						});
						
						jqx.done(function(result){
							if (result.type == "success") {
								$("#pop").hide();
								popEvn.hint({
									txt: result.content
								});
								// 刷新表格
								var page = $('.toolbar-item.num').find('a.active').text();
								data = {
									pageNo: page
								};
								gridEvn.loadData(data);
							} else {
								popEvn.hint({
									tipsClass: 'pop-tips-warn',
									txt: result.content
								});
							}
						});
					}
				}
			}).fail(function(result){
				
			});
		});
		
		// 确认替换用户的任务目标
		$pop.on('click','#popTargetExist .js-pop-save',function() {

			var jqx = baseEvn.ajaxFun({
				url: moduleConfig.activeModule.changeUserTarget,
				contentType : 'application/json;charset=utf-8',
				data: JSON.stringify(pageDataSet.userTargetVO)
			});
			
			jqx.done(function(result){
				if (result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					
					// 刷新表格
					var page = $('.toolbar-item.num').find('a.active').text();
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
			
		});
		
		// 修改任务目标，点击保存
		$pop.on('click','#popEditGoal .js-pop-save',function(){
			// 判断是否选择了用户
			var user = {},
				userId= $('#popEditGoal').attr("userId");
			// 赋值用户信息
			user.userId=userId;
			
			// 赋值年信息
			var year = $('#popEditGoal .in-box.year p').text();
			
			
			// 处理目标信息
			var $target = $('#popEditGoal .in-box-subbox.info'); 
			var result = settingEvn.checkTarget($target);
			// 校验目标是否正确
			if (!result.flag) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: result.text
				});
				return;
			}
			
			var targetList=[];
			$target.each(function(i, obj){
				var cycle = $(this).find('.cycle').val();
				var moduleType = $(this).find('.module-type').val();
				var count = $(this).find('input').val();
				
				// 允许一行全部不选择，不做处理
				if (cycle == "unselect" && moduleType == "unselect" && !count) {
					
				} else {
					var target = {};
					target.cycle = cycle;
					target.moduleType = moduleType;
					target.target = count;
					targetList.push(target);
				}
			});
			
			var userTargetVO = {};
			userTargetVO.user=user;
			userTargetVO.year=year;
			userTargetVO.targetList=targetList;
			var jqx = baseEvn.ajaxFun({
				url: '/setting/changeUserTarget',
				contentType : 'application/json;charset=utf-8',
				data: JSON.stringify(userTargetVO)
			});
			
			jqx.done(function(result){
				if (result.type == "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					// 刷新表格
					var page = $('.toolbar-item.num').find('a.active').text();
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});

		// 点击添加一行
		$pop.on('click','.js-add-oneline',function(){
			var str = 	'<div class="in-box-subbox clearfix info">\
	                        <select class="assessment in-sel cycle" name="targetList.cycle" id="">\
	                            <option value="unselect">请选择周期</option>\
	                            <option value="周">每周</option>\
	                            <option value="月">每月</option>\
	                            <option value="季度">每季度</option>\
	                            <option value="年">每年</option>\
	                        </select>\
	                        <select class="assessment in-sel module-type" name="targetList.moduleType" id="">\
	                            <option value="unselect">请选择任务</option>\
	                            <option value="客户">客户</option>\
	                            <option value="联系人">联系人</option>\
	                            <option value="拜访">拜访</option>\
	                            <option value="商机">商机</option>\
	                            <option value="售后">售后</option>\
	                            <option value="市场">市场</option>\
	                        </select>\
	                        <input class="in-txt" type="text" name="targetList.target" value="" placeholder="请输入数量">\
	                        <a class="js-del-oneline del-oneline" href="javascript:void(0)"></a>\
	                    </div>';

	        $(str).insertBefore($(this).parent());
	        popEvn.setPopcontentHeight();
		});

		// 点击删除一行
		$pop.on('click','.js-del-oneline',function(){
			var len = $(this).closest('.in-box-subbox').siblings('.in-box-subbox').length;
			
			if(len > 1) {
				$(this).closest('.in-box-subbox').remove();
			} else {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '请至少添加一行'
				});
			}
			 popEvn.setPopcontentHeight();
		});
		
		
		// 删除任务目标-出现弹窗
		$contentWrapper.on('click','.table-batch-ctrl .del',function(){
			
			var userIdList = [];
			var $table = $('#planGrid');
			
			$table.find('tr[aria-selected="true"]').each(function(){
				userIdList.push($(this).find('a').attr('id'));
			});
			
			var remindContent='是否确定删除选中的'+userIdList.length+'个目标？删除之后，该操作将无法恢复。'
			renderEvn.renderTpl({
				tplId: '#popMulDelTpl',
				outputId: '#pop',
				data:{
					remindContent: remindContent
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});

		// 确定删除任务目标
		$pop.on('click','#popMulDel a.js-pop-save',function(){
			
			// 获取选中id
			var delUserTargetVO = {},
				userIdList = [];
			var $table = $('#planGrid');
			
			$table.find('tr[aria-selected="true"]').each(function(){
				userIdList.push($(this).find('a').attr('id'));
			});
			var year = $('.content-main .screen-title span').attr('data-year');
			delUserTargetVO.year = year;
			delUserTargetVO.userIdList = userIdList;
			
			var jqx = baseEvn.ajaxFun({
				url: '/setting/deleteBatchUserTarget',
				contentType : 'application/json;charset=utf-8',
				data: JSON.stringify(delUserTargetVO)
			});
			
			jqx.done(function(result){
				if (result.type === "success") {
					$("#pop").hide();
					popEvn.hint({
						txt: result.content
					});
					
					var page = $('.toolbar-item.num').find('a.active').text();
					data = {
						pageNo: page
					};
					gridEvn.loadData(data);
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});



	};
	
	// 添加和修改任务目标时，判断任务目标格式是否正确
	settingEvn.checkTarget = function($target) {
		var result = {
				flag: true
			},
		 	targetList = [];
		var cycleFlag = false,
			moduleFlag = false,
			targetFlag = false;

		$target.each(function(i,obj){
			var cycle = $(this).find('.cycle').val();
			var moduleType = $(this).find('.module-type').val();
			var count = $(this).find('input').val();
			
			// 允许一行全部不选择，不做处理
			if (cycle == "unselect" && moduleType == "unselect" && !count) {
				
			} else {
				
				// 判断周期是否被选择
				if (cycle == "unselect") {
					cycleFlag = true;
				}
				// 判断模块是否被选择
				if (moduleType == "unselect") {
					moduleFlag = true;
				}				
				// 判断是否设置了目标(目标必须大于0)
				if (!count || count<=0) {
					targetFlag = true;
				}
				var target = {};
				target.cycle = cycle;
				target.moduleType = moduleType;
				target.target = count;
				targetList.push(target);
			}

			

		});
		
		
		if (cycleFlag) {
			result.flag = false;
			result.text = "请选择周期";
			return result;
		}
		
		if (moduleFlag) {
			result.flag = false;
			result.text = "请选择任务";
			return result;
		}
		
		if (targetFlag) {
			result.flag = false;
			result.text = "请填写正确的目标数";
			return result;
		}
		
		if (targetList.length == 0) {
			result.flag = false;
			result.text = "请填写任务目标";
			return result;
		}
		
		// 循环校验数据，不允许存在相同周期、相同任务的目标
		for (var i=0, leni=targetList.length; i<leni; i++) {
			var targeti = targetList[i];
			for (var j = 0, lenj = targetList.length; j < lenj; j++) {
				if (i == j) {
					continue;
				} else {
					var targetj = targetList[j];
					if (targeti.moduleType == targetj.moduleType && targeti.cycle == targetj.cycle) {
						result.flag = false;
						result.text = "请不要创建相同周期、相同任务的目标";
						return result;
					}
				}
			}
		}
		return result;
	};

	// 修改资料
	settingEvn.personalFun = function() {
		// 修改个人信息
		$contentWrapper.on('click', '.btn-form-sub', function(){
			var $contentFrom = $('.content-form form');
				perObts = {
					url : moduleConfig.activeModule.changeMyInfo,
					data : $contentFrom.serialize()
				};
			var jqxhr = baseEvn.ajaxFun(perObts);
			
			jqxhr.done(function(result){
				if (result.type === 'success') {
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
	};
	
	// 修改和设置密码
	settingEvn.changePwFun = function() {
		// 修改密码
		$contentWrapper.on('click', '#changePassword .btn-form-sub', function(){
			var $contentForm = $('.content-form form'),
				oldPassword,
				newPassword,
				checkPassword;
			
			oldPassword = $contentForm.find("input[name='oldPassword']").val();
			newPassword = $contentForm.find("input[name='newPassword']").val();
			checkPassword = $contentForm.find("input[name='checkPassword']").val();
			
			if (!oldPassword) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '旧密码不能为空'
				});
				return;
			}
			
			if (!newPassword) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '新密码不能为空'
				});
				return;
			}
			
			if (!checkPassword) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '确认密码不能为空'
				});
				return;
			}
			
			newPassword = newPassword.trim();
			checkPassword = checkPassword.trim();
			
			if (newPassword !== checkPassword) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '两次输入密码不一致'
				});
				return;
			}
			
			var perObts = {
					url : moduleConfig.activeModule.changePassword,
					data : $contentForm.serialize()
				};
			
			var jqxhr = baseEvn.ajaxFun(perObts);
			
			jqxhr.done(function(result){
				if (result.type === 'success') {
					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
		
		// 设置密码
		$contentWrapper.on('click', '#setPassword .btn-form-sub', function(){
			var $contentForm = $('.content-form form'),
				password,
				checkPassword;
			
			password = $contentForm.find("input[name='password']").val();
			checkPassword = $contentForm.find("input[name='checkPassword']").val();
			
			
			if (!password) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '密码不能为空'
				});
				return;
			}
			
			if (!checkPassword) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '确认密码不能为空'
				});
				return;
			}
			
			password = password.trim();
			checkPassword = checkPassword.trim();
			
			if (password !== checkPassword) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '两次输入密码不一致'
				});
				return;
			}
			
			var perObts = {
					url : moduleConfig.activeModule.setPassword,
					data : $contentForm.serialize()
				};
			
			var jqxhr = baseEvn.ajaxFun(perObts);
			
			jqxhr.done(function(result){
				if (result.type === 'success') {
					popEvn.hint({
						txt: result.content
					});
					
					setTimeout(function(){
						location.reload();
					},1000);
					
					
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
		});
	};


	// 初始化
	settingEvn.init = function(){
		if ($contentWrapper.hasClass('content-wrapper-personal')) {
			settingEvn.personalFun();
		}
		
		if ($contentWrapper.hasClass('content-wrapper-changepw')) {
			settingEvn.changePwFun();
		}
		
		if($contentWrapper.hasClass('content-wrapper-staff')){
			settingEvn.staffFun();
		}
		
		if($contentWrapper.hasClass('content-wrapper-plan')){
			settingEvn.planFun();
		}
		
	};
	


	$(function(){
		settingEvn.init();
	});

})(jQuery);