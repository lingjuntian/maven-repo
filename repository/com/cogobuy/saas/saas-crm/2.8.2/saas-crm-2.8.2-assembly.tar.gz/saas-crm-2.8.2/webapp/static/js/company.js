var moduleName = 'admin';

(function($){

	var customerEvn = {},
	$wrapper = $('#wrapper'),
	$pageLeft = $('#pageLeft'),
	$contentWrapper = $('#contentWrapper');
	$body = $('body');
	$pop = $('body .pop');
 
	// 初始化
	customerEvn.init = function(){
	      
	// 弹出框pop-main清除内容
	$body.on('click','.js-pop-close.pop-clear',function(){
		$(this).parents('.pop-main').remove();
	});
	 

	// 表格初始化
	var $grid = gridEvn.init({
		tablewrap: '#saasGrid',
		dataUrl: '/admin/findCompany',
		// 默认的排序列
		sortname: 'sort',
		// 表头名称
		colNames : [ 'companyName', 'createByName', 'createTime'],
		colModel: [
			{
				name: 'companyName',
				width: 100,
				sortable: false
			},
			{
				name: 'createByName',
				sortable: false,
				width: 90
			},
			{
				name: 'createTime',
				sortable: false,
				width: 50,
				formatter: function(value){
					if(value ==0 )
						return '-';
					else
						return value;
				}
			}
			
		]
	});
	$contentWrapper.on("click","[name='logreport']",function(){
		 
			data = {
				startDate: $("[name=startDate]").val(),
				endDate:	$("[name=endDate]").val()
			};
			gridEvn.loadData(data);
		});

	};


	$(function(){
	customerEvn.init();
	});

})(jQuery);