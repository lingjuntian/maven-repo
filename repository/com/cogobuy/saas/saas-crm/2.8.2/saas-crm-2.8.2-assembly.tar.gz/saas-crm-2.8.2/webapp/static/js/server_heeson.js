(function($){
	'use strict';
	// tab切换
	$(function(){
		serverEvn.init();
	});

	var serverEvn = {
		// 关闭按钮
		bodyOnFun: function(){
			var $body = $('body');
			//新增服务
			$body.on('click','.pop .pop-btn .skins-btn.btn-confirm',function(){
				var data = $("#pop_add_server_form").serialize();
				$.ajax ({
					url:"/server/addService",
					data:data,
					success:function(message){
						console.log(message);
					},
					error:function(message){
						console.log(message);
					}
				});
			});
			$body.on('click','.main .wrap.clearfix .list .list-main .list-item .info p',function(){
				var serviceId = $(this).attr("data-id");
				$.ajax ({
					url:"/server/detail",
					data:{
						serviceId:serviceId
					},
					success:function(html){
						$("#server_detail_tab_div").html(html);
					},
					error:function(){
						console.log("/server/detail请求失败");
					}
				});
			});
			
			
		},
				
		// 单击事件绑定,ajax获取数据
		bindEvent: function(){
			var $main = $('.main');
			
			
		},

		init: function(){
			this.bodyOnFun();
			this.bindEvent();
		}
	};


}(jQuery));
