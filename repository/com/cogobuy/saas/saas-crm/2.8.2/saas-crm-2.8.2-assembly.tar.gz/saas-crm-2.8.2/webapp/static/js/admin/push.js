//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'push';

moduleConfig.activeModule = {
	moduleName: 'push',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		dataUrl: '/admin/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '客户名称', '地址', '电话', '所属用户', '用户公司', '创建时间', '已推送', '是否接收', '推送时间', '是否绑定微信'],
		colModel: [
			{
				name: 'customerName',
				width: 120,
				sortable: false
			},
			{
				name: 'address',
				sortable: false,
				width: 120,
				formatter: function(value, options, rowObject){
					var result = '';
					if(rowObject.province)
						result += rowObject.province+"&nbsp";
					if(rowObject.city)
						result += rowObject.city+"&nbsp";
					if(value)
						result += value;
					return result;
				}
			},
			{
				name: 'phone',
				sortable: false,
				width: 80
			},
			{
				name: 'chargeUserName',
				sortable: false,
				width: 80
			},
			{
				name: 'companyName',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 60,
				formatter: function(value, options, rowObject){
					if(value){
						return value.substring(0,10);
					}
					return '';
				}
			},
			{
				name: 'pushId',
				sortable: false,
				width: 50,
				formatter: function(value, options, rowObject){
					return '<a push-id="'+ value 
					+'" data-id="'+ rowObject.customerId 
					+'" customer-name="'+ rowObject.customerName 
					+'" class="js-push" href="javascript:void(0);">' 
					+ (value?'是':'否') + '</a>';
				}
			},
			{
				name: 'isGet',
				sortable: false,
				width: 50,
				formatter: function(value, options, rowObject){
					if(value==false)
						return '否';
					if(value)
						return '是';
					return '';
				}
			},
			{
				name: 'pushTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			},
			{
				name: 'userOpenId',
				sortable: false,
				width: 50,
				formatter: function(value, options, rowObject){
					if(value)
						return '是';
					return '否';
				}
			}
		]
	},

};


(function($){
	//4、定义jquery对象
	var pushEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');
	
	// 点击进行客户推送
	pushEvn.pushPop = function(){
		$wrapper.on('click','.js-push',function(){
			var textValue = $(this).text();
			var customerId = $(this).attr("data-id");
			var customerName = $(this).attr("customer-name");
			if(textValue=='否'){
				renderEvn.renderTpl({
					tplId: "#popPushTpl",
					outputId: "#pop",
					data: {
						customerId : customerId,
						customerName : customerName
					},
					callback: function(outObj){
					//	popEvn.setPopcontentHeight();
						popEvn.open();
					}
				});
			}else if(textValue=='是'){
				var pushId = $(this).attr("push-id");
				//5.5加载任务提醒
				var popJqx = baseEvn.ajaxFun({
					url: "/admin/getPush",
					data: {
						id:pushId
					}
				});

				popJqx.done(function(result){
					if(result.type='success'){
						renderEvn.renderTpl({
							tplId: '#popGetPushTpl',
							outputId: "#pop",
							data: result,
							callback: function(outObj){
								popEvn.open();
							}
						});
					}					
				})
			}
			
			
		});
	}
	
	// 弹出框-保存（确定）
	pushEvn.saveOpt = function(){
		$pop.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'pushCustomer':
					ajaxUrl = '/admin/pushCustomer';
					break;
			}
			if(ajaxUrl){
				//表单提交
				var formData = $(this).parents("form:first").serialize();
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});

				formJqx.done(function(result){
					if(result.type=="success"){
						$item.parents('.pop-main').remove();
						$("#pop").hide();

						popEvn.hint({
							txt:'操作成功'
						});
					}else if(result.type=="error"){
						popEvn.hint({
							txt: result.content
						});
					}
				});
			}
		});	
	};
	
	
	// 初始化
	pushEvn.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		
		//弹出推荐框
		this.pushPop();
		//确定按钮保存
		this.saveOpt();
	};


	$(function(){
		pushEvn.init();
	});

})(jQuery);