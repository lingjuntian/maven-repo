//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'chance';

moduleConfig.activeModule = {
	moduleName: 'chance',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		
		dataUrl: '/opportunity/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '项目', '客户名称', '进度', '预计成交金额','预计成交日期','重要性', '负责人', '创建时间'],
		colModel: [
			{
				name: 'project',
				width: 90,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					return '<a data-id="'+ rowObject.opportunityId +'" project="'+ rowObject.project +'" class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'customerName',
				sortable: false,
				width: 120
			},
			{
				name: 'progress',
				sortable: false,
				width: 40
			},
			{
				name: 'amtType',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					var result = '暂无';
					var atype = '';
					if(rowObject.amtType)
						atype = rowObject.amtType;
					if(rowObject.amtRangeBegin)
						result = rowObject.amtRangeBegin+"&nbsp" +atype;
					if(rowObject.amtRangeEnd)
						result = rowObject.amtRangeEnd+"&nbsp" +atype;
					  
					return result;
				}
			},
			{
				name: 'expectedClosingDate',
				sortable: false,
				width: 60
			},
			{
				name: 'important',
				sortable: false,
				width: 60
			},
			{
				name: 'chargeUserName',
				sortable: false,
				width: 60
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			}
		]
	},

	// 详情tab菜单接口
	// infoNav: '../../pages/test/infoTab.json',
	infoNav: '/opportunity/infoTab',

	// 详情右侧任务接口
	// infoSlideTask: '../../pages/test/infoSlideTask.json',
	infoSlideTask: '/opportunity/findTopUnfinishTask',

	// 详情右侧参与成员接口
	// infoSlideStaff: '../../pages/test/infoSlideStaff.json',
	infoSlideStaff: '/opportunity/findShareEmployee',
	// detailItemReport: '../../pages/test/itemReport.json',

	// 拜访报告接口
	// 参数 dataId（id）&type（栏目名称）
	infoReport:	'/communication/findTab',

	// 详情(资料)接口
	// 参数 dataId（id）&type（栏目名称）
	infoDetail: '/opportunity/get',

	// 联系人接口
	// 参数 dataId（id）&type（栏目名称）
	infoContacts:	'/contacts/findTab',

	// 商机接口
	// 参数 dataId（id）&type（栏目名称）
	infoChance:	'/opportunity/findTab',

	// 售后接口
	// 参数 dataId（id）&type（栏目名称）
	infoServer:	'/service/findTab',

	// 任务日程接口
	// 参数 customerId（客户id）&type（栏目名称）
	infoTask:	'/opportunity/findTask'
};




(function($){
	//4、定义jquery对象
	var opportunityEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');

	//5、点击列表-显示详情
	function getDetail(){
			var dataId = $(this).attr('data-id');
			
			pageDataSet.dataId = dataId;

			// 判断栏目是否存在
			if(!moduleConfig.activeModule.moduleName){
				return false;
			}

			clickInfoBox = true;
			
			$contentWrapper.find('.content-info').addClass('active');
			
			//5.1保存客户名称
			pageDataSet.project = $(this).attr('project');

			//5.2详情显示当前客户名称
			$contentWrapper.find('.detail .js-name').html(pageDataSet.project);

			// console.log(moduleConfig.activeModule);
						
			//5.3加载tab导航
			var navJqx = baseEvn.ajaxFun({
				// url: baseEvn.ajaxUrl.infoNav,
				url: moduleConfig.activeModule.infoNav,
				data: {
					id:dataId
				}
			});

			navJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoNavTpl',
					outputId: $contentWrapper.find('.content-info .detail-nav'),
					data: result,
					callback: function(outObj){
						outObj.find('a').eq(0).addClass('active');
						// 详情页tab加上active状态
						$contentWrapper.find('.detail-main .main-item').eq(0).addClass('active').siblings().removeClass('active').html('');
					}
				});
			}).fail(function(){
				// console.log('fail');
			}).always(function(){
				// console.log('aways');
				//$contentWrapper.find('.detail-main .main-item').eq(Idx).addClass('active').siblings().removeClass('active');
			});
			
			
			//5.4显示详情
			var infoJqx = baseEvn.ajaxFun({
				// url: baseEvn.ajaxUrl.infoSlideTask,
				url: moduleConfig.activeModule.infoDetail,
				data: {
					dataId:dataId
				}
			});

			infoJqx.done(function(result){
				//console.log(result);
				renderEvn.renderTpl({
					tplId: pageDataSet.tplName.infoDetailCustomer,
					outputId: $contentWrapper.find('.content-info .item-customer'),
					data: result					
				});
			}).fail(function(){
				 //console.log('fail');
			}).always(function(){
				 //console.log('aways');
			});
			 
 		
			//5.5加载任务提醒
			var taskJqx = baseEvn.ajaxFun({
				// url: baseEvn.ajaxUrl.infoSlideTask,
				url: moduleConfig.activeModule.infoSlideTask,
				data: {
					id:dataId
				}
			});

			taskJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoSlideTaskTpl',
					outputId: $contentWrapper.find('.content-info .slide .task'),
					data: result
				});
			}).fail(function(){
				// console.log('fail');
			}).always(function(){
				// console.log('aways');
			});
			
			//5.6负责人
			var taskJqx = baseEvn.ajaxFun({
				// url:baseEvn.ajaxUrl.customerGet,
				url: moduleConfig.activeModule.infoDetail,
				data:{
					dataId:dataId
				}
			});

			taskJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoSlideLeader',
					outputId: $contentWrapper.find('.content-info .slide .leading'),
					data: result
				});
			}).fail(function(){
				// console.log('fail');
			}).always(function(){
				// console.log('aways');
			});
			
			//5.7加载参与成员
			var staffJqx = baseEvn.ajaxFun({
				// url: baseEvn.ajaxUrl.infoSlideStaff,
				url: moduleConfig.activeModule.infoSlideStaff,
				data: {
					id : dataId
				}
			});

			staffJqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#infoSlideStaffTpl',
					outputId: $contentWrapper.find('.content-info .slide .staff'),
					data: result
				});
			}).fail(function(){
				// console.log('fail');
			}).always(function(){
				// console.log('aways');
			});
	};
	
	//6、列表右上角，新建商机按钮
	function addChance(){
		var type = $(this).attr('data-type'),
			tplId = '',
			initUrl= '';

		switch (type){
			case 'chance':
				tplId = '#popAddChanceTpl';
				break;
		}

		if(initUrl && tplId){
			//如果初始化表单需要请求后台数据
			var initFormJqx = baseEvn.ajaxFun({
				url : initUrl
			});

			initFormJqx.done(function(result){
				if(result.type == 'success'){
					renderEvn.renderTpl({
						tplId: tplId,
						outputId: '#pop',
						data : result.args,
						callback: function(outObj){
							popEvn.setPopcontentHeight();
							outObj.show();
						}
					});
				}
			});
		}else if(tplId){
			//初始化表单不需要请求后台数据
			renderEvn.renderTpl({
				tplId: tplId,
				outputId: '#pop',
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		}
	};
	
	// table -操作区table-batch-ctrl
	opportunityEvn.tablBatchCtrl = function(){
		$contentWrapper.on('click','.js-table-batch-ctrl a',function(){
			var columnType = $(this).attr('data-type'),
				actionType = $(this).attr('data-action'),
				tplId='';

			if (columnType == 'opportunity'){
				// 获取选中id
				var dataId = [];
				var $table = $('#saasGrid');
				$table.find('tr[aria-selected="true"]').each(function(){
					dataId.push($(this).find('a').attr('data-id'));
				});
				var remindContent;
				switch (actionType){
					case 'addMember':
						tplId = '#popAddMemberTpl';
						remindContent = '将团队成员添加成为选中的'+dataId.length+'个商机的相关成员：'
						break;
					case 'removeMember':
						tplId = '#popRemoveMemberTpl';
						remindContent = '将以下成员从选中的'+dataId.length+'个商机中移除：'
						break;
					case 'del':
						tplId = '#popMulDelTpl';
						remindContent = '是否确定删除选中的'+dataId.length+'个商机？删除之后，该操作将无法恢复。'
						break;
					case 'transform':
						tplId = '#popMulTransformTpl';
						remindContent = '是否将选中的'+dataId.length+'个商机转移给其他负责人？转移成功之后，该操作将无法恢复。'
						break;
				}
			}
			// 渲染模板
			renderEvn.renderTpl({
				tplId: tplId,
				outputId: '#pop',
				data:{
					dataId:dataId,
					remindContent:remindContent
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});

		});
	};
	
	//6、添加按钮的绑定
	// 右侧栏-操作区域-添加
	opportunityEvn.detailOpt = function(){
		$contentWrapper.on('click','.js-detail-opt a',function(){
			var type = $(this).attr('data-type'),
				tplId = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'report':
					tplId = '#popAddReportTpl';
					break;
				case 'contact':
					tplId = '#popAddContactTpl';
					break;
				case 'chance':
					tplId = '#popAddChanceTpl';
					break;
				case 'service':
					tplId = '#popAddServicetTpl';
					break;
				case 'del':
					tplId = '#popSingleOpportunityDelTpl';
					break;
				case 'transform':
					tplId = '#popTransformTpl';
					break;
				case 'task':
					tplId = '#popAddtasktTpl';
					break;
			}
			
			// 渲染模板
			if (type){
				renderEvn.renderTpl({
					tplId: tplId,
					outputId: '#pop',
					data:{
						opportunityId:pageDataSet.dataId,
						project:pageDataSet.project
					},
					callback: function(outObj){
						popEvn.setPopcontentHeight();
						outObj.show();
					}
				});
			}
			
		});	
	};

	// 右侧栏 - 任务提醒设置完成 或 取消
	opportunityEvn.taskRemind = function(){
		$contentWrapper.on('click','.js-aside-task .list-title i',function(){
			var $li = $(this).closest('li'),
				dataId = $li.attr("data-id"),
				data = null;

			if($(this).closest('li').hasClass('active')){
				$li.removeClass('active');
				data={
					id : dataId,
					action : 'unfinish'
				};
			}else{
				$li.addClass('active');
				data={
					id : dataId,
					action : 'finish'
				};
			}
			var finishJqx = baseEvn.ajaxFun({
					url:"/opportunity/finishTask",
					data:data
			});

			finishJqx.done(function(result){
				if(result.type=="success"){
					popEvn.hint({
						txt:'操作成功'
					});
				}else if(result.type=="error"){
					popEvn.hint({
						txt: result.content,
						tipsClass: 'pop-tips-warn'
					});
				}
			});
		});
	};

	// 右侧栏 - 添加成员
	opportunityEvn.addRelativeStaff = function(){
		console.log()
		$contentWrapper.on('click','.js-add-staff-btn',function(){

			renderEvn.renderTpl({
				tplId: '#popAddMember',
				outputId: '#pop',
				data:{
					opportunityId:pageDataSet.dataId,
					project:pageDataSet.project
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
	};

	// 右侧栏-参与成员删除
	opportunityEvn.deleteRelativeStaff = function(){
		// 编辑保存状态切换
		$contentWrapper.on('click','.js-leading-e',function(){
			$(this).closest('.slide-box.staff').addClass('active');
		});

		$contentWrapper.on('click','.js-leading-s',function(){
			$(this).closest('.slide-box.staff').removeClass('active');
		});

		// 点击删除
		$contentWrapper.on('click','.js-staff-d',function(){
			var userId = $(this).siblings("span").attr("data-id"),
				userName = $(this).siblings("span").text(),
				opportunityId = pageDataSet.dataId;
		
			renderEvn.renderTpl({
				tplId: '#popDelRelativeStaffTpl',
				outputId: '#pop',
				data:{
					opportunityId: opportunityId,
					userId:userId,
					userName:userName
				},
				callback: function(outObj){
					popEvn.setPopcontentHeight();
					outObj.show();
				}
			});
		});
	};


	// 详情页 - 单条记录删除
	opportunityEvn.detailDelTitle = function(){
		$contentWrapper.on('click','.js-title-d',function(){
	
			var id = $(this).closest('.item-box').attr('data-id'),
				name= $(this).closest('.item-box').attr('data-name'),
				deleteType = $(this).attr('deleteType'),
				remindContent = '';
	
			// 根据不同tab，显示不同弹出框
			switch (deleteType){
				case 'delComm':
					remindContent = '是否确定删除选中拜访报告记录['+name+']<br>删除之后，该操作将无法恢复。';
					break;
				case 'delContacts':
					remindContent = '是否确定删除选中联系人记录['+name+']<br>删除之后，该操作将无法恢复。';
					break;
				case 'delOpp':
					remindContent = '是否确定删除选中商机记录['+name+']<br>删除之后，该操作将无法恢复。';
					break;
				case 'delService':
					remindContent = '是否确定删除选中售后记录['+name+']<br>删除之后，该操作将无法恢复。';
					break;
				case 'delService':
					remindContent = '是否确定删除选中商机['+name+']<br>删除之后，该操作将无法恢复。';
					break;
			}
			if (deleteType){
				renderEvn.renderTpl({
					tplId: '#popSingleDelTpl',
					outputId: '#pop',
					data:{
						remindContent:remindContent,
						deleteType: deleteType,
						dataId:id
					},
					callback: function(outObj){
						popEvn.setPopcontentHeight();
						outObj.show();
					}
				});
			}	
		});
	};

	// 详情页 - 复选框的勾选(弹窗和页面共用)
	opportunityEvn.checkboxChange = function(){
		$body.on('click','.list-title input',function(){
			$(this).closest('li').addClass('active').find('input').prop('checked','checked');

		});

		$body.on('click','.list-title .js-icon-checked',function(){
			$(this).closest('li').removeClass('active').find('input').prop('checked','');
		});
	};
	
	
	// 详情页的tab切换
	function tabDetail(){
		var Idx = $(this).index();

		if($(this).hasClass('active')){
			return false;
		}

		$(this).addClass('active').siblings().removeClass('active');
		$contentWrapper.find('.detail-main .main-item').eq(Idx).addClass('active').siblings().removeClass('active');
		
		var opts = {
				url: moduleConfig.activeModule.infoReport,
				data: {
					type: moduleConfig.activeModule.moduleName,
					dataId: pageDataSet.dataId
				},
				tplId: pageDataSet.tplName.infoReport,
				outputId: $contentWrapper.find('.item-report')
			};
		var datatype = $(this).attr('data-type');

		switch (datatype){
			case 'report':
				break;
			case 'data':
				opts.url = moduleConfig.activeModule.infoDetail,
				opts.tplId = pageDataSet.tplName.infoDetailCustomer,
				opts.outputId = $contentWrapper.find('.item-customer');
				break;
			case 'contact':
				opts.url = moduleConfig.activeModule.infoContacts,
				opts.tplId = pageDataSet.tplName.infoDetailContact,
				opts.outputId = $contentWrapper.find('.item-contact');
				break;
			case 'chance':
				opts.url = moduleConfig.activeModule.infoChance,
				opts.tplId = pageDataSet.tplName.infoDetailChance,
				opts.outputId = $contentWrapper.find('.item-chance');
				break;
			case 'service':
				opts.url = moduleConfig.activeModule.infoServer,
				opts.tplId = pageDataSet.tplName.infoDetailServer,
				opts.outputId = $contentWrapper.find('.item-server');
				break;	
			case 'task':
				opts.url = moduleConfig.activeModule.infoTask,
				opts.tplId = pageDataSet.tplName.infoDetailTask,
				opts.outputId = $contentWrapper.find('.item-task');
				 
				break;
			default:
				break;
		}
		

		//console.log(opts);
		var tabJqx = baseEvn.ajaxFun(opts);

		tabJqx.done(function(result){
			console.log(result);
			if (result.type === "success") {
			
				if(datatype === 'report'){
					//单独处理日期格式
					for (var i=0,len = result.args.length;i < len; i++) {
						result.args[i].commTime2 = fValidate.dateFormat(result.args[i].commTime);
					}
				}

				renderEvn.renderTpl({
					tplId: opts.tplId,
					outputId: opts.outputId,
					data: result
				});
			}
		});
	};
	 
	
	// 弹出框-保存（确定）
	opportunityEvn.saveOpt = function(){
		$pop.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'contact':
					ajaxUrl = '/contacts/add';
					break;
				case 'chance':
					ajaxUrl = '/opportunity/add';
					break;
				case 'del':
					ajaxUrl = '/opportunity/delete';
					break;
				case 'transform':
					ajaxUrl = '/opportunity/changeCharge';
					break;
				case 'task':
					ajaxUrl = '/opportunity/createTask';
					break;
				case 'addMember':
					ajaxUrl = '/opportunity/addShareEmployee';
					break;
				case 'topBarAddMember':
					ajaxUrl = '/opportunity/addShareEmployee';
					break;
				case 'topBarRemoveMember':
					ajaxUrl = '/opportunity/deleteShareEmployee';
					break;
				case 'MulDel':
					ajaxUrl = '/opportunity/delete';
					break;
				case 'delContacts':
					ajaxUrl = '/opportunity/delete';
					break;
				case 'removeSingleMember':
					ajaxUrl = '/opportunity/deleteShareEmployee';
					break;
			}
			if(ajaxUrl){
				//表单提交
				var formData = $(this).parents("form:first").serialize();
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});

				formJqx.done(function(result){
					if(result.type=="success"){
						$item.parents('.pop-main').remove();
						$("#pop").hide();

					/*	// 判断是否刷新当前表格数据
						switch (type){
							 
							case 'contact':
								// 修改num
								$('.js-detail-nav .num-contact').text( parseInt($('.js-detail-nav .num-contact').text())+1 );

								// 修改tab内容
								opportunityEvn.refreshTpl('contact',result);

							case 'del':
								// 如果是删除，删除后关闭详情页,刷新列表
								$contentWrapper.find('.content-info').removeClass('active');
								// 获取当前页
								var page = $('.toolbar-item.num').find('a.active').text();
								data = {
									pageNo: page
								};
								gridEvn.loadData(data);
								break;
						}*/



						popEvn.hint({
							txt:'操作成功'
						});
					}else if(result.type=="error"){
						popEvn.hint({
							txt: result.content
						});
					}
				});
			}
		});	
	};
	
	 
	 
	// 初始化
	opportunityEvn.init = function(){
		
		// 搜索选择功能-客户选择
		$('body').on('click', '.customer.js-auto-fill-input', function(){
			$(this).autoFill({
				url: '/customer/findPageByName',
				selTypeName: 'customer',
				selHiddenInputId: 'customerId',
				selHiddenInputName: 'customerName'
			});
		});
		
		// 搜索选择功能-联系人选择
		$('body').on('click', '.contacts.js-auto-fill-input', function(){
			var $customerResult = $('#customerSearch').siblings('dl').find('dt:first');
			
			if ($customerResult.length == 0) {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '请先选择公司'
				});
			}
			var customerId = $customerResult.find('input[name="customerId"]').val();
			
			$(this).autoFill({
				url: '/contacts/findByCustomerAndName',
				selTypeName: 'contacts',
				selHiddenInputId: 'contactsId',
				selHiddenInputName: 'contactsName',
				data: {
					customerId: customerId,
					keyword: ''
				}
			});
		});
		
		// 搜索选择功能
		$('body').on('click', '.js-auto-fill-input', function(){
			var searchType = $(this).attr("search-type");
			switch (searchType){
				//成员添加
				case 'addMember':
					$(this).autoFill({
						url: "/user/findByName",
						selTypeName:'user',
						selHiddenInputId:'toUserId',
					//	selHiddenInputName:'toUserName',
						isMulti: true
					});
				break;
				//成员移除
				case 'delMember':
					$(this).autoFill({
						url: "/user/findByName",
						selTypeName:'user',
						selHiddenInputId:'toUserId',
					//	selHiddenInputName:'toUserName',
						isMulti: true
					});
				break;
				//转移
				case 'transform':
					$(this).autoFill({
						url: "/user/findByName",
						selTypeName:'user',
						selHiddenInputId:'toUserId',
					//	selHiddenInputName:'toUserName',
						isMulti: false
					});
				break;
				//客户选择
				case 'customer':
					$(this).autoFill({
						url: "/customer/findPageByName",
						selTypeName:'customer',
						selHiddenInputId:'customerId',
						selHiddenInputName:'customerName',
						isMulti: false
					});
				break;
				
				//默认
				default :
					
				break;
			}
		});	

		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		
		// 查看详情
		$wrapper.on('click','.js-get-info',getDetail);
		
		// 详情页的tab切换
		$contentWrapper.on('click','.js-detail-nav a',tabDetail);
		
		// 添加商机
		$contentWrapper.on('click','.js-toolbar-ctrl a',addChance);
		
		// 弹出框 - 客户搜索下拉框
		$pop.on('click','.box-list .js-list-checked',function(){
			$(this).parents('li').toggleClass('active');
		});
		
		// 弹窗 - 搜索下拉出来（搜索成员）
		$body.on('click','.search-fl .js-icon-search',function(){

			var keyword = $(this).parent().find(".search-intxt").val();

			// 加载参与成员
			var searchMemberJqx = baseEvn.ajaxFun({
			    url: "/user/findByName",

			//	url:'../../pages/test/customerList.json',
				data: {
					keyword: keyword
				}
			});

			searchMemberJqx.done(function(result){

				// console.log(result);
				renderEvn.renderTpl({
					tplId: '#popFindMember',
					outputId: $pop.find('.search-select-box'),
					data: result.args.list
				});

				// 添加上下页的可点击按钮

			}).fail(function(result){
				console.log('fail');
				renderEvn.renderTpl({
					tplId: '#popFindMember',
					outputId: $pop.find('.search-select-box'),
					callback: function(outObj){
						popEvn.setPopcontentHeight();
						outObj.show();
					}
				});
			});
			
			$('.search-fl').toggleClass('active');
		});


		// 左侧操作区 添加按钮显示
		$contentWrapper.on('click','.js-icon-add',function(){
			$contentWrapper.find('.js-detail-opt .sub-menu').addClass('active');
		});

		// 左侧操作区 添加按钮隐藏
		$contentWrapper.on('mouseleave','.js-detail-opt .sub-menu',function(){
			$contentWrapper.find('.js-detail-opt .sub-menu').removeClass('active');
		});

		// 弹出框
		this.detailOpt();

		//弹出框的保存
		this.saveOpt();
		
		// table -操作区table-batch-ctrl
		this.tablBatchCtrl();
		
		// 添加相关成员
		this.addRelativeStaff();
		// 详情页 - 复选框的勾选
		baseEvn.checkboxChange();
		
		// 右侧栏 - 任务提醒
		this.taskRemind();
		
		// 相关成员的删除
		this.deleteRelativeStaff();

		// 详情页内的删除
		this.detailDelTitle();
 

	};


	$(function(){
		opportunityEvn.init();
	});

})(jQuery);