(function($) {
	'use strict';

	$(function() {
		accountEvn.init();

		if ($('.container').hasClass('container-login')) {
			accountEvn.loginPublicFun();
		}

		if ($('.container').hasClass('container-reg')) {
			accountEvn.regPublicFun();
		}
	});

	var accountEvn = {
		// 切换内容块
		itemSlide : function(className) {
			var cln = '.' + className;

			$('#formBox').find(cln).addClass('active').siblings().removeClass(
					'active');
		},
		loginPublicFun : function() {
			var $formBox = $('#formBox'), formUrl = {
				home : '/',
			};

			// 输入手机号-下一步
			$formBox.on('click', '.login-phone .js-btn-next', function() {
				var $phone = $formBox.find('input[name="phone"]');

				// 验证

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/mobileSubmit',
					data : {
						phone : $phone.val()
					}
				});

				phoneXhr.done(function(result) {
					$(".phone-num").html($phone.val());
					if (result.registed) {
						if (result.firstLogin) {
							accountEvn.itemSlide('login-captcha');
						} else {
							accountEvn.itemSlide('login-pw');
						}
					} else {
						alert("手机号未注册，请注册后再登录。");
					}
					// alert('done');
				}).fail(function() {
					// alert('fail');
				}).always(function() {
					// alert('always');
					// accountEvn.itemSlide('login-pw');
					// accountEvn.itemSlide('login-captcha');
				});

			});

			// 输入密码-登陆
			$formBox.on('click', '.login-pw .js-btn-login', function() {
				var $phone = $formBox.find('input[name="phone"]');

				// 验证

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/passwordSubmit',
					data : {
						phone : $phone.val(),
						password : $("#password").val()
					}
				});

				phoneXhr.done(function(result) {
					if (result.loginState) {
						if (result.onlyOneCompany) {
							// 跳转到首页
							window.location.href = formUrl.home;
						} else {
							var allUsers = result.allUsers;
							window.allUsers = allUsers;
							for (var i = 0; i < allUsers.length; i++) {
								if(i == 0){
									$("#selTitle").html(allUsers[i].companyName);
								}
								$(".in-sel-sub").append("<span data-cid=\""+i+"\">"+allUsers[i].companyName+"</span>");
							}
							accountEvn.itemSlide('login-company');

						}
					} else {

					}
					// alert('done');
				}).fail(function() {
					// alert('fail');
				}).always(function() {
					// alert('always');
					// accountEvn.itemSlide('login-pw');
					// window.location.href = formUrl.home;
				});

			});

			// 输入手机验证码-首次登陆
			$formBox.on('click', '#authenticodeSubmit', function() {
				var $phone = $formBox.find('input[name="phone"]');
				var authenticode = $("#authenticode").val();

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/authenticodeSubmit',
					data : {
						phone : $phone.val(),
						authenticode : authenticode
					}
				});

				phoneXhr.done(function(result) {
					if (result.loginState) {
						if (result.onlyOneCompany) {
							// 跳转到首页
							window.location.href = formUrl.home;
						} else {
							var allUsers = result.allUsers;
							window.allUsers = allUsers;
							for (var i = 0; i < allUsers.length; i++) {
								if(i == 0){
									$("#selTitle").html(allUsers[i].companyName);
								}
								$(".in-sel-sub").append("<span data-cid=\""+i+"\">"+allUsers[i].companyName+"</span>");
							}
							accountEvn.itemSlide('login-company');
						}
					} else {

					}
					// alert('done');
				}).fail(function() {
					// alert('fail');
				}).always(function() {
					// alert('always');
					//accountEvn.itemSlide('login-company');
					// window.location.href = formUrl.home;
				});

			});
			
			// 下拉选择框，选择团队
			$formBox.on('click', '.in-sel-sub span', function(event) {
				$("#selTitle").html($(this).html());
				$("#selTitle").attr("data-cid",$(this).attr("data-cid"));
			});

			// 选择团队
			$formBox.on('click', '.login-company .js-btn-login', function() {
				var $phone = $formBox.find('input[name="phone"]');

				var userIndex = parseInt($("#selTitle").attr("data-cid"));
				var userId = window.allUsers[userIndex].userId;
				
				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/chooseCompany',
					data : {
						userId: userId
					}
				});

				phoneXhr.done(function(result) {
					if (result) {
						// 跳转到首页
						window.location.href = formUrl.home;
					}

				}).fail(function() {
					// alert('fail');
				}).always(function() {
					// alert('always');
					//accountEvn.itemSlide('login-company');
					// window.location.href = formUrl.home;
				});

			});

			// 找回密码-下一步
			$formBox.on('click', '.pw-captcha .js-btn-next', function() {
				var $phone = $formBox.find('input[name="phone"]');
				var authenticode = $(".pw-captcha input").val();

				// 验证

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/findBackPasswordSubmit',
					data : {
						phone : $phone.val(),
						authenticode : authenticode
					}
				});

				phoneXhr.done(function(result) {
					if (result) {
						accountEvn.itemSlide('pw-set');
					} else {
						alert('验证码错误。');
					}
					// alert('done');
				}).fail(function() {
					// alert('fail');
				}).always(function() {
					// alert('always');
					//accountEvn.itemSlide('pw-set');
				});

			});

			// 设置密码-提交
			$formBox.on('click', '.pw-set .js-btn-pw', function() {
				var $phone = $formBox.find('input[name="phone"]');
				
				if ($("#newPassword1").val() !== $("#newPassword2").val()) {
					alert('输入的密码不一致。');
					return;
				}
				
				// 验证

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/passwordChangeSubmit',
					data : {
						phone : $phone.val(),
						newPassword : $("#newPassword1").val()
						
					}
				});

				phoneXhr.done(function(result) {
					if (result) {
						alert('修改密码成功。');
						window.location.href = formUrl.home;
					} else {
						alert('修改密码失败。');
					}
					// alert('done');
				}).fail(function() {
					// alert('fail');
				}).always(function() {
					// alert('always');
					// accountEvn.itemSlide('pw-set');
					//window.location.href = formUrl.home;
				});

			});

			// 返回上一步 忘记密码 取消修改
			$formBox.on('click', '.js-item-slide', function() {
				accountEvn.itemSlide($(this).attr('data-prev'));
			});
			
			

		},
		regPublicFun : function() {
			var $formBox = $('#formBox'), formUrl = {
				home : '../home/index.html',
				phone : 'http://ndev.ingdan.com/'
			};

			// 输入手机号 验证码-下一步
			$formBox.on('click', '.reg-phone .js-btn-next', function() {
				var $phone = $formBox.find('input[name="phone"]');

				// 验证

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/register/certificate',
					data : {
						phone : $phone.val(),
						authenticode : $("#authenticode").val()
					}
				});

				phoneXhr.done(function(result) {
					if (result) {
						accountEvn.itemSlide('reg-step span:eq(1)');
						accountEvn.itemSlide('reg-info');
					} else {
						alert('验证码错误！');
					}
					// alert('done');
				}).fail(function() {
					// alert('fail');
				}).always(function() {
					// alert('always');
					// accountEvn.itemSlide('login-pw');
					//accountEvn.itemSlide('reg-step span:eq(1)');
					//accountEvn.itemSlide('reg-info');
				});

			});

			// 完善资料-下一步
			$formBox.on('click', '.reg-info .js-btn-sub', function() {
				var $phone = $formBox.find('input[name="phone"]');

				// 验证

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/register/addInformation',
					data : {
						phone : $phone.val(),
						companyName : $("#companyName").val(),
						userName : $("#userName").val()
					}
				});

				phoneXhr.done(function(result) {
					if (result) {
						$(".reg-over-txt").children().remove();
						$(".reg-over-txt").append("<p>团队："+result.companyName+"</p>");
						$(".reg-over-txt").append("<p>手机号："+result.mobile+"</p>");
						
						accountEvn.itemSlide('reg-step span:eq(2)');
						accountEvn.itemSlide('reg-over');
					} else {
						alert('添加用户失败');
					}
					// alert('done');
				}).fail(function() {
					// alert('fail');
				}).always(function() {
					// alert('always');
					// accountEvn.itemSlide('login-pw');
					//accountEvn.itemSlide('reg-step span:eq(2)');
					//accountEvn.itemSlide('reg-over');
				});

			});

		},
		// 获取手机验证码
		getCaptcha : function() {
			var $formBox = $('#formBox'), capTime = null, capTimeNum = 10;

			// 输入手机号 验证码-下一步
			$formBox.on('click', '.btn-captcha', function() {
				capTimeNum = 10;
				var $phone = $formBox.find('input[name="phone"]');

				// 验证
				timeOut($(this));

				var phoneXhr = baseEvn.ajaxFun({
					url : '/login/getAuthenticode',
					data : {
						phone : $phone.val()
					}
				});

//				phoneXhr.done(function(result) {
//					//alert(result);
//					// alert('done');
//				}).fail(function() {
//					// alert('fail');
//				}).always(function() {
//					// alert('always');
//					// accountEvn.itemSlide('login-pw');
//				});
			});

			// 倒计时
			function timeOut(btnObj) {
				btnObj.html('还剩' + capTimeNum + '秒后重发');
				capTimeNum--;

				capTime = setTimeout(function() {
					if (capTimeNum <= 0) {
						clearTimeout(capTime);
						btnObj.html('获取验证码');
					} else {
						timeOut(btnObj);
					}
				}, 1000);
			}
			;

		},
		init : function() {

			accountEvn.getCaptcha();

		}
	};

}(jQuery));
