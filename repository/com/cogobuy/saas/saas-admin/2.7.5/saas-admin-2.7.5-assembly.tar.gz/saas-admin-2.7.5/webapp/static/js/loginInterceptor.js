
(function($){
    // 保存原有的jquery ajax;
    var $_ajax = $.ajax;
    
	$.ajax = function(options){
		var originalSuccess,
			originalError,
			mySuccess,
			myError,
			error_context,
			success_context;

		if (options.success) {
            // save reference to original success callback
			originalSuccess = options.success;
			success_context = options.context ? options.context : $;
			
            // 自定义callback
			mySuccess = function(data) {

				if (data == "LOGIN_TIMEOUT") {
                    window.location.href = '/login';
                    return;	
				}
                // call original success callback							
			    originalSuccess.apply(success_context, arguments);
					
			};
            // override success callback with custom implementation
			options.success = mySuccess;
		}
		
		if (options.error) {
			
			originalError = options.error;
			error_context = options.context ? options.context : $;
			
            // 自定义callback
			myError = function(data) {

				if (data.status==200 && data.responseText == "LOGIN_TIMEOUT") {
                    window.location.href = '/login';
                    return;	
				}
                // call original error callback							
				originalError.apply(error_context, arguments);
					
			};
			
			options.error = myError;
		}
		
		// call original ajax function with modified arguments
		return $_ajax.apply($, arguments);
	};
	
})(jQuery);

