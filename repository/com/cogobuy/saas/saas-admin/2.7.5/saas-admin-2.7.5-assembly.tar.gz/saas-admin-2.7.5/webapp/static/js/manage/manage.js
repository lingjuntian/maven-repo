//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'manage';

moduleConfig.activeModule = {
	moduleName: 'manage',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		dataUrl: '/manage/findAdminUser',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '账号', '姓名', '电话', '邮箱', '部门', '职位', '状态'],
		colModel: [
			{
				name: 'userName',
				width: 120,
				sortable: false
			},
			{
				name: 'name',
				sortable: false,
				width: 120
			},
			{
				name: 'phone',
				sortable: false,
				width: 80
			},
			{
				name: 'email',
				sortable: false,
				width: 80
			},
			{
				name: 'department',
				sortable: false,
				width: 80
			},
			{
				name: 'position',
				sortable: false,
				width: 60
			},
			{
				name: 'status',
				sortable: false,
				width: 50
			}
		]
	},

};


(function($){
	//4、定义jquery对象
	var manageEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');
	
	// 点击添加账号
	manageEvn.addPop = function(){
		$wrapper.on('click','.js-add-user',function(){	
			renderEvn.renderTpl({
				tplId: "#popAddAdminTpl",
				outputId: "#pop",
				callback: function(outObj){
					popEvn.open();
				}			
			});
		});
	}
	
	// 弹出框-保存（确定）
	manageEvn.saveOpt = function(){
		$pop.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'addAdmin':
					ajaxUrl = '/manage/addAdmin';
					break;
			}
			if(ajaxUrl){
				//表单提交
				var formData = $(this).parents("form:first").serialize();
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});

				formJqx.done(function(result){
					if(result.type=="success"){
						$item.parents('.pop-main').remove();
						$("#pop").hide();

						popEvn.hint({
							txt:'操作成功'
						});
					}else if(result.type=="error"){
						popEvn.hint({
							txt: result.content
						});
					}
				});
			}
		});	
	};
	
	
	// 初始化
	manageEvn.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		
		//弹出推荐框
		this.addPop();
		//确定按钮保存
		this.saveOpt();
	};


	$(function(){
		manageEvn.init();
	});

})(jQuery);