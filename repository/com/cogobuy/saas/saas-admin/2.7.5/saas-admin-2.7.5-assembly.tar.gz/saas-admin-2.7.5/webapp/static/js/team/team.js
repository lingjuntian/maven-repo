//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'team';

moduleConfig.activeModule = {
	moduleName: 'team',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		dataUrl: '/team/find',
		multiselect : false,
		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : ['已处理', '注册时间', '团队', '姓名', '手机', '邮箱', '角色', '最后登录时间', '有无数据', '绑定微信', '注册来源', '备注'],
		colModel: [
			{
				name: 'isHandel',
				width: 60,
				sortable: false,
				formatter:function(value, options, rowObject){
					if(value==null || value==false)
						return '<div class="table-cell-checkbox">'
							  +'<input type="checkbox" user-id="'+rowObject.userId+'">'
							  +'</div>';
					return '<div class="table-cell-checkbox">'
					  +'<input type="checkbox" checked="checked"  user-id="'+rowObject.userId+'">'
					  +'</div>';
				}
			},
			{
				name: 'createTime',
				width: 120,
				sortable: false
			},
			{
				name: 'companyName',
				sortable: false,
				width: 120
			},
			{
				name: 'name',
				sortable: false,
				width: 80
			},
			{
				name: 'mobile',
				sortable: false,
				width: 80
			},
			{
				name: 'email',
				sortable: false,
				width: 80
			},
			{
				name: 'roleName',
				sortable: false,
				width: 60
			},
			{
				name: 'loginTime',
				sortable: false,
				width: 80
			},
			{
				name: 'hasCustomer',
				sortable: false,
				width: 40,
				formatter: function(value, options, rowObject){
					if(value==false)
						return '<p style="color:gray;">无</p>';
					return '<p style="color:#ec7946;">有</p>';
				}
			},
			{
				name: 'wopenid',
				sortable: false,
				width: 40,
				formatter: function(value, options, rowObject){
					if(value)
						return '<p style="color:#ec7946;">是</p>';
					return '<p style="color:gray;">否</p>';
				}
			},
			{
				name: 'source',
				sortable: false,
				width: 40,
				formatter: function(value, options, rowObject){
					if(value=="PC_BY_ADMIN")
						return 'PC手动添加';
					if(value=="WECHAT_BY_ADMIN")
						return '微信手动添加';
					if(value=="PC")
						return 'PC注册';
					if(value=="WECHAT")
						return '微信注册';
					if(value=="INVITE")
						return '微信邀请';
					if(value=="HANDCREATE")
						return '手动添加';
					return '';
				}
			},
			{
				name: 'remark',
				sortable: false,
				width: 120,
				formatter: function(value, options, rowObject){
					if(value==null)
						value="";
					return '<input class="table-cell-input" user-id="'+rowObject.userId+'" name="remark" value="'+value+'">';
				}
			}
		]
	},

};


(function($){
	//4、定义jquery对象
	var teamEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');
	
	// 点击查询
	teamEvn.searchEvent = function(){
		$wrapper.on('keyup','.js-toolbar-ctrl input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('.search-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','.search-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = {};
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param[name]=value;
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param[name]=value;
			}
			moduleConfig.activeModule.gridOpts.param=param;
			
			gridEvn.loadData(param);
		});
	};
	
	// 点击导出
	teamEvn.exportEvent = function(){	
		$wrapper.on('click','.export-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = "";
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param += name+"="+value+"&";
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param += name+"="+value+"&";
			}
			param = param.substring(0,param.length-1);
			window.open("/team/exportExcel?"+param);
		});
	};
	
	// 页跳转
	teamEvn.jumpPageEvent = function(){
		$wrapper.on('keyup','#tableToolbar .page-toolbar-input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('#tableToolbar .page-toolbar-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','#tableToolbar .page-toolbar-btn',function(){
			var pageNo = $wrapper.find('#tableToolbar .page-toolbar-input').val();
			if(pageNo){
				var data1={
					pageNo:pageNo
				}
				var param = $.extend(data1,moduleConfig.activeModule.gridOpts.param);
				gridEvn.loadData(param);
			}
		});
	};
	
	teamEvn.remark = function(){
		$wrapper.on('change','#saasGrid .table-cell-checkbox input',function(){
			var checked = $(this).prop("checked");
			var userId = $(this).attr("user-id");
			var data={
				userId:userId,
				isHandel:checked
			}
			var checkJqx = baseEvn.ajaxFun({
				url:"/team/updateExtUser",
				data:data
			});

			checkJqx.done(function(result){
				if(result.type=="success"){
					popEvn.hint({
						txt:'操作成功'
					});
				}else if(result.type=="error"){
					popEvn.hint({
						txt: result.content
					});
				}
			});
		});
		
		$wrapper.on('blur','#saasGrid .table-cell-input',function(){
			var remark = $(this).val();
			var userId = $(this).attr("user-id");
			var data={
				userId:userId,
				remark:remark
			};
			var remarkJqx = baseEvn.ajaxFun({
				url:"/team/updateExtUser",
				data:data
			});

			remarkJqx.done(function(result){
				if(result.type=="success"){
					popEvn.hint({
						txt:'操作成功'
					});
				}else if(result.type=="error"){
					popEvn.hint({
						txt: result.content
					});
				}
			});
		});
	};
	
	// 初始化
	teamEvn.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		
		//搜索事件
		this.searchEvent();
		//页面跳转GO
		this.jumpPageEvent();
		//填写备注
		this.remark();
		//导出
		this.exportEvent();
	};


	$(function(){
		teamEvn.init();
	});

})(jQuery);