//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'action';
var weekOfYear = $("#WeekOfYear").attr("data-value");
moduleConfig.activeModule = {
	moduleName: 'action',
	
	gridOpts:{
		param:{}
	},
	
	// 表格
	gridOpts0: {
		tablewrap: '#Grid0',
		dataUrl: '/userAction/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '团队', '姓名', '电话', '来源', '登录时间', 
		             (weekOfYear-4)+'周', (weekOfYear-3)+'周', (weekOfYear-2)+'周', (weekOfYear-1)+'周', '本周'],
		colModel: [
			{
				name: 'companyName',
				width: 120,
				sortable: false
			},
			{
				name: 'name',
				sortable: false,
				width: 120
			},
			{
				name: 'mobile',
				sortable: false,
				width: 80
			},
			{
				name: 'source',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					if(value=="PC_BY_ADMIN")
						return 'PC手动添加';
					if(value=="WECHAT_BY_ADMIN")
						return '微信手动添加';
					if(value=="PC")
						return 'PC注册';
					if(value=="WECHAT")
						return '微信注册';
					if(value=="INVITE")
						return '微信邀请';
					if(value=="HANDCREATE")
						return '手动添加';
					return '';
				}
			},
			{
				name: 'loginTime',
				sortable: false,
				width: 80
			},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value["week"+(weekOfYear-4)])?value["week"+(weekOfYear-4)]:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value["week"+(weekOfYear-3)])?value["week"+(weekOfYear-3)]:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value["week"+(weekOfYear-2)])?value["week"+(weekOfYear-2)]:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value["week"+(weekOfYear-1)])?value["week"+(weekOfYear-1)]:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value["week"+weekOfYear])?value["week"+weekOfYear]:"";}}
		]
	},
	
	// 表格
	gridOpts1: {
		tablewrap: '#Grid1',
		dataUrl: '/userAction/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '团队', '姓名', '电话', '来源', '登录时间', 
		             'W1', 'W2', 'W3', 'W4', 'W5', 'W6', 'W7', 'W8', 'W9', 'W10',
		             'W11', 'W12', 'W13'],
		colModel: [
			{
				name: 'companyName',
				width: 120,
				sortable: false
			},
			{
				name: 'name',
				sortable: false,
				width: 120
			},
			{
				name: 'mobile',
				sortable: false,
				width: 80
			},
			{
				name: 'source',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					if(value=="PC_BY_ADMIN")
						return 'PC手动添加';
					if(value=="WECHAT_BY_ADMIN")
						return '微信手动添加';
					if(value=="PC")
						return 'PC注册';
					if(value=="WECHAT")
						return '微信注册';
					if(value=="INVITE")
						return '微信邀请';
					if(value=="HANDCREATE")
						return '手动添加';
					return '';
				}
			},
			{
				name: 'loginTime',
				sortable: false,
				width: 80
			},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week1)?value.week1:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week2)?value.week2:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week3)?value.week3:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week4)?value.week4:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week5)?value.week5:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week6)?value.week6:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week7)?value.week7:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week8)?value.week8:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week9)?value.week9:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week10)?value.week10:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week11)?value.week11:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week12)?value.week12:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week13)?value.week13:"";}}
		]
	},
	
	gridOpts2: {
		tablewrap: '#Grid2',
		dataUrl: '/userAction/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '团队', '姓名', '电话', '来源', '登录时间', 
		             'W14', 'W15', 'W16', 'W17', 'W18', 'W19', 'W20',
		             'W21', 'W22', 'W23', 'W24', 'W25', 'W26'],
		colModel: [
			{
				name: 'companyName',
				width: 120,
				sortable: false
			},
			{
				name: 'name',
				sortable: false,
				width: 120
			},
			{
				name: 'mobile',
				sortable: false,
				width: 80
			},
			{
				name: 'source',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					if(value=="PC_BY_ADMIN")
						return 'PC手动添加';
					if(value=="WECHAT_BY_ADMIN")
						return '微信手动添加';
					if(value=="PC")
						return 'PC注册';
					if(value=="WECHAT")
						return '微信注册';
					if(value=="INVITE")
						return '微信邀请';
					if(value=="HANDCREATE")
						return '手动添加';
					return '';
				}
			},
			{
				name: 'loginTime',
				sortable: false,
				width: 80
			},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week14)?value.week14:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week15)?value.week15:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week16)?value.week16:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week17)?value.week17:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week18)?value.week18:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week19)?value.week19:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week20)?value.week20:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week21)?value.week21:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week22)?value.week22:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week23)?value.week23:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week24)?value.week24:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week25)?value.week25:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week26)?value.week26:"";}}
		]
	},
	
	gridOpts3: {
		tablewrap: '#Grid3',
		dataUrl: '/userAction/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '团队', '姓名', '电话', '来源', '登录时间', 
		             'W27', 'W28', 'W29', 'W30',
		             'W31', 'W32', 'W33', 'W34', 'W35', 'W36', 'W37', 'W38', 'W39'],
		colModel: [
			{
				name: 'companyName',
				width: 120,
				sortable: false
			},
			{
				name: 'name',
				sortable: false,
				width: 120
			},
			{
				name: 'mobile',
				sortable: false,
				width: 80
			},
			{
				name: 'source',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					if(value=="PC_BY_ADMIN")
						return 'PC手动添加';
					if(value=="WECHAT_BY_ADMIN")
						return '微信手动添加';
					if(value=="PC")
						return 'PC注册';
					if(value=="WECHAT")
						return '微信注册';
					if(value=="INVITE")
						return '微信邀请';
					if(value=="HANDCREATE")
						return '手动添加';
					return '';
				}
			},
			{
				name: 'loginTime',
				sortable: false,
				width: 80
			},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week27)?value.week27:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week28)?value.week28:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week29)?value.week29:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week30)?value.week30:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week31)?value.week31:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week32)?value.week32:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week33)?value.week33:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week34)?value.week34:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week35)?value.week35:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week36)?value.week36:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week37)?value.week37:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week38)?value.week38:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week39)?value.week39:"";}}
		]
	},
	
	gridOpts4: {
		tablewrap: '#Grid4',
		dataUrl: '/userAction/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '团队', '姓名', '电话', '来源', '登录时间', 
		             'W40',
		             'W41', 'W42', 'W43', 'W44', 'W45', 'W46', 'W47', 'W48', 'W49', 'W50', 'W51', 'W52'],
		colModel: [
			{
				name: 'companyName',
				width: 120,
				sortable: false
			},
			{
				name: 'name',
				sortable: false,
				width: 120
			},
			{
				name: 'mobile',
				sortable: false,
				width: 80
			},
			{
				name: 'source',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					if(value=="PC_BY_ADMIN")
						return 'PC手动添加';
					if(value=="WECHAT_BY_ADMIN")
						return '微信手动添加';
					if(value=="PC")
						return 'PC注册';
					if(value=="WECHAT")
						return '微信注册';
					if(value=="INVITE")
						return '微信邀请';
					if(value=="HANDCREATE")
						return '手动添加';
					return '';
				}
			},
			{
				name: 'loginTime',
				sortable: false,
				width: 80
			},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week40)?value.week40:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week41)?value.week41:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week42)?value.week42:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week43)?value.week43:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week44)?value.week44:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week45)?value.week45:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week46)?value.week46:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week47)?value.week47:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week48)?value.week48:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week49)?value.week49:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week50)?value.week50:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week51)?value.week51:"";}},
			{name: 'weekMap', sortable: false, width: 60, formatter: function(value, options, rowObject){return (value&&value.week52)?value.week52:"";}}
		]
	},
};


(function($){
	//4、定义jquery对象
	var actionEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');
	
	actionEvn.changeTabOpts = function(){
		$contentWrapper.on('click','.search-tab a',function(){
			var dataType = $(this).attr("data-type");
			
			$(this).addClass('active').siblings().removeClass('active');
			$contentWrapper.find('#'+dataType).parents('.table-item').addClass("active").siblings().removeClass("active");
			
			if(dataType && dataType=='Grid1'){
				$grid = gridEvn.init(moduleConfig.activeModule.gridOpts1);
				 moduleConfig.activeModule.gridOpts.param= moduleConfig.activeModule.gridOpts1.param;
			}else if(dataType && dataType=='Grid2'){
				$grid = gridEvn.init(moduleConfig.activeModule.gridOpts2);
				moduleConfig.activeModule.gridOpts.param= moduleConfig.activeModule.gridOpts2.param;
			}else if(dataType && dataType=='Grid3'){
				$grid = gridEvn.init(moduleConfig.activeModule.gridOpts3);
				moduleConfig.activeModule.gridOpts.param= moduleConfig.activeModule.gridOpts3.param;
			}else if(dataType && dataType=='Grid4'){
				$grid = gridEvn.init(moduleConfig.activeModule.gridOpts4);
				moduleConfig.activeModule.gridOpts.param= moduleConfig.activeModule.gridOpts4.param;
			} 
		});
	};
	
	//页面跳转GO
	actionEvn.jumpPageEvent = function(){
		$wrapper.on('keyup','#tableToolbar .page-toolbar-input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('#tableToolbar .page-toolbar-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','#tableToolbar .page-toolbar-btn',function(){
			var pageNo = $wrapper.find('#tableToolbar .page-toolbar-input').val();
			if(pageNo){
				var data1={
					pageNo:pageNo
				}
			//	var param = $.extend(data1,moduleConfig.activeModule.gridOpts.param);
				gridEvn.loadData(data1);
			}
		});
	};
	
	// 点击查询
	actionEvn.searchEvent = function(){
		$wrapper.on('keyup','.js-toolbar-ctrl input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('.search-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','.search-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = {};
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param[name]=value;
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param[name]=value;
			}
			moduleConfig.activeModule.gridOpts.param=param;
			
			gridEvn.loadData(param);
		});
	};
	
	// 点击导出
	actionEvn.exportEvent = function(){	
		$wrapper.on('click','.export-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = "";
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param += name+"="+value+"&";
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param += name+"="+value+"&";
			}
			param = param.substring(0,param.length-1);
			window.open("/userAction/exportExcel?"+param);
		});
	};
	
	// 初始化
	actionEvn.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts0);
		//页面跳转GO
		this.jumpPageEvent();
		//tab切换
		this.changeTabOpts();
		//查询
		this.searchEvent();
		//导出
		this.exportEvent();
	};


	$(function(){
		actionEvn.init();
	});

})(jQuery);