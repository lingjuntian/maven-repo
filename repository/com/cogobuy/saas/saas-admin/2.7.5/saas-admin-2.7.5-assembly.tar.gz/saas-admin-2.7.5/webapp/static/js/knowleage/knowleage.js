//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'knowleage';

moduleConfig.activeModule = {
	moduleName: 'knowleage',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		//表格数据的请求地址
		dataUrl: '/knowleage/find',
		multiselect : false,
		// 默认的排序列
		sortname: 'knowleageId',
		// 表头名称
		colNames : ['知识ID', '标题', '状态', '创建人', '权重','创建时间', '操作'],
		colModel: [
			{
				name: 'knowleageId',
				width: 60,
				sortable: false
			},
			{
				name: 'knowleageTitle',
				width: 120,
				sortable: false
			},
			{
				name: 'isRelease',
				sortable: false,
				width: 120,
				formatter: function(value, options, rowObject){
					if(value==false)
						return '<p style="color:gray;">未发布</p>';
					return '<p style="color:#ec7946;">已发布</p>';
				}
			},
			{
				name: 'createName',
				sortable: false,
				width: 80
			},
			{
				name: 'knowleageSort',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 80
			},
			{
				name: 'option',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					/*console.log(value);
					console.log(options);
					console.log(rowObject);*/
					return '<a href="/knowleage/edit?knowleageId='+rowObject.knowleageId+'" class="js_edit_knowleage" >编辑</a>&nbsp;&nbsp;'+
							'<a href="javascript:void(0);" class="js_del_knowleage" data-index='+rowObject.knowleageId+' >删除</a>';
				}
			}

		]
	},

};


(function($){
	//4、定义jquery对象
	var knowleageEnv = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');
	// 点击查询
	knowleageEnv.searchEvent = function(){
		$wrapper.on('keyup','.js-toolbar-ctrl input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('.search-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','.search-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = {};
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param[name]=value;
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param[name]=value;
			}
			moduleConfig.activeModule.gridOpts.param=param;
			console.log(param);
			gridEvn.loadData(param);
		});
		$wrapper.on('change','.js_select_state',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = {};
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param[name]=value;
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param[name]=value;
			}
			moduleConfig.activeModule.gridOpts.param=param;
			console.log(param);
			gridEvn.loadData(param);
		});
	};
	// 页跳转
	knowleageEnv.jumpPageEvent = function(){
		$wrapper.on('keyup','#tableToolbar .page-toolbar-input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('#tableToolbar .page-toolbar-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','#tableToolbar .page-toolbar-btn',function(){
			var pageNo = $wrapper.find('#tableToolbar .page-toolbar-input').val();
			if(pageNo){
				var data1={
					pageNo:pageNo
				}
				var param = $.extend(data1,moduleConfig.activeModule.gridOpts.param);
				gridEvn.loadData(param);
			}
		});
	};
	// 弹出框-保存（确定）
	knowleageEnv.saveOpt = function(){
		$pop.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			var $form = $(this).parents("form:first");
			$('#contentTextarea').val($('#contentEditor').html());
			if($.trim($('#contentTextarea').val()) == "<p><br></p>"){
				$('#contentTextarea').val("");
			}
			//表单验证
			$form.find('.js_require').each(function(){
				fValidate.init({
					inObj:$(this)
				});
				
			});
			//提交表单
			if(!type){
				return false;
			}
			switch (type){
				case 'addKnowleage':
					ajaxUrl = '/manage/addAdmin';
					break;
			}
			if(ajaxUrl){
				//表单提交
				var formData = $(this).parents("form:first").serialize();
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});

				formJqx.done(function(result){
					if(result.type=="success"){
						$item.parents('.pop-main').remove();
						$("#pop").hide();

						popEvn.hint({
							txt:'操作成功'
						});
					}else if(result.type=="error"){
						popEvn.hint({
							txt: result.content
						});
					}
				});
			}
		});	
	};
	//删除某个知识
	knowleageEnv.del = function(){
		$wrapper.on('click','.js_del_knowleage',function(){
			var _index = $(this).attr('data-index');
			if(confirm('确定要删除该项吗？')){
				var jqx = baseEvn.ajaxFun({
					url:'/knowleage/delete?knowleageId='+$.trim(_index)
				});
				jqx.done(function(data){
					if(typeof data != 'undefined'){
						if(data.type == 'success'){
							popEvn.hint({
								txt: '删除成功'
							});
							var data1 = {};
							$('.toolbar-item.num').find('a').each(function(){
								if($(this).hasClass('active')){
									data1 = {
										pageNo:parseInt($(this).attr('data-page'))
									};
								}
							});
							var param = $.extend(data1,moduleConfig.activeModule.gridOpts.param);
							gridEvn.loadData(param);
						}
					}
				}).fail(function(data){

				});
			}else{
				return false;
			}
		});
	};
	// 初始化
	knowleageEnv.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		//点击搜索
		this.searchEvent();
		//页跳转
		this.jumpPageEvent();
		//删除某个知识
		this.del();
	};


	$(function(){
		knowleageEnv.init();
	});

})(jQuery);