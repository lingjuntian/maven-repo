(function($){
	'use strict';

var forgetEvn = {
	publicFun: function(){
		var $main = $('#main'),
			codeTime = null,
			dataApi = {
				// 获取验证码
				getCode: '/login/getAuthenticode',
				// 提交手机号及验证码
				codeSubmit: '/login/findBackPasswordSubmit',
				// 设置新密码
				setPwd: '/login/passwordChangeSubmit'
			};

		// 输入框获取焦点
		$main.on('focus', '.in-txt', function(){
			$(this).removeClass('in-err');
			// $(this).removeClass('in-err').parent().find('.tips').html('');
		});

		// 输入框失去焦点
		$main.on('blur', '.in-txt', function(){
			fValidate.init({
	        	inObj: $(this),
	        }, function(opts){

	        	if(!opts.isTrue){
	        		opts.inObj.addClass('in-err');
	        	}

	        	// 确认密码框
	        	if(opts.inObj.attr('name') == 'rpwd'){
	        		if(opts.inObj.val() != opts.inObj.parents('form').find('input[name="pwd"]').val()){
	        			opts.Tips = '两次输入的密码不一致！';
	        		}
	        	}

	            opts.inObj.parent().find('.tips').html(opts.Tips);
	        });
		});

		// 获取手机验证码
		$main.on('click', '.js-btn-getcode', function() {
			var phone = $main.find('.phone-num').text(),
				$this = $(this);

			// 验证
			if(!$this.hasClass('z-cld')){
				$this.addClass('z-cld');
				timeOut($this, 60);

				var jqxhr = baseEvn.ajaxFun({
					url : dataApi.getCode,
					data : {
						phone : phone
					}
				});

				jqxhr.done(function ( data ) {
					// alert('done');
				}).fail(function ( data ) {
					// alert('fail');
					popEvn.confirmFun({
						contentTxt: '获取验证码失败，请稍后重试！',
						cancelBtn: '',
						initCallback: function(){
							// console.log('ok');
							timeOut($this, 0);
						}
					});
				}).always(function ( data ) {
					$this.removeClass('z-cld');
				});
			}

			return false;
		});


		// 忘记密码-下一步
		$main.on('click', '.js-forget-next', function() {
			var phone = $main.find('.phone-num').text(),
				vcode = $.trim($main.find('input[name="code"]').val()),
				isTure = true,
				$this = $(this);

			fValidate.init({
	        	inObj: $main.find('input[name="code"]'),
	        }, function(opts){

	        	isTure = opts.isTrue;

	        	if(!isTure){
	        		opts.inObj.addClass('in-err');
	        	}

	            opts.inObj.parent().find('.tips').html(opts.Tips);
	        });

			// 验证
			if(!$this.hasClass('z-cld') && isTure){
				$this.addClass('z-cld').text('提交中...');

				var jqxhr = baseEvn.ajaxFun({
					url : dataApi.codeSubmit,
					data : {
						phone : phone,
						authenticode : vcode
					}
				});

				jqxhr.done(function ( data ) {
					// alert('done');
					$main.find('.item2').addClass('active').siblings().removeClass('active');
				}).fail(function ( data ) {
					// alert('fail');
					popEvn.confirmFun({
						contentTxt: '提交失败，请稍后重试！',
						cancelBtn: '',
						initCallback: function(){
							// console.log('ok');
						},
						confirmCallback: function(){
							$main.find('.item2').addClass('active').siblings().removeClass('active');
						}
					});
				}).always(function ( data ) {
					// alert('always');
					$this.removeClass('z-cld').text('下一步');
				});
			}

			return false;
		});

		// 忘记密码-设置新密码
		$main.on('click', '.js-forget-sub', function() {
			var phone = $main.find('.phone-num').text(),
				$form = $(this).parents('form'),
				isTure = 0,
				$this = $(this);

			$form.find('.in-txt').each(function(){
				fValidate.init({
		        	inObj: $(this),
		        }, function(opts){

		        	if(!opts.isTrue){
		        		isTure++;
		        		opts.inObj.addClass('in-err');
		        	}

		        	// 确认密码框
		        	if(opts.inObj.attr('name') == 'rpwd'){
		        		if(opts.inObj.val() != opts.inObj.parents('form').find('input[name="pwd"]').val()){
		        			opts.Tips = '两次输入的密码不一致！';
		        		}
		        	}

		            opts.inObj.parent().find('.tips').html(opts.Tips);
		        });
			});

			

			// 验证
			if(!$this.hasClass('z-cld') && isTure <= 0){
				$this.addClass('z-cld').text('提交中...');

				var jqxhr = baseEvn.ajaxFun({
					url : dataApi.setPwd,
					data : {
						phone: phone,
						password : $.trim($form.find('input[name="pwd"]').val())
					}
				});

				jqxhr.done(function ( data ) {
					// alert('done');
					popEvn.confirmFun({
						contentTxt: '新密码设置成功！<br>请使用新密码重新登录',
						cancelBtn: '',
						initCallback: function(){
							// console.log('ok');
						},
						confirmCallback: function(){
							window.location.href = '/login';
						}
					});
				}).fail(function ( data ) {
					// alert('fail');
					popEvn.confirmFun({
						contentTxt: '提交失败，请稍后重试！',
						cancelBtn: '',
						initCallback: function(){
							// console.log('ok');
						},
						confirmCallback: function(){

						}
					});
				}).always(function ( data ) {
					// alert('always');
					$this.removeClass('z-cld').text('确定');
				});
			}

			return false;
		});

		// 倒计时
		function timeOut(btnObj, num) {
			clearTimeout(codeTime);

			btnObj.html(num + '秒后重发');
			num--;

			codeTime = setTimeout(function() {
				if (num <= 0) {
					clearTimeout(codeTime);
					btnObj.html('获取验证码').removeClass('z-cld');
				} else {
					timeOut(btnObj, num);
				}
			}, 1000);
		};
	},
	init: function(){
		this.publicFun();
	}
};

$(function(){
	forgetEvn.init();
});

}(jQuery));
