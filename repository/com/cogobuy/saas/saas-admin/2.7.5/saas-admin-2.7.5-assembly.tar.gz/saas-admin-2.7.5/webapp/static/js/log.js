var moduleName = 'admin';

(function($){

	var customerEvn = {},
	$wrapper = $('#wrapper'),
	$pageLeft = $('#pageLeft'),
	$contentWrapper = $('#contentWrapper');
	$body = $('body');
	$pop = $('body .pop');
 
	// 初始化
	customerEvn.init = function(){
	      
	// 弹出框pop-main清除内容
	$body.on('click','.js-pop-close.pop-clear',function(){
		$(this).parents('.pop-main').remove();
	});
	 

	// 表格初始化
	var $grid = gridEvn.init({
		tablewrap: '#saasGrid',
		dataUrl: '/admin/logReport',
		// 默认的排序列
		sortname: 'sort',
		// 表头名称
		colNames : [ '', '访问用户数', '产品概述', '选择赤狐','点击注册','demo账号登录', '获取验证码', '完善信息'],
		colModel: [
			{
				name: 'res',
				width: 100,
				sortable: false
			},
			{
				name: 'uv',
				sortable: false,
				width: 50,
				formatter: function(value){
					if(value ==0 || value == null)
						return '-';
					else
						return value;
				}
			},
			{
				name: 'btnDes',
				sortable: false,
				width: 50,
				formatter: function(value){
					if(value ==0 || value == null)
						return '-';
					else
						return value;
				}
			},
			{
				name: 'btnWhy',
				sortable: false,
				width: 50,
				formatter: function(value){
					if(value ==0 || value == null)
						return '-';
					else
						return value;
				}
			},
			{
				name: 'btnReg',
				sortable: false,
				width: 50,
				formatter: function(value){
					if(value ==0 || value == null)
						return '-';
					else
						return value;
				}
			},
			{
				name: 'define1',
				sortable: false,
				width: 50,
				formatter: function(value){
					if(value ==0 || value == null)
						return '-';
					else
						return value;
				}
			},
			{
				name: 'getCode',
				sortable: false,
				width: 50,
				formatter: function(value){
					if(value ==0 || value == null)
						return '-';
					else
						return value;
				}
			},
			{
				name: 'regCompanyName',
				sortable: false,
				width: 50,
				formatter: function(value){
					if(value ==0 || value == null)
						return '-';
					else
						return value;
				}
			}
		]
	});
	$contentWrapper.on("click","[name='logreport']",function(){
		 
			data = {
				startDate: $("[name=startDate]").val(),
				endDate:	$("[name=endDate]").val()
			};
			gridEvn.loadData(data);
		});

	};


	$(function(){
	customerEvn.init();
	});

})(jQuery);