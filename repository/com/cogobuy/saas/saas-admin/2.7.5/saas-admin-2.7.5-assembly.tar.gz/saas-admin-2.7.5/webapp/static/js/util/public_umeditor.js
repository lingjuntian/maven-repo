(function($){
	var umEditorArr,
	saveDraftsTime,
	isSaveDraftsTime = true,
	$body = $('body');
	var umeditorEnv = {
		umOpts:{
			isEdit:false,
			// 获取
			draftsGetUrl: '',
			getCallback: function(result){
				// console.log('get');
				// console.log(result);
			},
			// 设置
			draftsSaveUrl: '',
			saveCallback: function(result){
				// console.log('save');
				// console.log(result);
			}
		},
		// 定时存储草稿
		saveDraftsTimer:function(){
			var _that = this;
			clearTimeout(saveDraftsTime);

			// 30秒保存一次
			saveDraftsTime = setTimeout(function(){
				if(isSaveDraftsTime){
					_that.getSaveDrafts();
					_that.saveDraftsTimer();
				}		
			},30000);
		},
		// 获取或存储到草稿
		getSaveDrafts:function(isGet){
			var _that = this;
			// console.log('isGet：' + isGet);
			// console.log( _that.umOpts.umArr);
			if(isGet === true){
				_that.ueditorDrafts({
					getUrl: _that.umOpts.draftsGetUrl,
					saveUrl: _that.umOpts.draftsSaveUrl,
					ueditorName: _that.umOpts.umArr[i],
					isSave: false
				});
			}else{
				for (var i = _that.umOpts.umArr.length - 1; i >= 0; i--) {
					_that.ueditorDrafts({
						getUrl: _that.umOpts.draftsGetUrl,
						saveUrl: _that.umOpts.draftsSaveUrl,
						ueditorName: _that.umOpts.umArr[i],
						isSave: true
					});
				};
			}
		},
		// AJAx 保存或获取草稿
		ueditorDrafts:function(opts){
			var _that = this;
			var ajaxParme = {
					url: opts.getUrl,
					data: {}
				};

			// 是否是保存草稿
			if(opts.isSave){
				ajaxParme.url = opts.saveUrl;
				ajaxParme.data.type = opts.ueditorName;
				ajaxParme.data.draft = (typeof(opts.content) == 'string') ? opts.content : umEditorArr[opts.ueditorName].getContent();
			}

			// console.log(umEditorArr[opts.ueditorName]);

			var jqxhr = baseEvn.ajaxFun(ajaxParme);
			
			jqxhr.done(function(result){
				if(opts.isSave){
					_that.umOpts.saveCallback(result);
				}else{

					// 设置草稿内容
					for (var k in result.args) {
						if(k == 'file'){

						}else{
							umEditorArr[k].setContent(result.args[k] || '');
						}					
					}

					_that.umOpts.getCallback(result);
				}
			});
		},
		// 生成编辑器
		ueditorInit:function(ueOpts){
			var _that = this;
			if(!ueOpts){
				return;
			}
			var tempArr = [],
				tempUM;

			for (var i = ueOpts.editorIdArr.length - 1; i >= 0; i--) {
				tempUM = UM.getEditor(ueOpts.editorIdArr[i],{
				    //这里可以选择自己需要的工具按钮名称,此处仅选择如下七个
				    toolbar:['bold italic underline fontsize forecolor justifyleft justifycenter justifyright insertorderedlist insertunorderedlist'],

				    //focus时自动清空初始化时的内容
				    autoClearinitialContent: false,
				    //关闭字数统计
				    wordCount:false,
				    maximumWords: 1000,
				    //关闭elementPath
				    elementPathEnabled:false,
				    //初始化编辑器宽度,默认500
				    initialFrameWidth: 555,
				    //默认的编辑区域高度
				    initialFrameHeight:135,
				    autoHeightEnabled: false,
				    autoFloatEnabled: false,
				    initialStyle: 'li,p{line-height:1.6;font-size:12px;}',
				    fontsize: [12,14,16,18]
				});

				tempArr[ueOpts.editorIdArr[i]] = tempUM;
			}

			return tempArr;
		},
		// 注销编辑器
		umDestroy:function(){
			var _that = this;
			for (var k in umEditorArr) {
				if(typeof(umEditorArr[k]) != 'undefined'){
					umEditorArr[k].destroy();
				}
			};

			$body.off('click', '.js-pop-close', _that.umDestroy);
		},
		// 清除缓存
		clearDrafts:function(){
			var _that = this;
			for (var i = _that.umOpts.umArr.length - 1; i >= 0; i--) {
				_that.ueditorDrafts({
					getUrl: _that.umOpts.draftsGetUrl,
					saveUrl: _that.umOpts.draftsSaveUrl,
					ueditorName: _that.umOpts.umArr[i],
					content: '',
					isSave: true
				});
			};
		},
		// 初始化编辑器
		init:function(opts){
			var _that = this;
			_that.umOpts = $.extend({}, _that.umOpts, opts);


			if(!_that.umOpts.umArr){
				return;
			}

			// 初始化所有编辑器
			umEditorArr = _that.ueditorInit({
				editorIdArr: _that.umOpts.umArr
			});
			
			// 判断是否是编辑状态
			if(!_that.umOpts.isEdit){

				for (var i = _that.umOpts.umArr.length - 1; i >= 0; i--) {
					umEditorArr[_that.umOpts.umArr[i]].addListener( 'blur', _that.getSaveDrafts);
				};


				umEditorArr[_that.umOpts.umArr[0]].ready(function(){
					// 启动定时存储草稿
					isSaveDraftsTime = true;
					_that.getSaveDrafts(true);
					_that.saveDraftsTimer();
				});

				umEditorArr[_that.umOpts.umArr[0]].addListener( 'destroy', function(){
					isSaveDraftsTime = false;
				});
			}

			$body.on('click', '.js-pop-close', _that.umDestroy);
			// $body.on('click', '.js-pop-save', _that.umDestroy);
		}
	};

	window.umeditorEnv = umeditorEnv;

})(jQuery);

