$(function(){
	$("#codeButton").click(function(){
		$.ajax({
		    type: 'get',
		    url: '/login/getAuthenticode' ,
		    success: function(authenticode){
		    	$("#showAuthenticode").html(authenticode);
		    } ,
		    dataType: 'json'

		});
	});

});