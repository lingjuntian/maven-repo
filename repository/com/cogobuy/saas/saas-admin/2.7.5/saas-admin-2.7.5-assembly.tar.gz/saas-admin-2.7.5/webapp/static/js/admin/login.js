
(function($){
	//4、定义jquery对象
	var loginEvn = {},
		$body = $('body');
	
	// 初始化
	loginEvn.init = function(){
		$body.on('click', '#login-submit', function(){
			var userName = $(this).siblings('#userName').val();
			var password = $(this).siblings('#password').val();
			var $this = $(this);
			if(!userName){
				$(this).siblings('.tips.err').text('请填写用户名');
				return;
			}
			if(!password){
				$(this).siblings('.tips.err').text('请填写密码');
				return;
			}
			var formJqx = baseEvn.ajaxFun({
				url:"/login/doLogin",
				data:{
					userName:userName,
					password:password
				}
			});

			formJqx.done(function(result){
				if(result.type=='success'){
					window.location="/push";
				}else{
					$this.siblings('.tips.err').text(result.content);
				}
			});
		});
	};


	$(function(){
		loginEvn.init();
	});

})(jQuery);