(function($){
	//4、定义jquery对象
	var validateEvn = {},
		$body = $('body');
	
	// 正整数验证
	validateEvn.validateNum = function(){
		
		$body.on('keydown','[data-type="positive-integer"]',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if (code >= 48 && code <= 57 ) return true
		    // 小数字键盘
		    if (code >= 96 && code <= 105) return true
		    if (code ==8) return true
			return false;
		});	
	};
	

	// 初始化
	validateEvn.init = function(){
		
		this.validateNum();
	};


	$(function(){
		validateEvn.init();
	});

})(jQuery);