//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'push';

moduleConfig.activeModule = {
	moduleName: 'push',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		dataUrl: '/push/find',

		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : [ '客户名称', '地址', '电话', '所属用户', '用户团队', '创建时间', '已推送', '已查看', '是否接收','原因', '推送时间','所属用户联系方式', '是否绑定微信', '输入来源'],
		colModel: [
			{
				name: 'customerName',
				width: 120,
				sortable: false
			},
			{
				name: 'address',
				sortable: false,
				width: 120,
				formatter: function(value, options, rowObject){
					var result = '';
					if(rowObject.province)
						result += rowObject.province+"&nbsp";
					if(rowObject.city)
						result += rowObject.city+"&nbsp";
					if(value)
						result += value;
					return result;
				}
			},
			{
				name: 'phone',
				sortable: false,
				width: 80
			},
			{
				name: 'chargeUserName',
				sortable: false,
				width: 80
			},
			{
				name: 'companyName',
				sortable: false,
				width: 80
			},
			{
				name: 'createTime',
				sortable: false,
				width: 60,
				formatter: function(value, options, rowObject){
					if(value){
						return value.substring(0,10);
					}
					return '';
				}
			},
			{
				name: 'pushId',
				sortable: false,
				width: 60,
				formatter: function(value, options, rowObject){
					var findStatus = rowObject.findStatus;
					var state = rowObject.waitReason;
					
					if(state==null || !state || state=='3'){
						if(findStatus==null || !findStatus){
							state="否（未找）";
						}else if(findStatus=="NotFound"){
							state="否（找不到）";
						}else if(findStatus=="Found"){
							state="否（找到）";
						}
					}else if(state=='0'){
						state="是";
					}else{
						state="待";
					}
					return '<a push-id="'+ value 
					+'" data-id="'+ rowObject.customerId 
					+'" open-id="'+ rowObject.userOpenId
					+'" customer-name="'+ rowObject.customerName 
					+'" charge-name="'+ rowObject.chargeUserName 
					+'" charge-id="'+ rowObject.chargeUserId 
					+'" class="js-push" href="javascript:void(0);">' 
					+ state + '</a>';
				}
			},
			{
				name: 'isRead',
				sortable: false,
				width: 50,
				formatter: function(value, options, rowObject){
					if(value==false)
						return '<p style="color:gray;">否</p>';
					if(value)
						return '<p style="color:#ec7946;">是</p>';
					return '';
				}
			},
			{
				name: 'isGet',
				sortable: false,
				width: 50,
				formatter: function(value, options, rowObject){
					if(value==false)
						return '<p style="color:gray;">否</p>';
					if(value)
						return '<p style="color:#ec7946;">是</p>';
					return '';
				}
			},
			{
				name: 'reason',
				sortable: false,
				width: 50
			},
			{
				name: 'pushTime',
				sortable: false,
				width: 80,
				sorttype: 'date'
			},
			
			{
				name: 'mobile',
				sortable: false,
				width: 100,
				formatter: function(value, options, rowObject){
				   return value;
				}
				
			},
			{
				name: 'userOpenId',
				sortable: false,
				width: 50,
				formatter: function(value, options, rowObject){
					if(value)
						return '<p style="color:#ec7946;">是</p>';
					return '<p style="color:gray;">否</p>';
				}
			},
			{
				name: 'createType',
				sortable: false,
				width: 50,
				formatter: function(value, options, rowObject){
					if(value=='RECOMMEND')
						return '推荐';
					else if(value=='SCAN'){
						return '名片扫描';
					}
					return '普通';
				}
			}
		]
	},

};


(function($){
	//4、定义jquery对象
	var pushEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');
	
	// 点击进行客户推送
	pushEvn.pushPop = function(){
		$wrapper.on('click','.js-push',function(){
			var textValue = $(this).text();
			var customerId = $(this).attr("data-id");
			var customerName = $(this).attr("customer-name");
			var forUserName = $(this).attr("charge-name");
			var forUserId = $(this).attr("charge-id");
			var openId = $(this).attr("open-id");
			if(textValue=='是'){
				var pushId = $(this).attr("push-id");
				//5.5加载任务提醒
				var popJqx = baseEvn.ajaxFun({
					url: "/push/getPush",
					data: {
						id:pushId
					}
				});

				popJqx.done(function(result){
					if(result.type='success'){
						renderEvn.renderTpl({
							tplId: '#popGetPushTpl',
							outputId: "#pop",
							data: result,
							callback: function(outObj){
								popEvn.open();
							}
						});
					}					
				})
			}else if(!openId || openId=='null'){
				popEvn.hint({
					txt:'用户没有绑定微信，不能进行推送'
				});
				return;
			}else if(textValue=='否（未找）' || textValue=='否（找不到）'){
				renderEvn.renderTpl({
					tplId: "#popPushTpl",
					outputId: "#pop",
					data: {
						customerId : customerId,
						customerName : customerName,
						forUserName : forUserName,
						forUserId : forUserId
					},
					callback: function(outObj){
					//	popEvn.setPopcontentHeight();
						popEvn.open();
					}
				});
			}else if(textValue=='否（找到）'){
				var pushId = $(this).attr("push-id");
				//5.5加载任务提醒
				var popJqx = baseEvn.ajaxFun({
					url: "/push/findLikeResult",
					data: {
						id:pushId
					}
				});

				popJqx.done(function(result){
					if(result.type='success'){
						renderEvn.renderTpl({
							tplId: '#popLikeResultTableTpl',
							outputId: "#pop",
							data: {
								pushId:pushId,
								result:result.args
							},
							callback: function(outObj){
								popEvn.open();
							}
						});
					}					
				})
			}else if(textValue=='待'){
				var pushId = $(this).attr("push-id");
				//5.5加载任务提醒
				var popJqx = baseEvn.ajaxFun({
					url: "/push/getPush",
					data: {
						id:pushId
					}
				});

				popJqx.done(function(result){
					if(result.type='success'){
						renderEvn.renderTpl({
							tplId: '#popEditPushTpl',
							outputId: "#pop",
							data: result,
							callback: function(outObj){
								popEvn.open();
							}
						});
					}					
				})
			}			
			
		});
	}
	
	// 弹出框-保存（确定）
	pushEvn.saveOpt = function(){
		$pop.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'pushCustomer':
					ajaxUrl = '/push/pushCustomer';
					break;
			}
			if(ajaxUrl){
				//表单提交
				var formData = $(this).parents("form:first").serialize();
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});

				formJqx.done(function(result){
					if(result.type=="success"){
						$item.parents('.pop-main').remove();
						$("#pop").hide();
						//刷新
						var $sel = $("#saasGrid").find(".js-push[data-id='"+result.args.forCustomerId+"']");
						$sel.attr("push-id",result.args.id);
						if(result.args.waitReason==null || result.args.waitReason=="0")
							$sel.text("是");
						else{
							$sel.text("待");
						}
						
						popEvn.hint({
							txt:'操作成功'
						});
					}else if(result.type=="error"){
						popEvn.hint({
							txt: result.content
						});
					}
				});
			}
		});	
	};
	
	pushEvn.radioChoose = function(){
		$pop.on('click','table .js-radio',function(){
			$pop.find('table .js-radio.selected').removeClass("selected");
			$(this).addClass("selected");
		});
	};
	
	// 弹出框   下一步
	pushEvn.nextStepOpt = function(){
		$pop.on('click','.pop-btn.js-pop-nextStep',function(){
			var pushId = $(this).attr("push-id");
			var selectedId = $pop.find('table .js-radio.selected').val();
			console.log(selectedId);
			if(!selectedId || selectedId==null || selectedId==''){
				popEvn.hint({
					txt: '请选择一个推荐客户'
				});
				return false;
			}
			var popJqx = baseEvn.ajaxFun({
				url: "/push/getSelectedPush",
				data: {
					pushId:pushId,
					selectedId:selectedId
				}
			});

			popJqx.done(function(result){
				if(result.type='success'){
					renderEvn.renderTpl({
						tplId: '#popEditPushTpl',
						outputId: "#pop",
						data: result,
						callback: function(outObj){
							popEvn.open();
						}
					});
				}					
			})
		});	
	};
	
	// 弹出框   手动填写
	pushEvn.handFormOpt = function(){
		$pop.on('click','.pop-btn.js-pop-handForm',function(){
			var pushId = $(this).attr("push-id");
			
			var popJqx = baseEvn.ajaxFun({
				url: "/push/getPush",
				data: {
					id:pushId
				}
			});

			popJqx.done(function(result){
				if(result.type='success'){
					renderEvn.renderTpl({
						tplId: '#popEditPushTpl',
						outputId: "#pop",
						data: result,
						callback: function(outObj){
							popEvn.open();
						}
					});
				}					
			})
		});
	};
	
	// 点击查询
	pushEvn.searchEvent = function(){
		$wrapper.on('keyup','.js-toolbar-ctrl input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('.search-btn').trigger('click');
			}
			
		});

		$wrapper.on('click','.search-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = {};
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param[name]=value;
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param[name]=value;
			}
			moduleConfig.activeModule.gridOpts.param=param;
			
			gridEvn.loadData(param);
		});
	};
	
	// 页码跳转
	pushEvn.jumpPageEvent = function(){
		$wrapper.on('keyup','#tableToolbar .page-toolbar-input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('#tableToolbar .page-toolbar-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','#tableToolbar .page-toolbar-btn',function(){
			var pageNo = $wrapper.find('#tableToolbar .page-toolbar-input').val();
			if(pageNo){
				var data1={
					pageNo:pageNo
				}
				var param = $.extend(data1,moduleConfig.activeModule.gridOpts.param);
				gridEvn.loadData(param);
			}
		});
	};
	
	// 点击导出
	pushEvn.exportEvent = function(){	
		$wrapper.on('click','.export-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = "";
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param += name+"="+value+"&";
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param += name+"="+value+"&";
			}
			param = param.substring(0,param.length-1);
			window.open("/push/exportExcel?"+param);
		});
	};
	
	//无法推送 radio取消选择
	pushEvn.cancelRadio = function(){	
		$pop.on('click','#no_push_radio input',function(){
			var selected = $(this).parent().attr("selected_value");
			var sel = $(this).val();
			if(selected == sel){
				$(this).removeAttr("checked");
				$(this).parent().attr("selected_value","");
			}else{
				$(this).parent().attr("selected_value",sel);
			}			
		});
	};
	
	// 初始化
	pushEvn.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		//radio选择
		this.radioChoose();
		//弹出推荐框
		this.pushPop();
		//手动填写
		this.handFormOpt();
		//下一步
		this.nextStepOpt();
		//确定按钮保存
		this.saveOpt();
		//搜索查询
		this.searchEvent();
		//页面跳转GO
		this.jumpPageEvent();
		//导出
		this.exportEvent();
		//无法推荐原因取消
		this.cancelRadio();
	};


	$(function(){
		pushEvn.init();
	});

})(jQuery);