//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'corporation';

moduleConfig.activeModule = {
	moduleName: 'corporation',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		dataUrl: '/corporation/find',
		
		// 默认的排序列
		sortname: 'createTime',
		// 表头名称
		colNames : ['团队', '注册时间', '注册来源', '团队人数', '创建人', '创建人身份', '创建人手机', '创建人邮箱', '创建人最后一次登录时间'],
		colModel: [
			{
				name: 'companyName',
				sortable: false,
				width: 120
			},
			{
				name: 'createTime',
				width: 100,
				sortable: false
			},
			{
				name: 'source',
				sortable: false,
				width: 80/*,
				formatter: function(value, options, rowObject){
					if(value=="PC_BY_ADMIN")
						return 'PC手动添加';
					if(value=="WECHAT_BY_ADMIN")
						return '微信手动添加';
					if(value=="PC")
						return 'PC注册';
					if(value=="WECHAT")
						return '微信注册';
					if(value=="INVITE")
						return '微信邀请';
					if(value=="HANDCREATE")
						return '手动添加';
					return '';
				}*/
			},
			{
				name: 'totalUser',
				width: 60,
				sortable: false
			},
			{
				name: 'createByName',
				sortable: false,
				width: 80
			},
			{
				name: 'isAdmin',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					var roleName = rowObject.roleName;
					var department = rowObject.department;
					if(value || value=='true')
						return '管理员';
					else if(roleName && roleName=='部门主管')
						return '部门主管'+(department==null?"":"（"+department+"）");
					else
					    return '普通员工'+(department==null?"":"（"+department+"）");
				}
			},
			{
				name: 'mobile',
				sortable: false,
				width: 80
			},
			{
				name: 'email',
				sortable: false,
				width: 100
			},
			{
				name: 'loginTime',
				sortable: false,
				width: 80
			}			
		]
	},

};


(function($){
	//4、定义jquery对象
	var corporationEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');
	
	// 点击查询
	corporationEvn.searchEvent = function(){
		$wrapper.on('keyup','.js-toolbar-ctrl input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('.search-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','.search-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = {};
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param[name]=value;
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param[name]=value;
			}
			moduleConfig.activeModule.gridOpts.param=param;
			
			gridEvn.loadData(param);
		});
	};
	
	// 点击导出
	corporationEvn.exportEvent = function(){	
		$wrapper.on('click','.export-btn',function(){
			var form = $(this).parents("form:first");
			var input = $(form).find('input');
			var select = $(form).find('select');
			var param = "";
			for(var i=0; i<input.length; i++){
				var name = $(input[i]).attr("name");
				var value = $(input[i]).val();
				if(name && value)
					param += name+"="+value+"&";
			}
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param += name+"="+value+"&";
			}
			param = param.substring(0,param.length-1);
			window.open("/corporation/exportExcel?"+param);
		});
	};
	
	// 页跳转
	corporationEvn.jumpPageEvent = function(){
		$wrapper.on('keyup','#tableToolbar .page-toolbar-input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('#tableToolbar .page-toolbar-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','#tableToolbar .page-toolbar-btn',function(){
			var pageNo = $wrapper.find('#tableToolbar .page-toolbar-input').val();
			if(pageNo){
				var data1={
					pageNo:pageNo
				}
				var param = $.extend(data1,moduleConfig.activeModule.gridOpts.param);
				gridEvn.loadData(param);
			}
		});
	};
	
	
	// 初始化
	corporationEvn.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		
		//搜索事件
		this.searchEvent();
		
		//页面跳转GO
		this.jumpPageEvent();
		
		//导出
		this.exportEvent();
	};


	$(function(){
		corporationEvn.init();
	});

})(jQuery);