function fileFormUpload(fileInput,callback){
		var $iframe,
			$form,
			$inputParent = fileInput.parent(),
			$input = fileInput,
			iframeName = 'fileFormIframe',
			formName = 'fileFormForm',
			_formUrl = '/commonapi/do_upload_image',
			inputStr = '',
			$body = $('body');

		if($inputParent.hasClass('fileUploading')){
			popEvn.hint({
				tipsClass: 'pop-tips-warn',
				txt: '文件正在上传，请稍等！'
			});
			return false;
		}

		$inputParent.addClass('fileUploading').find('span.file_img_span').text('上传中...');

		$iframe = $('#' + iframeName);
		$form = $('#' + formName);

		if($iframe.length == 0){
			$iframe = $('<iframe style="display:none; width: 0; height: 0;" id="'+ iframeName +'" name="'+ iframeName +'" />');

			$body.append($iframe);
		}
		
		if($form.length == 0){
			$form = $('<form method="post" target="'+ iframeName +'" action="'+ _formUrl +'" id="'+ formName +'" name="'+ formName +'" enctype="multipart/form-data" style="display:none; width: 0; height: 0;"></form>');

			$body.append($form);
		}


		$form.html($input).submit();

		$iframe.load(function(){

			var data = $(this).contents().find('body pre').html();		    

		    var result = data ? eval('(' + data + ')') : { type : 'error', content: '上传失败'};

		    callback(result);

		    $input.val('');
		    $inputParent.removeClass('fileUploading').find('span.file_img_span').text('上传图片');
		    $inputParent.append($input);
		    $form.html('');
		});
	}