//1、初始化模块名
//2、初始化表格配置
//3、初始化接口URL
//4、定义jquery对象
//5、添加按钮的绑定
var moduleName = 'operation';

moduleConfig.activeModule = {
	moduleName: 'operation',

	// 表格
	gridOpts: {
		tablewrap: '#saasGrid',
		dataUrl: '/userOperation/find',
		multiselect : false,
		// 默认的排序列
		sortname: 'id',
		// 表头名称
		colNames : ['团队','团队注册时间', '成员', '手机', '邮箱','角色', '注册入口', '来源渠道','成员加入时间' , '最后活动', '未活跃天数','系统运营','人工运营','是否放弃','用户标签'],
		colModel: [
			{
				name: 'companyName',
				width: 120,
				sortable: false
			},
			{
				name: 'regTime',
				sortable: false,
				width: 60
			},
			{
				name: 'name',
				width: 60,
				sortable: false,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					return '<a data-id="'+ rowObject.userId +'" customer-name="'+ rowObject.name +"/" + rowObject.companyName+'"  class="js-get-info" href="javascript:void(0);">' + value + '</a>';
				}
			},
			{
				name: 'mobile',
				sortable: false,
				width: 60
			},
			{
				name: 'email',
				sortable: false,
				width: 80
			},			 
			{
				name: 'roleName',
				sortable: false,
				width: 60
			},
			{
				name: 'source',
				sortable: false,
				width: 60,
				formatter: function(value, options, rowObject){
					if(value=="PC_BY_ADMIN")
						return 'PC手动添加';
					if(value=="WECHAT_BY_ADMIN")
						return '微信手动添加';
					if(value=="PC")
						return 'PC注册';
					if(value=="WECHAT")
						return '微信注册';
					if(value=="INVITE")
						return '微信邀请';
					if(value=="HANDCREATE")
						return '手动添加';
					return '';
				}
			},
			{
				name: 'channel',
				sortable: false,
				width: 60
			},
			{
				name: 'userCreateTime',
				sortable: false,
				width: 60
			},
			{
				name: 'lastActiveMsg',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					if (value!=null)
						return '<a data-id="'+ rowObject.userId +'" customer-name="'+ rowObject.name +"/" + rowObject.companyName+'"  class="js-get-info" href="javascript:void(0);">' + value + '</a>';
					else
						return '';
				}
			},
			{
				name: 'unActiveDay',
				sortable: false,
				width: 50
			},
			{
				name: 'sysLastRecallMsg',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					if (value!=null)
						return '<a data-id="'+ rowObject.userId +'" customer-name="'+ rowObject.name +"/" + rowObject.companyName+'"   class="js-get-info" href="javascript:void(0);">' + value + '</a>';
					else
						return '';
				}
			},
			{
				name: 'lastRecallMsg',
				sortable: false,
				width: 80,
				formatter: function(value, options, rowObject){
					// console.log(rowObject);
					if (value!=null)
						return '<a data-id="'+ rowObject.userId +'" customer-name="'+ rowObject.name +"/" + rowObject.companyName+'"  class="js-get-info" href="javascript:void(0);">' + value + '</a>';
					else
						return '';
				}
			},
			{
				name: 'isDeadUser',
				sortable: false,
				width: 80
			},
			{
				name: 'userTag',
				sortable: false,
				width: 80
			}
		]
	},

};


(function($){
	//4、定义jquery对象
	var teamEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body'),
		dataId = '';
	
	// 点击查询
	teamEvn.searchEvent = function(){
		$wrapper.on('keyup','.js-toolbar-ctrl input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('.search-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','.search-btn',function(){
			var form = $(this).parents("form:first");
			var input = form.find('input');
			var select = form.find('select');
			var param = {};
			
			input.each(function(){
				var name = $(this).attr("name"); 
				var inputType = $(this).attr("type");
				var value = $(this).val();
				
				if(name && value){
					//param[name] = [];
					if(inputType=="checkbox"){
						if($(this).prop('checked')){
							if(param[name]){
								param[name] = param[name]+","+value;
							}else{
								param[name] = value;
							}
						}
					}else{
						param[name] = value;
					}
				}
			});
			
			
			for(var i=0; i<select.length; i++){
				var name = $(select[i]).attr("name");
				var value = $(select[i]).val();
				if(name && value)
					param[name]=value;
			}
			console.log(param);
			moduleConfig.activeModule.gridOpts.param= param;
			
			gridEvn.loadData(param);
		});
	};
	
	// 点击导出
	teamEvn.exportEvent = function(){	
		$wrapper.on('click','.export-btn',function(){
			var form = $(this).parents("form:first");
			var input = form.find('input');
			var select = form.find('select');
			var param = {};
			var urlStr = [];

			
			input.each(function(){
				var name = $(this).attr("name"); 
				var inputType = $(this).attr("type");
				var value = $(this).val();
				
				if(name && value){
					//param[name] = [];
					if(inputType=="checkbox"){
						if($(this).prop('checked')){
							if(param[name]){
								param[name] = param[name]+","+value;
							}else{
								param[name] = value;
							}
						}
					}else{
						urlStr.push(name + '=' + value);
					}
				}
			});
			
//			console.log(param);
			$.each(param,function(n,value) { 
				
				urlStr.push(n + '=' + value);
			});
//			alert(encodeURI(urlStr.join('&')));
			window.open("/userOperation/exportExcel?"+encodeURI(urlStr.join('&')));
		});
	};
	
	// 点击重新计算
	teamEvn.countEvent = function(){	
		$wrapper.on('click','.count-btn',function(){
			var checkJqx = baseEvn.ajaxFun({
				url:"/userOperation/count"
			});

			checkJqx.done(function(result){
				if(result.type=="success"){
					popEvn.hint({
						txt:result.args
					});
				}else if(result.type=="error"){
					popEvn.hint({
						txt: result.content
					});
				}
			});
		});
	};
	
	// 页跳转
	teamEvn.jumpPageEvent = function(){
		$wrapper.on('keyup','#tableToolbar .page-toolbar-input',function(e){
			var theEvent = window.event || e,
			code = theEvent.keyCode || theEvent.which;
			if(code == 13){
				$wrapper.find('#tableToolbar .page-toolbar-btn').trigger('click');
			}
			
		});
		
		$wrapper.on('click','#tableToolbar .page-toolbar-btn',function(){
			var pageNo = $wrapper.find('#tableToolbar .page-toolbar-input').val();
			if(pageNo){
				var data1={
					pageNo:pageNo
				}
				var param = $.extend(data1,moduleConfig.activeModule.gridOpts.param);
				gridEvn.loadData(param);
			}
		});
	};
	
	
	teamEvn.showEvent = function(){
		// 判断是否点击了详细内容区域
		var clickInfoBox = false;
	
		// 关闭详情
		$wrapper.on('click',function(){
			if(!clickInfoBox){
				// 清空项目的id
				pageDataSet.dataId = '';
				$contentWrapper.find('.content-info').removeClass('active');
			}else{
				clickInfoBox = false;
			}
		});
	
		// 点击表格名称-显示详情
		$wrapper.on('click','.js-get-info',function(){
			clickInfoBox = true;
			$contentWrapper.find('.content-info').addClass('active').find('.tag-box').removeClass('tag-box-edit');
			
			dataId = $(this).attr('data-id');
			
			//alert(dataId);
			
			//保存客户名称
			pageDataSet.customerName = $(this).attr('customer-name');
			//详情显示当前客户名称
			$contentWrapper.find('.detail .js-name').html(pageDataSet.customerName);
			
			//用户活动
			var infoJqx = baseEvn.ajaxFun({
				url: "/userOperation/findUserActive",
				data: {
					userId:dataId
				}
			});

			infoJqx.done(function(result){
				//console.log(result);
				renderEvn.renderTpl({
					tplId: "#infoDetailUserActiveTpl",
					outputId: $contentWrapper.find('.content-info .item-report'),
					data: result					
				});
			}).fail(function(){
				 //console.log('fail');
			}).always(function(){
				 //console.log('aways');
			});
			
		}).on('click','.content-info',function(){
			clickInfoBox = true;
		});
		
	};
	

	// table -操作区table-batch-ctrl
	teamEvn.tablBatchCtrl = function(){
		$contentWrapper.on('click','.js-detail-opt a',function(){
			var columnType = $(this).attr('data-type'),
				actionType = $(this).attr('data-action'),
				tplId='#AddReportTpl';
			 
			if (columnType == 'add'){
			
			}else if(columnType == 'reactivated'){
				var jqx = baseEvn.ajaxFun({
					url: "/userOperation/reactivated",
					data: {
						userId:dataId
					}
				});
				
				jqx.done(function (result){
					if (result.type == 'success'){
						popEvn.hint({
							txt: result.content
						});
					} else if (result.type == 'error') {
						popEvn.hint({
							txt: result.content
						});
					}
				});
				return;
			}else if(columnType == 'drop'){
				var jqx = baseEvn.ajaxFun({
					url: "/userOperation/drop",
					data: {
						userId:dataId
					}
				});
				
				jqx.done(function (result){
					if (result.type == 'success'){
						popEvn.hint({
							txt: result.content
						});
					} else if (result.type == 'error') {
						popEvn.hint({
							txt: result.content
						});
					}
				});
				return;
			}
			
			// 渲染模板
			renderEvn.renderTpl({
				tplId: tplId,
				outputId: '#pop',
				data: {userId:dataId},
				callback: function(outObj){
					popEvn.open();
				}
			});

		});
	};
	
	 
	// 弹出框-保存（确定）
	teamEvn.saveOpt = function(){
		$pop.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			if(!type){
				return false;
			}
			switch (type){
				case 'recallRecord':
					ajaxUrl = '/userOperation/addRecallRecord';
					break;
			}
			if(ajaxUrl){
				//表单提交
				var formData = $(this).parents("form:first").serialize();
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});

				formJqx.done(function(result){
					if(result.type=="success"){
						// $item.parents('.pop-main').remove();
						$pop.find('.js-pop-close').trigger('click');
						popEvn.hint({
							txt: result.content
						});
					}else if(result.type=="error"){
						popEvn.hint({
							txt: result.content
						});
					}
				});
			}
		});	
	};
	
	// 详情页的tab切换
	teamEvn.tabDetail = function(){
		$contentWrapper.on('click','.js-detail-nav a',function(){
			var Idx = $(this).index();
			if($(this).hasClass('active')){
				return false;
			}
	
			$(this).addClass('active').siblings().removeClass('active');
			$contentWrapper.find('.detail-main .main-item').eq(Idx).addClass('active').siblings().removeClass('active');
			
			var opts = {
					url: "/userOperation/findUserActive",
					data: {
						userId:dataId
					},
					tplId: "#infoDetailUserActiveTpl",
					outputId: $contentWrapper.find('.item-report')
				};
			var datatype = $(this).attr('data-type');
	
			switch (datatype){
				case 'userActiveRecord':
					break;
				case 'sysRecall':
					opts.url = "/userOperation/findRecallRecord",
					opts.data={
						recallCreateType: "sys",
						userId: dataId
					},
					opts.tplId = "#recallRecordTpl",
					opts.outputId = $contentWrapper.find('.item-contact');
					break;
				case 'personRecall':
					opts.url = "/userOperation/findRecallRecord",
					opts.data={
						recallCreateType: "person",
						userId: dataId
					},
					opts.tplId = "#recallRecordTpl",
					opts.outputId = $contentWrapper.find('.item-chance');
					break;
				default:
					break;
			}
			
	
			//console.log(opts);
			var tabJqx = baseEvn.ajaxFun(opts);
	
			tabJqx.done(function(result){
				// console.log(result);
				if (result.type === "success") {
					renderEvn.renderTpl({
						tplId: opts.tplId,
						outputId: opts.outputId,
						data: result
					});
				}
			});
		});
	};
	// 初始化
	teamEvn.init = function(){
		// 表格初始化
		var $grid = gridEvn.init(moduleConfig.activeModule.gridOpts);
		//搜索事件
		this.searchEvent();
		//页面跳转GO
		this.jumpPageEvent();
		//导出
		this.exportEvent();
		//重新计算
		this.countEvent();
		
		this.showEvent();
		
		this.tablBatchCtrl();
		
		this.saveOpt();
		
		this.tabDetail();
	};


	$(function(){
		teamEvn.init();
	});

})(jQuery);