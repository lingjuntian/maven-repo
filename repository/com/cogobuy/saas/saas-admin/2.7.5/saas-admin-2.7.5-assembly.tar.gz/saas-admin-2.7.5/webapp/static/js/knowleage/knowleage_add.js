(function($){
	//基础url
	var _baseUrl = 'http://testres.cogobuy.com/';
	//4、定义jquery对象
	var knowleageEnv = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$body = $('body');
	//文件上传
	knowleageEnv.fileUpload = function(){
		//附件上传
		$wrapper.on('change', '#uploadFile', function() {
			if ($.trim($(this).val()) == '') {
				return false;
			}

			fileFormUpload($(this), knowleageEnv.uploadCallback);
		});
	};
	//上传照片成功回调
	knowleageEnv.uploadCallback = function(result){
		console.log(result);
		if (typeof result != "undefined") {
			if (result.type == "success") {

				var fileName = result.args.fileName,
					fileRealName = result.args.fileRealName,
					fileSize = result.args.fileSize,
					returnImagePath = result.args.returnImagePath;

				
				// $("input[name=file]").val(fileName);
				$("input[name=fileName]").val(fileName);
				$("input[name=fileRealName]").val(fileRealName);
				$("input[name=fileSize]").val(fileSize);
				$("input[name=knowleageThumb]").val(returnImagePath);

				//上传照片成功之后，将文件名写在下面
				$('.js-img-name').text(fileName);
				//将图片的路径填写在img标签的src上，显示出来
				$('.js-img').attr('src',_baseUrl+returnImagePath);
				
			} else {
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: result.content
				});
			}
		}
	};
	//标签的输入搜索相关标签，自己点击添加标签也可添加
	knowleageEnv.tagsOption = function(){
		//输入框搜索函数
		function tagsSearch(){
			var key = $('.js_tags_input').val();
			$('.js_auto_filter').show();
			var jajax = baseEvn.ajaxFun({
				url:'/knowleage/find_tag?tagRefName='+key
			});

			jajax.done(function(data){
				if(typeof data != 'undefined'){
					if($.trim(data.type) == 'success'){
						var list = data.args;
						console.log(list.length)
						var str = "";
						var  _currTags = $('.js_curr_tags').find('label');
						if(list.length > 0){
							for(var i = 0;i <list.length; i++){
								var _number = 0;
								if(_currTags.length > 0){
									for(var j = 0 ; j < _currTags.length; j++){
										if($.trim($(_currTags[j]).attr('data-id')) == list[i].tagId){
											_number++;
										}
									}
								}
								
								if(_number > 0){
									str += '<li class="js_filter_li" data-id="'+list[i].tagId+'" data-name="'+list[i].tagName+'">'+
									'<input  type="checkbox" value="'+list[i].tagId+'" checked><span>'+list[i].tagName+'</span></li>';
							
								}else{
									str += '<li class="js_filter_li" data-id="'+list[i].tagId+'" data-name="'+list[i].tagName+'">'+
									'<input  type="checkbox" value="'+list[i].tagId+'" ><span>'+list[i].tagName+'</span></li>';
								}
								
							}
							$('.js_auto_filter').empty().append(str).show();
						}else{
							$('.js_auto_filter').empty().hide();
						}
					}else{
						popEvn.hint({
							tipsClass: 'pop-tips-warn',
							txt: data.content
						});
					}
				}

			}).fail(function(data){
				popEvn.hint({
					tipsClass: 'pop-tips-warn',
					txt: '请求失败'
				});
			});
		}
		$wrapper.on('click',function(){
			$('.js_auto_filter').empty().hide();
		});
		//输入框中输入值进行搜索
		$('.js_tags_input').bind('input propertychange',function(){
			tagsSearch();
		});
		$('.js_tags_input').on('click',function(){
			tagsSearch();
		});
		//增加标签
		$wrapper.on('click','.js_add_tags',function(){
			var value = $('.js_tags_input').val();
			if($.trim(value) == ""){
				return false;
			}
			if($.trim(value).length > 12 || $.trim(value).length < 2){
				$(this).parents('.in-box').find('.form-tips').text('').text('长度在2-12之间');
				return false;
			}else{
				$(this).parents('.in-box').find('.form-tips').text('');
			}
			var $labelArr = $('.js_curr_tags').children('label');
			//统计在当前标签中是否存在该值
			var _number = 0;
			$('.js_curr_tags').children('label').each(function(){
				if($.trim($(this).attr('data-name')) == $.trim(value)){
					_number ++;
				}
			});
			if(_number > 0){
				return false;
			}
			var _childLength = $('.js_curr_tags').children('label').length;
			var str = "<label class='js_tag' data-id='' data-name='"+value+"'>"+
							"<input class='js_hidden_id'        type='hidden'   name='knowleageTag["+_childLength+"].tagId' 	 value='' >"+
							"<input class='js_checkbox_name'    type='checkbox' name='knowleageTag["+_childLength+"].tagName'  value='"+value+"'  checked='checked'/><span>"+value+"</span>"+
							"<input class='js_hidden_isDelete'  type='hidden' 	name='knowleageTag["+_childLength+"].isDelete' value='0' /></label>";
			$('.js_curr_tags').append(str);
			$('.js_auto_filter').hide();

		});
		//列表中选中某一项
		$wrapper.on('click','.js_filter_li',function(){
			var $checkbox = $(this).find('input[type=checkbox]');

			if($checkbox.attr("checked")){
				$('.js_auto_filter').hide();
				return false;
			}else{
				$checkbox.attr('checked',true);
				var _id=$(this).attr('data-id'),
					_name = $(this).attr('data-name'),
					_value = $checkbox.val();
				console.log(_name);
				var _number = 0;
				$('.js_curr_tags').find('label').each(function(){
					if($(this).attr('data-id') == _id){
						++_number;
					}
				});
				if(_number > 0){
					return false;
				}
				var _childLength = $('.js_curr_tags').children('label').length;
				var str = "<label class='js_tag' data-id="+_id+" data-name='"+_name+"'>"+
							"<input class='js_hidden_id'       type='hidden'   name='knowleageTag["+_childLength+"].tagId' 	value="+_id+">"+
							"<input class='js_checkbox_name'   type='checkbox' name='knowleageTag["+_childLength+"].tagName' 	value='"+_name+"' checked/><span>"+_name+"</span>"+
							"<input class='js_hidden_isDelete' type='hidden' 	name='knowleageTag["+_childLength+"].isDelete' value='0' /></label>";
				$('.js_curr_tags').append(str);
				$('.js_auto_filter').hide();
			}
		});
		//已经选中的标签绑定点击事件
		$wrapper.on('click','.js_tag',function(){
			var $checkbox = $(this).find('input[type=checkbox]');
			//获取input的name属性值来获取里面的index
			var _name = $checkbox.attr('name');
			var _nameArr =_name.split('[');
			var _index = _nameArr[1].charAt(0);
			var _hiddenNameStr = "<input class='js_hidden_name'  value='"+$checkbox.val()+"'   type='hidden'   name='knowleageTag["+_index+"].tagName'>";
			if($checkbox.attr('checked')){
				$checkbox.removeAttr('checked');
				$(this).find('.js_hidden_isDelete').val('1');
				$(this).append($(_hiddenNameStr));
			}else{
				$checkbox.attr('checked',true);
				$(this).find('.js_hidden_isDelete').val('0');
				$(this).find('.js_hidden_name').remove();
			}
			
		});
	};
	//选择分类
	knowleageEnv.selClassify = function(){
		$wrapper.on('change','.js_in_sel',function(i){
			var _index = parseInt($(this).val());
			var _rel = $(this).children('option').eq(_index).attr('data-rel');
			$('input[name=categoryName]').val(_rel);
		});
	};
	// 保存（确定）
	knowleageEnv.saveOpt = function(){
		$wrapper.on('click','.pop-btn.js-pop-save',function(){
			var $item=$(this);
			var type = $(this).attr('data-type'),
				ajaxUrl = '';
			var $form = $(this).parents("form:first");
			
			//获取html内容，返回: <p>hello</p>
			var html = knowleageEditor.getContent();
			$('#contentTextarea').val(html);

			var _validateNum = 0;
			//表单验证
			$form.find('.js_require').each(function(){
				var $this = $(this);
				formValidate.validate({
					obj:$(this),
					callback:function(opts){
						if(!opts.isTrue){
							_validateNum++;
							$this.parents('.in-box').find('.form-tips').text('').text(opts.tips);
						}else{
							$this.parents('.in-box').find('.form-tips').text('');
						}
					}
				});
				
			});
			//验证标签
			var $tagsList = $('.js_curr_tags');
			if($tagsList.find('label').length <= 0){
				$tagsList.parents('.in-box').find('.form-tips').text('').text('标签不能为空');
				_validateNum ++;
			}else{
				var _checkNum = $tagsList.children('label').length;
				$tagsList.children('label').each(function(){
					var $checkbox = $(this).find('input[type=checkbox]');
					if(!$checkbox.attr('checked')){
						_checkNum--;
					}
				});
				if(_checkNum <= 0){//没有选中的
					$tagsList.parents('.in-box').find('.form-tips').text('').text('标签不能为空');
					_validateNum++;
				}else if(_checkNum > 9){
					$tagsList.parents('.in-box').find('.form-tips').text('').text('标签最多可选9个');
					_validateNum++;
				}else{
					$tagsList.parents('.in-box').find('.form-tips').text('');
				}

			}
			if(_validateNum > 0){
				return false;
			}
			//提交表单
			if(!type){
				return false;
			}
			var _knowleageId = $('input[name=knowleageId]').val();
			if($.trim(_knowleageId) == ""){
				//添加
				ajaxUrl = '/knowleage/add_submit';
			}else{
				//编辑
				ajaxUrl = '/knowleage/edit_submit';
				
			}
			if(ajaxUrl){
				var formData = $(this).parents("form:first").serialize();
				//表单提交
				if(!formData){
					return false;
				}
				var formJqx = baseEvn.ajaxFun({
					url:ajaxUrl,
					data:formData
				});

				formJqx.done(function(result){
					console.log(result);
					if(result.type=="success"){
						$item.parents('.pop-main').remove();

						popEvn.hint({
							txt:'操作成功'
						});
						setTimeout(function(){
							if($.trim(_knowleageId) == ""){
								//添加成功
								if(confirm('是否要继续添加？')){
									window.location.reload(); 
								}else{//跳转到编辑页面
									window.location.href = '/knowleage/edit?knowleageId='+result.args;
								}
							}else{
								//编辑成功
								window.location.reload(); 
							}
						},1000);
						
					}else if(result.type=="error"){
						popEvn.hint({
							tipsClass: 'pop-tips-warn',
							txt: result.content
						});
					}
				});
			}
		});	
	};
	//预览
	knowleageEnv.review = function(){
		$wrapper.on('click','.pop-btn.js-pop-review',function(){
			var _knowleageId = $('input[name=knowleageId]').val();
				if($.trim(_knowleageId)==""){
					popEvn.hint({
						txt:'请先保存再预览'
					});
				}else{
					window.open('/knowleage/review/'+_knowleageId);
				}
		});
		
	};
	//取消
	knowleageEnv.closeOpt = function(){
		$wrapper.on('click','.pop-btn.js-pop-close',function(){
			if(confirm('是否要取消本次操作?')){
				window.location.reload(); 
			}else{

			}
		});
	};
	// 初始化
	knowleageEnv.init = function(){
		
		//弹出框保存
		this.saveOpt();
		//文件上传
		this.fileUpload();
		//标签选择和添加
		this.tagsOption();
		//选择分类
		this.selClassify();
		//预览
		this.review();
		//取消
		this.closeOpt();
	};


	$(function(){
		knowleageEnv.init();
	});

})(jQuery);