(function($){
	'use strict';
	
	$(function(){
		headerEvn.init();
	});

	var headerEvn = {
		init: function() {
			this.bindEvent();
		},
		
		bindEvent: function() {
			var $body = $("body");
			var that = this;
			// 修改密码弹窗
			$("header").on("click",".js-pull-box .js-btn-pop",function(){
				$("#pop").fadeIn().find('.pop-edit-passwd-set').slideDown().siblings().hide();
				$("#pop").find('.pop-edit-passwd-set input').val('');
			});
			
			// 修改密码
			$body.on('click','.pop-edit-passwd-set .btn-confirm',function(){
				var vo = baseEvn.validateFun($(this));

				if (vo.errTotal > 0) {
					for (var i = 0; i < vo.tipsArr.length; i++) {
						// console.log(vo.tipsArr[i].errTxt);
					};
					return false;
				}

				if (!that.isLock("modifyPassword")) {
					that.modifyPassword();
				}
			});
		},
		
		/**
		 * 修改密码
		 */
		modifyPassword: function() {
			
			var that = this;
			var $table = $("#pop .pop-edit-passwd-set");

			// 验证
			$table.find('input').each(function(){
				fValidate.init({
	            	inObj: $(this)
		        }, function(opts){

		        	if(!opts.isTrue){
		        		errTotal++;
		        	}

		        	if(opts.inObj.attr('name') == 'checkPassword' && opts.inObj.val() != $table.find('input[name="newPassword"]').val()){
		        		opts.Tips = '两次输入的密码不一致';
		        	}

		            opts.inObj.parent().find('.tips').html(opts.Tips);
		        });
			});


			this.lock("modifyPassword");
			$.ajax({
			    type: 'post',
			    url: '/setting/modifyCurUserPassword' ,
			    dataType: 'json',
			    data: {	
					oldPassword: $table.find('input[name="oldPassword"]').val().trim(),
					newPassword: $table.find('input[name="newPassword"]').val().trim()
				}, 
			    success: function(message){
			    	that.unlock();
			    	if (message.type === "success") {
			    		$('.pop').slideUp('1000',function(){
			    			$('.pop-box').slideUp('1000');
			    		});
			    		popEvn.confirmFun({
			    			contentTxt: '修改密码成功'
			    		});
			    	} else {
			    		that.unlock();
			    		popEvn.confirmFun({
			    			contentTxt: message.content
			    		});
			    	}			    	
			    },
			    error: function(data) {
			    	that.unlock();
			    	popEvn.confirmFun({
		    			contentTxt: '修改密码失败'
		    		});
			    }

			});
		},
		
		/**
		 * 调用ajax方法前，添加锁
		 */
		lock: function(methodName) {
			this.methodName = methodName;
			this.lockFlag = true;
		},
		
		/**
		 * 去掉锁
		 */
		unlock: function() {
			this.lockFlag = false;
		},
		
		/**
		 * 是否上锁。
		 */
		isLock: function(methodName) {
			if (this.methodName === methodName && this.lockFlag) {
				return true;
			} else {
				return false;
			}
		}
	};


}(jQuery));
