// 当前页面数据集合，避免多次加载重复数据
var pageDataSet = {
	// 表格数据
	// 项目详情
	// 模板名称
	tplName: {
		// 详情-拜访报告
		infoDetailReport: '#infoDetailReportTpl',
		// 详情-资料
		infoDetailCustomer: '#infoDetailCustomerTpl',
		// 详情-联系人
		infoDetailContact: '#infoDetailContactTpl',
		// 详情-商机
		infoDetailChance: '#infoDetailChanceTpl',
		// 详情-售后
		infoDetailServer: '#infoDetailServerTpl',
		// 详情-任务
		infoDetailTask: '#infoDetailTaskTpl'
	}
};

// 参数配置
var moduleConfig = {
	// 当前栏目
	activeModule: {}
};


// 公共部分
(function($){

	var baseEvn = {},
		$wrapper = $('#wrapper'),
		$pageLeft = $('#pageLeft'),
		$contentWrapper = $('#contentWrapper'),
		$pop = $('#pop'),
		$body = $('body');

	//是否支持placeholder
	baseEvn.isPlaceholder = function(){
		
		if(!('placeholder' in document.createElement('input'))){
			var placeholder = '';


			$('input').each(function(){
				placeholder = $(this).attr('placeholder') || '';

				if(placeholder == ''){
					return;
				}

				if(true){
					var self = $(this),
						selfW = $(this).width();

		            self.wrap($('<div class="password-box"></div>').css({
		            	position:'relative', 
		            	zoom:'1', 
		            	border:'0', 
		            	background:'none', 
		            	padding:'0', 
		            	margin:'0',
		            	cursor: 'text',
		            	width:selfW
		            }));

		            var pos = self.position(),
		            	h = self.outerHeight(true) - 2,
		            	paddingleft = self.css('padding-left');

		            var holder = $('<span></span>').text(placeholder).css({
		            	position: 'absolute',
		            	left: paddingleft,
		            	top: pos.top,
		            	right: 3,
		            	height: h,
		            	lineHeight: h + 'px',
		            	whiteSpace: 'nowrap',
		            	fontSize: '12px',
		            	// background: '#fff',
		            	color: '#999'
		            }).addClass('in-placeholder').appendTo(self.parent());

		            if(self.val() != ''){
		            	holder.hide();
		            }

		            self.on('focus', function(e) {
		                holder.hide();
		            }).on('blur', function(e) {
		                if(!self.val()){
		                    holder.show();
		                }
		            });

		            holder.on('click', function(e) {
		                holder.hide();
		                self.focus();
		            });
				}else{

					if($(this).val() == ''){
						$(this).val(placeholder).addClass('in-placeholder');
					}

					// alert($(this).val());
					// alert(placeholder);

					$(this).on('focus', function(){
						// alert($(this).val() == placeholder);
						if($(this).val() == $(this).attr('placeholder')){
							$(this).val('').removeClass('in-placeholder');
						}
					}).on('blur', function(){
						// alert(placeholder);
						if($(this).val() == ''){
							$(this).val($(this).attr('placeholder')).addClass('in-placeholder');
						}
					});

				}

				
			});
		}
	};


	// Ajax请求
	baseEvn.ajaxFun = function(ajaxOpts){
		var opts = $.extend({
			url: '/',
			dataType: 'json',
			method: 'post',
			data: {},
			complete: function(){},
			success: function(){},
			error: function(){}
		}, ajaxOpts);

		var jqxhr = $.ajax(opts);
		

		jqxhr.done(function ( data ) {
			//alert('done');
			if( data == 'LOGIN_TIMEOUT'){
				baseEvn.isLoginTimeout = true;
				window.location.href ='/login';
			}
			// return false;
		}).fail(function ( data ) {
			if( data.responseText == 'LOGIN_TIMEOUT'){
				baseEvn.isLoginTimeout = true;
				window.location.href ='/login';
			}else{
				// popEvn.hint({
				// 	tipsClass: 'pop-tips-warn',
				// 	txt: '请求失败，请稍后重试！'
				// });
			}
				
			// return false;
			//alert('fail');
		}).always(function ( data ) {
			//alert('always');
		});

		return jqxhr;
	};


	// 公共事件
	baseEvn.publicFun = function(){
		// 判断是否点击了详细内容区域
		var clickInfoBox = false;

		// 关闭详情
		$wrapper.on('click',function(){
			if(!clickInfoBox){
				$contentWrapper.find('.content-info').removeClass('active');
			}else{
				clickInfoBox = false;
			}
		});

		// 点击表格名称-显示详情
		$wrapper.on('click','.js-get-info',function(){
			clickInfoBox = true;
			$contentWrapper.find('.content-info').addClass('active');
		}).on('click','.content-info',function(){
			clickInfoBox = true;
		});


		// 头部下拉搜索框
		$('.content-header').on('click','.search-btn',function(){
			var key = $.trim($(this).parent().find('input').val());

			if(key.length > 0){
				window.location.href = '/search?key=' + key;
			}else{
				$(this).parent().find('input').focus();
			}
			
		});

		// 头部-邀请同事
		$wrapper.on('click', '.js-add-staff', function(){
			var Jqx = baseEvn.ajaxFun({
				url: '/setting/findCompanyRole'
			});

			Jqx.done(function(result){
				renderEvn.renderTpl({
					tplId: '#popAddStaffTpl',
					outputId: '#pop',
					data: result.args,
					callback: function() {
						popEvn.open();

						areaCodePublicInit();
					}
				});
			});
		});


		// 多行文本框获取焦点时加高
		$pop.on('focus', '.in-text', function(){
			$(this).addClass('in-text-focus');
		}).on('blur', '.in-text', function(){
			$(this).removeClass('in-text-focus');
		});


		// 添加成员提交按钮
		$pop.on('click', '#popAddStaff .js-pop-save', function(){
			var $form = $(this).parents('form'),
				errNum = 0;


			$form.find('input').each(function(){
				// 验证
			 	if($(this).attr('data-vd')){
			 		
				 	var vdBack = fValidate.init({
						inObj: $(this)
					});

				 	// console.log('验证结果：' + vdBack.isTrue);

				 	if(!vdBack.isTrue){
				 		errNum++;
				 	}
			 	}
			});


			if(errNum > 0){
				return false;
			}

			
			var _mobile = $form.find('input[name="areaCode"]').val() + $form.find('input[name="mobile"]').val();

			$form.find('input[name="mobile"]').val(_mobile);


			var jqx = baseEvn.ajaxFun({
				url: '/setting/addStaffInfo',
				data: $form.serialize()
			});
			
			jqx
				.done(function(result){
					if (result.type === "success") {
						popEvn.close();

						popEvn.hint({
							txt: result.content
						});
						
						// 如果是在成员栏目刷新表格
						if($contentWrapper.hasClass('content-wrapper-staff')){
							var page = $('.toolbar-item.num').find('a.active').text();
							gridEvn.loadData({
								pageNo: page
							});
						}					
					} else {
						popEvn.hint({
							tipsClass: 'pop-tips-warn',
							txt: result.content
						});

					}
				})
				.complete(function(){
					$form.find('input[name="mobile"]').val('');
				});
			
		});


		// 客户查重
		$pop.on('click', '.js-chachong', function(){
			var ccCompanyName = $(this).parents('.in-box').find('input').val();
			$pop.find('.pop-chachong-box').fadeIn().find('input[name="chachongCustomerName"]').val(ccCompanyName);

			findCompanyNameFun(ccCompanyName);
		}).on('click', '.js-chachang-post', function(){
			var ccCompanyName = $(this).parents('.in-box').find('input').val();
			findCompanyNameFun(ccCompanyName);
		}).on('keyup', '.pop-chachong-box input[name="chachongCustomerName"]', function(){
			var ccCompanyName = $(this).val();
			findCompanyNameFun(ccCompanyName);
		});




		// 执行客户查找
		var ccJqx;
		function findCompanyNameFun(key){
			var $chaChong = $pop.find('.pop-chachong-box');

			// 关键词不能为空
			if ($.trim(key) == '') {
				$chaChong.find('.chachong-customer-list tbody').html('<tr class="null-data"><td colspan="3">没有相关的搜索结果</td></tr>');
				return;
			};

			// 停止上一次还未完成的ajax请求
			if(ccJqx){
				ccJqx.abort();
			}

			ccJqx = baseEvn.ajaxFun({
				url: '/customer/findPageByName',
				data: {
					keyword: key
				}
			});
			
			ccJqx.done(function(result){
				var str = '';

				if(result.type == 'success'){
					
					if(result.args.list.length > 0){
						for (var i = 0, len = result.args.list.length; i < len; i++) {
							str += '<tr>';
							str += '<td title="'+ result.args.list[i].customerName +'">'+ result.args.list[i].customerName.substr(0,25) +'</td>';
							str += '<td title="'+ result.args.list[i].createByName +'">'+ result.args.list[i].createByName.substr(0,25) +'</td>';
							str += '<td>'+ result.args.list[i].createTime.split(' ')[0] +'</td>';
							str += '</tr>';
						};
					}else{
						str += '<tr class="null-data"><td colspan="3">没有相关的搜索结果</td></tr>';
					}

				}else{
					str += '<tr class="null-data"><td colspan="3">没有相关的搜索结果</td></tr>';
				}


				$chaChong.find('.chachong-customer-list tbody').html(str);
			}).fail(function(){
				$chaChong.find('.chachong-customer-list tbody').html('<tr class="null-data"><td colspan="3">没有找到相关结果</td></tr>');
			});
		};



		// 头部-意见反馈
		$wrapper.on('click', '.js-feedback', function(){
			renderEvn.renderTpl({
				tplId: '#feedbackTpl',
				outputId: '#pop',
				callback: function() {
					popEvn.open();					
				}
			});
		});

		$pop.on('click', '#feedbackForm .js-pop-save', function(){
			var $form = $(this).parents('form'),
				errNum = 0;

			$form.find('input,textarea').each(function(){
				// 验证
			 	if($(this).attr('data-vd')){
			 		
				 	var vdBack = fValidate.init({
						inObj: $(this)
					});

				 	// console.log('验证结果：' + vdBack.isTrue);

				 	if(!vdBack.isTrue){
				 		errNum++;
				 	}
			 	}
			});


			if(errNum > 0){
				return false;
			}

			var jqx = baseEvn.ajaxFun({
				url: '/advise/add',
				data: $form.serialize()
			});
			
			jqx.done(function(result){
				if (result.type === "success") {
					popEvn.close(true);

					popEvn.hint({
						txt: result.content
					});
				} else {
					popEvn.hint({
						tipsClass: 'pop-tips-warn',
						txt: result.content
					});
				}
			});
			
		});


		// screen下拉框
		baseEvn.screenFun();

		// 日期选择初始化
		$body.on('focus','.laydate', function(){
			if(typeof(laydate) != 'undefined'){
				laydate();
			}
		});


		var $ewmTxt = $('.content-header .ewm-txt'),
			ewmMoveTxt = $ewmTxt.find('span').eq(0).text();

		// 头部二维码-文字向上滚动
		function headEwmTxt(){
			ewmMoveTxt = $ewmTxt.find('span').eq(0).text();

			// console.log(ewmMoveTxt);

			$ewmTxt.find('span').eq(0).delay(2000).animate({
				marginTop: '-42px'
			},800 , function(){
				$(this).remove();
				$ewmTxt.append('<span>'+ ewmMoveTxt +'</span>');
				headEwmTxt();
			});
		};

		headEwmTxt();


		// 判断是否是体验用户
		isExperienceUser();

		// 客户批量导入
		infoImport();
	};



	// 判断是否是体验用户
	function isExperienceUser(){
		var isPc = userAgentType();

		if(typeof(_ExperienceUser) != 'undefined' && _ExperienceUser == 'Yes'){

			// 判断是否填写过邮箱
			var jqxhr = baseEvn.ajaxFun({
				url : '/checkExperienceUserEmail'
			});
			
			jqxhr.done(function(result){
				if (result.type == "success") {
					// 已经提交了
				}else{
					// 未提交
					experienceUserEmailIn(isPc);
				}
			});
		}


		// 填写邮箱并提交，不可关闭
		function experienceUserEmailIn(isPc){
			// pc端显示二维码， 移动端显示邮箱
			renderEvn.renderTpl({
				tplId: isPc ? '#testEwmTpl' : '#testEmailTpl',
				outputId: '#pop',
				callback: function() {
					popEvn.open();					
				}
			});
			

			$pop.on('click', '.js-test-email', function(){
				var $form = $(this).parents('form');

				var email = $form.find("input[name='email']").val(),
					errNum = 0;


				if($form.find("input[name='email']").attr('data-vd')){
			 		
				 	var vdBack = fValidate.init({
						inObj: $form.find("input[name='email']")
					});

				 	if(!vdBack.isTrue){
				 		errNum++;
				 	}
			 	}


				if(errNum > 0){
					return false;
				}
				
				
				var jqxhr = baseEvn.ajaxFun({
					url : '/addExperienceUserEmail',
					data : $form.serialize()
				});
				
				jqxhr.done(function(result){
					if (result.type == "success") {
						popEvn.close(true);

						if(!isPc){
							popEvn.hint({
								txt: result.content
							});
						}					
					} else {
						if(!isPc){
							popEvn.hint({
								tipsClass: 'pop-tips-warn',
								txt: result.content
							});
						}
					}
				});			
			});
		};

	};



	// 判断浏览器
	function userAgentType(){
		// 判断浏览器设备
		var userAgent = navigator.userAgent;
        var documentElement = document.documentElement;
        var isPc = true;

        if ( userAgent.match( /micromessenger\/5/gi ) ) {
            documentElement.className += " mobile wx_mobile wx_mobile_5";
            isPc = false;
        } else if ( userAgent.match( /micromessenger/gi ) ) {
            documentElement.className += " mobile wx_mobile";
            isPc = false;
        } else if ( userAgent.match( /ucbrowser/gi ) ) {
            documentElement.className += " mobile uc_mobile";
            isPc = false;
        } else if ( /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test( userAgent.toLowerCase() ) ) {
            documentElement.className += " mobile";
            isPc = false;
        } else if ( userAgent.toLowerCase().match( /msie/gi ) && ( parseFloat( userAgent.toLowerCase().match( /msie ([0-9]{1,}[\.0-9]{0,})/i )[1] || 999 ) < 9 ) ) {
            documentElement.className += " pc pc-ie pc-ie8";
        } else if ( userAgent.toLowerCase().match( /msie/gi ) || navigator.msPointerEnabled || navigator.pointerEnabled ) {
             documentElement.className += " pc pc-ie";
        } else {
            documentElement.className += " pc";
        }

        return isPc;
	};	



	// 客户批量导入
	function infoImport(){
		var isUploading = false,
			isUploaded = false,
			uploadData = {};

		$body.on('click', '.content-header .import', function(){
			renderEvn.renderTpl({
				tplId: '#importFileTpl',
				outputId: '#pop',
				callback: function() {
					// $('#pop').addClass('pop-file');
					popEvn.open();

					$('#importFile').on('change', function(){
						if(isUploading){
							alert('数据模板正在上传，请稍后或取消');
							return false;
						}
						isUploading = true;

						ajaxUpload({
							id: 'importFile',
							frameName: 'filesIframe',
							url: '/customer/importExcel',
							format: ['xls'],
							callBack: function(data){
								isUploaded = true;
								isUploading = false;
								// console.log(data);
								// alert(data);
								// 转换json
								uploadData = eval('(' + data + ')');
							}
						});
					});
				}
			});
		});


		// 关闭导入弹出框


		// 停止上传并取消文件
		$body.on('click', '.import-file .file-close,.js-pop-again', function(){
			isUploading = false;
			isUploaded = false;

			var $this = $(this),
				$form = $this.parents('form'),
				$span = $form.find('.import-step span'),
				$item = $form.find('.import-item');

			$form.find('#importFile').val('');
			$form.find('.file-item').remove();

			$span.eq(0).addClass('active').siblings().removeClass('active');
			$item.eq(0).addClass('active').siblings().removeClass('active');

			$form.find('.pop-btn-again').hide();
			$form.find('.pop-btn-import').removeClass('importing').css('display','inline-block');

			popEvn.setPopcontentHeight();
		});

		// 开始导入
		$body.on('click', '.js-pop-import', function(){
			if(isUploading){
				alert('数据模板正在上传，请稍后或取消');
				return false;
			}

			if(!isUploaded){
				alert('还未上传文件，请先上传数据模板');
				return false;
			}

			var $this = $(this),
				$form = $this.parents('form'),
				$span = $form.find('.import-step span'),
				$item = $form.find('.import-item');

			if($this.hasClass('importing')){
				return false;
			}
			$this.addClass('importing').html('导入中...');

			$span.eq(1).addClass('active');
			$item.eq(1).addClass('active').siblings().removeClass('active');

			popEvn.setPopcontentHeight();

			// 模拟导入进度
			uploadProcess(0, 99, function(n){
				// 导入中
				$item.eq(1).find('.import-progress-box span').text(n + '%').css('width', n + '%');
			},function(){
				// 导入完成
				$span.eq(2).addClass('active');
				$item.eq(2).addClass('active').siblings().removeClass('active');

				$this.hide().html('开始导入').parent().find('.pop-btn-again').css('display','inline-block');

				// console.log(uploadData);
				// uploadData
				// {"type":"success","content":"success","url":null,"args":{"totalCount":1,"errorCount":1,"successCount":0}} 
				$item.eq(2).find('.file-import-progress p').html('导入完毕，共导入'+ uploadData.args.totalCount +'条信息，'+ uploadData.args.successCount +'条导入成功，'+ uploadData.args.errorCount +'条导入失败。');

				popEvn.setPopcontentHeight();
			});
		});

		// 上传文件
		function ajaxUpload(opt){
			/*
			    参数说明:
			    opt.id : 页面里file控件的ID;
			    opt.frameName : iframe的name值;
			    opt.url : 文件要提交到的地址;
			    opt.format : 文件格式，以数组的形式传递，如['jpg','png','gif','bmp'];
			    opt.callBack : 上传成功后回调;
			*/
			var iName = opt.frameName;
			var iframe,form,file,fileParent;
			//创建iframe和form表单
			iframe = $('<iframe style="display:none; width: 0; height: 0;" name="'+iName+'" />');

			//通过id获取flie控件
			file = $('#'+opt.id);

			form = file.parents('form').attr({
				'method': 'post',
				'target': iName,
				'action': opt.url,
				'name': 'form_' + iName,
				'enctype': 'multipart/form-data'
			});

			//插入body
			$('body').append(iframe);

			//取得所选文件的扩展名
			var fileFormat=/\.[a-zA-Z]+$/.exec(file.val())[0].substring(1);

			if(opt.format.join('-').indexOf(fileFormat)!=-1){
				// 获取文件名及文件大小，显示上传进度
				ajaxUploadFindSize(file);

				//格式通过验证后提交表单;
			    form.submit();
			}else{
			    // file.appendTo(fileParent);
			    iframe.remove();
			    // form.remove();
			    alert('文件格式错误，请重新选择！');
			};

			//文件提交完后
			iframe.load(function(){
			    var data = $(this).contents().find('body').html();        
			    // file.appendTo(fileParent);
			    iframe.remove();
			    // form.remove();
			    opt.callBack(data);
			});
		};

		// 获取文件名及文件大小，并显示
		function ajaxUploadFindSize(inObj){
			var fileInput = inObj[0],
				ua = window.navigator.userAgent,
				fileInfo = {
					name: inObj.val(),
					size: 0
				};

			if (ua.indexOf('MSIE') >= 1){
				
				var nameArr = fileInfo.name.replace(/(\\+)/g,'#').split('#');
				fileInfo.name = nameArr[nameArr.length - 1];

				fileInput.dynsrc = inObj.val();
				fileInfo.size = fileInput.fileSize || 0;
			}else{
				fileInfo.size = fileInput.files[0].size;
				fileInfo.name = fileInput.files[0].name;
			}

			fileInfo.size = (fileInfo.size > 0) ? (' - ' + fileInfo.size / 1024 + 'kb') : '';

			// alert(fileInfo.size);
			// alert(fileInfo.name);

			// 生成文件提示
			var htmlStr = '';

			htmlStr += '<div class="file-item">';
	        htmlStr += '    <div class="file-name">'+ fileInfo.name + fileInfo.size +'</div>';
	        htmlStr += '    <div class="file-progress"><span style="width:5%;"></span></div>';
	        htmlStr += '    <a href="###" class="file-close">X</a>';
	        htmlStr += '</div>';

	        inObj.parents('form').find('.import-file').append(htmlStr);



	        // 模拟上传进度
			uploadProcess(0, 95, function(n){
				// 上传中
				inObj.parents('form').find('.import-file .file-progress span').css('width', n + '%');

				if(!isUploading){
					inObj.parents('form').find('.import-file .file-progress span').css('width', '100%');
					return true;
				}
			});
		};

		// 进度模拟
		function uploadProcess(n, e, processback, callback){
			++n;
			if(n < e){
				if(!processback(n)){
					setTimeout(function(){
						uploadProcess(n, e, processback, callback);
					},30);
				}
			}else{
				if(typeof(callback) != 'undefined'){
					callback();
				}
			}
		};
	};



	// 详情页 - 复选框的勾选(弹窗和页面共用)
	baseEvn.checkboxChange = function(){
		$body.on('click','.list-title input',function(){
			$(this).closest('li').addClass('active').find('input').prop('checked','checked');
		});

		$body.on('click','.list-title .js-icon-checked',function(){
			$(this).closest('li').removeClass('active').find('input').prop('checked','');
		});
	};


	// screen下拉框
	baseEvn.screenFun = function(){
		// screen下拉框
		$contentWrapper.on('click','.js-screen .screen-title',function(){
			$(this).prev('.menu-box').toggleClass('active');
		});

		// 二级菜单切换
		$contentWrapper.on('click','.js-screen .menu-1 li',function(){
			var Idx = $(this).index();

			$(this).addClass('active').siblings().removeClass();
			$(this).closest('.js-screen').find('.menu-2 .menu-2-box').eq(Idx).addClass('active').siblings().removeClass('active');
		});

		// 点击二级菜单后收回
		$contentWrapper.on('click','.js-screen .menu-2-box li',function(){
			$(this).closest('.menu-box').removeClass('active');
		});
	};


	// 初始化
	baseEvn.init = function(){
		baseEvn.publicFun();

		baseEvn.isPlaceholder();

		// 表格宽高改变定时器
		var gridWHchange = null;

		// 导航栏伸缩
		$pageLeft.on('click','.js-toggle-btn',function(){
			$wrapper.toggleClass('wrapper-left-hide');
			clearTimeout(gridWHchange);
			gridWHchange = setTimeout(gridEvn.setWidthHeight,300);
			
			//存储cookie
			if($wrapper.hasClass("wrapper-left-hide")){
				$.cookie("left-nav-toggle", "hide", {expires: 7});
			}else{
				$.cookie("left-nav-toggle", null);
			}
		});

		// 浏览器窗口改变
		$(window).on('resize', function(){
			clearTimeout(gridWHchange);
			gridWHchange = setTimeout(gridEvn.setWidthHeight,300);
		});
	};


	$(function(){
		baseEvn.init();
	});


	window.baseEvn = baseEvn;

}(jQuery));



// 模版渲染
(function($){
	var renderEvn = {};

	// 模版渲染
	renderEvn.renderTpl = function(opts){
		var tplOpts = {
			// 选择器
			tplId: '',
			// 选择器
			outputId: '',
			data: {},
			callback: function(){},		

			insetType: 'html'
		},tplObj,outputObj;

		tplOpts = $.extend(tplOpts, opts);

		tplObj = $(tplOpts.tplId);
		outputObj = $(tplOpts.outputId);

		// console.log(tplOpts);

		if(tplOpts.tplId != '' && tplObj.length > 0){
			if(tplOpts.data.args){
				tplOpts.data = tplOpts.data.args;
			}

			for (var k in tplOpts.data){
				// console.log(tplOpts.data[k].length);
				tplOpts.data[k] = tplOpts.data[k] ? tplOpts.data[k] : '';
				for (var j in tplOpts.data[k]){
				// console.log(tplOpts.data[k].length);
				tplOpts.data[k][j] = tplOpts.data[k][j] ? tplOpts.data[k][j] : '';
			};
			};

			// console.log(tplOpts);


			laytpl(tplObj.html()).render(tplOpts.data, function(html){
				//参与成员（#infoSlideStaffTpl） 要显示模板
				if(tplOpts.data.length <= 0 && tplOpts.tplId !='#infoSlideStaffTpl'){
					// 右侧栏 - 任务提醒
					if (tplOpts.tplId == '#infoSlideTaskTpl') {
						outputObj.html('<p class="ctrl-title">任务提醒</p><div class="box-list"><p class="data-null">暂无数据</p></div>');
					}else {
						outputObj.html('<p class="data-null">暂无数据</p>');
					}
				}else if(tplOpts.insetType == 'append'){
					outputObj.append(html);
				}else if(tplOpts.insetType == 'prepend'){
					outputObj.prepend(html);
				}else if(tplOpts.insetType == 'after'){
					outputObj.after(html);
				}else if(tplOpts.insetType == 'before'){
					outputObj.before(html);
				}else{
					outputObj.html(html);
				}
			    
			    if(tplOpts.callback){
			    	tplOpts.callback(outputObj);
			    }
			});
		}		
	};

	window.renderEvn = renderEvn;
}(jQuery));



// 弹出框处理
(function($){
	var popEvn = {
		hintTime: null
	},
		$pop = $('#pop'),
		$popTips = $('#popTips');

	// 弹出框高度适配
	popEvn.setPopcontentHeight = function(){

		setTimeout(function(){
			var mainHeight = $pop.find('.pop-main').height(),
				winHeight = $(window).height();

			mainHeight = (mainHeight > winHeight) ? winHeight : mainHeight;

			// console.log(mainHeight, winHeight);

			if(mainHeight >= winHeight){
				mainHeight = winHeight;

				var maxH = mainHeight - 175;

				// $pop.find('.pop-content').height(maxH);
				// console.log(mainHeight, maxH);
				$pop.find('.pop-content').css('maxHeight',maxH);
			}

			$pop.find('.pop-main').animate({
				'marginTop': -(mainHeight/2)
			});

			$pop.delay(300).animate({
				'opacity': 1
			});

		}, 150);
	};

	// 轻提示
	popEvn.hint = function(opts){
		var $popTips = $('#popTips'),
			htmlArr = [];

		clearTimeout(popEvn.hintTime);

		var defaults = {
			tipsClass: '',
			tipsActiveClass: 'pop-tips-active',
			txt: '',
			showTime: 3000
		};

		defaults = $.extend(defaults,opts);

		htmlArr.push('<div class="tips-txt">');
		htmlArr.push('<i></i>');
		htmlArr.push('<p>'+ defaults.txt +'</p>');
		htmlArr.push('</div>');
		htmlArr.push('<a href="javascript:void(0);" class="tips-close js-tips-close">关闭</a>');

		$popTips.attr('class', 'pop-tips '+ defaults.tipsClass).html(htmlArr.join('')).addClass(defaults.tipsActiveClass);

		popEvn.hintTime = setTimeout(function(){
			$popTips.removeClass(defaults.tipsActiveClass);
		},defaults.showTime);
	};

	// 初始化
	popEvn.init = function(opts){
		var defaultOpts = {
			title: '温馨提示',
			tplname: '',
			tpldata: {}
		};

		//popEvn.loadTpl();
	};
	//打开弹出框
	popEvn.open = function(callback){
		$pop.fadeIn('fast', function(){
			popEvn.setPopcontentHeight();

			if(typeof(callback) == 'function'){
				callback();
			}
		});
	};

	// 关闭弹出框
	popEvn.close = function(itag){
		// if(popEvn.isClose || itag){
			$pop.fadeOut();
		// }
	};


	$(function(){
		popEvn.isClose = true;

		popEvn.init();

		// 关闭弹出框
		$pop.on('click', '.js-pop-close, .pop-clear', popEvn.close);

		$pop.on('click', '.pop-main', function(){
			popEvn.isClose = false;

			setTimeout(function(){
				popEvn.isClose = true;
			},300);
		});

		// $pop.on('click', popEvn.close);


		// 关闭轻提示
		$popTips.on('click', '.js-tips-close', function(){
			$popTips.removeClass('pop-tips-active');
		});

		// 关闭客户查重
		$pop.on('click', '.js-pop-chachong-close', function(){
			$(this).parents('.pop-chachong-box').fadeOut();
		});


		// 弹出框 - 查看更多
		$pop.on('click','.js-more-btn',function(){
			var tags = $(this).attr('data-tags');

			if(tags == 'open'){
				// 收起
				$(this).attr('data-tags', 'close').html('添加更多信息&#62;&#62;');
				$(this).closest('.pop-info').find('.hidden').hide();
			}else{
				// 展开
				$(this).attr('data-tags', 'open').html('收起更多信息&#62;&#62;');
				$(this).closest('.pop-info').find('.hidden').css('display', 'block');
			}
			
			// $(this).hide();

			popEvn.setPopcontentHeight();
		});
	});


	window.popEvn = popEvn;

})(jQuery);




// 表格处理
(function($){

	var gridEvn = {},
		$contentWrapper = $('#contentWrapper');

	// 加载表格数据
	gridEvn.loadData = function(data){
		var gridJqx = baseEvn.ajaxFun({
			url: gridEvn.opts.dataUrl,
			data: data ? data : {}
		});

		gridJqx.done(function ( jqx ) {
			// console.log(jqx);

			// 存入数据集
			pageDataSet.tableData = jqx;

			// 将获取到的数据args.list转移入rows中
			pageDataSet.tableData.rows = pageDataSet.tableData.args.list;
			// pageDataSet.tableData.args.list = null;

			// 渲染表格数据
	        gridEvn.tableObj[0].addJSONData(pageDataSet.tableData);

	        // 页码
	        gridEvn.initPageToolbar(pageDataSet.tableData);
		}).fail(function ( jqx ) {
			
		}).always(function ( jqx ) {
			
		});
	};

	// 设置表格宽高
	gridEvn.setWidthHeight = function(){
		if(gridEvn.tableObj){
			gridEvn.tableObj.setGridHeight($contentWrapper.find('.content-table').height() - 44);
			gridEvn.tableObj.setGridWidth($contentWrapper.find('.content-table').width());
		}		
	};


	// 判断是否选中行
	gridEvn.isSelectRow = function(){
		var len = gridEvn.tableObj.jqGrid('getGridParam', 'selarrrow').length;
		
		if(len > 0){
			$contentWrapper.find('.table-batch-ctrl').show().find('.num').text(len);
		}else{
			$contentWrapper.find('.table-batch-ctrl').fadeOut(300);
		}
	};


	//分页工具条
	gridEvn.initPageToolbar = function(result){
		var tableToolbarTpl = $('#tableToolbarTpl').html();

		laytpl(tableToolbarTpl).render(result, function(html){
			$('#tableToolbar').html(html);
		});
	};

	// 初始化
	gridEvn.init = function(opts){
		var defaultOpts = {
			dataUrl: '',
			loadtext: ' ',
			// 当返回的数据行数为0时显示的信息。只有当属性 viewrecords 设置为ture时起作用
			emptyrecords: '没有数据哦~',

			// 多选框
			multiselect : true,
			multiselectWidth: 80,

			sortable: false,

			// 定义是否要显示总记录数
			// viewrecords: false,
			// 定义了记录信息的位置： left, center, right
			// recordpos: 'left',
			// 显示记录数信息。{0} 为记录数开始，{1}为记录数结束。viewrecords为ture时才能起效，且总记录数大于0时才会显示此信息
			// recordtext: '当前{0}-{1}项，共{2}项',
			// 当执行ajax请求时要干什么
			// disable禁用ajax执行提示
			// enable默认，当执行ajax请求时的提示；
			// block启用Loading提示，但是阻止其他操作
			loadui: 'block',
			// hoverrows: true,
			// width: 900,
			height: 500,
			autowidth: true,
			// height: 300,
			// 默认显示10条
			//rowNum: 10,
			// rowList: [10,20,30],
			// loadonce: true
			jsonReader: {
				root: 'rows',
				// 总页数
				total:'totalCount',
				// 当前页
				page:'pageNo', 
				// 查询出的记录数
				records: 'pageCount',
				repeatitems: false
			}
		};

		gridEvn.opts = $.extend(defaultOpts,opts);

		gridEvn.tableObj = $(gridEvn.opts.tablewrap);

		if(gridEvn.tableObj.length == 0){
			return false;
		}

		// gridEvn.tableObj.setGridParam(gridEvn.opts);
		// gridEvn.tableObj.trigger('reloadGrid');

		// 选中行时触发
		gridEvn.opts.onSelectRow = function(rowid,status){
			if(gridEvn.tableObj.jqGrid('getGridParam', 'selarrrow').length == ($contentWrapper.find('.label-cbox').length - 1)){
				$contentWrapper.find('.label-cbox-all').addClass('label-cbox-checked');
				$contentWrapper.find('#cb_jqGrid').prop('checked', true);
			}else{
				$contentWrapper.find('.label-cbox-all').removeClass('label-cbox-checked');
				$contentWrapper.find('#cb_jqGrid').prop('checked', false);
			}


			gridEvn.isSelectRow();

			// 选中行时回调
			if(gridEvn.opts.onSelectRowCallback){
				gridEvn.opts.onSelectRowCallback(rowid,status);
			}
		};

		// 全选时触发
		gridEvn.opts.onSelectAll = function(aRowids, status){
			// console.log(status);
			if(status){
				$contentWrapper.find('.label-cbox-all').addClass('label-cbox-checked');
			}else{
				$contentWrapper.find('.label-cbox-all').removeClass('label-cbox-checked');
			}

			gridEvn.isSelectRow();

			// 全选时回调
			if(gridEvn.opts.onSelectAllCallback){
				gridEvn.opts.onSelectAllCallback(aRowids, status);
			}
		};

		gridEvn.opts.loadComplete = function(jqx){
			// console.log(jqx);
			
		};

		// 初始化表格完成后触发
		gridEvn.opts.gridComplete = function(){
			gridEvn.setWidthHeight();

			gridEvn.tableObj.parents('.content-table').removeClass('info-loading');
		};

		gridEvn.tableObj.jqGrid(gridEvn.opts);

		gridEvn.loadData();

		return gridEvn.tableObj;
	};	

	$(function(){
		// 点击页码
		$contentWrapper.on("click",'.content-table-toolbar .enable',function(){
			var pageNo = $(this).attr("data-page"),
				data = {
					pageNo: pageNo
				};
			var param = moduleConfig.activeModule.gridOpts.param;
			data = $.extend(data, param);
			gridEvn.loadData(data);
		});


		// 关闭多选选择操作工具栏
		$contentWrapper.on('click', '.table-batch-ctrl .close', function(){
			gridEvn.tableObj.jqGrid('resetSelection');

			$contentWrapper.find('.label-cbox-all').removeClass('label-cbox-checked');

			gridEvn.isSelectRow();
		});

	});

	window.gridEvn = gridEvn;

})(jQuery);




// 表单验证
(function($){
	window.fValidate = {};

	// 判断是否为空
	fValidate.isNull = function(vOpts){
        if(vOpts.inLen == 0 || vOpts.inVal == ''){
            // console.log(vOpts.inObj.attr('data-null') || vOpts.nullErrTips);
            return {
                isTrue: false,
                Tips: vOpts.inObj.attr('data-null') || ( vOpts.nullErrTips + vOpts.inName )
            };
        }else{
            return {
                isTrue: true,
                Tips: ''
            };
        }
    };

	// 判断长度
	fValidate.isMinmax = function(vOpts){
        // console.log(vOpts.inVal.length);
        if(vOpts.inLen < vOpts.min || vOpts.inLen > vOpts.max){
            // 获取该输入框的长度限制
            // var maxLen = vOpts.inObj.attr('data-minmax').split(' ')[1]+'个字';
            
            return {
                isTrue: false,
                Tips: vOpts.inObj.attr('data-minmaxtxt') || (vOpts.inName + vOpts.minmaxErrTips+ vOpts.min + '~' + vOpts.max + '个字')
            };
        }else{
            return {
                isTrue: true,
                Tips: ''
            };
        }
    };
	
	// 正则验证
	fValidate.isRex = function(vOpts){
        // console.log(vOpts.inRex, vOpts.inVal, vOpts.inRex.test(vOpts.inVal));
        if(vOpts.inRex.test(vOpts.inVal)){
            return {
                isTrue: true,
                Tips: ''
            };
        }else{
            
            return {
                isTrue: false,
                Tips: vOpts.inObj.attr('data-rextxt') || (vOpts.inName + vOpts.rexErrTips)
            };            
        }
    };

    // 日期格式化
    fValidate.dateFormat = function(ctime){
		var date = new Date(Date.parse(ctime));
		return (date.getMonth() + 1) + '月' + date.getDay() + '日';
    };

	// 初始化
	fValidate.init = function(Opts, Callback){

        // 默认设置
        var defaults = {
            inObj: null,
            inName: '',
            inVal: null,
            inLen: 0,
            inRex: null,
            inType: null,
            // 判断为空
            isVnull: false,
            nullErrTips: '请输入',
            // 判断长度
            isVminmax: false,
            isVch: false,
            min: 0,
            max: 1,
            minmaxErrTips: '的长度应为',
            // 使用正则
            isVrex: false,
            rexErrTips: '输入的内容格式不正确',

            // 常用正则表达式
            vRex : {
                // 1-9的数字
                integer19 : /^[1-9]\d*$/,
                // 0-9的数字
                integer09 : /^[0-9]\d*$/,
                // 数字
                num : /^\d+(\.\d+)?$/,
                // 邮箱
                email: /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/,
                // （下划线、字母、数字、汉字开头）
                nickname: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/,
                // 密码 6-16位
                password: /^\w{6,20}$/,
                // 电话号码-座机
                tel: /^(\(\d{3,4}\)|\d{3,4}-)?\d{7,8}$/,
                // 手机号码
                phone: /^[1]\d{10}$/,
                // phone: /^(13[0-9]|15[012356789]|17[0-9]|18[0-9]|14[57])[0-9]{8}$/,
                // 特殊字符
                specialChar: /[`~!@#$%^&*-+.<>{}\/'[\]]/im,
                // 网址
                url: /^(https?|ftp|mms):\/\/([A-z0-9_\-]+\.)*[A-z0-9]+\-?[A-z0-9]+\.[A-z]{2,}(\/.*)*\/?/
            }
        };

        var vOpts = $.extend(defaults, Opts);

        // 是否进行验证
        // data-vd是否进行验证
        // data-force是否强行进行验证-用于区别公用的失去焦点验证方法
        vOpts.isVd = Boolean(vOpts.inObj.attr('data-vd')) || Boolean(vOpts.inObj.attr('data-force')) || false;
        if(!vOpts.isVd){return false;};


        // 判断验证的规则
        vOpts.isVnull = Boolean(vOpts.inObj.attr('data-nonull')) || false;
        vOpts.isVminmax = Boolean(vOpts.inObj.attr('data-minmax')) || false;
        vOpts.isVrex = Boolean(vOpts.inObj.attr('data-type') || vOpts.inObj.attr('data-rex')) || false;

        // 输入框的名称
        vOpts.inName = vOpts.inObj.attr('data-name') || vOpts.inObj.attr('name');
        // 输入框的值
        vOpts.inVal = $.trim(vOpts.inObj.val());
        // 输入框值的长度， 默认中文占两字符长度
        if(vOpts.isVch){
            vOpts.inLen = vOpts.inVal.match(/[^ -~]/g) == null ? vOpts.inVal.length : vOpts.inVal.length + vOpts.inVal.match(/[^ -~]/g).length;
        }else{
            vOpts.inLen = vOpts.inVal.length;
        }
        // 输入框的类型
        vOpts.inType = vOpts.inObj.attr('data-type');
        // 输入框的正则
        vOpts.inRex =  new RegExp(vOpts.inObj.attr('data-rex') || vOpts.vRex[vOpts.inType]);

        // 验证返回对象
        var backOpts = {
            isTrue: true,
            inObj: null,
            Tips: ''
        };

        // console.log(backOpts.isTrue && vOpts.isVrex);

        // 判断为空
        if(!vOpts.isVnull){
            backOpts = fValidate.isNull(vOpts);
        }

        // 判断长度
        if(backOpts.isTrue && vOpts.inLen > 0 && vOpts.isVminmax){
            var mimx = vOpts.inObj.attr('data-minmax').split(' ');
            if(mimx.length > 1){
                vOpts.min = ~~(mimx[0] || 0);
                vOpts.max = ~~(mimx[1] || (vOpts.min + 1));
            }

            backOpts = fValidate.isMinmax(vOpts);
        }

        // 使用正则
        if(backOpts.isTrue && vOpts.inLen > 0 && vOpts.isVrex){
            backOpts = fValidate.isRex(vOpts);
        }
        
        backOpts.inObj = vOpts.inObj;

        if(Callback){
            Callback(backOpts);
        }

        if(!backOpts.isTrue){
        	fValidate.inerr(backOpts);
        }else{
        	fValidate.inok(backOpts);
        }


        return backOpts;
	};

	// 错误处理
	fValidate.inerr = function(backOpts){
		var $tips = backOpts.inObj.parent().find('.form-tips');

		backOpts.inObj.addClass('in-err');

		if($tips.length > 0){
			$tips.html(backOpts.Tips);
		}else{
			backOpts.inObj.parent().append('<span class="form-tips">'+ backOpts.Tips +'</span>');
		}
	}

	// 正确处理
	fValidate.inok = function(backOpts){
		backOpts.inObj.removeClass('in-err').parent().find('.form-tips').html('');
	}


	$(function(){
		var $body = $('body');

		$body.on('blur', 'input, textarea', function(){
			if($(this).attr('data-vd')){
				fValidate.init({
					inObj: $(this)
				}, function(backOpts){
					// console.log(backOpts);
				});
			}
		});
	});

})(jQuery);

//表单验证2
(function($){
	var formValidate = {
    // 判断是否为空
    isNull: function(opts){
        if(opts.inLen == 0 || opts.inVal == ''){
            // console.log(opts.obj.attr('data-null') || opts.nullErrtips);
            return {
                isTrue: false,
                tips: opts.obj.attr('data-nullTxt') || ( opts.nullErrtips + opts.inName )
            };
        }else{
            return {
                isTrue: true,
                tips: ''
            };
        }
    },
    // 判断长度
    isMinmax: function(opts){
        // console.log(opts.inVal.length);
        if(opts.inLen < opts.min || opts.inLen > opts.max){
            // 获取该输入框的长度限制
            var minLen = opts.obj.attr('data-minmax').split(' ')[0],
                maxLen = opts.obj.attr('data-minmax').split(' ')[1];
            
            return {
                isTrue: false,
                tips: opts.obj.attr('data-minmaxtxt') || (opts.inName + opts.minmaxErrtips+minLen + '-' + maxLen+'个字符')
            };
        }else{
            return {
                isTrue: true,
                tips: ''
            };
        }
    },
    // 正则验证
    isRex: function(opts){
        // console.log(opts.inRex, opts.inVal, opts.inRex.test(opts.inVal));
        if(opts.inRex.test(opts.inVal)){
            return {
                isTrue: true,
                tips: ''
            };
        }else{
            
            return {
                isTrue: false,
                tips: opts.obj.attr('data-rextxt') || (opts.inName + opts.rexErrtips)
            };            
        }
    },
    validate: function(Opts){

        // 默认设置
        var defaults = {
            obj: null,
            inName: '',
            inVal: null,
            inLen: 0,
            inRex: null,
            inType: null,
            // 判断为空
            isVnull: false,
            nullErrtips: '请输入',
            // 判断长度
            isVminmax: false,
            isVch: false,
            min: 0,
            max: 1,
            minmaxErrtips: '字数应为',
            // 使用正则
            isVrex: false,
            rexErrtips: '输入的内容格式不正确',

            // 常用正则表达式
            vRex : {
                // 1-9的数字
                integer19 : /^[1-9]\d*$/,
                // 0-9的数字
                integer09 : /^[0-9]\d*$/,
                // 数字
                num : /^\d+(\.\d+)?$/,
                // 邮箱
                email: /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/,
                // （下划线、字母、数字、汉字开头）
                nickname: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/,
                // 密码 6-16位
                password: /^\w{6,20}$/,
                // 电话号码-座机
                tel: /^(\(\d{3,4}\)|\d{3,4}-)?\d{7,8}$/,
                // 手机号码
                phone: /^[1]\d{10}$/,
                //国际号码
                interPhone: /^[0-9]{6,20}$/,
                // phone: /^(13[0-9]|15[012356789]|17[0-9]|18[0-9]|14[57])[0-9]{8}$/,
                // 特殊字符
                specialChar: /[`~!@#$%^&*-+.<>{}\/'[\]]/im,
                // 网址
                url: /^(https?|ftp|mms):\/\/([A-z0-9_\-]+\.)*[A-z0-9]+\-?[A-z0-9]+\.[A-z]{2,}(\/.*)*\/?/,
                // 金额
                amount: /^(\d{3}\,)*\d+(\.\d+)?$/
            }
        };

        var opts = $.extend(defaults, Opts),
            _vd = opts.obj.attr('data-vd') || false,
            _null = opts.obj.attr('data-null') || false,
            _minmax = opts.obj.attr('data-minmax') || false,
            _type = opts.obj.attr('data-type') || false,
            _rex = opts.obj.attr('data-rex') || false;

        // 是否进行验证
        opts.isVd = (_vd == 'true') ? true : false;

        if(!opts.isVd){
            return false;
        }


        // 判断验证的规则
        opts.isVnull = (_null == 'true') ? true : false;
        opts.isVminmax = (_minmax != '') ? true : false;
        opts.isVrex = (_type != '' || _rex != '') ? true : false;

        // 输入框的名称
        opts.inName = opts.obj.attr('data-name') || opts.obj.attr('name');
        // 输入框的值
        opts.inVal = $.trim(opts.obj.val());


        // 输入框值的长度， 默认中文占两字符长度
        if(opts.isVch){
            opts.inLen = opts.inVal.match(/[^ -~]/g) == null ? opts.inVal.length : opts.inVal.length + opts.inVal.match(/[^ -~]/g).length;
        }else{
            opts.inLen = opts.inVal.length;
        }


        // 输入框的类型
        opts.inType = _type;

        // 输入框的正则
        opts.inRex =  new RegExp(_rex || opts.vRex[opts.inType]);


        // 验证返回对象
        var result = {
            isTrue: true,
            tips: ''
        };

        // 判断为空
        if(!opts.isVnull){
            result = this.isNull(opts);
        }

        // 判断长度
        if(result.isTrue && opts.inLen > 0 && opts.isVminmax){
            var mimx = _minmax.split(' ');

            if(mimx.length > 1){
                opts.min = ~~(mimx[0] || 0);
                opts.max = ~~(mimx[1] || (opts.min + 1));
            }

            result = this.isMinmax(opts);
        }

        // 使用正则
        if(result.isTrue && (opts.inLen > 0) && opts.isVrex){
            result = this.isRex(opts);
        }

        if(typeof(opts.callback) != 'undefined'){
            opts.callback({
                obj: opts.obj,
                isTrue: result.isTrue,
                tips: result.tips
            });
        }
    }
};


window.formValidate = formValidate;
})(jQuery);




// 搜索选择功能
(function($){
	var $body = $('body');

	$.fn.autoFill = function(options){
		var defaults = {
			// 自动选择输入框的容器
			container: '.dl-box',
			// 发起请求的url
			// url: '../test/ByName.json',
			url: '/user/findByName',
			// 发起请求的data
			data: {},
			// 请求成功后回调
			loadCallBack: null,
			// 是否多选
			isMulti: false,
			// 搜索结果为空时是否可新增
			isInsert: false,
			// 选中后回调
			selCallBack: null,
			// 删除后回调
			delCallBack: null,
			// 是否可新增
			isAdd: true,
			// 容器的层级
			zIndex: 1500,
			// 关闭自动填充框回调
			closeCallBack: null,
			// 选择填充类型-默认为用户
			selTypeName: 'user',
			// 选中项-生成name值为Name的隐藏输入框
			selHiddenInputName: 'toUserName',
			// 选中项-生成name值为ID的隐藏输入框
			selHiddenInputId: 'toUserId',

			// 自动填充相关class
			autoClassFillBox: '#autoFillBox',
			autoClassPrev: '.js-auto-fill-prev',
			autoClassNext: '.js-auto-fill-next',
			autoClassClose: '.js-auto-fill-close',

			// 模板id
			autoTplName: '#autoFillTpl',

			// 数据存储容器
			selectedData: [],
			listData: null,
			// 是否立即打开-页面加载初始化或点击输入框初始化
			isShow: true,
			isCloseFillBox: true
		};

        this.each(function(){
        	var opts = $.extend(defaults, options);

        	opts.$this = $(this);

        	if(opts.$this.attr('data-bind') || opts.$this.length == 0){
        		return false;
        	}

            // 初始化
            init(opts);


            // 清除已选数据-对外方法
            this.clearData = clearData(opts);
        });
    };

    // 初始化
    function init(opts){
    	// console.log(opts);
    	// 判断容器
    	if(opts.container == '' || $(opts.container) == 0){
    		return false;
    	}
    	opts.$container = opts.$this.parents(opts.container);


    	// 插入自动填充容器
    	if($(opts.autoClassFillBox).length == 0){
    		opts.autoClassFillBox += Math.ceil(Math.random()*100000);

    		$body.append('<div id="'+ opts.autoClassFillBox.replace('#', '') +'" class="auto-fill-box"></div>');
    	}
    	opts.$fillBox = $(opts.autoClassFillBox);

    	opts.$this.attr('data-bind', true);

		// 输入框绑定-值改变-发起请求
		opts.$this.on('focus keyup', function(e){
			valChange(opts);
		});

		// 鼠标离开-如输入框值与选项值有相同则默认选中
		opts.$this.on('blur', function(){
			var ival = $.trim($(this).val());
			if(opts.listData){
				for (var i = 0, listlen = opts.listData.length; i < listlen; i++) {
					if(opts.listData[i].customerName == ival || opts.listData[i].name == ival){
						opts.$fillBox.find('li').eq(i).trigger('click');
						continue;
					}
				};
			}
		});

		// 选中列表项
		opts.$fillBox.on('click', 'li', function(){
			selectItem(opts,$(this));
		});

		// 删除已选项
		opts.$container.on('click', '.js-auto-fill-deldt', function(){
			isFillClose(opts);
			delItem(opts,$(this));

			return false;
		});

		// 上一页
		opts.$fillBox.on('click', opts.autoClassPrev, function(){
			var $pageThis = $(this);
			if($pageThis.hasClass('disable')){
				return false;
			}
			var clickPage = $pageThis.attr('pageNo');
			if(!opts.firstPage){
				opts.data.pageNo = clickPage;
				getData(opts);
			}
		});
		// 下一页
		opts.$fillBox.on('click', opts.autoClassNext, function(){
			var $pageThis = $(this);
			if($pageThis.hasClass('disable')){
				return false;
			}
			var clickPage = $pageThis.attr('pageNo');
			if(!opts.lastPage){
				opts.data.pageNo = clickPage;
				getData(opts);
			}
		});
		

		// 关闭自动填充框
		$body.on('click', function(){
			fillClose(opts);
		});

		// 关闭
		opts.$fillBox.on('click', opts.autoClassClose, function(){
			fillClose(opts);
		});

		// 点击自动填充区域阻止关闭
		$body.on('click', opts.autoClassFillBox + ',' + opts.container, function(){
			isFillClose(opts);
		});

		// 定位自适应
		$(window).on('resize',countPosition);

		// 是否执行加载数据操作
		if(opts.isShow){
			valChange(opts);
		}
    };

	// 请求数据
	function getData(opts){
		if(opts.url == ''){
			return false;
		}

		opts.$fillBox.show().siblings('.auto-fill-box').hide();

		// console.log('getData');

		// 停止上一次还未完成的ajax请求
		if(opts.jqxhr){
			opts.jqxhr.abort();
		}

		opts.jqxhr = baseEvn.ajaxFun({
			url: opts.url,
			data: opts.data
		});
		
		opts.jqxhr.done(function(result){
			if(!result.args){
				return;
			}

			opts.listData = result.args.list;

			// 判断是否有已选中项
			for (var i = 0, len = result.args.list.length; i < len; i++) {
				result.args.list[i].isActive = '';

				// 是否已被选中
				for (var j = 0, len2 = opts.selectedData.length; j < len2; j++) {
					if(result.args.list[i].userId == opts.selectedData[j].lid){
						result.args.list[i].isActive = 'active';
						continue;
					}
				};
			};

			// console.log(len);
			// 自动创建提示
			insertTips(opts,len2);


			// 用户或客户
			result.args.dataType = opts.selTypeName;

			//是否第一页
			opts.firstPage = result.args.firstPage;
			//是否最后一页
			opts.lastPage = result.args.lastPage;
			// 上一页
			opts.prePage = result.args.prePage;
			// 下一页
			opts.nextPage = result.args.nextPage;
			// 当前页
			opts.totalPage = result.args.totalPage;


			// 渲染模板
			renderEvn.renderTpl({
				tplId: opts.autoTplName,
				outputId: opts.autoClassFillBox,
				data: result.args,
				callback: function(outBox){
					pageInit(outBox,opts);

					countPosition(opts);
				}
			});


			// 回调
			if(opts.loadCallBack){
				opts.loadCallBack(result);
			}
		}).fail(function(){

		});
	};

	// 自动创建提示
	function insertTips(opts,len2){
		var $inserBox = opts.$this.parents('.in-box'),
			ival = opts.$this.val();

		// console.log(ival.length,!len2,opts.isInsert);
		if(ival.length && !len2 && !opts.selectedData.length && opts.isInsert){
			// 新增提示语
			if ($inserBox.find('.inser-tips').length) {
				$inserBox.find('.inser-tips').text('客户不存在,系统将自动创建');
			}else{
				$inserBox.append('<span class="inser-tips">客户不存在,系统将自动创建</span>');	
			}					
		}else{
			// 清除提示语
			$inserBox.find('.inser-tips').text('');
		}
	};

	// 页码初始化
	function pageInit(outBox,opts){
		outBox.find('.prev').attr('pageNo',opts.prePage);
		outBox.find('.next').attr('pageNo',opts.nextPage);
		if(opts.firstPage){
			outBox.find('.prev').addClass('disable');
		}

		if(opts.lastPage){
			outBox.find('.next').addClass('disable');
		}
	};



	// 输入框的值改变and获取焦点
	function valChange(opts){
		var $input = opts.$this,
			key = $.trim($input.val());

		// console.log('getData');

		// 阻止相同关键词重复请求
		if(opts.oldKey != key || key == ''){

			opts.oldKey = key;

			opts.data.keyword = key;

			getData(opts);
		}

		isFillClose(opts);
	};

	// 计算自动填充的位置
	function countPosition(opts){
		if(opts.$this.length == 0){
			return false;
		}

		var _enterW = opts.$this.parent().outerWidth() - 2;

		// 计算输入框宽度-尽量避免换行
		// console.log(opts.$this.parent().find('dt').length);
		var dtW = 0;
		opts.$this.parent().find('dt').each(function(){
			dtW += $(this).width() + 5;
		});

		// 容器宽度减去内边距
		var _enterW2 = _enterW - 70;
		// 容器宽度减去已选项宽度和
		dtW = _enterW2 - dtW;

		// 判断最终值范围
		dtW = dtW > 70 ? dtW : _enterW2;
		// 设置输入框宽度
		opts.$this.parent().find('input').width(dtW);




		var _enterH = opts.$this.outerHeight(),
			_enterTop = opts.$this.offset().top,
			_enterLeft = opts.$this.parent().offset().left;

		// 计算选择下拉框位置及宽高
		opts.$fillBox.css({
			// display: 'block',
			width: _enterW,
			top: _enterTop + _enterH,
			left: _enterLeft,
			zIndex: opts.zIndex
		});
	};

	// 自动填充框关闭判断
	function isFillClose(opts){
		opts.isCloseFillBox = false;

		setTimeout(function(){
			opts.isCloseFillBox = true;
		},300);
	};

	// 关闭自动填充框
	function fillClose(opts){
		if(opts.isCloseFillBox){

			opts.$fillBox.hide();

			// 判断是否有选中值
			if(opts.selectedData.length == 0){
				// alert('请选择');
			}

			// 清空数据

			// 关闭填充框回调
			if(opts.closeCallBack){
				opts.closeCallBack(opts.selectedData);
			}
		}
	};

	// 选中列表项
	function selectItem(opts, liObj){
		var $this = liObj,
			lId = $this.attr('data-id'),
			lName = $this.text(),
			isRepeat = false;

		// 判断是否多选
		if(opts.isMulti){
			// 多选

			// 是否已被选中
			for (var i = 0, len = opts.selectedData.length; i < len; i++) {
				if(lId == opts.selectedData[i].lid){
					isRepeat = opts.selectedData[i];
					break;
				}
			};

			// 判断该条信息是否已选中
			if(isRepeat){
				// 已选
				$this.removeClass('active');
				opts.selectedData.splice($.inArray(isRepeat, opts.selectedData), 1);
			}else{
				// 未选
				$this.addClass('active');
				opts.selectedData.push({lid: lId, lname: lName});
			}
		}else{
			// 单选
			$this.addClass('active').siblings().removeClass('active');
			opts.selectedData.splice(0, opts.selectedData.length);
			opts.selectedData.push({lid: lId, lname: lName});

			// 关闭
			fillClose(opts);
		}

		opts.$this.val('');

		// 渲染选中值
		outputSelected(opts);
	
		countPosition(opts);

		// 自动创建提示
		insertTips(opts,0);

		// 回调
		if(opts.selCallBack){
			opts.selCallBack($this);
		}
	};

	// 删除已选项
	function delItem(opts, liObj){
		var lId = liObj.parent().find('input').val();

		for (var i = 0, len = opts.selectedData.length; i < len; i++) {
			if(lId == opts.selectedData[i].lid){

				liObj.remove();

				opts.selectedData.splice($.inArray(opts.selectedData[i], opts.selectedData), 1);

				outputSelected(opts);

				opts.$fillBox.find('li').each(function(){
					if($(this).attr('data-id') == lId){
						$(this).removeClass('active');
					}
				});
				break;
			}
		};

		countPosition(opts);

		opts.$fillBox.siblings('.auto-fill-box').hide();

		// 回调
		if(opts.delCallBack){
			opts.delCallBack();
		}
	};

	// 清空数据数组
	function clearData(opts){
		opts.selectedData.splice(0, opts.selectedData.length);
	};

	// 渲染已选内容
	function outputSelected(opts){
		var str = '';

		for (var i = 0, len = opts.selectedData.length; i < len; i++) {
			str += '<dt>'+ opts.selectedData[i].lname;
			str += '<i class="js-auto-fill-deldt icon-del-search"></i>';
			str += '<input type="hidden" name="'+ opts.selHiddenInputId +'" value="'+ opts.selectedData[i].lid +'">';
			str += '<input type="hidden" name="'+ opts.selHiddenInputName +'" value="'+ opts.selectedData[i].lname +'">';
			str += '</dt>';
		};

		opts.$container.find('dl').html(str);
	};

	// $(function(){
	// 	$body.on('click', '.js-auto-fill-input', function(){
	// 		$(this).autoFill({
	// 			isShow: true
	// 		});
	// 	});

	// 	$('.js-auto-fill-input2').autoFill({
	// 		isMulti: true
	// 	});
	// });


})(jQuery);




// 地址选择器
(function($){
	$.fn.addressEvn = function(options){
		var defaults = {
			// 下拉选择ID
            selId : {
            	province: '#province',
            	city: '#city',
            	county: '#county',
            	town: '#town'
            },
            // 下拉选择默认空值
            selNullVal : {
            	province: '请选择',
            	city: '请选择',
            	county: '请选择',
            	town: '请选择'
            },
            // 下拉选择默认值
            selDefauleVal : {
            	province: '',
            	city: '',
            	county: '',
            	town: ''
            },
            // 下拉选择数据接口
            selDataApi : {
            	province: '',
            	city: '',
            	county: '',
            	town: ''
            },
            // N级联动
            linkage: 2
        };

        this.each(function(){
        	var opts = $.extend(defaults, options);

            // 初始化
            init(opts, $(this));
        });

        // 初始化
        function init(opts, obj){
        	obj.province = obj.find(opts.selId.province);
        	obj.city = obj.find(opts.selId.city);
        	obj.county = obj.find(opts.selId.county);
        	obj.town = obj.find(opts.selId.town);
        	
        	// 事件绑定
        	obj.province.on('change', function(){
        		cityFun(obj, opts);
        	});
        	obj.city.on('change', function(){
        		countyFun(obj, opts);
        	});
    		obj.county.on('change', function(){
        		townFun(obj, opts);
        	});

        	// 省份初始化
        	provinceFun(obj, opts);
        };

        // 获取数据
        function insertOption(dataType, pVal, param){
        	// dataType
        	// pVal
        	// param

        	// $.ajax({

        	// });



			var data = getData(dataType, param),
				i = 0,
				len = data.length,
				str = '',
				d,
				v,
				p;

			for(;i<len; i++) {

				d = data[i][dataType + '_id'];

				v = data[i][dataType + '_name'];

				p = (v == pVal) ? 'selected' : '';

				str += '<option value="' + d + '" '+ p +'>' + v +'</option>';
			};

			return str;
		};

		// 省份
		function provinceFun(obj, opts){
			creatHtml(obj, opts, 'province', 'none');
			cityFun(obj, opts);
		};

		// 城市
		function cityFun(obj, opts){
			creatHtml(obj, opts, 'city', 'province');
			if(opts.linkage > 2){
				countyFun(obj, opts);
			}			
		};

		// 区县
		function countyFun(obj, opts){
			if(opts.linkage > 2){
				creatHtml(obj, opts, 'county', 'city');
			}
			
			if(opts.linkage > 3){
				townFun(obj, opts);
			}
		};

		// 街道
		function townFun(obj, opts){
			if(opts.linkage > 3){
				creatHtml(obj, opts, 'town', 'county');
			}
		};

		// 省份、城市、区县、街道
		function creatHtml(obj, opts, ntype, ptype){
			// console.log(ptype, obj[ptype]);

			var pv = (ptype == 'none') ? [] : obj[ptype].val(),
				nv = '<option value="">'+ opts.selNullVal[ntype] +'</option>';

			// console.log(pv,pv.length,ptype,nv);
			if(pv.length == 0 && ptype != 'none') {
				obj[ntype].html(nv);
				showHide(obj, ntype, true);
			}else{
				// console.log(typeof(obj[ntype]) != 'undefined');
				if(typeof(obj[ntype]) != 'undefined'){
					obj[ntype].html(nv + insertOption(ntype, opts.selDefauleVal[ntype], {ptype: pv}));
				}				
				showHide(obj, ntype);
			}
		};

		// 显示或隐藏
		function showHide(Obj, ntype, isHide){
			// if(isHide){
			// 	Obj[ntype].addClass('sel-hide ' + ntype + '-hide');
			// }else{
			// 	Obj[ntype].removeClass('sel-hide ' + ntype + '-hide');
			// }
		};


		// 模拟  获取数据，type 类型，param 参数
		function getData(type, param){
			var data = [];

			if(typeof(arrCity) != 'undefined'){
				// 新的地图数据，额外加载
				if(type == 'province'){
					for (var k in arrCity) {
						if(arrCity[k].name != '请选择'){
							data.push({
								"province_name": arrCity[k].name,
								"province_id": arrCity[k].name
							});
						};
					};
				}else if(type == 'city'){
					for (var k in arrCity) {
						if(arrCity[k].name != '请选择' && arrCity[k].name == param.ptype){
							// console.log(arrCity[k].name);
							for (var i = 0,len = arrCity[k].sub.length; i < len; i++) {
								// console.log(arrCity[k].sub[i].name);
								if(arrCity[k].sub[i].name != '请选择'){
									data.push({
										"city_name": arrCity[k].sub[i].name,
										"city_id": arrCity[k].sub[i].name
									});
								}
								
							};
						};
					};
				}else if(type == 'county'){

				}else{

				}

				// console.log(data);
			}else{
				if(type == 'province'){
					for (var i = addressData.length - 1; i >= 0; i--) {
						data.push({
							"province_name": addressData[i].name,
							"province_id": addressData[i].name
						});
					};
				}else if(type == 'city'){
					for (var i = addressData.length - 1; i >= 0; i--) {
						if(param.ptype == addressData[i].name){
							for (var j = addressData[i].cities.length - 1; j >= 0; j--) {
								data.push({
									"city_name": addressData[i].cities[j],
									"city_id": addressData[i].cities[j]
								});
							};
						}
					};
				}else if(type == 'county'){

				}else{

				}
			}
		

			return data;
		}

	};

	var addressData = [{
	    name: "北京",
	    cities: ["西城", "东城", "崇文", "宣武", "朝阳", "海淀", "丰台", "石景山", "门头沟", "房山", "通州", "顺义", "大兴", "昌平", "平谷", "怀柔", "密云", "延庆"]
	}, {
	    name: "天津",
	    cities: ["青羊", "河东", "河西", "南开", "河北", "红桥", "塘沽", "汉沽", "大港", "东丽", "西青", "北辰", "津南", "武清", "宝坻", "静海", "宁河", "蓟县", "开发区"]
	}, {
	    name: "河北",
	    cities: ["石家庄", "秦皇岛", "廊坊", "保定", "邯郸", "唐山", "邢台", "衡水", "张家口", "承德", "沧州", "衡水"]
	}, {
	    name: "山西",
	    cities: ["太原", "大同", "长治", "晋中", "阳泉", "朔州", "运城", "临汾"]
	}, {
	    name: "内蒙古",
	    cities: ["呼和浩特", "赤峰", "通辽", "锡林郭勒", "兴安"]
	}, {
	    name: "辽宁",
	    cities: ["大连", "沈阳", "鞍山", "抚顺", "营口", "锦州", "丹东", "朝阳", "辽阳", "阜新", "铁岭", "盘锦", "本溪", "葫芦岛"]
	}, {
	    name: "吉林",
	    cities: ["长春", "吉林", "四平", "辽源", "通化", "延吉", "白城", "辽源", "松原", "临江", "珲春"]
	}, {
	    name: "黑龙江",
	    cities: ["哈尔滨", "齐齐哈尔", "大庆", "牡丹江", "鹤岗", "佳木斯", "绥化"]
	}, {
	    name: "上海",
	    cities: ["浦东", "杨浦", "徐汇", "静安", "卢湾", "黄浦", "普陀", "闸北", "虹口", "长宁", "宝山", "闵行", "嘉定", "金山", "松江", "青浦", "崇明", "奉贤", "南汇"]
	}, {
	    name: "江苏",
	    cities: ["南京", "苏州", "无锡", "常州", "扬州", "徐州", "南通", "镇江", "泰州", "淮安", "连云港", "宿迁", "盐城", "淮阴", "沐阳", "张家港"]
	}, {
	    name: "浙江",
	    cities: ["杭州", "金华", "宁波", "温州", "嘉兴", "绍兴", "丽水", "湖州", "台州", "舟山", "衢州"]
	}, {
	    name: "安徽",
	    cities: ["合肥", "马鞍山", "蚌埠", "黄山", "芜湖", "淮南", "铜陵", "阜阳", "宣城", "安庆"]
	}, {
	    name: "福建",
	    cities: ["福州", "厦门", "泉州", "漳州", "南平", "龙岩", "莆田", "三明", "宁德"]
	}, {
	    name: "江西",
	    cities: ["南昌", "景德镇", "上饶", "萍乡", "九江", "吉安", "宜春", "鹰潭", "新余", "赣州"]
	}, {
	    name: "山东",
	    cities: ["青岛", "济南", "淄博", "烟台", "泰安", "临沂", "日照", "德州", "威海", "东营", "荷泽", "济宁", "潍坊", "枣庄", "聊城"]
	}, {
	    name: "河南",
	    cities: ["郑州", "洛阳", "开封", "平顶山", "濮阳", "安阳", "许昌", "南阳", "信阳", "周口", "新乡", "焦作", "三门峡", "商丘"]
	}, {
	    name: "湖北",
	    cities: ["武汉", "襄樊", "孝感", "十堰", "荆州", "黄石", "宜昌", "黄冈", "恩施", "鄂州", "江汉", "随枣", "荆沙", "咸宁"]
	}, {
	    name: "湖南",
	    cities: ["长沙", "湘潭", "岳阳", "株洲", "怀化", "永州", "益阳", "张家界", "常德", "衡阳", "湘西", "邵阳", "娄底", "郴州"]
	}, {
	    name: "广东",
	    cities: ["广州", "深圳", "东莞", "佛山", "珠海", "汕头", "韶关", "江门", "梅州", "揭阳", "中山", "河源", "惠州", "茂名", "湛江", "阳江", "潮州", "云浮", "汕尾", "潮阳", "肇庆", "顺德", "清远"]
	}, {
	    name: "广西",
	    cities: ["南宁", "桂林", "柳州", "梧州", "来宾", "贵港", "玉林", "贺州"]
	}, {
	    name: "海南",
	    cities: ["海口", "三亚"]
	}, {
	    name: "重庆",
	    cities: ["渝中", "大渡口", "江北", "沙坪坝", "九龙坡", "南岸", "北碚", "万盛", "双桥", "渝北", "巴南", "万州", "涪陵", "黔江", "长寿"]
	}, {
	    name: "四川",
	    cities: ["成都", "达州", "南充", "乐山", "绵阳", "德阳", "内江", "遂宁", "宜宾", "巴中", "自贡", "康定", "攀枝花"]
	}, {
	    name: "贵州",
	    cities: ["贵阳", "遵义", "安顺", "黔西南", "都匀"]
	}, {
	    name: "云南",
	    cities: ["昆明", "丽江", "昭通", "玉溪", "临沧", "文山", "红河", "楚雄", "大理"]
	}, {
	    name: "西藏",
	    cities: ["拉萨", "林芝", "日喀则", "昌都"]
	}, {
	    name: "陕西",
	    cities: ["西安", "咸阳", "延安", "汉中", "榆林", "商南", "略阳", "宜君", "麟游", "白河"]
	}, {
	    name: "甘肃",
	    cities: ["兰州", "金昌", "天水", "武威", "张掖", "平凉", "酒泉"]
	}, {
	    name: "青海",
	    cities: ["黄南", "海南", "西宁", "海东", "海西", "海北", "果洛", "玉树"]
	}, {
	    name: "宁夏",
	    cities: ["银川", "吴忠"]
	}, {
	    name: "新疆",
	    cities: ["乌鲁木齐", "哈密", "喀什", "巴音郭楞", "昌吉", "伊犁", "阿勒泰", "克拉玛依", "博尔塔拉"]
	}, {
	    name: "香港",
	    cities: ["中西区", "湾仔区", "东区", "南区", "九龙-油尖旺区", "九龙-深水埗区", "九龙-九龙城区", "九龙-黄大仙区", "九龙-观塘区", "新界-北区", "新界-大埔区", "新界-沙田区", "新界-西贡区", "新界-荃湾区", "新界-屯门区", "新界-元朗区", "新界-葵青区", "新界-离岛区"]
	}, {
	    name: "澳门",
	    cities: ["花地玛堂区", "圣安多尼堂区", "大堂区", "望德堂区", "风顺堂区", "嘉模堂区", "圣方济各堂区", "路氹城"]
	}];


	$(function(){

		// 获取全国省市信息
		// console.log(typeof(arrCity));
		if(typeof(_resUrl) == 'undefined'){
			_resUrl = 'http://res.foxsaas.com';
		}

		$.ajax({
			url: _resUrl + '/saasdist_v2/js/sitedata_bas.js',
			dataType: 'script',
			cache: true
		}).done(function(response,status) {
			// console.log(typeof(arrCity));
			// console.log(arrCity);
			// for (var k in arrCity) {
			// 	if(arrCity[k].name != '请选择'){
			// 		console.log(arrCity[k].name);
			// 		for (var i = arrCity[k].sub.length - 1; i >= 0; i--) {
			// 			console.log(arrCity[k].sub[i].name);
			// 		};
			// 	};
			// };
		});



		// $('#addressBox').addressEvn({
		// 	selDefauleVal : {
  //           	province: '广东',
  //           	city: '深圳',
  //           	county: '',
  //           	town: ''
  //           }
		// });
	});

})(jQuery);



// 国际手机号码
(function($){
	var mArr = [
		{
			tag: 'CN',
			name: 'China（中国大陆）',
			val: '+86'
		},
		{
			tag: 'HK',
			name: 'Hong Kong（香港）',
			val: '+852'
		},
		{
			tag: 'IL',
			name: 'Israel（以色列）',
			val: '+972'
		},
		{
			tag: 'IT',
			name: 'Italy（意大利）',
			val: '+39'
		},
		{
			tag: 'JP',
			name: 'Japan（日本）',
			val: '+81'
		},
		{
			tag: 'MO',
			name: 'Macau（澳门）',
			val: '+853'
		},
		{
			tag: 'NL',
			name: 'Netherlands（荷兰）',
			val: '+31'
		},
		{
			tag: 'PL',
			name: 'Poland（波兰）',
			val: '+48'
		},
		{
			tag: 'KR',
			name: 'South Korea（韩国）',
			val: '+82'
		},
		{
			tag: 'ES',
			name: 'Spain（西班牙）',
			val: '+34'
		},
		{
			tag: 'TW',
			name: 'Taiwan（台湾）',
			val: '+886'
		},
		{
			tag: 'GB',
			name: 'United Kingdom（英国）',
			val: '+44'
		},
		{
			tag: 'US',
			name: 'United States（美国）',
			val: '+1'
		}
	];


	$(function(){
		var $body = $('body'),
			isCloseSb = true;


		// 国家数据初始化
		function mLoad($box){
			var str = '<ul>';

			for (var i = 0,len = mArr.length; i < len; i++) {
				str += '<li data-value="'+ mArr[i].val +'" data-tag="'+ mArr[i].tag +'">'+ mArr[i].name +'<span>'+ mArr[i].val +'</span></li>';
			};

			str += '</ul>';

			$box.find('.sel-box-txt').html(mArr[0].val);
			$box.find('.sel-box-list').html(str);
		};


		// 初始化国际区号
		function areaCodeInit(){
			$body.find('.area-code-box').each(function(){
				$(this).addClass('in-sel-box').html('<input name="areaCode" type="hidden" value="+86"><div class="sel-box-txt"></div><div class="sel-box-list"></div>');

				mLoad($(this));
			});
		};

		areaCodeInit();


		window.areaCodePublicInit = areaCodeInit;


		$body.on('click', '.sel-box-txt', function(){
			$(this).parents('.in-sel-box').toggleClass('in-sel-box-open');
		});

		$body.on('click', '.sel-box-list li', function(){
			var val = $(this).attr('data-value'),
				$box = $(this).parents('.in-sel-box');

			$box.removeClass('in-sel-box-open').find('.sel-box-txt').html(val);
			$box.find('input').val(val);
		});

		$body.on('click','.in-sel-box',function(){
			isCloseSb = false;

			setTimeout(function(){
				isCloseSb = true;
			},300);
		});


		$body.on('click', function(){
			if(isCloseSb){
				$(this).find('.in-sel-box').removeClass('in-sel-box-open');
			}
		});

	});


})(jQuery);


