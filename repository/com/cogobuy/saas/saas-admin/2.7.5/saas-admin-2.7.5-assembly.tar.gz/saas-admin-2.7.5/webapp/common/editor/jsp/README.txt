引入maven配置：
<dependency>
	<groupId>com.ingdan</groupId>
	<artifactId>ingdan-ueditor</artifactId>
	<version>1.1.3</version>
</dependency>