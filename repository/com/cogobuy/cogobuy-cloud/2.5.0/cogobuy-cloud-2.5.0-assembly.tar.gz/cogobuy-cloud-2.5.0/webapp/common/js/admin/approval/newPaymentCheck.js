$(function(){
	/* 表格修饰 */
	$(".table-list > table").decorateList();
	
	/* 模拟select下拉列表 */	
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find("input").val($(this).attr("state"));//赋值，其他的显示效果被提出共用
		var id=$(this).parents(".options-select").find("input").attr("statusId");
		if(id=="completeState"||id=="payState"||id=="verifiState"){	//如果是"完成否"或"确认否"选框，点击时清除更多框的内容，同时查询			
			if(id=="completeState" && $(this).attr("state")==1){ //如果点击已完成，则清除“确认”“核销”的状态
				$("#payState").val("");
				$("#verifiState").val("");
			}//清除
			$("#salesNameC").val("");
			$("#sortC").val("");
			$("#customerNameC").val("");
			$("#datetime1C").val("");
			$("#datetime2C").val("");	
			$("#bankcheck").find("input").removeAttr("checked");
			//查询	
			$("#selectbutton").trigger("click");
		}
		if(id=="pCategory" && $(this).attr("state")!=""){
			$("#tishi").addClass("none"); 
		}
		return false;
	});
	
	/* 更新筛选  已经提出共用
	$(".switch a").click(function(){
		$(".switch a").removeClass("none");
		$(this).addClass("none");
		if($("#moreFilter").hasClass("none")){
			$("#moreFilter").removeClass("none");
		}else{
			$("#moreFilter").addClass("none");
		}
	});*/
    
	/* 修改 */
	$(".edit-text").click(function(){	
		//var role=$("#role").val();
		var updateType = $(this).attr("update");//修改按钮的类型，因为客服和主管是不同的按钮
		var $obj = $(this).parents("tr");
		var state = $(this).attr("payState");
		var updateId = $obj.find("[cname='updateId']").val();
		var $number = $obj.find("[cname='number']").eq(0).text(); 
		var $date = $obj.find("[cname='time']").eq(0).text();
		var $amount = $obj.find("[cname='amount']").text();
		var $customerName = $obj.find("[cname='username']").attr("nameV");
		var $paymenter = $obj.find("[cname='paymenter']").text();
		var $bank = $obj.find("[cname='bank']").text();
		var $category = $obj.find("[cname='category']").text();
		var $bankId = $obj.find("[cname='bankId']").val();
		var $sortId = $obj.find("[cname='sortId']").val();
		var $scode = $obj.find("[cname='scode']").text();
		var $attachment = $obj.find("[cname='attachment']").html();
		var $CS = $obj.find("[cname='CS']").text();
		$("#pNumber").val($number);
		$("#pDate").val($date);
		$("#pAmount").val($amount);
		$("#customerNameP").val($customerName);
		$("#pPaymenter").val($paymenter);
		$("#pBank").val($bankId);
		$("#pBank").prev(".select").find("span").text($bank);
		$("#pCategory").val($sortId);
		$("#pCategory").prev(".select").find("span").text($category);
		$("#pScode").val($scode);
		$("#pId").val(updateId);
		$("#pCS").val($CS);		
		
		if($attachment != null && $attachment != ""){//附件存在			
			var fileCreate=$("#fileCreate"); //添加附件块 ，用于后面隐藏
			if(state==0||(state==1 && updateType=="scsUpdate")){//已确认的不能再修改，但主管除外
				fileCreate.hide();
				var attachmentId= $obj.find("[cname='attachment']").find("input").val();
				var delAction = "/approval/attach_delete?id="+attachmentId;
				var aHTML = $attachment+"<a href='javascript:;' tag='delold'>删除</a>";
				$("#fileList").find("li").append(aHTML);
				$("#fileList").show();
				//重新绑定删除（本来的）
	        	$(".attachments li").find("a[tag='delold']").unbind("click");
	        	$(".attachments li").find("a[tag='delold']").bind("click",function(){
	        		delFile($("#fileList").find("a"),delAction);
	        	  	return false;
	        	}); 
			}else{
				var aHTML = $attachment;
				$("#fileList").find("li").append(aHTML);
				$("#fileList").show();	
			}
		}else{//附件不存在
			var fileCreate=$("#fileCreate"); 
			fileCreate.show();
			$(".attachments li").html("");
			$(".attachments .box-content").hide();
		}				
		//popupFun(450,510);
		pagePopup(".popup-check-payment",true);
	});
	/* 取消 关闭 */
	$("#close1,#close2").click(function(){
		$("#fileList").find("a").remove();
		$("#updateform").validationEngine("hideAll");
		$("#tishi").addClass("none"); 
	});
	
	/* 文件上传 */
    $("input[id^=fileId]").change(function(){
    	var fileName=$(this).val();
    	var type="session";
    	$(this).parents("div").find("input[id^=fileNameId]").val(fileName);
    	var fileCreate=$("#fileCreate"); //添加附件块 ，用于后面隐藏
    	$(this).parents("div").find("form[id^=fileUploadForm]").ajaxSubmit(function(returnStr){
            if(returnStr == "0"){
               dialog("文件上传失败","unsuccess",true,2);
               return;
            }else{
            	var path = returnStr;
            	var delAction = "/approval/attach_delFromSession?attachPath="+path;
            	var changeAction = "/approval/attach_changeSessionFileType?attachPath="+path;
            	if(type != 'session'){
            		var array = returnStr.split(",");
               		path = array[0];
               		delAction = "/approval/attach_delete?id="+array[1];
               		changeAction = "/approval/attach_changeFileType?id="+array[1];
               	}         	
            	//var _fileName = fileName.substring(fileName.lastIndexOf("\\") + 1,6)+"...";  //名字做截断
            	var liStr = "<a href=\"/fileDownload?downloadType=PAYMENT_APPROVAL_DIR&fileName="+path+"&srcName="+fileName+"\">"+fileName+"</a>";
            		liStr +="<a tag='del' href=\"javascript:;\">删除</a>"; 
            	$("#fileList").find("li").append(liStr);
            	$("#fileList").show();
            	fileCreate.hide(); 
            	//重新绑定删除（指后来新添后）
            	$(".attachments li").find("a[tag='del']").unbind("click");
            	$(".attachments li").find("a[tag='del']").bind("click",function(){
            		delFile($("#fileList").find("a"),delAction);
            	  	return false;
            	});            
            }
    	});
	});
    /* 删除文件  */
    function delFile(obj,action){
    	$.ajax({
            type:"GET",
            url:encodeURI(action),
            success:function(returnStr){
            	if (returnStr == "2") {            		
            		$(obj).remove(); 
            		$("#fileList").hide();//因为只允许上传一个文件
            		$("#fileCreate").show();
            		//dialog("成功！","success",true,1);
      		        //setTimeout(function(){window.location = "/approval/paymentCheck_index";},1000);
            		return;
      	        } else{
      	        	dialog("删除出错","unsuccess",true,2);
      	        	return;
      	        }
            }
        });
    }   
	
    /* 给表单元素添加验证 */
    $("#date1,#date2").addClass("validate[required]");
    $("#amount1,#amount2").addClass("validate[required],custom[positiveNumber]");
    
   	$("#form1").validationEngine('detach');
	$("#form1").validationEngine('attach');
   	$("#form2").validationEngine('detach');
	$("#form2").validationEngine('attach');
	
    /* 日期控件*/
	$("#date1,#date2").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');},maxDate:GetTodayDateStr()});
	});
	$("#datetime1C").click(function(){
		WdatePicker({onpicked:function(){},maxDate:getMinValue($('#datetime2C').val(), GetTodayDateStr())});
	});
	$("#datetime2C").click(function(){
		WdatePicker({onpicked:function(){},minDate:$('#datetime1C').val(),maxDate:GetTodayDateStr()});
	});
	/* 客户名称 */
    $.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findCustomerList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.customerList != null){
				$("input[id^=customerName]").autocomplete(data.customerList, {
					/**加自定义表头**/
					tableHead: "<div><span style='width:58%' class='col-2'>客户名称</span><span style='width:40%' class='col-1'>客户编码</span></div>",
					minChars: 0,
					width: 330,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span style='width:58%' class='col-2'>" + row.fullName + "</span>" +"<span  style='width:40%' class='col-1'>" + row.customerCode + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.fullName;
					},
					formatResult: function(row) {
						return row.fullName;
					}
					/*formatInputResult: function(data){
                    	autoCompleteCustomer(data)					
					},*/
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					//$("#customerId").val(data.id);
					$(this).val(data.fullName);
				}).bind("unmatch", function(){
					//$("#customerName").val("");
					//$("#customerId").val("");
				});
			}
		}
	}); 
    /* 添加 */						
	$("button[id^=submit]").click(function(){
		var depno = $("#dispathNo").val();
		var sort = $("#sort").val();
        if( sort=="" && depno!="") {		/*填写或修改发货单时，验证类别*/  				
        	$("#sort").addClass("validate[required]");
		}else{
			$("#sort").removeClass();
		}
		var form=$(this).attr("name");
		var error = $("#"+form).validationEngine('validate');
		if(error){
			$("#"+form).ajaxSubmit(function(returnStr){
		        if (returnStr == "success") {
			      setTimeout(function(){window.location = "/approval/paymentCheck_index";},1000);	        
		        } else if(returnStr == "error"){
		         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
		        }
		      });
		}
	});
	/* 查询 */						
	$("#selectbutton").click(function(){	
		var url="/approval/paymentCheck_index";
		$("#selectform").attr("action",url);
		$("#selectform").submit();
	});
	/* 导出 */						
	$("#export").click(function(){		
		var url="/approval/paymentCheck_export";
		//$("#tbody").find("input[id^=export_]").attr("name","idListForExport");当前页的导出	
		//$("#allConfirmForm").attr("action",url);
		//$("#allConfirmForm").submit();
		$("#selectform").attr("action",url);
		$("#selectform").submit();
		return false;
	});
	/* 修改 */						
	$("#updatebutton").click(function(){
		var depno = $.trim($("#pScode").val());
		var sort =  $.trim($("#pCategory").val());
        if( sort=="" && depno!="") {		/*填写或修改发货单时，验证类别*/  				
        	$("#tishi").removeClass("none");       	
		}else{
			$("#tishi").addClass("none");
			  var error = $("#updateform").validationEngine('validate');
				if(error){
					$("#updateform").ajaxSubmit(function(returnStr){
				        if (returnStr == "success") {	        	
				        	  dialog("成功！","success",true,1); 
				      		  var payState=$("#payState").val();
						      setTimeout(function(){window.location = "/approval/paymentCheck_index?payState="+payState;},1000);	        
					        } else if(returnStr == "error"){
					         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
					        }
					 }); 
				}
		}      
	});
	/* 删除   */
	$(".del-text").click(function(){
		if (confirm("确定要删除这一行吗?")){
			var url = "/approval/paymentCheck_delete?paymentCheckId=" + $(this).attr("paymentCheckId"); 
			$.get(encodeURI(url),function(returnStr){
		         if (returnStr == "success") {
		        	 dialog("成功！","success",true,1);
		        		 var payState=$("#payState").val();	//(出纳 客服 都可以删除，但是跳转不一样)	        		 
		        		 if(payState != null){
		        			 setTimeout(function(){window.location = "/approval/paymentCheck_index?payState="+payState;},1000);	  	
		        		 }else{
		        			 setTimeout(function(){window.location = "/approval/paymentCheck_index";},1000);
		        		 }	        	
		         } else if(returnStr == "error"){
		            dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
		         }
		    });	    
		    return false;
		}
	});
	/* 全部 确认到款 */
	$("#allCheck").click(function(){
		var flag=false;
    	$("[name=idList]:checkbox").each(function(){
    		if(this.checked){
    			flag=true;
    		}
    	});
    	if(flag){
			if (confirm("已勾选的查款单确认到款?")){
				var url="/approval/paymentCheck_confirm";
				$("#allConfirmForm").attr("action",url);				
				$("#allConfirmForm").ajaxSubmit(function(returnStr){
			        if (returnStr == "success") {
			          var payState=$("#payState").val();
				      setTimeout(function(){window.location = "/approval/paymentCheck_index?payState="+payState;},1000);	        
			        } else if(returnStr == "error"){
			         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
		          	 window.location.reload();//勾选还能保存
			        }
			      }); 
			}
		}else{
			alert("请至少选择一条记录！");
		}
	});
	
	/* 单个 确认到款 或者 确认核销*/
	$(".con-text").click(function(){
		var inputId=$(this).attr("inputId");
		var patt = new RegExp("confirmOne");//匹配，如果有则为“确认”，否则为“核销” 
		var result = patt.test(inputId);
		if(result){
			if (confirm("确认到款?")){				
				$("#"+inputId).attr("name","idList");
				var url="/approval/paymentCheck_confirm";
				$("#allConfirmForm").attr("action",url);
				$("#allConfirmForm").ajaxSubmit(function(returnStr){
			        if (returnStr == "success") {
			           var payState=$("#payState").val();
				       setTimeout(function(){window.location = "/approval/paymentCheck_index?payState="+payState;},1000);	        
			        } else if(returnStr == "error"){
			           dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
		          	   window.location.reload();//勾选还能保存
			        }
			      });
			}
		}else{
			if (confirm("确认核销?")){				
				$("#"+inputId).attr("name","idList");
				var url="/approval/paymentCheck_cancel";
				$("#allConfirmForm").attr("action",url);
				$("#allConfirmForm").ajaxSubmit(function(returnStr){
			        if (returnStr == "success") {
			           var verifiState=$("#verifiState").val();
				       setTimeout(function(){window.location = "/approval/paymentCheck_index?verifiState="+verifiState;},1000);	        
			        } else if(returnStr == "error"){
			           dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
		          	   window.location.reload();//勾选还能保存
			        }
			      });
			}  
		}
	});
	 /* 多选框 联动 
    $("#CheckedAll").click(function(){
    	$("[name=idList]:checkbox").attr("checked",this.checked);//this.checked等同于 $(this).attr("checked")
    }); */
    $("[name=bankIdList]:checkbox").click(function(){
    	$("#bankshow").text("");
    	var bankshow ="";
    	$("[name=bankIdList]:checkbox").each(function(){
    		if(this.checked){
    			bankshow = bankshow +$(this).attr("data-name") +",";
    		}
    	});
    	$("#bankshow").text(bankshow);
    });  
    
    /*绑定回车事件*/
    $("#salesNameC,#customerNameC").keydown(function(event){
        if (event.keyCode == 13) {	  				
        	$("#selectbutton").trigger("click");
		}
    });
});