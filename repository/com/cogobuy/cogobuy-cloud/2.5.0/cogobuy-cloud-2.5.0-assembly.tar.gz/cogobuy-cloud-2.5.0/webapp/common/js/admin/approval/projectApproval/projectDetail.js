$(function(){

    $("[tdTag=endTime]").click(function(){
        WdatePicker();
    });
    /* 添加一行 */
    $("tr input").click(function () {
        var $tr = $(this).parents("tr");
        if ($tr.nextAll().length == 0) {
            addTr($tr);
        }
    });
    /*删除一行*/
    $(".del-text").click(function () {
        var $obj = $(this).parents("tr");
        var $length = $obj.parents("tbody").find("tr").length;
        if ($length < 2) {
            dialog("请最少保留1行", "warning", false, 2);
            return false;
        }
        $obj.remove();
    });
})



  
  
/*
 * it技术审批通过
 */
function itTec_approval() {
    cleanTbody($("#detailListTbody"));//去空行
    addIdAndNameForInput($("#detailListTbody"));
    //验证填写数据
    var $form= $("#projectProgramForm");
    $("[tdTag=description],[tdTag=endTime],[tdTag=manCost]").addClass("validate[required]");
    var $error=$form.validationEngine('validate');
    if($error){
        //$("[tdTag=pur_update]").hide();
        //ajax提交修改的数据
        $form.attr("action","/approval/project_addProjectProgram");
        $form.ajaxSubmit(function(returnStr){
            if(returnStr=="success"){
                dialog("成功", "success", true, 2);
                window.location.reload(true);
                return true;
            }else{
                dialog(returnStr, "unsuccess", true, 2);
                return false;
            }
        });
    }
}


function pro_approval(){
    $("#finalvalue").addClass("validate[required,custom[number]]");
    $("#finalPriority").addClass("validate[required]");
    var $form= $("#proForm");
    var $error=$form.validationEngine('validate');
    if($error){
        $form.attr("action","/approval/project_addFinal");
        $form.ajaxSubmit(function(returnStr){
            if(returnStr=="success"){
                dialog("成功", "success", true, 2);
                window.location.reload(true);
                return true;
            }else{
                dialog(returnStr, "unsuccess", true, 2);
                return false;
            }
        });
    }
}





/*清除行的数据*/
function clearTr($tr){
    $tr.find("input[filterNull!=true]").val("");
    $tr.find("[tdTag=inventoryCode]").validationEngine('hidePrompt');
}

/* 克隆行 */
function addTr($tr){
    $copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
    $copyTr.removeAttr("hide");
    $copyTr.removeAttr("style");
    $("#detailListTbody").append($copyTr);
}


/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
    var $trNum = $tbody.find("tr").size();
    for ( var i = $trNum-1; i >= 0; i--) {
        $trNum = $tbody.find("tr").size();
        var $tr = $tbody.find("tr").eq(i);
        if (checkEmptyTr($tr)) {
            if ($trNum > 1) {
                $tr.remove();
            }
        }
    }
}


/* 验证空行 */
function checkEmptyTr($tr) {
    var $inputNum = $tr.find("input").size();
    var flag = true; // 为空
    for ( var i = 0; i < $inputNum; i++) {
        var $input = $tr.find("input[filterNull!=true]").eq(i);
        if ($.trim($input.val()) != "") {
            flag = false; // 不为空
            break;
        }
    }
    return flag;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
    var $trs = $tbody.find("tr");/* 获取所有tr */
    var firstName = "projectProgram";/* 前缀名称 */
    for ( var i = 0; i < $trs.size(); i++) {
        var numtag = "[" + i + "]";
        var $tr = $trs.eq(i);
        var $inputNum = $tr.find("input").size();
        for ( var j = 0; j < $inputNum; j++) {
            var $input = $tr.find("input").eq(j);
            $input.attr("id", $input.attr("tdTag") + numtag);
            $input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
        }
    }
}

