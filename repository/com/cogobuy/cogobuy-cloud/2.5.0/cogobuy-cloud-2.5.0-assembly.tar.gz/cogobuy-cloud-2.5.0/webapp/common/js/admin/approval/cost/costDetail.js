/**
 * 异步加载sales  PM一年业绩
 * @param parentId
 *
 */
 $(function(){
	 
	     $("#selectPer").click(function(){
	    	 //异步请求sales 业绩
	    	 $("#selectPer").hide();
	    	 $("[tdTag=mes]").show();
	    	 var data={
	                 "costApproval.createUserId":$("#createUserId").val(),
	                 "costApproval.createTime":$("#createTime").val()
	             };
	             $.ajax({
	                type : "GET",
	                url:encodeURI("/approvalajax/findSalePMDispatch"),
	                data:data,
	                dataType:"json",
	                success: function(dataResult){
	                    var saleDisPachs=dataResult.salesDispatchs;
	                    var pmDisPachs=dataResult.pmDispatchs;
	                    var saleDisStr='';
	                    var pmDisStr='';
	                    for(var i= 0;i<12;i++){
	                        if(saleDisPachs[i]!=null&&saleDisPachs[i].rmb!=null) {
	                            saleDisStr = saleDisStr + "<td>" + saleDisPachs[i].rmb + "</td>";
	                        }else{
	                            saleDisStr = saleDisStr + "<td>0</td>";
	                        }
	                        if(pmDisPachs[i]!=null&&pmDisPachs[i].rmb!=null) {
	                            pmDisStr = pmDisStr + "<td>" + pmDisPachs[i].rmb + "</td>";
	                        }else{
	                            pmDisStr = pmDisStr + "<td>0</td>";
	                        }
	                    }
	                   $("#pmDispatchShow").append(pmDisStr);
	                   $("#saleDispatchShow").append(saleDisStr);
	                   $("[tdTag=mes]").hide();//隐藏查询提示
	                },
		               error:function(){
		            	   $("[tdTag=mes]").text("无相关数据");
		               }
	             });
	    	 
	     });
        
 });


/**
 * 助理审核通过
 * @param parent
 */
function costAssistantApproval(parentId,redirect) {
	$(".button-yellow").hide();
	var data = {
		"costApproval.id" : parentId,
		"mails" : getApprovalMail()
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/cost_assistantApproval"),
		data : data,
		success : function(returnStr) {
			if (returnStr == 'success') {
				dialog("成功！", "success", true, 2);
				window.location.href = redirect;
			} else {
				$(".button-yellow").show();
				dialog("失败", "unsuccess", true, 2);
			}
		}
	});
}


/**
 * 财务付款
 * @parentId parentId
 */
function costFinanceApproval(parentId,redirect) {
	var $debt = $("#debt").val();
	var $deduct = $("#deduct").val();
	var $str =/^((([1-9]\d{0,7})|0)(\.\d{1,2})?)$/; 
	if(!$str.test($deduct)){
		dialog("抵扣金额不能为空且最多8位整数、两位小数", "unsuccess", true, 2);
	}else{
		if(parseFloat($debt) < parseFloat($deduct)){
			dialog("抵扣金额超过待还款金额", "unsuccess", true, 2);
		}else{
			$(".button-yellow").hide();
			var data = {
				"costApproval.id" : parentId,
				"costApproval.debt" : $debt,
				"costApproval.deduct" : $deduct,
				"mails" : getApprovalMail()
			};
			$.ajax({
				type : "GET",
				url : encodeURI("/approval/cost_costFinanceApproval"),
				data : data,
				success : function(returnStr) {
					if (returnStr == 'success') {
						dialog("成功！", "success", true, 2);
						window.location.href = redirect;
					} else {
						$(".button-yellow").show();
						dialog("失败", "unsuccess", true, 2);
					}
				}
			});
		}
	}
	
}
