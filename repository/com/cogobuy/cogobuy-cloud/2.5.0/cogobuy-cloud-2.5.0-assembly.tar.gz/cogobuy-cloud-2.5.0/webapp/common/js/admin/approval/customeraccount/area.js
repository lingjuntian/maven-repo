$(function () {
	/* 模拟select下拉列表 */
	$("[tag^=area]").click(function(event){
		event.stopPropagation();
		$(".options-select .select").removeClass("select-focus");
		$(this).addClass("select-focus");
		$(".input-box").css({zIndex:"0",position:"relative"});
		$(this).parents(".input-box").css({zIndex:"88"});
		var $optionsObj = $(this).parent(".options-select").find(".options") ;
		$(".options-select .options").addClass("none");
		$(".multiselect-menu").addClass("none");
		if($optionsObj.hasClass("none")){
			$optionsObj.removeClass("none");
		}else{
			$optionsObj.addClass("none");
		}
	});
	optionsaBind();
});

function optionsaBind(){
	$(".options-select .options a").unbind("click");
	$(".options-select .options a").click(function(){
		var $obj = $(this).parents(".options-select");
		$obj.find(".select").removeClass("select-focus");
		$obj.find(".select").find("span").text($(this).attr("vhidden"));
		$obj.find("input").val($(this).attr("tagvalue"));
		$obj.find(".options").addClass("none");
		chengeList($(this).attr("tagname"), $(this).attr("tagvalue"));
		return false;
	});
}

/**
 * @param tagname 改变列表
 */
function chengeList(tagname, tagvalue){
	if(tagname == "province"){
		chengeCityList(tagvalue);
	}
}

/**
 * 改变城市列表
 */
function chengeCityList(provinceid){
	$("[tag=areacity]").find("span").text("请选择市");
	$("[tag=areacity]").parents(".options-select").find("input").val("");
	$("#city_list_ul").empty();
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/area_findCityByProvinceId?id="+provinceid),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null){
            	if(data.list != null){//动态填充流程
            		$.each(data.list,function(n,value) {
           			 	var listr = "<li><a href=\"#\" tagname=\"city\" tagvalue=\""+value.id+"\" vhidden=\""+value.name+"\">"+value.name+"</a></li>";
           			 	$("#city_list_ul").append(listr);
	           			optionsaBind();
           	     	});
            	}
            }
        }
    });
}