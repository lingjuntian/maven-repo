function debug() {
	if (window.console && window.console.log) {
		window.console.log(arguments);
	}
}
var autoCompleteInventoryList;
$(function() {
	/*增加验证*/
	$("#buName,#buId,#vendor,#currencyName,#currencyCode,[tdTag=inventoryCode]").addClass("validate[required]");
	$("[tdTag=taxUnitPrice],[tdTag=unitPrice],[tdTag=sum]").addClass("validate[custom[amountSixPoint]]");
	$("[tdTag=quantity],[tdTag=fcMonth1],[tdTag=fcMonth2],[tdTag=fcMonth3],[tdTag=fcMonth4]").addClass("validate[custom[numberFormar]]");
	/*加载存货编码 可编辑 ashanahzhang 20160908*/
	addInventoryAutoCompleteChange($("#detailListTbody").find("input[tdTag=inventoryCode]"));
	/*初始化明细区域需要绑定的事件*/
	init_table(0);

	/*取消拆行*/
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $length = $obj.parents("tbody").find("tr").length;
		if($length<2){
			dialog("请最少保留1行","warning",false,2);
			return false;
		}
		delTr($obj);
	});
	
	/*拆行 ashanahzhang 20160811*/
	$("[data-name=split]").click(function(){
		var $tr = $(this).parents("tr");
		var rowNo = $tr.find("input[tdTag=rowNo]").val();
		var inventoryCode = $tr.find("input[tdTag=inventoryCode]").val();
		var inventorySpecfName = $tr.find("input[tdTag=inventorySpecfName]").val();
		var slCode = $tr.find("input[tdTag=slCode]").val();
		var restQuantity = $tr.find("input[tdTag=restQuantity]").val();
		var shipQuantity = $tr.find("input[tdTag=shipQuantity]").val();
		var taxUnitPrice = $tr.find("input[tdTag=taxUnitPrice]").val();
		var unitPrice = $tr.find("input[tdTag=unitPrice]").val();
		var sum = $tr.find("input[tdTag=sum]").val();
		var quote =  $tr.find("input[tdTag=quote]").val();
		var expectDate = $tr.find("input[tdTag=expectDate]").val();
		var erpPoNo =  $tr.find("input[tdTag=erpPoNo]").val();
	
		$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
		$copyTr.removeAttr("hide");
		$copyTr.removeAttr("style");
		
		$copyTr.find("input[tdTag=rowNo]").val(rowNo);
		
		$copyTr.find("input[tdTag=inventoryCode]").val(inventoryCode);
		$copyTr.find("input[tdTag=changeInventoryCode]").val(inventoryCode);
		
		$copyTr.find("input[tdTag=inventorySpecfName]").val(inventorySpecfName);
		$copyTr.find("input[tdTag=changeInventorySpecfName]").val(inventorySpecfName);
		
		$copyTr.find("input[tdTag=slCode]").val(slCode);
		$copyTr.find("input[tdTag=changeSlCode]").val(slCode);
		
		$copyTr.find("input[tdTag=restQuantity]").val(restQuantity);
		$copyTr.find("input[tdTag=changeRestQuantity]").val(restQuantity);
		$copyTr.find("input[tdTag=shipQuantity]").val(0);
		$copyTr.find("input[tdTag=quantity]").val(restQuantity);
		
		$copyTr.find("input[tdTag=taxUnitPrice]").val(taxUnitPrice);
		$copyTr.find("input[tdTag=changeTaxUnitPrice]").val(taxUnitPrice);
		
		$copyTr.find("input[tdTag=unitPrice]").val(unitPrice);
		$copyTr.find("input[tdTag=changeUnitPrice]").val(unitPrice);
		
		$copyTr.find("input[tdTag=sum]").val(sum);
		$copyTr.find("input[tdTag=changeSum]").val(sum);
		
		$copyTr.find("input[tdTag=quote]").val(quote);
		$copyTr.find("input[tdTag=changeQuote]").val(quote);
		
		$copyTr.find("input[tdTag=expectDate]").val(expectDate);
		$copyTr.find("input[tdTag=changeExpectDate]").val(expectDate);
		
		$copyTr.find("input[tdTag=erpPoNo]").val(erpPoNo);
		
		//隐藏属性
		var productLineName =  $tr.find("input[tdTag=productLineName]").val();
		var inventoryName = $tr.find("input[tdTag=inventoryName]").val();
		var eccnNo =  $tr.find("input[tdTag=eccnNo]").val();
		var customer =  $tr.find("input[tdTag=customer]").val();
		var purchaseCus = $tr.find("input[tdTag=purchaseCus]").val();
		var cusPono =  $tr.find("input[tdTag=cusPono]").val();
		var oldId =  $tr.find("input[tdTag=oldId]").val();
		var erpMid = $tr.find("input[tdTag=erpMid]").val();
		var cogobuyPoNo =  $tr.find("input[tdTag=cogobuyPoNo]").val();
		
		$copyTr.find("input[tdTag=productLineName]").val(productLineName);
		$copyTr.find("input[tdTag=inventoryName]").val(inventoryName);
		$copyTr.find("input[tdTag=eccnNo]").val(eccnNo);
		$copyTr.find("input[tdTag=customer]").val(customer);
		$copyTr.find("input[tdTag=purchaseCus]").val(purchaseCus);
		$copyTr.find("input[tdTag=cusPono]").val(cusPono);
		$copyTr.find("input[tdTag=oldId]").val(oldId);
		$copyTr.find("input[tdTag=erpMid]").val(erpMid);
		$copyTr.find("input[tdTag=cogobuyPoNo]").val(cogobuyPoNo);
		
		//导入ERP时用到的
		var ledger =  $tr.find("input[tdTag=ledger]").val();	
		var erpVendorName =  $tr.find("input[tdTag=erpVendorName]").val();
		var erpVendorCode = $tr.find("input[tdTag=erpVendorCode]").val();
		var personName =  $tr.find("input[tdTag=personName]").val();
		var personCode =  $tr.find("input[tdTag=personCode]").val();
		var shippingTypeName = $tr.find("input[tdTag=shippingTypeName]").val();
		var shippingTypeCode =  $tr.find("input[tdTag=shippingTypeCode]").val();
		var procurementType =  $tr.find("input[tdTag=procurementType]").val();
		
		$copyTr.find("input[tdTag=ledger]").val(ledger);
		$copyTr.find("input[tdTag=erpVendorName]").val(erpVendorName);
		$copyTr.find("input[tdTag=erpVendorCode]").val(erpVendorCode);
		$copyTr.find("input[tdTag=personName]").val(personName);
		$copyTr.find("input[tdTag=personCode]").val(personCode);
		$copyTr.find("input[tdTag=shippingTypeName]").val(shippingTypeName);
		$copyTr.find("input[tdTag=shippingTypeCode]").val(shippingTypeCode);
		$copyTr.find("input[tdTag=procurementType]").val(procurementType);
		
		$tr.after($copyTr);
		addInventoryAutoCompleteChange($copyTr.find("input[tdTag=inventoryCode]"));
	});
	
	/*打开、关闭行*/
	$("[data-name=work]").click(function(){
		var $obj = $(this).parents("tr");
		if($(this).hasClass("open-text")){//打开
			changeClosed($obj,"0","");
			$obj.find("[readOrChange]").attr("readonly",false).removeClass("disabled");
			$obj.find("input[tdTag=reason]").removeClass("validate[required]");
			$obj.find("input[tdTag=reason]").val("");
			$(this).removeClass("open-text");
			$(this).text("关闭");
			$(this).attr("title","关闭");
			$obj.find("[data-name=split]").attr("style","display:inline");
		}else{//关闭
			changeClosed($obj,$("#closeStatus").val(),"");
			$obj.find("[readOrChange]").attr("readonly",true).addClass("disabled");
			$obj.find("input[tdTag=reason]").addClass("validate[required]");
			$(this).addClass("open-text");
			$(this).text("打开");
			$(this).attr("title","打开");
			$obj.find("[data-name=split]").attr("style","display:none");//关闭订单即不可拆行
			//删除该行拆出的行
			var rowNo = $obj.find("input[tdTag=rowNo]").val();
			var $trs = $("#detailListTbody").find("tr");
			for ( var i = 0; i < $trs.size(); i++) {
				var $tr = $trs.eq(i);
				if($tr.find("input[tdTag=isAdd]").val()==1 && $tr.find("input[tdTag=rowNo]").val()==rowNo){
					$tr.remove();
				}
			}
		}
	});
	
	/*关闭订单*/
	/*
	$("[data-name=closeOrder]").click(function(){
			if($(this).hasClass("closeOrder-text")){
				var $trs = $("#detailListTbody").find("tr");
				for ( var i = 0; i < $trs.size(); i++) {
					var $tr = $trs.eq(i);
					changeClosed($tr,$("#closeStatus").val(),"");			
					$tr.find("[readOrChange]").attr("readonly",true).addClass("disabled");					
					$("input[tdTag=pm]").val(1);
				}
				$("[tdTag=orderReason]").addClass("validate[required]");
				$("#closeSymbol").val("1")	
				$("#closeorderReason").show();
				$("[tdTag=isApproval]").val("Y");
				$(this).removeClass("closeOrder-text");
				$(this).text("取消关闭订单");
				$(this).attr("title","取消关闭订单");
			}else{		
				var $trs = $("#detailListTbody").find("tr");
				for ( var i = 0; i < $trs.size(); i++) {
					var $tr = $trs.eq(i);
					changeClosed($tr,$tr.find("input[tdTag=closedCopy]").val(),"");			
					$tr.find("[readOrChange]").attr("readonly",true).removeClass("disabled");					
					$("input[tdTag=pm]").val("");
				}
				$("[tdTag=orderReason]").removeClass("validate[required]");
				$("#closeorderReason").hide();
				$("#closeorderReason").val("");
				$("#closeSymbol").val("0")
				$("[tdTag=isApproval]").val("");
				$(this).addClass("closeOrder-text");
				$(this).text("关闭订单");
				$(this).attr("title","关闭订单");
			}
		});
		*/
	
	/*替换*/
	$("[data-name=replace]").click(function(){
		var $obj = $(this).parents("tr");
		if($(this).hasClass("replace-text")){
			$obj.find("[repalceOrChange]").attr("readonly",false).removeClass("disabled");
			$obj.find("input[tdTag=inventoryCode]").focus();
			$obj.find("input[tdTag=reason]").addClass("validate[required]");			
			$(this).removeClass("replace-text");
			$(this).text("取消替换");
			$(this).attr("title","取消替换");			
			addInventoryAutoCompleteChange($obj.find("input[tdTag=inventoryCode]"));
		}else{
			$obj.find("input[tdTag=inventoryCode]").val($obj.find("input[tdTag=InventoryCodeCopy]").val());
			$obj.find("input[tdTag=inventorySpecfName]").val($obj.find("input[tdTag=inventorySpecfNameCopy]").val());
			$obj.find("input[tdTag=slCode]").val($obj.find("input[tdTag=slCodeCopy]").val());
			$obj.find("input[tdTag=restQuantity]").val($obj.find("input[tdTag=restQuantityCopy]").val());
			$obj.find("input[tdTag=shipQuantity]").val($obj.find("input[tdTag=shipQuantityCopy]").val());
			$obj.find("input[tdTag=taxUnitPrice]").val($obj.find("input[tdTag=taxUnitPriceCopy]").val());
			$obj.find("input[tdTag=unitPrice]").val($obj.find("input[tdTag=unitPriceCopy]").val());
			$obj.find("input[tdTag=sum]").val($obj.find("input[tdTag=sumCopy]").val());
			$obj.find("input[tdTag=quote]").val($obj.find("input[tdTag=quoteCopy]").val());
			$obj.find("input[tdTag=customer]").val($obj.find("input[tdTag=customerCopy]").val());
			$obj.find("input[tdTag=purchaseCus]").val($obj.find("input[tdTag=purchaseCusCopy]").val());
			$obj.find("input[tdTag=cusPono]").val($obj.find("input[tdTag=cusPonoCopy]").val());
			$obj.find("input[tdTag=expectDate]").val($obj.find("input[tdTag=expectDateCopy]").val());
			$obj.find("input[tdTag=reason]").removeClass("validate[required]");
			$obj.find("input[tdTag=reason]").val("");
			$obj.find("[repalceOrChange]").attr("readonly",true).addClass("disabled");
			$(this).addClass("replace-text");
			$(this).text("型号替换");
			$(this).attr("title","型号替换");
		}
	});
	/*修改关闭人*/
	function changeClosed($tr,closed,colseUserName){
		$tr.find("[tdTag=closed]").val(closed);
	}

	
});

/*表格初始化
 isBindTrClick : 是否绑定点击表格最后一行时，自动添加一个新行事件，如果是参照销售订单的话，就不需要在绑定这个事件了
 */
function init_table(isBindTdClick){
	if(isBindTdClick == 1){
		//debug("Add Click Function:"+isBindTdClick);
		/* 添加一行 */
		$("tr input").click(function(){
			var $tr = $(this).parents("tr");
			if($tr.nextAll().length==0){
				addTr($tr);
			}
		});
	} else {
		//debug("Remove Click Function:"+isBindTdClick);
		$('tr input').unbind("click");
	}
	
	/*增加日期控件*/
	$("#createTime").click(function() {
		WdatePicker();
	});
	/*增加日期控件*/
	$("input[tdTag=expectDate]").click(function() {
//		WdatePicker();
		//交期变化要写reason ashanahzhang 20160811
		WdatePicker({
			   onpicking:function(dp){
				   $(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
			       return false;
			     }
			   });

	});
	$("#createTime").val(GetTodayDateStr());
	/*增加显示提交按钮*/
	$(document).keydown(function(event){ 
		 if (event.ctrlKey && event.keyCode == 122) {
			 $("#submit").show();
		 }
	});
	
	/*删除一行*/
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $length = $obj.parents("tbody").find("tr").length;
		if($length<2){
			dialog("请最少保留1行","warning",false,2);
			return false;
		}
		delTr($obj);
	});

	$("input[tdTag=inventoryCode]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
	});
	$("input[tdTag=inventorySpecfName]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
	});
	$("input[tdTag=slCode]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
	});
	$("input[tdTag=restQuantity]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
		calTaxSum($(this).parents("tr"));
	});
	$("input[tdTag=taxUnitPrice]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
		calTaxSum($(this).parents("tr"));
	});
	$("input[tdTag=unitPrice]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
		calTaxSum($(this).parents("tr"));
	});
	$("input[tdTag=quote]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
	});
	$("input[tdTag=expectDate]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
	});

	
	/*显示创建页面Forecast的月份*/
	var myDate = new Date();
	$("span[tag=month]").each(function(i){
		var month = myDate.getMonth()+ i + 2;
		if(month > 12){
			var newDate = new Date();
			newDate.setMonth(month);
			$(this).text(newDate.getMonth());
		}else{
			$(this).text(month);
		}
	});
	/*显示详情页面Forecast的月份*/
	var myDate_confirm = new Date();
	$("span[tag=month_confirm]").each(function(i){
		var month = myDate_confirm.getMonth()+ i + 2;
		if(month > 12){
			var newDate = new Date();
			newDate.setMonth(month);
			$(this).text(newDate.getMonth());
		}else{
			$(this).text(month);
		}
	});
	
	/*选择系统日期*/
	$("#office").click(function(){
		if($(this).attr("checked")){
			$("#createTime_li").show();
		}else{
			$("#createTime_li").hide();
		}
	});
}

/*计算行含税总和、税额等*/
function calTaxSum($tr){
	/*在途数量*/
	var restQuantity = $tr.find("input[tdTag=restQuantity]").val();
	/*数量*/
	var quantity =parseFloat($tr.find("input[tdTag=restQuantity]").val())+parseFloat($tr.find("input[tdTag=shipQuantity]").val());
	$tr.find("input[tdTag=quantity]").val(quantity);
	/*含税单价*/
	var taxUnitPrice = changeNum($tr.find("input[tdTag=taxUnitPrice]").val());
	/*无税单价*/
	var unitPrice = changeNum($tr.find("input[tdTag=unitPrice]").val());
	/*金额*/
	if(taxUnitPrice!=null && taxUnitPrice!=""){
		var sum = multiply(restQuantity,taxUnitPrice);
	}else{
		var sum = multiply(restQuantity,unitPrice);
	}
	$tr.find("input[tdTag=sum]").val(changeFourDecimal(sum));
}


/*根据BU加载账套*/
function autoFillLedger($bu){
	$("#ledgerS").text("请选择");
	//$("#currencyName").val("");
	//$("#currencyCode").val("");
	//$("#exchangeRate").val(0);
	//$("#taxRate").val(0);
	$("#ledgerUl").empty();
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/prApproval_findLedgerListByBU?bu="+$bu),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null){
            	if(data.buLedgerList != null){//动态填充流程
            		//debug(data.buLedgerList);
            		$.each(data.buLedgerList,function(n,value) {
	           			var listtr = "<li><a href=\"#\" selectTag=\"ledger\" vid=\""+value.ledger+"\" vshow=\""+value.ledger+"\" title=\""+value.ledger+"\">"+value.ledger+"</a></li>";
	           			$("#ledgerUl").append(listtr);
	           			optionsaBind();
           	     	});
            	}
            }
        }
    });
}


/*清空因客户加载的数据*/
function clearCustomerInfo(){
	$("#customerabbname").val("");
	$("#customer").val("");
	$("#customercode").val("");
}

/*增加存货编码自动匹配*/
function addInventoryAutoCompleteChange($input){
	$input.autocomplete(encodeURI("/approvalajax/prApproval_findInventoryList"), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>存货编码</span> <span class='col-2'>存货名称</span></div>",
		minChars: 0,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.inventoryList == null){
            	return rows;
            }
            for(var i=0; i<data.inventoryList.length; i++){    
                rows[rows.length] = {    
                    data:data.inventoryList[i],              //下拉框显示数据格式   
                    value:data.inventoryList[i].invCode,     //选定后实际数据格式  
                    result:data.inventoryList[i].invCode   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.invCode + "</span> " + "<span class='col-2'>" + row.invName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.invCode + row.invName;
		},
		formatResult: function(row) {
			return row.invCode;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$(this).parents("tr").find("[tdTag=inventoryCode]").val(data.invCode);
		$(this).parents("tr").find("[tdTag=inventoryName]").val(data.invName);
		$(this).parents("tr").find("[tdTag=productLineName]").val(data.unionName);
		if(data.eccnNo!=null && data.eccnNo!="" && data.eccnNo.indexOf("00") != -1){
			$(this).parents("tr").find("[tdTag=produceNation]").css('display','block');
			$(this).parents("tr").find("[tdTag=produceNation]").html("<font color='red'>管制物品("+data.eccnNo+")！</font>")
			$(this).parents("tr").find("[tdTag=eccnNo]").val(data.eccnNo);
		}
	}).bind("unmatch", function(){
		$(this).parents("tr").find("[tdTag=inventoryCode]").val("");
	});
}

/*增加存货编码自动匹配*/
function addInventoryAutoComplete($input){
	$input.autocomplete(encodeURI("/approvalajax/prApproval_findInventoryList"), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>存货编码</span> <span class='col-2'>存货名称</span></div>",
		minChars: 0,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.inventoryList == null){
            	return rows;
            }
            for(var i=0; i<data.inventoryList.length; i++){    
                rows[rows.length] = {    
                    data:data.inventoryList[i],              //下拉框显示数据格式   
                    value:data.inventoryList[i].invCode,     //选定后实际数据格式  
                    result:data.inventoryList[i].invCode   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.invCode + "</span> " + "<span class='col-2'>" + row.invName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.invCode + row.invName;
		},
		formatResult: function(row) {
			return row.invCode;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		clearTr($(this).parents("tr"));
		$(this).parents("tr").find("[tdTag=inventoryCode]").val(data.invCode);
		$(this).parents("tr").find("[tdTag=inventoryName]").val(data.invName);
		$(this).parents("tr").find("[tdTag=productLineName]").val(data.unionName);
	}).bind("unmatch", function(){
		clearTr($(this).parents("tr"));
	});
}

/*清除行的数据*/
function clearTr($tr){
	$tr.find("input[filterNull!=true]").val("");
	$tr.find("[tdTag=shipQuantity]").val(0);
	$tr.find("[tdTag=inventoryCode]").validationEngine('hidePrompt');
}

/*取回数值，没有值的为0*/
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}

/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.removeAttr("hide");
	$copyTr.removeAttr("style");
	$tr.after($copyTr);
	addInventoryAutoComplete($copyTr.find("input[tdTag=inventoryCode]"));
}
/* 删除行 */
function delTr($obj){
	$obj.validationEngine('hidePrompt');
	$obj.remove();
}

/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
	var $trNum = $tbody.find("tr").size();
	for ( var i = $trNum-1; i >= 0; i--) {
		$trNum = $tbody.find("tr").size();
		var $tr = $tbody.find("tr").eq(i);
		if (checkEmptyTr($tr)) {
			if ($trNum > 1) {
				$tr.remove();
			}
		}
	}
}

/* 验证空行 */
function checkEmptyTr($tr) {
	var $inputNum = $tr.find("input").size();
	var flag = true; // 为空
	for ( var i = 0; i < $inputNum; i++) {
		var $input = $tr.find("input[filterNull!=true]").eq(i);
		if ($.trim($input.val()) != "") {
			flag = false; // 不为空
			break;
		}
	}
	return flag;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
	var $trs = $tbody.find("tr");/* 获取所有tr */
	var firstName = "prChangeMain.details";/* 前缀名称 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $inputNum = $tr.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $tr.find("input").eq(j);
			$input.attr("id", $input.attr("tdTag") + numtag);
			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
		}
		$tr.find("input[tdTag=sub_index]").val(i);
		$tr.find("input[tdTag=item]").val(i+1);
	}
}

/*用于上传文件使用*/
function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}