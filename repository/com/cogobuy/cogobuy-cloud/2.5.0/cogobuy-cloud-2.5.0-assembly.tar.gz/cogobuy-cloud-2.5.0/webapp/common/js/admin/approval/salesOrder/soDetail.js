/**
 * PM审核通过
 * @param parent
 */
function soPmApproval(parentId,returnUrl) {
	var $postinput = $("body").find("input[posttag^=Sandisk]");/* 获取所有tr */
	//for ( var i = 0; i < $postinput.size(); i++) {
	//	var $input = $postinput.eq(i);
	//	var $inputVal = $input.val();
	//	if($inputVal==""){
	//		dialog("Sandisk产品线必须维护POS成本","warning",false,2);
	//		return;	
	//	}
	//}
	
	var flag = false;
	
	//var trShows = $("body").find("tr[trTag='trData']");
	$("body").find("tr[trTag='trData']").each(function(){
		var $this = $(this);
		var $postinput_margin = $this.find("input[posttag^=margin]");/* 获取所有tr */
		//验证毛利是否符合要求，毛利小于0 or 毛利大于30%，则提示
		for ( var i = 0; i < $postinput_margin.size(); i++) {
			var $input_margin = $postinput_margin.eq(i);
			var $inputMarginVal = $input_margin.val();  //每一行的毛利
			if($inputMarginVal == "" || $inputMarginVal >= 30 || $inputMarginVal < 0){
				
				//dialog("第【"+ (i+1) +"】行毛利不符合要求，请检查输入的实际COST是否输入有误.","warning",false,6);
				//alert("第【"+ (i+1) +"】行毛利不符合要求，请检查输入的实际COST是否输入有误.");
				// return;
				/*ashanahzhang 20160805*/
				 var b = confirm("第【"+ (i+1) +"】行毛利不符合要求，请确认输入的实际COST是否正确.");
				 if(!b){
					 flag=true;
					 break;
				 }
				 /*ashanahzhang 20160805*/
			}
		}
	});
	
	if(!flag){//当所有毛利都通过时
		//var orderBa = $("input[name=orderBa]:checked").val();
		//if( orderBa == undefined){
		//	dialog("请选择订单属性","warning",false,2);
		//	return;
		//}else{
		$(".button-yellow").hide();
		var data = {
				"salesOrder.id" : parentId,
				// "orderBa" : orderBa,
				"mails" : getApprovalMail()
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/approval/salesOrder_pmApproval"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					window.location.href = returnUrl;
				} else {
					$(".button-yellow").show();
					dialog(returnStr, "unsuccess", true, 10);
				}
			}
		});
		//}
	}
	
}


/**
 * CT审核通过
 * @param parent
 */
function soCtApproval(parentId,returnUrl) {
	
	var flag = false;
	
	$("body").find("tr[trTag='trData']").each(function(){
		var $this = $(this);
		var $postinput_margin = $this.find("input[posttag^=margin]");/* 获取所有tr */
		//验证毛利是否符合要求，毛利小于0 or 毛利大于30%，则提示
		for ( var i = 0; i < $postinput_margin.size(); i++) {
			var $input_margin = $postinput_margin.eq(i);
			var $inputMarginVal = $input_margin.val();  //每一行的毛利
			if($inputMarginVal == "" || $inputMarginVal >= 30 || $inputMarginVal < 0){
				
				//dialog("第【"+ (i+1) +"】行毛利不符合要求，请检查输入的实际COST是否输入有误.","warning",false,6);
				//alert("第【"+ (i+1) +"】行毛利不符合要求，请检查输入的实际COST是否输入有误.");
				// return;
				/*ashanahzhang 20160805*/
				 var b = confirm("第【"+ (i+1) +"】行毛利不符合要求，请确认输入的实际COST是否正确.");
				 if(!b){
					flag=true;
					break;
				 }
				 
			}
		}
	});
	
	if(!flag){//当所有毛利都通过时
			 $(".button-yellow").hide();
				var data = {
						"salesOrder.id" : parentId,
						"mails" : getApprovalMail()
				};
				$.ajax({
					type : "GET",
					url : encodeURI("/approval/salesOrder_ctApproval"),
					data : data,
					success : function(returnStr) {
						if (returnStr == 'success') {
							dialog("成功", "success", true, 2);
							window.location.href = returnUrl;
						} else {
							$(".button-yellow").show();
							dialog(returnStr, "unsuccess", true, 10);
						}
					}
				});
			 
	}
	
	
}

/**
 * CT需要领导审批
 * @param parent
 */
function soCtApproval2(parent,parentId,returnUrl) {
	
	var flag = false;
	
	$("body").find("tr[trTag='trData']").each(function(){
		var $this = $(this);
		var $postinput_margin = $this.find("input[posttag^=margin]");/* 获取所有tr */
		//验证毛利是否符合要求，毛利小于0 or 毛利大于30%，则提示
		for ( var i = 0; i < $postinput_margin.size(); i++) {
			var $input_margin = $postinput_margin.eq(i);
			var $inputMarginVal = $input_margin.val();  //每一行的毛利
			if($inputMarginVal == "" || $inputMarginVal >= 30 || $inputMarginVal < 0){
				
				//dialog("第【"+ (i+1) +"】行毛利不符合要求，请检查输入的实际COST是否输入有误.","warning",false,6);
				//alert("第【"+ (i+1) +"】行毛利不符合要求，请检查输入的实际COST是否输入有误.");
				// return;
				/*ashanahzhang 20160805*/
				 var b = confirm("第【"+ (i+1) +"】行毛利不符合要求，请确认输入的实际COST是否正确.");
				 if(!b){
					 flag=true;
					 break;
				 }
				 
			}
		}
	});
	
	if(!flag){//当所有毛利都通过时
		
		$(".button-yellow").hide();
		var data = {
			"parent" : parent,
			"parentId" : parentId,
			"mails" : ""
		};
			$.ajax({
				type : "GET",
				url : encodeURI("/approval/flowApproval_approval"),
				data : data,
				success : function(returnStr) {
					if (returnStr == 'success') {
						dialog("成功", "success", true, 2);
						window.location.href = returnUrl;
					} else {
						$(".button-yellow").show();
						dialog(returnStr, "unsuccess", true, 10);
					}
				}
			});
			
			 
	}
	
	
}