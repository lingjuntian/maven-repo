function debug() {
	if (window.console && window.console.log) {
		window.console.log(arguments);
	}
}
var autoCompleteInventoryList;
$(function() {
	/*增加验证*/
	$("#buName,#buId,#vendor,#currencyName,#currencyCode,[tdTag=inventoryCode]").addClass("validate[required]");
	$("[tdTag=taxUnitPrice],[tdTag=unitPrice],[tdTag=sum]").addClass("validate[custom[amountSixPoint]]");
	$("[tdTag=quantity],[tdTag=fcMonth1],[tdTag=fcMonth2],[tdTag=fcMonth3],[tdTag=fcMonth4]").addClass("validate[custom[numberFormar]]");
	/* 模拟select下拉列表选择值 */
	optionsaBind();

	/*客户自动提示*/
	autoFillCustomer();
	
	/*订单自动提示*/
	autoFillOrderList();
	
	/*业务员*/
	autoCompletePerson();
	
	/*初始化明细区域需要绑定的事件*/
	init_table(1);
	
	/*销售订单号未输入时，明细区域表格直接恢复成原始状态，可自由输入*/
	$("#salesorderno").blur(function(){
		if($(this).val()==""){
			//debug("111");
			CreatePrDetail(0,null,null);
		}
	});
});

/*表格初始化
 isBindTrClick : 是否绑定点击表格最后一行时，自动添加一个新行事件，如果是参照销售订单的话，就不需要在绑定这个事件了
 */
function init_table(isBindTdClick){
	if(isBindTdClick == 1){
		//debug("Add Click Function:"+isBindTdClick);
		/* 添加一行 */
		$("tr input").click(function(){
			var $tr = $(this).parents("tr");
			if($tr.nextAll().length==0){
				addTr($tr);
			}
		});
	} else {
		//debug("Remove Click Function:"+isBindTdClick);
		$('tr input').unbind("click");
	}
	/*存货编码*/
	addInventoryAutoComplete($("#detailListTbody").find("input[tdTag=inventoryCode]"));
	/*增加日期控件*/
	$("input[tdTag=expectDate],#createTime").click(function() {
		WdatePicker();
	});
	$("#createTime").val(GetTodayDateStr());
	/*增加显示提交按钮*/
	$(document).keydown(function(event){ 
		 if (event.ctrlKey && event.keyCode == 122) {
			 $("#submit").show();
		 }
	});
	
	/*删除一行*/
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $length = $obj.parents("tbody").find("tr").length;
		if($length<2){
			dialog("请最少保留1行","warning",false,2);
			return false;
		}
		delTr($obj);
	});
	/*绑定根据含税单价算合计*/
	$("input[tdTag=taxUnitPrice]").bind("change",function(){ 
		calTaxSum($(this).parents("tr"));
	});
	/*绑定数量每条详情的合计*/
	$("input[tdTag=quantity]").bind("change",function(){ 
		calTaxSum($(this).parents("tr"));
	});
	/*绑定根据无税单价算合计*/
	$("input[tdTag=unitPrice]").bind("change",function(){ 
		calTaxSum($(this).parents("tr"));
	});
	
	/*显示创建页面Forecast的月份*/
	var myDate = new Date();
	$("span[tag=month]").each(function(i){
		var month = myDate.getMonth()+ i + 2;
		if(month > 12){
			var newDate = new Date();
			newDate.setMonth(month);
			$(this).text(newDate.getMonth());
		}else{
			$(this).text(month);
		}
	});
	/*显示详情页面Forecast的月份*/
	var myDate_confirm = new Date();
	$("span[tag=month_confirm]").each(function(i){
		var month = myDate_confirm.getMonth()+ i + 2;
		if(month > 12){
			var newDate = new Date();
			newDate.setMonth(month);
			$(this).text(newDate.getMonth());
		}else{
			$(this).text(month);
		}
	});
	
	/*选择系统日期*/
	$("#office").click(function(){
		if($(this).attr("checked")){
			$("#createTime_li").show();
		}else{
			$("#createTime_li").hide();
		}
	});
}

/*计算行含税总和、税额等*/
function calTaxSum($tr){
	/*数量*/
	var quantity = changeNum($tr.find("input[tdTag=quantity]").val());
	/*含税单价*/
	var taxUnitPrice = changeNum($tr.find("input[tdTag=taxUnitPrice]").val());
	/*无税单价*/
	var unitPrice = changeNum($tr.find("input[tdTag=unitPrice]").val());
	/*含税总额*/
	var sum = multiply(quantity,taxUnitPrice);
	if(sum == 0){
		sum = multiply(quantity,unitPrice);
	}
	$tr.find("input[tdTag=sum]").val(changeFourDecimal(sum));
}

/*绑定下拉选项*/
function optionsaBind(){
	$(".options-select .options a").unbind("click");
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=show]").val($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=id]").val($(this).attr("vid"));
		$(this).parents(".options-select").find("input[tag=show]").validationEngine('hidePrompt');
		$(this).parents(".options-select").find(".options").addClass("none");
		
		var $selectTag = $(this).attr("selectTag");
		//debug($selectTag);
		if($selectTag == 'buname'){ 
			//debug($(this).attr("vid"));
			autoFillLedger($(this).attr("vid"));
		}
		if($selectTag == 'ledger'){ 
			//debug($(this).attr("vid"));
			$("#hidLedger").val($(this).attr("vid"));
			//debug($("#hidLedger").val());
		}
		return false;
	});
}

/*将选择的销售订单的明细数据填充到数据区域，然后补全其他信息后，直接生成PR单*/
function autoFillOrderList(){
	var data_all = null;
	//https://s.cogobuy.com/approvalajax/salesOrderApproval_findCustomerList?q=bj&limit=10&timestamp=1439800842326&ledger=811
	$("#salesorderno").autocomplete(encodeURI("/approvalajax/prApproval_findOutStandingSalesOrderByCondition"), {
		/**加自定义表头**/
		//tableHead: "<div><span style='width:100%' class='col-1'>Sales Order No</span></div>",
		minChars: 0,
		width: 310,
		cacheLength: 1,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		onBegin: function(options) { //修改--用于动态改变ledger的值
			//debug($("#customercode").val());
            options.extraParams.ledger= $("#hidLedger").val();
            options.extraParams.customerCode = $("#customercode").val();
            dist = Math.random(); 
            return options;
        },
		dataType: 'json',
		parse: function(data) {  
			data_all = data;
            var rows = [];  
            if(data == null || data.list == null){
            	return rows;
            }
            var tmp_orderno = "";
            for(var i=0; i<data.list.length; i++){
            	//去除重复的单号
            	if(tmp_orderno == ""){
            		tmp_orderno = data.list[i].salesOrderNo;
            		rows[rows.length] = {
                            data:data.list[i],              //下拉框显示数据格式   
                            value:data.list[i].salesOrderNo,     //选定后实际数据格式  
                            result:data.list[i].salesOrderNo   //选定后输入框显示数据格式  
                        };
            	}
            	else{
            		if(tmp_orderno != data.list[i].salesOrderNo){
            			rows[rows.length] = {
                                data:data.list[i],              //下拉框显示数据格式   
                                value:data.list[i].salesOrderNo,     //选定后实际数据格式  
                                result:data.list[i].salesOrderNo   //选定后输入框显示数据格式  
                            };
            		}
            		tmp_orderno = data.list[i].salesOrderNo;
            	}
            }
            //debug(rows);
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span  style='width:100%' class='col-1'>" + row.salesOrderNo + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.salesOrderNo;
		},
		formatResult: function(row) {
			return row.salesOrderNo;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		CreatePrDetail(1,data.salesOrderNo,data_all);
	}).bind("unmatch", function(){
		/*clearCustomerInfo();*/
	});
}

/*获取选中的单号的明细，然后将型号和数量写入明细区域*/
function CreatePrDetail(IsReferSalesOrder,$salesOrderNo,data){
	$("#detailListTbody").empty();
	if(IsReferSalesOrder == 1){
		for(var i=0; i<data.list.length; i++){
			if(data.list[i].salesOrderNo == $salesOrderNo){
				var tr_string = "<tr>"+
				"<td class=\"first supplier-model\"><div>"+
				"		<input type=\"text\" tdTag=\"inventoryCode\" class=\"input-text\" value=\""+data.list[i].inventoryCode+"\" />"+
				"		<!-- 产品线名称-->"+
				"		<input type=\"hidden\" tdTag=\"productLineName\" class=\"input-text\" value=\""+data.list[i].productLine+"\" />"+
				"		<!-- 销售订单号-->"+
				"		<input type=\"hidden\" tdTag=\"saleOrderNo\" class=\"input-text\" value=\""+$salesOrderNo+"\" />"+
				"		<!-- 销售订单子表ID-->"+
				"		<input type=\"hidden\" tdTag=\"iorderdid\" class=\"input-text\" value=\""+data.list[i].iorderdid+"\" />"+
				"		<!-- 销售订单子表标识-->"+
				"		<input type=\"hidden\" tdTag=\"isosid\" class=\"input-text\" value=\""+data.list[i].isosid+"\" />"+
				"		<!-- 物料名称-->"+
				"		<input type=\"hidden\" tdTag=\"inventoryName\" class=\"input-text\" value=\""+data.list[i].inventoryName+"\" />"+
				"		<!-- 行号-->"+
				"	  <input type=\"hidden\" tdTag=\"rowNo\" class=\"input-text\" value=\"${(detail.rowNo?c)!''}\" />"+
				"	  <!-- sub_index-->"+
				"		<input type=\"hidden\" tdTag=\"sub_index\" value=\"${(detail.sub_index?c)!''}\" />"+
				"	</div></td>"+
				"	<td class=\"sl-code\"><div><input type=\"text\" tdTag=\"slCode\"  value=\"\" class=\"input-text\"  /></div></td>"+
				"	<td class=\"quantity\"><div><input type=\"text\" tdTag=\"quantity\" value=\""+data.list[i].quantity+"\" class=\"input-text\" /></div></td>"+
				"	<td class=\"price price-istax\"><div><input type=\"text\" tdTag=\"taxUnitPrice\" value=\"\" class=\"input-text\" /></div></td>"+
				"	<td class=\"price price-notax\"><div><input type=\"text\" tdTag=\"unitPrice\" value=\"\" class=\"input-text\" /></div></td>"+
				"	<td class=\"amount\"><div><input type=\"text\" tdTag=\"sum\" value=\"\" class=\"input-text\" /></div></td>"+
				"	<td class=\"quote\"><div><input type=\"text\" tdTag=\"quote\" value=\"\" class=\"input-text\" /></div></td>"+
				"	<td class=\"customer-name customer-name-end\"><div><input type=\"text\" tdTag=\"customer\" value=\"\" class=\"input-text\" /></div></td>"+
				"	<td class=\"customer-name customer-name-purchasing\"><div><input type=\"text\" tdTag=\"purchaseCus\" value=\"\" class=\"input-text\" /></div></td>"+
				"	<td class=\"po-number\"><div><input type=\"text\" tdTag=\"cusPono\" value=\"\" class=\"input-text\" /></div></td>"+
				"	<td class=\"time\"><div><input type=\"text\" tdTag=\"expectDate\" value=\"\" class=\"input-text input-text-date\" /></div></td>"+
				"	<td class=\"quantity quantity1\"><input type=\"text\" tdTag=\"fcMonth1\" value=\"\" class=\"input-text\" /></td>"+
				"	<td class=\"quantity quantity2\"><input type=\"text\" tdTag=\"fcMonth2\" value=\"\" class=\"input-text\" /></td>"+
				"	<td class=\"quantity quantity3\"><input type=\"text\" tdTag=\"fcMonth3\" value=\"\" class=\"input-text\" /></td>"+
				"	<td class=\"quantity quantity4\"><input type=\"text\" tdTag=\"fcMonth4\" value=\"\" class=\"input-text\" /></td>"+
				"	<td class=\"ncnr\"><div><input type=\"checkbox\" tdTag=\"ncnr\" value=\"1\" filterNull=\"true\" /></div></td>"+
				"	<td class=\"stop\"><div><input type=\"checkbox\" tdTag=\"stop\" value=\"1\" filterNull=\"true\" /></div></td>"+
				"	<td class=\"last works\"><div><a href=\"javascript:;\" title=\"Delete\" class=\"del-text\">Delete</a></div></td>"+
				//"	<td class=\"last works\"><div></div></td>"+
				"</tr>";
				$("#detailListTbody").append(tr_string);
			}
		} 
		init_table(1);
    } else {
    	for(var i=0; i < 2; i++){
			var tr_string = "<tr>"+
			"	<td class=\"first supplier-model\"><div>"+
			"		<input type=\"text\" tdTag=\"inventoryCode\" class=\"input-text\" value=\"\" />                                                                     "+
			"		<!-- 产品线名称-->"+
			"		<input type=\"hidden\" tdTag=\"productLineName\" class=\"input-text\" value=\"${(detail.productLineName)!''}\" />                                                              "+
			"		<!-- 销售订单号-->"+
			"		<input type=\"hidden\" tdTag=\"saleOrderNo\" class=\"input-text\" value=\"\" />                                                              "+
			"		<!-- 物料名称-->                                                                                                                                                               "+
			"		<input type=\"hidden\" tdTag=\"inventoryName\" class=\"input-text\" value=\"${(detail.inventoryName)!''}\" />                                                                  "+
			"		<!-- 行号-->                                                                                                                                                                   "+
			"	  <input type=\"hidden\" tdTag=\"rowNo\" class=\"input-text\" value=\"${(detail.rowNo?c)!''}\" />                                                                                "+
			"	  <!-- sub_index-->                                                                                                                                                              "+
			"		<input type=\"hidden\" tdTag=\"sub_index\" value=\"${(detail.sub_index?c)!''}\" />                                                                                             "+
			"	</div></td>                                                                                                                                                                      "+
			"	<td class=\"sl-code\"><div><input type=\"text\" tdTag=\"slCode\"  value=\"\" class=\"input-text\"  /></div></td>"+
			"	<td class=\"quantity\"><div><input type=\"text\" tdTag=\"quantity\" value=\"\" class=\"input-text\" /></div></td>"+
			"	<td class=\"price price-istax\"><div><input type=\"text\" tdTag=\"taxUnitPrice\" value=\"\" class=\"input-text\" /></div></td>"+
			"	<td class=\"price price-notax\"><div><input type=\"text\" tdTag=\"unitPrice\" value=\"\" class=\"input-text\" /></div></td>"+
			"	<td class=\"amount\"><div><input type=\"text\" tdTag=\"sum\" value=\"\" class=\"input-text\" /></div></td>"+
			"	<td class=\"quote\"><div><input type=\"text\" tdTag=\"quote\" value=\"\" class=\"input-text\" /></div></td>"+
			"	<td class=\"customer-name customer-name-end\"><div><input type=\"text\" tdTag=\"customer\" value=\"\" class=\"input-text\" /></div></td>"+
			"	<td class=\"customer-name customer-name-purchasing\"><div><input type=\"text\" tdTag=\"purchaseCus\" value=\"\" class=\"input-text\" /></div></td>"+
			"	<td class=\"po-number\"><div><input type=\"text\" tdTag=\"cusPono\" value=\"\" class=\"input-text\" /></div></td>"+
			"	<td class=\"time\"><div><input type=\"text\" tdTag=\"expectDate\" value=\"\" class=\"input-text input-text-date\" /></div></td>"+
			"	<td class=\"quantity quantity1\"><input type=\"text\" tdTag=\"fcMonth1\" value=\"\" class=\"input-text\" /></td>"+
			"	<td class=\"quantity quantity2\"><input type=\"text\" tdTag=\"fcMonth2\" value=\"\" class=\"input-text\" /></td>"+
			"	<td class=\"quantity quantity3\"><input type=\"text\" tdTag=\"fcMonth3\" value=\"\" class=\"input-text\" /></td>"+
			"	<td class=\"quantity quantity4\"><input type=\"text\" tdTag=\"fcMonth4\" value=\"\" class=\"input-text\" /></td>"+
			"	<td class=\"ncnr\"><div><input type=\"checkbox\" tdTag=\"ncnr\" value=\"1\" filterNull=\"true\" /></div></td>"+
			"	<td class=\"stop\"><div><input type=\"checkbox\" tdTag=\"stop\" value=\"1\" filterNull=\"true\" /></div></td>"+
			"	<td class=\"last works\"><div><a href=\"javascript:;\" title=\"Delete\" class=\"del-text\">Delete</a></div></td>"+
			"</tr>";
			$("#detailListTbody").append(tr_string);
		} 
    	init_table(1);
	}
}

/*根据BU加载账套*/
function autoFillLedger($bu){
	$("#ledgerS").text("Selected");
	//$("#currencyName").val("");
	//$("#currencyCode").val("");
	//$("#exchangeRate").val(0);
	//$("#taxRate").val(0);
	$("#ledgerUl").empty();
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/prApproval_findLedgerListByBU?bu="+$bu),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null){
            	if(data.buLedgerList != null){//动态填充流程
            		//debug(data.buLedgerList);
            		$.each(data.buLedgerList,function(n,value) {
	           			var listtr = "<li><a href=\"#\" selectTag=\"ledger\" vid=\""+value.ledger+"\" vshow=\""+value.ledger+"\" title=\""+value.ledger+"\">"+value.ledger+"</a></li>";
	           			$("#ledgerUl").append(listtr);
	           			optionsaBind();
           	     	});
            	}
            }
        }
    });
}

/*加载对应账套的客户*/
function autoFillCustomer(){
	//var ledger = $("#hidLedger").val();
	//debug(ledger);
	$("#customer").autocomplete(encodeURI("/approvalajax/salesOrderApproval_findCustomerList"), {
		/**加自定义表头**/
		tableHead: "<div><span style='width:40%' class='col-1'>Customer Code</span> <span style='width:58%' class='col-2'>Customer Name</span></div>",
		minChars: 0,
		width: 310,
		cacheLength: 1,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		onBegin: function(options) { //修改--用于动态改变ledger的值
			//debug($("#hidLedger").val());
            options.extraParams.ledger = $("#hidLedger").val();
            return options;
        },
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.customerList == null){
            	return rows;
            }
            for(var i=0; i<data.customerList.length; i++){    
                rows[rows.length] = {    
                    data:data.customerList[i],              //下拉框显示数据格式   
                    value:data.customerList[i].cusName,     //选定后实际数据格式  
                    result:data.customerList[i].cusName   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span  style='width:40%' class='col-1'>" + row.cusCode + "</span> " + "<span style='width:58%' class='col-2'>" + row.cusName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.cusCode+row.cusName;
		},
		formatResult: function(row) {
			return row.cusName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		clearCustomerInfo();
		$("#customerabbname").val(data.cusAbbName);
		$("#customer").val(data.cusName);
		$("#customercode").val(data.cusCode);
		//$("#licensecode").val(data.licensecode);
	}).bind("unmatch", function(){
		clearCustomerInfo();
	});
}

/*清空因客户加载的数据*/
function clearCustomerInfo(){
	$("#customerabbname").val("");
	$("#customer").val("");
	$("#customercode").val("");
}

/*增加存货编码自动匹配*/
function addInventoryAutoComplete($input){
	$input.autocomplete(encodeURI("/approvalajax/prApproval_findInventoryList"), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>Part No.</span> <span class='col-2'>Description</span></div>",
		minChars: 0,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.inventoryList == null){
            	return rows;
            }
            for(var i=0; i<data.inventoryList.length; i++){    
                rows[rows.length] = {    
                    data:data.inventoryList[i],              //下拉框显示数据格式   
                    value:data.inventoryList[i].invCode,     //选定后实际数据格式  
                    result:data.inventoryList[i].invCode   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.invCode + "</span> " + "<span class='col-2'>" + row.invName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.invCode + row.invName;
		},
		formatResult: function(row) {
			return row.invCode;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		clearTr($(this).parents("tr"));
		$(this).parents("tr").find("[tdTag=inventoryCode]").val(data.invCode);
		$(this).parents("tr").find("[tdTag=inventoryName]").val(data.invName);
		$(this).parents("tr").find("[tdTag=productLineName]").val(data.unionName);
	}).bind("unmatch", function(){
		clearTr($(this).parents("tr"));
	});
}

/*加载业务员的自动匹配功能*/
function autoCompletePerson(){
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/prApproval_findAllBizADErpUser"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.personList != null){
				$("#personName").autocomplete(data.personList, {
					/**加自定义表头**/
					tableHead: "<div><span class='col-1'>Salesman EMail</span><span class='col-2'>Salesman</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span class='col-1'>" + row.ADUserEmail + "</span> <span class='col-2'>"+ row.ADUserName +"</span>";
					},
					formatMatch: function(row, i, max) {
						return row.ADUserName+ " | " + row.ADUserEmail;
					},
					formatResult: function(row) {
						return row.ADUserName;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#personName").val(data.ADUserName);
					$("#personCode").val(data.ADUserid);
					$("#personEmail").val(data.ADUserEmail);
				}).bind("unmatch", function(){
					$("#personName").val("");
					$("#personCode").val("");
				});
			}
		}
	}); 
}


/*清除行的数据*/
function clearTr($tr){
	$tr.find("input[filterNull!=true]").val("");
	$tr.find("[tdTag=inventoryCode]").validationEngine('hidePrompt');
}

/*取回数值，没有值的为0*/
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}

/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.removeAttr("hide");
	$copyTr.removeAttr("style");
	$tr.after($copyTr);
	addInventoryAutoComplete($copyTr.find("input[tdTag=inventoryCode]"));
}
/* 删除行 */
function delTr($obj){
	$obj.validationEngine('hidePrompt');
	$obj.remove();
}

/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
	var $trNum = $tbody.find("tr").size();
	for ( var i = $trNum-1; i >= 0; i--) {
		$trNum = $tbody.find("tr").size();
		var $tr = $tbody.find("tr").eq(i);
		if (checkEmptyTr($tr)) {
			if ($trNum > 1) {
				$tr.remove();
			}
		}
	}
}

/* 验证空行 */
function checkEmptyTr($tr) {
	var $inputNum = $tr.find("input").size();
	var flag = true; // 为空
	for ( var i = 0; i < $inputNum; i++) {
		var $input = $tr.find("input[filterNull!=true]").eq(i);
		if ($.trim($input.val()) != "") {
			flag = false; // 不为空
			break;
		}
	}
	return flag;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
	var $trs = $tbody.find("tr");/* 获取所有tr */
	var firstName = "prMain.details";/* 前缀名称 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $inputNum = $tr.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $tr.find("input").eq(j);
			$input.attr("id", $input.attr("tdTag") + numtag);
			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
		}
		$tr.find("input[tdTag=sub_index]").val(i);
		$tr.find("input[tdTag=rowNo]").val(i+1);
	}
}

/*用于上传文件使用*/
function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}