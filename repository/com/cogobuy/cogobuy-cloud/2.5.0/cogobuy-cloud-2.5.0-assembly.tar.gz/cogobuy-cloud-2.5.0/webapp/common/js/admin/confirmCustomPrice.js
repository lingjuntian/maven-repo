
$('#dataTables').dataTable( {
			"bPaginate": false,
			"bLengthChange": false,
			"bFilter": false,//不需要筛选
			"bSort": false,//需要排序
			"aaSorting": [],//不需要初始化排序
			"bInfo": false,
			"bAutoWidth": false,
			"bScrollCollapse": false
		} );

/*查询*/
$("#select").click(function(){
	$("#selectForm").submit();
});

/*复选框*/
$("#checkboxAll").click(function(){
	if(!document.getElementById("checkboxAll").checked){
		$("input[flag='checkflag']").attr("checked",false);
	}
	else{
		$("input[flag='checkflag']").attr("checked",true);
	}
});
$("[flag=checkflag]").click(function(){
	var flag = true;
	$("[flag=checkflag]").each(function(){
		if(!this.checked){
			flag = false;
		}
	});
	$("#checkboxAll").attr('checked', flag);
});
	
/*关闭弹出框*/
$("[tag=close]").click(function(){
	$(this).parents("form")[0].reset();
	$(".popup,.popup-mask").hide();
	for (var i = 0; i < $("form#updateForm input.input-text").length; i++) {
		$("form#updateForm input.input-text:eq(" + i + ")").validationEngine("hidePrompt");
	}
});
$("#pSupplierModel,#pProductName,#pRateReporting").addClass("validate[required]");
$("#pPrice").addClass("validate[required,custom[number]");

/* 修改 */
$(".edit-text").click(function(){
	var $pSupplierModel = $(this).parents("tr").find("div[name=inventoryCode]").attr("val");
//	var $pSupplierModel = $(this).parents("tr").find(".supplier-model").text();
	var $pProductName = $(this).parents("tr").find(".product-name").text();
	var $pProductLine = $(this).parents("tr").find(".product-line").text();
	var $pCost = $(this).parents("tr").find("div[name=cost]").attr("val");
	var $customsPriceId = $(this).parents("tr").find("input[name=CustomsPriceId]").val();
	$("#pSupplierModel").val($pSupplierModel);
	$("#pProductName").val($pProductName);
	$("#pProductLine").val($pProductLine);
	$("#pPrice").val($pCost);
	$("#customsPriceId").val($customsPriceId);
	pagePopup(".popup-customs-declaration-data-manage-price",true);
});

/*提交修改*/
$("#updateForm").validationEngine({validationEventTriggers:"blur", inlineValidation:true, success:false, promptPosition:"topRight"});

$("#submit").click(function(){
	var error = $("#updateForm").validationEngine('validate');
	if(error){
		$(".popup-customs-declaration-data-manage,.popup-mask").hide();
		$("#updateForm").ajaxSubmit(function(returnStr){
	        if (returnStr == "error") {
	        	dialog("操作失败，请稍后重试.","unsuccess",true,1);	 
	        	return;
	        } else{
	            dialog("操作成功.","success",true,1);
		        setTimeout(function(){$("#comfirmForm").submit();},1000);
		        window.location.reload(true);
	        }
	  	});
	}
});

/*确认价格*/
$("#confirmPrice").click(function(){
	var checked = $("#dataTables [flag=checkflag]:checkbox:checked");
	var size = checked.size();
	var checkedIds = new Array();
	//检查是否已勾选某型号来生成报关单
	if(size > 0){
		//$("#goTopButton").trigger("click");
		for(var i = 0; i <= size-1; i++){ //复制被选的行，并修改样式
			 var checkInput = checked.eq(i);
			 var tr = checkInput.parents("tr").eq(0);
			 var id = tr.find("input[flag=checkflag]").attr("detailId");
			 checkedIds[i] = id;
			 tr.remove();
		 }
		$.get(encodeURI('/admin/customsApply_confirmCustomPrice?priceConfirmId='+checkedIds.toString()));
		dialog("价格已确认完毕！","success",true,1);
	 }
	 else{
		 dialog("请选择一条记录！","unsuccess",true,1);
	 }
});

