$(function() {
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
		if (error) {
			countData(); /* 统计数量、金额合计等 */
			copyValueToConfig();/* 将新建页面的数值写入确认页面 */
			switchPageForCreate();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
			copyFileList();/*上传附件公用*/
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		switchPageForConfirm();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
    	$("#submit").hide();
		$("#salesOrderForm").ajaxSubmit(function(returnStr) {
			if(returnStr == "error"){
				$("#submit").show();
				dialog("修改失败，请稍后再试","unsuccess",true,1);
			}else{
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					dialog("修改成功","success",true,1);
					setTimeout(function(){window.location = "/approval/salesOrder_show?salesOrder.id="+id;},1000);	  
				}
			}
	        return false;
		});
	});
});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#salesOrderForm").validationEngine('validate');
}

/* 统计数量、金额合计等 */
function countData() {
	/* 总数量 */
	var totalQuantity = 0;
	/* 含税总额 */
	var totalTaxSum = 0;
	/* 无税总额 */
	var totalSum = 0;
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		totalQuantity = add(totalQuantity, changeNum($tr.find("input[tdTag=quantity]").val()));
		totalTaxSum = add(totalTaxSum, changeNum($tr.find("input[tdTag=taxSum]").val()));
		totalSum = add(totalSum, changeNum($tr.find("input[tdTag=sum]").val()));
	}
	$("#totalQuantity").val(changeTwoDecimal(totalQuantity));
	$("#totalTaxSum").val(changeFourDecimal(totalTaxSum));
	$("#totalSum").val(changeFourDecimal(totalSum));
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*######################详情列表BEGIN*/
	/*详情*/
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		var closeStr = "";
		if($tr.find("[tdTag=closed]").val() == $("#closeStatus").val()){
			closeStr = "class=\"order-close\" title=\"已关闭\"";
		}
		var trString = "<tr "+closeStr+"><td class=\"first num\"><div>"+$tr.find("input[tdTag=item]").val()+"</div></td>"
		 	+ "<td class=\"supplier-model\"><div>"+$tr.find("input[tdTag=inventoryCode]").val()+"</div></td>"
			+ "<td class=\"material-number\"><div>"+$tr.find("input[tdTag=customerInventoryCode]").val()+"</div></td>"
			+ "<td class=\"product-desc\"><div>"+$tr.find("input[tdTag=inventoryName]").val()+"</div></td>"
			+ "<td class=\"euc-number\"><div>"+$tr.find("input[tdTag=euc]").val()+"</div></td>"
			+ "<td class=\"license-number\"><div>"+$tr.find("input[tdTag=license]").val()+"</div></td>"
			+ "<td class=\"quantity\"><div>"+fmoney(changeNum($tr.find("input[tdTag=quantity]").val()),0)+"</div></td>"
			+ "<td class=\"price price0\"><div>"+fmoney(changeNum($tr.find("input[tdTag=taxUnitPrice]").val()),6)+"</div></td>"
			+ "<td class=\"price price1\"><div>"+fmoney(changeNum($tr.find("input[tdTag=unitPrice]").val()),6)+"</div></td>"
			+ "<td class=\"price price2\"><div>"+fmoney(changeNum($tr.find("input[tdTag=taxSum]").val()),4)+"</div></td>"
			+ "<td class=\"eccn-number\"><div>"+$tr.find("input[tdTag=eccn]").val()+"</div></td>"
			+ "<td class=\"mpq\"><div>"+$tr.find("input[tdTag=mpq]").val()+"</div></td>"
			+ "<td class=\"last time\"><div>"+$tr.find("input[tdTag=expectDate]").val()+"</div></td></tr>";
		$("#detailListTbody_confirm").append(trString);
	}
	/*合计行*/
	var totalString = "<tr class=\"total\"><td class=\"first num\"><div></div></td><td class=\"supplier-model\"><div></div></td>"
			+ "<td class=\"material-number\"><div></div></td>"
			+ "<td class=\"product-desc\"><div></div></td>"
			+ "<td class=\"euc-number\"><div></div></td>"
			+ "<td class=\"license-number\"><div>总计：</div></td>"
			+ "<td class=\"quantity\"><div>"+fmoney($("#totalQuantity").val(),0)+"</div></td>"
			+ "<td class=\"price price0\"><div></div></td>"
			+ "<td class=\"price price1\"><div></div></td>"
			+ "<td class=\"price price2\"><div>"+fmoney($("#totalTaxSum").val(),4)+"</div></td>"
			+ "<td class=\"eccn-number\"><div></div></td>"
			+ "<td class=\"mpq\"><div></div></td>"
			+ "<td class=\"last time\"><div></div></td></tr>";
	$("#detailListTbody_confirm").append(totalString);
	/*######################详情列表END*/
}

/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
function switchPageForCreate() {
	$("#write").hide();
	$("#confirm").show();
	return false;
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").hide();
	$("#write").show();
}