function ajaxLoading(){
	var maskHTML = '<div id="ajax-mask"></div>';
	var animation = "<div id='animation'></div>";
	$("body").append(maskHTML,animation);
	ajax_mask($("#ajax-mask"));
	showImg($("#animation"));
}

function ajaxLoaded(){
	$("#animation").remove();
	$("#ajax-mask").remove();
}

/* 锁层样式 */
function ajax_mask($obj){
	var cw = document.documentElement.clientWidth ;
	var ch = document.documentElement.clientHeight ;
	var st = document.body.scrollTop||document.documentElement.scrollTop ;
	$($obj).css({backgroundColor:"#000",position:"fixed",left:0,top:0,zIndex:1000,opacity:0.2,display:"block",width:cw+"px",height:ch+"px"});
	if($.browser.msie && $.browser.version == 6.0){
		$($obj).css({position:"absolute",top:st+"px"});
	}
}

function showImg($obj){
	$($obj).css({position:"fixed",left:"50%",top:"45%",zIndex:"1001"});
	$($obj).append("<img src='/common/img/preload.gif'/>");
}


