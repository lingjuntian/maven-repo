$(function() {
	/*表格修饰*/
	$(".table-list > table").decorateList();
	$(".details-text,.copy-text").click(function(event) {
		event.stopPropagation();
	});
	
	$("#detail").click(function(event) {
		event.stopPropagation();
	});
	
	/* 日期控件*/
	$("input[id$=Date]").click(function(){
		WdatePicker({dateFmt:'yyyy-MM-dd',onpicked:function(){$(this).validationEngine('hidePrompt');}});
	});
	
	$("#checkAll").click(function(){
		var checked = $(this).attr("checked");
		$("input[name='export']").each(function(){
			$(this).attr("checked",checked);
		});
	});
	
    /*取消弹出框*/
	$("[closeTag=close]").click(function(){
		$(".popup-mask,.popup").hide();
		return false;
	});
	
	/* 添加 */
	$("a[tag=exportplp]").click(function(){
		pagePopup(".popup-cost-approval-add-credit-type-person",true);
	});
	
	/*提交导出列表*/
	$("#addButton").click(function(){
		$(".popup-mask,.popup-cost-approval-add-credit-type-person").hide();
		$("#addForm").submit();
	});
});

function exportPayment(){
	var url = "/payment/payment_export";
	var exportIds = "?";
	$("input[name='export']:checked").each(function(){
		exportIds =exportIds +"exportIds="+ $(this).attr("pid")+"&";
	});
	if(exportIds.length>1){
		url += exportIds;
		window.open(url);
		window.setTimeout("window.location.reload();",3000);
	}else{
		dialog("请选择要导出的付款单！","unsuccess",false,2);
	}
	
}
