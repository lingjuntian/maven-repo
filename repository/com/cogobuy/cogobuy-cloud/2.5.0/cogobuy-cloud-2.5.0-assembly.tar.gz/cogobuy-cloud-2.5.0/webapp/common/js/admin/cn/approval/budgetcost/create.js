$(function(){
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		var $id = $(this).attr("vid");
		var $show = $(this).attr("vshow");
		var $rate = $(this).attr("vrate");
		$(this).parents(".options-select").find("input[tag=id]").val($id);
		$(this).parents(".options-select").find("input[tag=show]").val($show);
		$(this).parents(".options-select").find("input[tag=rate]").val($rate);
		var $selecttag = $(this).attr("selecttag");
		$("li ["+$selecttag+"]").hide();
		$("li ["+$selecttag+"="+$id+"]").show();
		$(this).validationEngine('hidePrompt');
		return false;
	});
	$(".dailyTypeOption").click(function(){
	 //alert($(this).attr("vshow"));
     $(this).parents(".options-select").find("[tdTag=type],[tdTag=emptyFlag]").val($(this).attr("vshow"));
	});
	//初始化时模拟点击BU，使其出现对应的Dep列表
	var buId = $("#buId").val();
	$("#buList").find("a[vid="+buId+"]").trigger("click");
	
	 //上一步
    $("#upStep").click(function(){
    	$("#costBody").find("tr[deleteFlag=yes]").remove();
    	//隐藏的Collect表单清空
    	$("#collectDiv").empty(); 
    	//清除提示
    	$("#prompt").text("");
    	
		$("#twoStep").hide();
		$("#oneStep").show();
    });

	//下一步
    $("#nextStep").click(function(){
		cleanPage();
    	if(!validateFunction()) {
			return false;
		}
        var error1 = $("#historyForm").validationEngine('validate');
		if(error1){
			count();//计算总额
			copyStyle();//复制表格 取回邮件列表
			$("#oneStep").hide();
			$("#twoStep").show();
			copyFileList();
			return false;
		}
		    return false;
    });
    
});

function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}

function cleanPage(){
	//取消所有验证（其实是针对表格中填了数据又去掉的情况）
	//$("#historyForm").validationEngine("hideAll");
	//去空行
	var tbodys=$("[tdTag=detailTbody]");
    for(var i=0;i<tbodys.size();i++){
		cleanTbody(tbodys.eq(i));
	}
	//改名
	changeName();
}

/*计算和*/
function count(){
	//隐藏的Collect表单清空
	$("#collectDiv").empty();
	var useMoneyInput = $("[tdTag = useMoney]");
	var totalSum = 0;  //
	for(var i = 0;i < useMoneyInput.size(); i++){
		var useMoneyVal = useMoneyInput.eq(i).val();
    	if(useMoneyVal != null && $.trim(useMoneyVal) != ""){
			totalSum = add(totalSum,useMoneyVal);
		}
	}
	//总和
	$("#totalSum").val(totalSum);

}

//复制
function copyStyle(){
	//取回邮箱
	fillMaillList();
	var trCopy;
	var rowNum;
	//复制项目主体
	$('#prebudgetNo').text($('#budgetNo').val());
	$('#preBudgetName').text($('#budgetName').val());
	if (document.getElementById("payType0").checked){
		$('#prepaytype').text('对公');
	}else{
		$('#prepaytype').text('对私');
	}
	$('#prebankaccount').text($('#bankaccount').val());
	$('#prebankname').text($('#bankname').val());
	$('#preaccountname').text($('#accountName').val());
	$("#sumConfirm").text($("#totalSum").val() + $("#currencyName").val());
	
	//复制项目预算明细
	var detailDiv = $("[tdTag=detailDiv]");
	$("#detailConfirm").empty();//清空确认详细数据
    for(var i =0 ; i< detailDiv.size() ; i++){
		//验证该item 是否填写了数据
		var count=detailDiv.eq(i).find("[id*=memo]").size();
        if(count!=0){
			var description = detailDiv.eq(i).find("[tdTag=description]").text();
			var memo = detailDiv.eq(i).find("[tdTag=memo]").val();
			var useMoney = detailDiv.eq(i).find("[tdTag=useMoney]").val();
			//是否对公
			var thHtml="";
			if(!document.getElementById("payType0").checked){
				thHtml='<th class="amount" style="text-align: center ;width:100p" maxlength="50"><div>报销类型</div></th> ';
			}
			var str='<div class="table-cost-details mb10"> ' +
				'<div class="table-summary"> ' +
				'<h3 class="summary-title">'+description+'</h3> ' +
				'</div> ' +
				'<div class="table-list"> ' +
				'<table width="100%" cellspacing="0" cellpadding="0" border="0" class="table-style1">' +
				'<thead>' +
				'<tr>' +
				 thHtml+
				'<th class="amount" style="text-align: center;width:600px"><div>使用说明</div></th>' +
				'<th class="amount" style="text-align: left;width:100px"><div>金额</div></th>' +
				'</tr>' +
				'</thead>' +
				'<tbody>';
			var $trs=detailDiv.eq(i).find("[tdTag=detailTbody]").find("tr");
			for(var j=0 ;j <$trs.size() ; j++){
				var memo=$trs.eq(j).find("[tdTag=memo]").val();
				var useMoney=$trs.eq(j).find("[tdTag=useMoney]").val();
				var tdHtml="";
				if(!document.getElementById("payType0").checked){
					var type=$trs.eq(j).find("[tdTag=type]").val();
					tdHtml='<td><span class="value">'+type+'</span></td>';
				}
				var tr='<tr>' +
					tdHtml+
					'<td class="first time"> <span class="value">'+memo+'</span></td>' +
					'<td><span class="value">'+useMoney+'</span></td></tr>';
				str = str + tr ;
			}
			str = str +"</tbody></table></div></div>"
			$("#detailConfirm").append(str);
		}

	}

}

//添加name,id，及验证属性；
function changeName(){
    var tbodys=$("[tdTag=detailTbody]");
	//去掉name,id,验证属性
	$("[tdTag=memo],[tdTag=pid],[tdTag=costName],[tdTag=detailId],[tdTag=budget],[tdTag=useMoney],[tdTag=emptyFlag]")
		.removeAttr("id").removeAttr("name")
		.removeClass("validate[required]").removeClass("validate[custom[number]]");
	var index=0;
    for(var i=0; i < tbodys.size();i++){
        var $trs = tbodys.eq(i).find("tr");
		var firstName = "budgetCostApproval.detailList";/* 前缀名称 */
		for ( var j = 0; j < $trs.size(); j++) {
			var $tr = $trs.eq(j);
			//验证非空行，将其加上name，id 属性
			if(!checkEmptyTr($tr)){
				var numtag = "[" + index + "]";
				var $inputNum = $tr.find("input").size();
				for ( var k = 0; k < $inputNum; k++) {
					var $input = $tr.find("input").eq(k);
					$input.attr("id", $input.attr("tdTag") + numtag);
					$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
					//加上验证
					if($input.attr("tdTag") == "memo"){
						$input.addClass("validate[required]");
					}
					if($input.attr("tdTag") == "useMoney"){
						$input.addClass("validate[required,custom[number]]");
					}
					if($input.attr("tdTag") == "emptyFlag"){
						$input.addClass("validate[required]");
					}
				}
					index++;
			}
		}
	}
}
//整理表格，去空行，至少保留一行
function cleanTbody(tbody){
	var trNum = tbody.find("tr").size();
	for(var i = trNum-1; i >= 0; i--){
		trNum = tbody.find("tr").size();
		var tr = tbody.find("tr").eq(i);
		if(checkEmptyTr(tr)){
			if(trNum > 1){ 
				//clearTrTips(tr);取消验证
				tr.remove();
			};
		};
	};
}

//验证空行
function checkEmptyTr($tr){
	var $inputNum = $tr.find("input").size();
	var flag = true; // 为空
	for ( var i = 0; i < $inputNum; i++) {
		var $input = $tr.find("input[filterNull!=true]").eq(i);
		if ($.trim($input.val()) != "") {
			flag = false; // 不为空
			break;
		}
	}
	return flag;
}

/* 添加一行 */
$("tr input").click(function(){
	var $tr = $(this).parents("tr");
	if($tr.nextAll().length==0){
		addTr($tr);
	};
});

$(".del-text").click(function(){
	var $obj = $(this).parents("tr");
	var $length = $obj.parents("tbody").find("tr").length;
	if($length<2){
		dialog("请最少保留1行","warning",false,2);
		return false;
	}
	delTr($obj);
});
/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.attr("hide","show");
	$copyTr.show();
	$tr.after($copyTr);
}
/* 删除行 */
function delTr($obj){
	$obj.remove();
	$obj.validationEngine('hidePrompt');
}
function getCurrencyFlag(currencyName){
	var flag = "";
	if(null == currencyName || "" == currencyName || "undefined" == currencyName){
		flag = "¥";
	}else{
		if(currencyName == "人民币"){
			flag = "¥";
		}else if(currencyName == "美元"){
			flag = "$";
		}else if(currencyName == "港元"||currencyName == "港币"){
			flag = "HK$";
		}else if(currencyName == "欧元"){
			flag = "€";
		}else if(currencyName == "日元"){
			flag = "¥";
		}else if(currencyName == "澳元"){
			flag = "AU$";
		} else if (currencyName == "台币") {
			flag = "TWD";
		}else{
			flag = "¥";
		}
	}
	return flag;
}
function lowToUpper(num){
	if(!/^\d*(\.\d*)?$/.test(num)){
		
	}else{
		var UPPER = new Array("零","壹","贰","叁","肆","伍","陆","柒","捌","玖");
		var num_array = ("" + num).split(".");
		var defStr="零";
		/*小数位*/
		if(num_array[1] != null && num_array[1].length > 0){
			if(num_array[1].length < 2){
				$("[jiao=jiao]").text(UPPER[num_array[1].charAt(0)]);
				$("[fen=fen]").text(defStr);
			}else{
				$("[jiao=jiao]").text(UPPER[num_array[1].charAt(0)]);
				$("[fen=fen]").text(UPPER[num_array[1].charAt(1)]);
			}
		}else{
			$("[jiao=jiao]").text(defStr);
			$("[fen=fen]").text(defStr);
		}
		/*整数位*/
		if(num_array[0] != null && num_array[0].length > 0){
			var intstr = "";
			if(num_array[0].length < 7){
				var temp = "";
				for(var i=0; i < 7 - num_array[0].length; i++){
					temp = temp + "0";
				}
				intstr = temp + num_array[0];
			}else{
				intstr = num_array[0].substring(num_array[0].length - 7);
			}
			$("[baiwan=baiwan]").text(UPPER[intstr.charAt(0)]);
			$("[shiwan=shiwan]").text(UPPER[intstr.charAt(1)]);
			$("[wan=wan]").text(UPPER[intstr.charAt(2)]);
			$("[qian=qian]").text(UPPER[intstr.charAt(3)]);
			$("[bai=bai]").text(UPPER[intstr.charAt(4)]);
			$("[shi=shi]").text(UPPER[intstr.charAt(5)]);
			$("[ge=ge]").text(UPPER[intstr.charAt(6)]);
		}else{
			$("[baiwan=baiwan]").text(defStr);
			$("[shiwan=shiwan]").text(defStr);
			$("[wan=wan]").text(defStr);
			$("[qian=qian]").text(defStr);
			$("[bai=bai]").text(defStr);
			$("[shi=shi]").text(defStr);
			$("[ge=ge]").text(defStr);
		}
		
	}
}
//取回数值，没有值的为0
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}

function changePaytype(t){
	if (t==0){//对公
		$("#bankaccount").val("");
		$("#bankname").val("");
		$("#accountName").val("");
		$("#bankaccount").removeAttr("readonly");
		$("#bankname").removeAttr("readonly");
		$("#accountName").removeAttr("readonly");
		$("[tdTag=publicHide]").css("display","none");
	}else{
		$("#bankaccount").val("-");
		$("#bankname").val("-");
		$("#accountName").val("-");
		$("#bankaccount").attr("readonly","readonly");
		$("#bankname").attr("readonly","readonly");
		$("#accountName").attr("readonly","readonly");
		$("[tdTag=publicHide]").css("display","block");
	}
}

function validateFunction(){
	$("#createUserId").addClass("validate[required]");
	$("#buName").addClass("validate[required]");
	$("#buId").addClass("validate[required]");
	$("#departmentName").addClass("validate[required]");
	$("#departmentId").addClass("validate[required]");
	$("#regionName").addClass("validate[required]");
	$("#regionId").addClass("validate[required]");
	$("#currencyName").addClass("validate[required]");
	//$("#currencyId").addClass("validate[required]");
	$("#bankaccount").addClass("validate[required,maxSize[100]]");
	$("#bankname").addClass("validate[required,maxSize[150]]");
	$("#accountName").addClass("validate[required,maxSize[200]]");
	var a=$("[id*=memo]");
	if(a.size()==0){
		dialog("请填写报销详细","unsuccess","false",2);
		return false;
	}
	    return true;
}