var inventoryList;
$(function(){
	initTrEvents();
	for(var i = 0; i < 5; i++){
		var tr = $("#copyTr").clone(true);
	   	tr.attr("id", "");	
	 	tr.appendTo($("#table"));
	 	tr.show();
 	}
 	resetRowNO();
	
	$("#gotoStep2").click(function(){
    	gotoStep2();
    	return false;
    });
    
    $("#gotoStep1").click(function(){
    	gotoStep1();
    	return false;
    });
	$("#submit").click(function(){
		save();
		return false;
    });
	
	ajaxCustomer($("#customerName"));
    $("#customerName").addClass("validate[required]");
    $("#currencyId").addClass("validate[required]");
	ajaxInventory("table", "inventoryCode");
});

function autoCompleteCustomer(data){
	clearCustomerInfo();
	$("#customerId").val(data.id);
	$("#customerName").val(data.fullName);
	$("#customerName").validationEngine('hidePrompt');
}

function clearCustomerInfo(){
	$("#customerId").val("");
}

/**初始化行事件**/
function initTrEvents(){
	$("[id^=add]").click(function(){
    	addTr(this);
    	return false;
    });
    $("[id^=del]").click(function(){
    	moveTr(this);
    	return false;
    });

    $("[id^=expectDate]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}, minDate:GetTodayDateStr()});
	});
}

function resetRowNO(){
	var len = $("#table tr").size();

	for(var i = len - 1; i >= 0; i--){
		var name = "salesInquiryDetails[" + i + "].";
		var tr = $("#table tr").eq(i);
		
		tr.find("input").each(function(){
			if($(this).attr("vhidden") != null && $(this).attr("vhidden") != ''){
				$(this).attr("name", name + $(this).attr("vhidden"));
				$(this).attr("id", $(this).attr("vhidden") + i);
			}
		});
		tr.find("[id*=rowNo]").val(i+1);
	    tr.find("#quantity" + i).addClass("validate[required,max[10000000],custom[positiveInteger]]");
	    tr.find("#expectDate" + i).addClass("validate[required,past[" + GetTodayDateStr() + "],custom[date]]");
	}

	if($("#table tr").size() >= 2){
  	   $("#table tr").find(".del").show();
    }else{
      $("#table tr").find(".del").hide();
    }
    
	$("#form").validationEngine('detach');
   	$("#form").validationEngine('attach');
}

function gotoStep2(){
	
	var error1 = checkPartNo("table", true);
	var error2 = $("#form").validationEngine('validate');
	showLineTips("table", "inventoryCode");

	if(error1 && error2 == true){
		copyData("form");
		copyTableData("table");
		$("#step1").hide();
		$("#step2").show();
		
		var url = "/approvalajax/approval_pmList?roleCode=pm";
		$("[id^=inventoryClassId]").each(function(){
			url += "&inventoryClassIdList=" + $(this).val();
		});
		
		$.ajax({
		    type:"GET",
		    url:encodeURI(url),
		    dataType:"json",
		    success:function(data, textStatus){
		    	if(data.inventoryUserMap != null){
		    		var len = $("#table [id^=inventoryClassId]").size();
		    		for(var i = 0; i < len; i++){
		    			var inventoryClassId = $("#table [id^=inventoryClassId]:eq(" + i + ")").val();
		    			var inventoryClass = data.inventoryUserMap[inventoryClassId];
		    			if(inventoryClass != null){
		    				var tr = $("#tableTd tr:eq(" + (i + 1) + ")");
		    				tr.find("td:eq(4)").text(inventoryClass[0]);
		    				tr.find("td:eq(5)").text(inventoryClass[1]);
		    			}
		    		}
		    	}
		    }
		});
	}
}

function save(){
	$("#copyTr").remove();
	//$("#orderForm").attr("action", "/admin/orderToken_create");
	$("#form").ajaxSubmit(function(returnStr){
        if (returnStr != "error") {
          dialog("成功！","success",true,1);
	      setTimeout(function(){window.location = "/approval/salesInquiry_index"},1000);	        
        } else if(returnStr == "error"){
         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
        }
      });
}

function autoCompleteInventory(data, $tr){
	clearInventory($tr);
	$tr.find("[id^=inventoryCode]").val(data.partNo);
	$tr.find("[id^=inventoryShow]").val(data.cinvName);
	$tr.find("[id^=inventoryName]").val(data.cinvName);
	$tr.find("[id^=inventoryClassId]").val(data.inventoryClassId);
}

function clearInventory($tr){
	$tr.find("[id^=inventoryShow]").val("");
	$tr.find("[id^=inventoryName]").val("");
	$tr.find("[id^=inventoryClassId]").val("");
}

function checkEmptyTr(tr){
	if(tr.find("[id^=inventoryCode]").val() == "" &&
		tr.find("[id^=quantity]").val() == "" &&
		tr.find("[id^=expectDate]").val() == ""){
			return true;
		}
	return false;	
}

//添加行的方法
function addTr(object){ 	
	var tr = $("#copyTr").clone(true);	
	tr.attr("id", "");				
    tr.insertAfter($(object).parents("tr"));
    tr.show();
    resetRowNO();
	setInventoryCodeAutoComplete(tr.find("[id^=inventoryCode]"));
	$("#form").validationEngine('hide');
}

/**删除行时消除原有的提示信息**/
function clearTrTips(tr){
	tr.find("[id*=inventoryCode]").validationEngine('hidePrompt');
	tr.find("[id*=quantity]").validationEngine('hidePrompt');
	tr.find("[id*=expectDate]").validationEngine('hidePrompt');
}