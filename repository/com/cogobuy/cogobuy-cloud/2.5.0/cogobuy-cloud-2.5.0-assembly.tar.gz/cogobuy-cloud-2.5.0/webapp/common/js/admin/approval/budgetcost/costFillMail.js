/* 填充确认页面邮箱列表 */
function fillMaillList() {
	var createUserId = $("#createUserId").val();
	var departmentId = $("#departmentId").val();
	var buId = $("#buId").val();
	var regionName = $("#regionName").val();
	var url = "/approval/budgetCost_showConfirmMail?budgetCostApproval.createUserId="+ createUserId 
			+ "&budgetCostApproval.departmentId=" + departmentId
			+ "&budgetCostApproval.buId=" + buId 
			+ "&budgetCostApproval.regionName=" + regionName;
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#allSubmit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,10);
			return false;
		}else if(nodeNoApprovalUser){
			$("#allSubmit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,10);
			return false;
		}else{
			$("#allSubmit").show();
		}
	});
}