function basicBar(placeHolder,data,ticks,max){
	$.plot($("#"+placeHolder),data ,
			  {
			  	series:{bars:{ show:true,fill:true,align:'center',barWidth:0.2}},
			  	grid:{hoverable:true},
			  	xaxis:{ticks:ticks,min:0,max:max,tickLength:0}
			  }
	);
	$("#"+placeHolder).bind("plothover", dataHover);
}

function showTooltip(x, y, contents) {
    $('<div id="tooltip">' + contents + '</div>').css( {
        position: 'absolute',
        display: 'none',
        top: y + 5,
        left: x + 10,
        border: '1px solid #fdd',
        padding: '2px',
        'background-color': '#fee',
        opacity: 0.80
    }).appendTo("body").fadeIn(200);
}

var previousPoint = null;
function dataHover(event, pos, item) {
    if (item) {
         if (previousPoint != item.dataIndex) {
             previousPoint = item.dataIndex;
             $("#tooltip").remove();
             showTooltip(item.pageX, item.pageY,item.datapoint[1].toFixed(2));
         }
    }else{
       $("#tooltip").remove();
       previousPoint = null;            
    }
 }