(function () {
    //添加机会
    $("#addLable").click(function () {
        if ($("#serviceLabelSel").val().trim() == "") {
            dialog("请选择机会名称", "unsuccess", true, 2);
        } else {
            var lableId = $("#serviceLabelSel").val().split(",")[0];
            var lableName = $("#serviceLabelSel").val().split(",")[1];
            var lableEnName = $("#serviceLabelSel").val().split(",")[2];
            var iotId = $("#iotId").val();
            data = {
                'serviceOpportunity.project': iotId,
                'serviceOpportunity.lableName': lableName,
                'serviceOpportunity.serviceLable': lableId,
                'serviceOpportunity.lableEnName': lableEnName
            }
            $.ajax({
                url: 'crm/serviceChance_addServiceChance',
                type: 'post',
                data: data,
                success: function (result) {
                    var type = result.split("_")[0];
                    if (type == 'success') {
                        dialog("成功", "success", true, 2);
                        var url = "/crm/serviceChance_detail?serviceOpportunity.id=" + result.split("_")[1];
                        window.location.href = url;
                    } else {
                        dialog(result, "unsuccess", true, 2);
                    }
                }
            })
        }
    });

    //修改跟进
    $(".update-follow").click(function () {
        var button = $(this);button.hide();
        var $form = $(this).closest("form");
        $form.attr("action","/crm/serviceChance_updateServiceFollow");
        $form.ajaxSubmit(function (returnStr) {
            if (returnStr == "success") {
                dialog("成功", "success", true, 1);
                window.location.reload(true);
            } else {
                button.show();
                dialog(returnStr, "unsuccess", true, 2);
            }
            return false;
        });
    })

})(jQuery);


