$(function() {
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
		if (error) {
			var exchangeRateValue = $("#exchangeRate").val();
			if(exchangeRateValue > 0){
				countData(); /* 统计数量、金额合计等 */
				copyValueToConfig();/* 将新建页面的数值写入确认页面 */
				getEmailList();/* 获取邮件发送列表 */
				switchPageForCreate();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
				copyFileList();/*上传附件公用*/
			}else{
				dialog("汇率必须大于0","unsuccess",true,2);
			}
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		switchPageForConfirm();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#salesOrderForm").append(inputStr);
    		}
    	});
    	$("#submit").hide();
    	$("#salesOrderForm").attr("action","/approval/salesOrder_create");
    	$("#salesOrderForm").attr("method","POST");
		$("#salesOrderForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/salesOrder_show?salesOrder.id="+id;},1000);	  
			}else if(type == "inventoryCode"){
				$("#submit").show();
				dialog("存货编码["+id+"]在对应账套中不存在，请重新选择","unsuccess",true,2);
			}else if(type == "cost"){
				$("#submit").show();
				dialog("存货编码["+id+"]对应成本价为空或为0，请重新选择","unsuccess",true,2);
			}else{
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
	});
	/* 点击生成临时订单 */
	$("#createtemp").click(function() {
    	$("#createtemp").hide();
    	$("#salesOrderForm").attr("action","/approval/createSalesOrder_temp");
		$("#salesOrderForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/salesOrder_show?salesOrder.id="+id;},1000);	  
			}else if(type == "inventoryCode"){
				$("#createtemp").show();
				dialog("存货编码["+id+"]在对应账套中不存在，请重新选择","unsuccess",true,2);
			}else if(type == "cost"){
				$("#createtemp").show();
				dialog("存货编码["+id+"]对应成本价为空或为0，请重新选择","unsuccess",true,2);
			}else{
				$("#createtemp").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
	});
});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#salesOrderForm").validationEngine('validate');
}

/* 统计数量、金额合计等 */
function countData() {
	/* 总数量 */
	var totalQuantity = 0;
	/* 含税总额 */
	var totalTaxSum = 0;
	/* 无税总额 */
	var totalSum = 0;
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		totalQuantity = add(totalQuantity, changeNum($tr.find("input[tdTag=quantity]").val()));
		totalTaxSum = add(totalTaxSum, changeNum($tr.find("input[tdTag=taxSum]").val()));
		totalSum = add(totalSum, changeNum($tr.find("input[tdTag=sum]").val()));
	}
	$("#totalQuantity").val(changeTwoDecimal(totalQuantity));
	$("#totalTaxSum").val(changeFourDecimal(totalTaxSum));
	$("#totalSum").val(changeFourDecimal(totalSum));
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/*清空头部*/
	$("div[tag=confirmHead] span[id$=_confirm]").text("");
	$("#supplyChainFinance_confirm").text("");
	
	/*清空客户名称的title*/
	$("#customerFullName_confirm").attr("title","");
	/*清空备注*/
	$("#remark_confirm").text("");
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*######################头部 BEGIN*/
	/*账套*/
	$("#ledger_confirm").text($("#ledger").val());
	/*采购订单号*/
	$("#purchaseOrderNo_confirm").text($("#purchaseOrderNo").val());
	/*客户名称*/
	$("#customerFullName_confirm").text($("#customerFullName").val());
	$("#customerFullName_confirm").attr("title",$("#customerFullName").val());
	/*销售类型*/
	$("#saleType_confirm").text($("#saleType").val());
	/*币种*/
	$("#currencyName_confirm").text($("#currencyName").val());
	/*汇率*/
	$("#exchangeRate_confirm").text($("#exchangeRate").val());
	/*税率*/
	$("#taxRate_confirm").text($("#taxRate").val());
	/*付款方式*/
	$("#payType_confirm").text($("#payType").val());
	/*发货方式*/
	$("#shippingType_confirm").text($("#shippingType").val());
	/*业务员*/
	$("#personName_confirm").text($("#personName").val());
	/*产品线*/
	$("#productLineName_confirm").text($("#productLineName").val());
	/*收付款协议名称*/
	$("#payConditionName_confirm").text($("#payConditionName").val());
	/*账期*/
	$("#creditPeriod_confirm").text($("#creditPeriod").val());
	/* 订单日期 */
	$("#orderDate_confirm").text(GetTodayDateStr());
	/* 制单人 */
	$("#maker_confirm").text($("#maker").val());
	/* IOT# */
	$("#iotNo_confirm").text($("#iotNo").val());
	/*供应链金融业务标识*/
	if($("#supplyChainFinance:checked").length > 0){
		$("#supplyChainFinance_confirm").text("供应链金融业务");
	}
	/*######################头部  END*/
	/*######################详情列表BEGIN*/
	/*详情*/
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		var trString = "<tr><td class=\"first num\"><div>"+$tr.find("input[tdTag=item]").val()+"</div></td>"
			+ "<td class=\"supplier-model\"><div>"+$tr.find("input[tdTag=inventoryCode]").val()+"</div></td>"
			+ "<td class=\"material-number\"><div>"+$tr.find("input[tdTag=customerInventoryCode]").val()+"</div></td>"
			+ "<td class=\"product-desc\"><div>"+$tr.find("input[tdTag=inventoryName]").val()+"</div></td>"
			+ "<td class=\"euc-number\"><div>"+$tr.find("input[tdTag=euc]").val()+"</div></td>"
			+ "<td class=\"license-number\"><div>"+$tr.find("input[tdTag=license]").val()+"</div></td>"
			+ "<td class=\"quantity\"><div>"+fmoney(changeNum($tr.find("input[tdTag=quantity]").val()),0)+"</div></td>"
			+ "<td class=\"price price0\"><div>"+fmoney(changeNum($tr.find("input[tdTag=taxUnitPrice]").val()),6)+"</div></td>"
			+ "<td class=\"price price1\"><div>"+fmoney(changeNum($tr.find("input[tdTag=unitPrice]").val()),6)+"</div></td>"
			+ "<td class=\"price price2\"><div>"+fmoney(changeNum($tr.find("input[tdTag=taxSum]").val()),4)+"</div></td>"
			+ "<td class=\"eccn-number\"><div>"+$tr.find("input[tdTag=eccn]").val()+"</div></td>"
			+ "<td class=\"mpq\"><div>"+$tr.find("input[tdTag=mpq]").val()+"</div></td>"
			+ "<td class=\"last time\"><div>"+$tr.find("input[tdTag=expectDate]").val()+"</div></td></tr>";
		$("#detailListTbody_confirm").append(trString);
	}
	/*合计行*/
	var totalString = "<tr class=\"total\"><td class=\"first num\"><div></div></td>"
			+ "<td class=\"supplier-model\"><div></div></td>"
			+ "<td class=\"material-number\"><div></div></td>"
			+ "<td class=\"product-desc\"><div></div></td>"
			+ "<td class=\"euc-number\"><div></div></td>"
			+ "<td class=\"license-number\"><div>总计：</div></td>"
			+ "<td class=\"quantity\"><div>"+fmoney($("#totalQuantity").val(),0)+"</div></td>"
			+ "<td class=\"price price0\"><div></div></td>"
			+ "<td class=\"price price1\"><div></div></td>"
			+ "<td class=\"price price2\"><div>"+fmoney($("#totalTaxSum").val(),4)+"</div></td>"
			+ "<td class=\"eccn-number\"><div></div></td>"
			+ "<td class=\"mpq\"><div></div></td>"
			+ "<td class=\"last time\"><div></div></td></tr>";
	$("#detailListTbody_confirm").append(totalString);
	/*######################详情列表END*/
	/*######################备注 BEGIN*/
	$("#remark_confirm").text($("#remark").val());
	/*######################备注 END*/
}

/* 获取邮件发送列表 */
function getEmailList() {
	var personEmail = $("#personEmail").val();
	var url = "/approval/salesOrder_showConfirmMail?salesOrder.personEmail="+personEmail;
	$("#detailListTbody").find("input[tdTag=productLineName]").each(function(){
		url+="&productLines="+$(this).val();
	});
	if($("#supplyChainFinance:checked").length > 0){
		url = url + "&salesOrder.supplyChainFinance="+$("#supplyChainFinance").val();
	}
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#submit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else if(nodeNoApprovalUser){
			$("#submit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else{
			$("#submit").show();
		}
	});
}

/* 获取销售订单号、且写入页面 */
function getSalesOrderSO() {
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/salesOrder_createSalesOrderNo"),
		success : function(returnStr) {
			$("#salesOrderNo").val(returnStr);
			$("#so_confirm").text(returnStr);
		}
	});
}

/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
function switchPageForCreate() {
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/salesOrder_checkPO?salesOrder.ledger="+$("#ledger").val()+"&salesOrder.purchaseOrderNo="+$("#purchaseOrderNo").val()),
		success : function(returnStr) {
			if(returnStr == "error"){
				dialog("采购订单号已经存在","unsuccess",true,5);
				return false;
			}else{
				$("#write").hide();
				$("#confirm").show();
				return false;
			}
		}
	});
}


/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").hide();
	$("#write").show();
}

