$(function() {
	//salesOrderAutoComplete();
	/**
	 * 添加行
	 */
	$("input[tdTag=purchaseOrderNo][addlinetag=purchaseOrderNo]").click(function(){
		var $p = $(this).parents("p");
		if($p.nextAll().length==0){
			$copyp = $("#saleOrderHide").clone(true);
			$copyp.removeAttr("id");
			$copyp.removeAttr("style");
			$p.after($copyp);
			salesOrderAutoComplete($("#saleOrder").find("input[initializeAuto=true]"));
		}
	});
	
	/*删除采购订单号*/
	$(".icon-del[deltag=purchaseOrderNo]").click(function(){
		var $obj = $(this).parents("p");
		var $length = $("#saleOrder").find("p").length;
		if($length<2){
			promptMessage($("#salesOrderMessage"),"请最少保留1行",2);
			return false;
		}
		delObj($obj);
	});
	
	
	
	/**
     * 文件下载
     */
	$("a[downFileTag=downFileTag]").click(function(){
		fileDownLoad($(this));
	});
	
	/* 审批通过 */
	$("#enterButton").click(function() {
		$("#enterButton").hide();
		$("#cancelButton").hide();
		
		var nodeName=$("#nodeName").val();
		var opinion=$("#opinion").val();
		if (opinion.length<5 && nodeName=='PM'){
			alert("请填写审批意见，不少于5个字，谢谢");
			$("#enterButton").show();
			$("#cancelButton").show();
		}else{
			var data = {
					"approvalId" : $("#mainId").val(),
					"opinion" : $("#opinion").val(),
					"notes" : $("#nodeName").val()
			};
			$.ajax({
				type : "GET",
				url : encodeURI("/weixinApproval/o2oApproval_approval"),
				data : data,
				success : function(returnStr) {
					if (returnStr == 'success') {
						promptMessage($("#approvalPromptMessage"),"成功",2);
						setTimeout(function(){window.location = location.href;},1000);	
					} else {
						$("#enterButton").show();
						$("#cancelButton").show();
						promptMessage($("#approvalPromptMessage"),returnStr,2);
					}
				}
			});
		}
	});
	
	/* 作废 */
	$("#cancelButton").click(function() {
		$("#enterButton").hide();
		$("#cancelButton").hide();
		var nodeName=$("#nodeName").val();
		var opinion=$("#opinion").val();
		if (opinion.length<5 && nodeName=='PM'){
			alert("请填写审批意见，不少于5个字，谢谢");
			$("#enterButton").show();
			$("#cancelButton").show();
		}else{
			var data = {
					"approvalId" : $("#mainId").val(),
					"opinion" : $("#opinion").val(),
					"notes" : $("#nodeName").val()
			};
			$.ajax({
				type : "GET",
				url : encodeURI("/weixinApproval/o2oApproval_invalid"),
				data : data,
				success : function(returnStr) {
					if (returnStr == 'success') {
						setTimeout(function(){window.location = location.href;},1000);	
					} else {
						$("#enterButton").show();
						$("#cancelButton").show();
						promptMessage($("#approvalPromptMessage"),returnStr,2);
					}
				}
			});
		}
	});
	
	/* 增加评论 */
	$("#commentButton").click(function() {
		$("#commentButton").hide();
		var data = {
				"approvalId" : $("#mainId").val(),
				"opinion" : $("#comment").val()
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/weixinApproval/o2oApproval_addComment"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					var commonStr = "<b>"+$("#createUserName").val()+":</b><br/>"+$("#comment").val()+"<br/>";
					$("#detailCommentList").prepend(commonStr);
					$("#comment").val("");
					$("#commentButton").show();
				} else {
					$("#commentButton").show();
					promptMessage($("#commentPromptMessage"),returnStr,2);
				}
			}
		});
	});
	
	/* 整理表格，去空行 */
	function cleanSalesTeam() {
		var $pNum = $("#saleOrder").find("p").size();
		for ( var i = $pNum-1; i >= 1; i--) {
			var $p = $("#saleOrder").find("p").eq(i);
			if ($.trim($p.find("input[tdTag=purchaseOrderNo]").val()) == "") {
				$p.remove();
			}
		}
	}
	
	/* 增加新建页面列表的name,id属性 */
	function addIdAndNameForSalesOrders() {
		var $firstName = "salesOrders";
		var $ps = $("#saleOrder").find("p");/* 获取所有p */
		for ( var i = 0; i < $ps.size(); i++) {
			var numtag = "[" + i + "]";
			var $p = $ps.eq(i);
			var $inputNum = $p.find("input").size();
			for ( var j = 0; j < $inputNum; j++) {
				var $input = $p.find("input").eq(j);
				$input.attr("id", $firstName + $input.attr("tdTag") + numtag);
				$input.attr("name", $firstName + numtag + "." + $input.attr("tdTag"));
			}
		}
	}
	
	/* 维护订单 */
	$("#orderButton").click(function() {
		//去空行，加name,id属性
		cleanSalesTeam();
		addIdAndNameForSalesOrders();
		$("#orderButton").hide();
//		var data = {
//				"approvalId" : $("#mainId").val(),
//				"opinion" : $("#order").val()
//		};
		$.ajax({
			type : "GET",
			url : encodeURI("/weixinApproval/o2oApproval_addOrder"),
			data:$('#salesOrderFrom').serialize(),
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("成功","success",true,1);
					setTimeout(function(){window.location = location.href;},1000);
				} else {
					$("#orderButton").show();
					dialog(returnStr,"unsuccess",true,2);
				}
			}
		});
	});
	
	//关联销售订单，连接到销售订单详情
	 var orderVal=$("#order").val();
	 if(orderVal!=''){
		 var orderJoson=JSON.parse(orderVal);
		 var a="";
		  $.each(orderJoson, function(i,order){ 
			  a=a+"<a style='margin-left:20px' target='_Blank' href='/approval/salesOrder_show?salesOrder.id="+order.id+"'>"+order.purchaseOrderNo+"</a>";
			 //一行放8个订单号
			  if((i+1)%8==0){
				  a=a+"</br>";  
			  }
		  });
		 $("#orderDiv").append(a);
	 }

	
});

/*文件下载*/
function fileDownLoad($obj){
	$("#fileNameDownId").val($obj.attr("fileName"));
	$("#srcNameDownId").val($obj.attr("srcName"));
	$("#fileDownloadForm").submit();
}


/* 删除对象 */
function delObj($obj){
	$obj.remove();
}


/*销售订单自动匹配*/
function salesOrderAutoComplete($input){
	    $input.autocomplete(encodeURI("/weixinApprovalAjax/o2o_findPurchaseOrderNo"), {
        /**加自定义表头**/
        tableHead: "<div> <span class='col-3'>采购订单号</div>",
        minChars: 0,
        width: 350,
        matchContains: "true",
        autoFill: false,
        dataType: 'json',
        parse: function(data) {  
            var rows = [];  
            if(data == null || data.saleOrderList == null){
            	return rows;
            }
            for(var i=0; i<data.saleOrderList.length; i++){    
                rows[rows.length] = {    
                    data:data.saleOrderList[i],              
                    value:data.saleOrderList[i].purchaseOrderNo,     
                    result:data.saleOrderList[i].purchaseOrderNo   
                };  
            }  
            return rows;  
        }, 
        formatItem: function(row, i, max) {
            return "<div style='height: 40px;font-size: 15px;'>"+row.purchaseOrderNo+"</div>";
        },
        formatMatch: function(row, i, max) {
            return row.purchaseOrderNo;
        },
        formatResult: function(row) {
            return row.purchaseOrderNo;
        }
	    }).result(function(e,data,value,sec){/**加选中后的回调函数**/
	    	$(this).parents("p").find("[tdTag=purchaseOrderNo]").val("");
	    	$(this).parents("p").find("[tdTag=id]").val("");
	    	$(this).parents("p").find("[tdTag=purchaseOrderNo]").val(data.purchaseOrderNo);
    		$(this).parents("p").find("[tdTag=id]").val(data.id);
	    }).bind("unmatch", function() {/**没有匹配时**/
	    	$(this).parents("p").find("[tdTag=purchaseOrderNo]").val("");
	    	$(this).parents("p").find("[tdTag=id]").val("");

	    });
	    
}


