/**
 * crm 客户添加js
 */

$(function(){
	$(".editShow").hide();
	$('.contact-edit .edit').live('click',function(){                          // live绑定事件到动态创建的元素
        $('.contact-edit table input,.contact-edit table textarea').attr('readonly','');
        $('.contact-edit table input,.contact-edit table textarea').addClass('input-text','');
        $('.customer-edit table input,.customer-edit table textarea,.customer-edit table select option').css({'border':'1px solid #ccc'});

        // 修改input框聚焦时的border-color
        $('.contact-edit table input,.contact-edit table textarea').focus(function(){
            $(this).css({'border-color':'#03A1E8'});
        });
        $('.contact-edit table input,.contact-edit table textarea').blur(function(){
            $(this).css({'border-color':'#ccc'});
        });

        var str1 = '<td colspan="2"  class="btn-td"><a href="#" title="保存" class="save btn-save ">保存</a><a href="#" title="取消" class=" cancel btn-save">取消</a></td>';
        $('.contact-edit .edit').parent().replaceWith(str1);
    });
     $('.contact-edit .edit').bind('click',function(){                           // bind绑定事件到已创建的元素
        $('.contact-edit table input,.contact-edit table textarea').attr('readonly','');
        $('.contact-edit table input,.contact-edit table textarea').addClass('input-text','');
        $('.customer-edit table input,.customer-edit table textarea,.customer-edit table select option').css({'border':'1px solid #ccc'});

        // 修改input框聚焦时的border-color
        $('.contact-edit table input,.contact-edit table textarea').focus(function(){
            $(this).css({'border-color':'#03A1E8'});
        });
        $('.contact-edit table input,.contact-edit table textarea').blur(function(){
            $(this).css({'border-color':'#ccc'});
        });

        var str1 = '<td colspan="2"  class="btn-td"><a href="#" title="保存" class="save btn-save ">保存</a><a href="#" title="取消" class=" cancel btn-save">取消</a></td>';
        $('.contact-edit .edit').parent().replaceWith(str1);
        
        //为客户输入框加id，自动补全
        $(".contactCus").attr("id","contactCus");
		 customerAutoComplete($("#contactCus"));
		 $(".editShow").show();
		 $(".editHide").hide();
    });

   
    $('.contact-edit .cancel').live('click',function(){
    	//取消按钮  强制刷新本页面
    	dialog("您确定要放弃编辑吗？",null,true,null,function(){
    		var id=$("#contactId").val();
        	var str="/crm/contact_show?contact.id="+id;
        	window.location.href=str;
    	});
    });
  
	
	//-----------------------------------------------------------------------
    /*增加验证*/
    $("#contactChName").addClass("validate[required]");
    $("#contactPhone").addClass("validate[required,custom[mobile]]");
    $("#contactEmail").addClass("validate[required,custom[email]]");
    $("#tel").addClass("validate[custom[phoneNumber]]");
    $("#qq").addClass("validate[custom[number]]");
		/**
		 * 点击保存按钮
		 */
	    $('.contact-edit .save').live('click',function(){
	    	var isPass=validationInput();
	    	if(isPass){
	    		$('.contact-edit .save').hide();
	    		$("#updateContackForm").attr("action","/crm/contact_update");
	    		$("#updateContackForm").ajaxSubmit(function(returnStr) {
	    			var type = returnStr.split("_")[0];
	    			var id = returnStr.split("_")[1];
	    			if (type == "success") {
	    				dialog("成功","success",true,1);
	    				setTimeout(function(){window.location.reload();},1000);	  
	    			}else {
	    				$('.contact-edit .save').show();
	    				dialog(returnStr,"unsuccess",true,2);
	    			}	
	    	        return false;
	    		});
	    	}
	   });
	     
	    /* 验证输入 */
	    function validationInput() {
	    	return $("#updateContackForm").validationEngine('validate');
	    };
	    
	    
	    /**
	     * 公司自动匹配
	     */
		/*客户自动匹配*/
		function customerAutoComplete($input){
			    $input.autocomplete(encodeURI("/crmAjax/customer_findCusTop8"), {
		        //**加自定义表头**//*
		        minChars: 0,
		        width: 350,
		        matchContains: "true",
		        autoFill: false,
		        dataType: 'json',
		        parse: function(data) {  
		            var rows = [];  
		            if(data == null || data.customers == null){
		            	return rows;
		            }
		            for(var i=0; i<data.customers.length; i++){    
		                rows[rows.length] = {    
		                    data:data.customers[i],              
		                    value:data.customers[i].chName,     
		                    result:data.customers[i].chName   
		                };  
		            }  
		            return rows;  
		        }, 
		        formatItem: function(row, i, max) {
		            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"</div>";
		        },
		        formatMatch: function(row, i, max) {
		            return row.chName;
		        }
			    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
			    	$(this).val("");
			    	$("#contactCid").val("");
			    	$(this).val(data.chName);
			    	$("#contactCid").val(data.id);
			    }).bind("unmatch", function() {//**没有匹配时**//*
			    	$(this).val("");
			    	$("#contactCid").val("");
			    });
		}
	  
		 // 查看全部，显示短信列表
        $('#msg-list').click(function(){
            $('#mask-div,.msg-list').fadeIn();
        });
        $('.msg-list-head a.close').click(function(){
            $('#mask-div,.msg-list').fadeOut();
        });
        // 点击页面空白，隐藏弹窗
        $('#mask-div').click(function(){                                  
             $('#mask-div,.msg-list').fadeOut();
        });
	    
});