/**
 * 审核通过
 * @param parent
 */
//隐藏保存按钮
$(function(){$("[tdTag='pur_save']").hide();});

  function update(e){
      //隐藏修改按钮
      $("[tdTag=it_update]").hide();
      //影藏审批按钮
      $("#pass").hide();
      //获得当前行
       var $tr=$(e).closest("tr");
      //获得下拉框币种的值
      var $currencyVal=$tr.find("[tdTag=currency]").text();
      var $currencyOption;
   
  }

  function save(e){
      //验证填写数据
      var $form= $("#updateDetaliForm");
      $form.find("[name=detail.equipment],[name=detail.remark],[name=detail.actualPrice]").addClass("validate[required]");
      $form.find("[name=detail.actualPrice]").addClass("validate[required,custom[amountSixPoint]]");
      var $error=$form.validationEngine('validate');
      if($error==true){
           //计算总额
          calTaxSum();
          //ajax提交修改的数据
          $form.attr("action","/approval/dimission_updateDetail");
          $form.ajaxSubmit(function(returnStr){
              if(returnStr=="success"){
                  dialog("成功", "success", true, 2);
                  //获得当前行
                  var $tr=$(e).closest("tr");
                  //将当前行变为不可编辑状态
                  var $trshow= "<td class='equipment' tdTag='equipment'><div>"+$tr.find("[tdtag=equipment]").val() +
                      "<input type='hidden' tdTag=detailId  value='"+$tr.find("[tdTag=detailId]").val()+"'></div></td>" +
                      "<td class='remark' tdTag='remark' ><div>"+$tr.find("[tdTag=remark]").val()+"</div></td>" +
                      "<td class='price price1' style='width:50px'  tdTag='price'><div>"+ $tr.find("[tdTag=price]").text()+"</div></td>"+
                      "<td class='currency' tdTag='currency'><div>" +$tr.find("[tdTag=currency]").val() +"</div></td> " +
                      " <td class='quantity' style='width:30px' tdTag='quantity'><div>" +$tr.find("[tdTag=quantity]").text() +"</div></td> " +
                      " <td class='price' tdTag='actualPrice' ><div>"+$tr.find("[tdTag=actualPrice]").val()+"</div></td>" +
                      " <td class='price' style='width:50px'><div><a style='cursor: pointer' tdTag='it_update' onclick='update(this)'>修改</a></div></td>" ;
                  $tr.html($trshow);
                  $("[tdTag=it_update]").show();
                  $("#pass").show();
                  return true;
              }else{
                  dialog(returnStr, "unsuccess", true, 2);
                  return false;
              }

          });
      }
}

  
  
/*
 * it部门审批通过
 */
function itDepart_approval(parent,parentId,returnUrl,obj,id) {
	if(id==""){
		dialog("审批错误，无流程");
		return ;
	}
	var thisId =id;
	var removMon = $("#removableEquivMoney").val();
	var canUMon=   $("#cancelUsernameMoney").val();
	var canUerMo = $("#cancelUofErpMoney").val();
	var canUoaMo = $("#cancelUofOaMoney").val();
	var canUofCrm =$("#cancelUofCrmMoney").val(); 
	var remov     = "";
	var canU      = "";
	var canUer     = "";
	var canUoa    = "";
	var canUof    ="";
	if($("#RemovableEquiv").is(':checked')){
		remov = "已归还";
	}else{
        remov ="未归还";		
	}
	if($("#CancelUsername").is(':checked')){
		 canU = "已归还"
	}else{
		canU = "未归还"	
	}
	if($("#CancelUofErp").is(':checked')){
		canUer = "已归还";
	}else{
		canUer= "未归还";
	}
	if($("#CancelUofOa").is(':checked')){
		canUoa = "已归还";
	}else{
		canUoa= "未归还"	;
	}
	if($("#CancelUofCrm").is(':checked')){
		canUof = "已归还";
	}else{
		canUof= "未归还"	;
	}
	var params = {
	    	"dimissionApproval.removableEquivMoney" :removMon, 
			"dimissionApproval.cancelUsernameMoney"  :canUMon,
			"dimissionApproval.cancelUofErpMoney"  :canUerMo, 
			"dimissionApproval.cancelUofOaMoney"  :canUoaMo,
			"dimissionApproval.cancelUofCrmMoney"  :canUofCrm,
			"dimissionApproval.removableEquiv"  :remov,
			"dimissionApproval.cancelUsername"  :canU,   
			"dimissionApproval.cancelUofErp"  :canUer,   
			"dimissionApproval.cancelUofOa"  :canUoa,  
			"dimissionApproval.cancelUofCrm"  :canUof,
			"dimissionApproval.id":thisId
	
	};
	/*alert( JSON.parse(params))*/
	$.ajax({
		url:"/approvalajax/updateDimission",
		data:params,
		type:"get",
		success:function(data){
			if(data == 'success'){
				flowApproval.approval(parent,parentId,returnUrl);	
			}else{
				 dialog(returnStr, "unsuccess", true, 2);
			}
		
		}
	});
	 
}
/*
 * it部门审批通过
telephone
calculater
otherOfficeEquiv
keys
officePlace
fixedAssets
stamperOfAdm


 */
function xingzheng_approval(parent,parentId,returnUrl,obj,id) {
	if(id==""){
		dialog("审批错误，无流程")
		return ;
	}
	var thisId =id;
	var removMon = $("#telephoneMoney").val();
	var canUMon=   $("#calculaterMoney").val();
	var canUerMo = $("#otherOfficeEquivMoney").val();
	var canUoaMo = $("#keysMoney").val();
	var canUofCrm =$("#fixedAssetsMoney").val();
	var officePla =$("#officePlaceMoney").val();
	var stamperMon   =$("#stamperOfAdmMoney").val()
	var remov     = "";
	var canU      = "";
	var canUer    = "";
	var canUoa    = "";
	var canUof    = "";
	var officePlas = "";
	var stamp =     "";
	if($("#telephone").is(':checked')){
		remov = "已归还"
	}else{
        remov ="未归还"		
	}
	if($("#calculater").is(':checked')){
		 canU = "已归还"
	}else{
		canU = "未归还"	
	}
	if($("#otherOfficeEquiv").is(':checked')){
		canUer = "已归还"
	}else{
		canUer= "未归还"	
	}
	if($("#keys").is(':checked')){
		canUoa = "已归还"
	}else{
		canUoa= "未归还"	
	}
	if($("#fixedAssets").is(':checked')){
		canUof = "已归还"
	}else{
		canUof= "未归还"	
	}
	if($("#stamperOfAdm").is(':checked')){
		stamp = "已归还"
	}else{
		stamp = "未归还"	
	}
	if($("#officePlace").is(':checked')){
		officePlas = "已归还"
	}else{
		officePlas= "未归还"	
	}
	var params = {
	    	"dimissionApproval.telephoneMoney" :removMon, 
			"dimissionApproval.calculaterMoney"  :canUMon,
			"dimissionApproval.otherOfficeEquivMoney"  :canUerMo, 
			"dimissionApproval.keysMoney"  :canUoaMo,
			"dimissionApproval.officePlaceMoney"  :officePla,
			"dimissionApproval.fixedAssetsMoney"  :canUofCrm,
			"dimissionApproval.stamperOfAdmMoney"  :stamperMon,
			"dimissionApproval.telephone       "  :remov,
			"dimissionApproval.calculater      "  :canU,   
			"dimissionApproval.otherOfficeEquiv" :canUer,   
			"dimissionApproval.keys"            :canUoa,  
			"dimissionApproval.officePlace"      :canUof,
			"dimissionApproval.fixedAssets     "  :officePlas,
			"dimissionApproval.stamperOfAdm    "  :stamp,
			"dimissionApproval.id":thisId
	
	}

/*	alert( JSON.parse(params))*/
	$.ajax({
		url:"/approvalajax/adminDimission",
		data:params,
		type:"post",
		success:function(data){
			if(data == 'success'){
				flowApproval.approval(parent,parentId,returnUrl);	
			}else{
				 dialog(returnStr, "unsuccess", true, 2);
			}
		}
		
	})
	
		
}
/*
loanBack
receivables
storageOfFinacial
stampleBackOfFinacial
financialBorrowAmount
finacialReceiveAmount
finacialStorageAmonut
finacialSampleAmount

财务部
 * 
 * **/
function finacial_approval(parent,parentId,returnUrl,obj,id) {
	if(id==""){
		dialog("审批错误，无流程")
		return ;
	}
	var thisId =id;
	var removMon = $("#loanBackMoney").val();
	var canUMon=   $("#receivablesMoney").val();
	var canUerMo = $("#storageOfFinacialMoney").val();
	var canUoaMo = $("#stampleBackOfFinacialMoney").val();
	var canUofCrm =$("#finacialReceiveAmount").val();
	var officePla =$("#financialBorrowAmount").val();
	var stamperMo =$("#finacialStorageAmonut").val()
	var finacialS =$("#finacialSampleAmount").val()
	var remov     = "";
	var canU      = "";
	var canUer    = "";
	var canUoa    = "";
	if($("#LoanBack").is(':checked')){
		remov = "已归还"
	}else{
        remov ="未归还"		
	}
	if($("#Receivables").is(':checked')){
		 canU = "已归还"
	}else{
		canU = "未归还"	
	}
	if($("#StorageOfFinacial").is(':checked')){
		canUer = "已归还"
	}else{
		canUer= "未归还"	
	}
	if($("#StampleBackOfFinacial").is(':checked')){
		canUoa = "已归还"
	}else{
		canUoa= "未归还"	
	}
	var params = {
	    	"dimissionApproval.loanBackMoney":              removMon,
			"dimissionApproval.receivablesMoney":           canUMon, 
			"dimissionApproval.storageOfFinacialMoney" :    canUerMo,
			"dimissionApproval.stampleBackOfFinacialMoney": canUoaMo,
			"dimissionApproval.finacialReceiveAmount":      canUofCrm, 
			"dimissionApproval.financialBorrowAmount":      officePla ,
			"dimissionApproval.finacialStorageAmonut":      stamperMo ,
			"dimissionApproval.finacialSampleAmount":       finacialS ,
			"dimissionApproval.loanBack"            :       remov,
			"dimissionApproval.receivables      "    :canU,   
			"dimissionApproval.storageOfFinacial"    :canUer,   
			"dimissionApproval.stampleBackOfFinacial":canUoa,  
			"dimissionApproval.id":thisId
	
	}

/*	alert( JSON.parse(params))*/
	$.ajax({
		url:"/approvalajax/finacialDimission",
		data:params,
		type:"post",
		success:function(data){
			if(data == 'success'){
				flowApproval.approval(parent,parentId,returnUrl);	
			}else{
				 dialog(returnStr, "unsuccess", true, 2);
			}
		}
		
	})

		
}


/**
 * 客服部
 * 
 * borrowAndOthers
 * */
function customer_approval(parent,parentId,returnUrl,obj,id) {
	if(id==""){
		dialog("审批错误，无流程")
		return ;
	}
	var thisId =id;
	var borrowAnd = $("#borrowAndOthers").val();
	var params = {
			"dimissionApproval.borrowAndOthers":borrowAnd,  
			"dimissionApproval.id":thisId
	}
/*	alert( JSON.parse(params))*/
	$.ajax({
		url:"/approvalajax/customerDimission",
		data:params,
		type:"post",
		success:function(data){
			if(data == 'success'){
				flowApproval.approval(parent,parentId,returnUrl);	
			}else{
				 dialog(returnStr, "unsuccess", true, 2);
			}
		}
		
	})
	
		
}

/**                       
 * 人力资源部审批                               
       

                                    
 * */
function humanResource_approval(parent,parentId,returnUrl,obj,id) {
	if(id==""){
		dialog("审批错误，无流程")
		return ;
	}
	var thisId =id;
	var assureLeave="";
	if($("#assureLeaveDay").attr("realvalue")){
		assureLeave=$("#assureLeaveDay").attr("realvalue")
	}
	var absenceLeave=$("#absenceLeave").val()
	var sickLeave =$("#sickLeave").val()
	var removMon = $("#workDays").val();
	var canUMon=   $("#absenceLeaveMoney").val();
	var canUerMo = $("#sickLeaveMoney").val();
    var launch   = $("#dinnerAllowanceMoney").val();
	var canUoaMo = $("#employeeCardMoney").val();
	var canUofCrm =$("#employeeHandbookMoney").val();
	var officePla =$("#fileManaFeeMoney").val();
	var stamperMo =$("#trainingFeeMoney").val()
	var finacialS =$("#individualIncomeMoney").val()
	var medical   =$("#medicalTreatmentMoney").val()
	var announce  =$("#announceFeeMoney").val()
	var fineFee   =$("#fineFeeMoney").val()
	var prizeFee  =$("#prizeFeeMoney").val()
	var remov     = "";
	var canU      = "";
	var canUer    = "";
	
	if($("#EmployeeCard").is(':checked')){
		remov = "已归还"
	}else{
        remov ="未归还"		
	}
	if($("#EmployeeHandbook").is(':checked')){
		 canU = "已归还"
	}else{
		canU = "未归还"	
	}
	if($("#FileManaFee").is(':checked')){
		canUer = "已归还"
	}else{
		canUer= "未归还"	
	}
	var params = {
			"dimissionApproval.id":thisId,                                  
			"dimissionApproval.absenceLeave":             absenceLeave ,    
			"dimissionApproval.sickLeave":                sickLeave ,       
			"dimissionApproval.assureLeaveDay":           assureLeave,    
	    	"dimissionApproval.workDays":                 removMon ,        
			"dimissionApproval.absenceLeaveMoney":        canUMon  ,        
			"dimissionApproval.sickLeaveMoney":           canUerMo  ,       
			"dimissionApproval.dinnerAllowanceMoney":     launch    ,       
			"dimissionApproval.employeeCardMoney":        canUoaMo  ,       
			"dimissionApproval.employeeHandbookMoney":    canUofCrm,        
			"dimissionApproval.fileManaFeeMoney":         officePla,        
			"dimissionApproval.trainingFeeMoney"      :   stamperMo,        
			"dimissionApproval.individualIncome" :   finacialS,        
			"dimissionApproval.medicalTreatment" :   medical  ,        
			"dimissionApproval.announceFee"           :   announce ,        
			"dimissionApproval.fineFee"               :   fineFee  ,        
			"dimissionApproval.prizeFee"              :   prizeFee,         
			"dimissionApproval.EmployeeCard"          :   remov,            
	        "dimissionApproval.EmployeeHandbook"      :   canU,             
	        "dimissionApproval.FileManaFee"           :   canUer            
	}                                                        
	$.ajax({                                                    
		url:"/approvalajax/humanResourceDimission",
		data:params,
		type:"post",
		success:function(data){
			if(data == 'success'){
				flowApproval.approval(parent,parentId,returnUrl);	
			}else{
				 dialog(returnStr, "unsuccess", true, 2);
			}
		}
	})
	
}
