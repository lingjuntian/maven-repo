var FlowApproval = function() {};

/**
 * @author warner
 * 
 */
FlowApproval.prototype = {
	/**
	 * 审核
	 * 
	 * @param parent
	 * @param parentId
	 * @param redirect
	 */
	approval : function(parent, parentId, redirect) {
		$(".button-yellow").hide();
		var data = {
			"parent" : parent,
			"parentId" : parentId,
			"mails" : ""
		};
		this.ajax("/approval/flowApproval_approval", data, redirect, "审核失败");
	},

	/**
	 * 作废
	 * 
	 * @param approvalName
	 * @param parent
	 * @param parentId
	 * @param redirect
	 */
	invalid : function(parent, parentId, redirect) {
		var data = {
			"parent" : parent,
			"parentId" : parentId,
			"mails" : ""
		};
		this.ajax("/approval/flowApproval_invalid", data, redirect, "作废失败");
	},
	/**
	 * 统一提交方式
	 * @param action
	 * @param data
	 * @param redirect
	 * @param error
	 */
	ajax : function(action, data, redirect, error) {
		var mails = getApprovalMail();
		data.mails = mails;
		$.ajax({
			type : "GET",
			url : encodeURI(action),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("成功！", "success", true, 2);
					window.location.href = redirect;
				} else {
					$(".button-yellow").show();
					dialog(returnStr, "unsuccess", true, 10);
				}
			}
		});
	}
};

function getApprovalMail() {
	var container = $("#mailsForApproval");
	var mails = [];
	$.each(container.find("input[name='mails']"), function() {
		if ($(this).attr("checked")) {
			mails.push($(this).val());
		}
	});
	return mails;
}

var flowApproval = new FlowApproval();
