$(function() {
	/*隐藏确定页面*/
	$("#confirm").hide();
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */	
		if (error) {
			switchPageForConfirm();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
            copyValueToConfig();/* 将新建页面的数值写入确认页面 */
            getEmailList();/* 获取邮件发送列表 */
            copyFileList();/*上传附件公用*/
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		$("#confirm").hide();
		$("#write").show();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#iotOrderForm").append(inputStr);
    		}
    	});
		
    	$("#submit").hide();
    	$("#iotOrderForm").attr("action","/crm/iotOrder_create");
		$("#iotOrderForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/crm/iotOrder_show?iotOrder.id="+id;},1000);
			}else {
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}	
	        return false;
			
		});
	});

});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#iotOrderForm").validationEngine('validate');
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
    /*清空备注*/
	$("#remark_confirm").text("");
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*写值*/
     $("#customerName_confirm").text($("#customerName").val());
	 $("#iotName_confirm").text($("#iotName").val());
	 $("#iotId_confirm").text($("#iotId").val());
	 $("#labelName_confirm").text($("#labelName").val());
	 $("#currencyList_confirm").text($("#currencyList").val());
	 $("#taxRate_confirm").text($("#taxRate").val()+"%");
	 $("#remark_confirm").text($("#remark").val());
	 /*写表格详细值*/
		var $trs = $("#detailListTbody").find("tr");
	    var sum = 0 ;
		for ( var i = 0; i < $trs.size(); i++) {
			var $tr = $trs.eq(i);
			var quantity = parseFloat($tr.find("input[tdTag=quantity]").val());
			var taxUnitPrice = parseFloat($tr.find("input[tdTag=taxUnitPrice]").val());
			var taxSum = quantity * taxUnitPrice;
			sum = sum+taxSum;
			var trString = 
				"<tr><td class=\"equiment\"><div>"+$tr.find("input[tdTag=ingdanNo]").val()+"</div></td>"
				+ "<td class=\"remark\"><div>"+$tr.find("input[tdTag=gmvDescribe]").val()+"</div></td>"
				+ "<td class=\"\"><div>"+$tr.find("input[tdTag=unit]").val()+"</div></td>"
				+ "<td class=\"\"><div>"+$tr.find("input[tdTag=quantity]").val()+"</div></td>"
				+ "<td class=\"currency\"><div>"+$tr.find("input[tdTag=taxUnitPrice]").val()+"</div></td>"
				+ "<td class=\"\" style=\"text-align: center\"><div>"+$tr.find("input[tdTag=unitPrice]").val()+"</div></td>"
				+ "<td class=\"\" style=\"text-align: center\"><div>"+taxSum+"</div></td></tr>"
			   $("#detailListTbody_confirm").append(trString);
		}
	   var sumTr =
		"<tr><td></td><td></td><td></td><td></td><td></td><td style=\"text-align: center\">总计：</td><td style=\"text-align: center\">"+sum+"</td>";
	   $("#detailListTbody_confirm").append(sumTr);
}

/* 获取邮件发送列表 */
function getEmailList() {
	var url = "/crm/iotOrder_showConfirmMail";
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#submit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else if(nodeNoApprovalUser){
			$("#submit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else{
			$("#submit").show();
		}
	});
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").show();
	$("#write").hide();
}

