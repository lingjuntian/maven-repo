$(function() {
	$("#change_userName,#addyear,#userName,#userId").addClass("validate[required]");
	$("[validate=money]").addClass("validate[required,custom[amountPlusOrMinus]]");
	/*表格修饰*/
	$(".table-box").css({'height':'auto'});
	$('#dataTables').dataTable( {
		"sScrollX": "100%",
		"sScrollXInner": "200%",
		"bPaginate": false,
		"bLengthChange": false,
		"bFilter": false,
		"bSort": false,//需要排序
		"aaSorting": [],//不需要初始化排序
		"aoColumnDefs": [{ "bSortable": false, "aTargets": [ 0 ] }],
		"bInfo": false,
		"bAutoWidth": false,
		"bScrollCollapse": true
	} );
	
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function() {
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=show]").val($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=id]").val($(this).attr("vid"));
		return false;
	});
	
	/**查询**/						
	$("#selectButton").click(function(){
		 $("#selectForm").submit();
	});
	
    /*取消修改*/
	$("[closeTag=close]").click(function(){
		$(".popup-mask,.popup").hide();
		$("body").validationEngine('hidePrompt');
		return false;
	});
	
	/* 显示修改框 */
	$(".edit-text").click(function(){
		var $dataArray = new Array();
		$(this).siblings("input").each(function(index, element) {
			$dataArray[index] = $(this).val();
		});
		$inputGroup = $(".popup-cost-approval-setting-credit-type-person .input-text");
		for (var i=0; i<$inputGroup.length; i++){
			$inputGroup.eq(i).val($dataArray[i]);
		}
		pagePopup(".popup-cost-approval-setting-credit-type-person",true);
	});
	
	/*提交修改*/
	$("#changeButton").click(function(){
		var formError = $("#changeForm").validationEngine('validate');
		if(formError){
			$(".popup-mask,.popup-cost-approval-setting-credit-type-person").hide();
			$("#changeForm").ajaxSubmit(function(returnStr){
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					$("#selectForm").submit();
				}else if(returnStr == 'inputIllegal'){
					dialog("数据错误", "unsuccess", true, 2);
				}else{
					dialog("服务器繁忙，请联系管理员或稍后再试", "unsuccess", true, 2);
				}
				return false;
			});
		}
	});
	
	/* 添加 */
	$(".add-text").click(function(){
		pagePopup(".popup-cost-approval-add-credit-type-person",true);
	});
	
	/*自动匹配用户*/
	userAutoComplete();
	
	/*提交增加用户*/
	$("#addButton").click(function(){
		var formError = $("#addForm").validationEngine('validate');
		if(formError){
			$(".popup-mask,.popup-cost-approval-add-credit-type-person").hide();
			$("#addForm").ajaxSubmit(function(returnStr){
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					$("#selectForm").submit();
				}else{
					dialog(returnStr, "unsuccess", true, 2);
				}
				return false;
			});
		}
	});
});

/*自动匹配用户*/
function userAutoComplete(){  
$.ajax({  
    type:"GET",  
    url:encodeURI("/approvalajax/findAllUser"),  
    dataType:"json",  
    success:function(data, textStatus){  
        if(data != null && data.userList != null){  
            $("#userName").autocomplete(data.userList, {  
                /**加自定义表头**/  
                tableHead: "<div><span style='width:40%' class='col-1'>名称</span> <span style='width:58%' class='col-2'>邮箱</span></div>",  
                minChars: 0,  
                width: 310,  
                matchContains: "true",  
                autoFill: false,  
                formatItem: function(row, i, max) {  
                    return "<span  style='width:40%' class='col-1'>" + row.name + "</span> " + "<span style='width:58%' class='col-2'>" + row.userMail + "</span>";  
                },  
                formatMatch: function(row, i, max) {  
                    return row.name+row.nickName+row.enName;  
                },  
                formatResult: function(row) {  
                    return row.name;  
                }  
            }).result(function(e,data,value,sec){/**加选中后的回调函数**/  
                $("#userName").val(data.name);  
                $("#userId").val(data.id);  
            }).bind("unmatch", function(){  
            	$("#userName").val("");  
                $("#userId").val("");
            });  
        }  
    }  
});   
} 