$(function(){
 	resetRowNO();
	$("#validDate").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}, minDate:GetTodayDateStr()});
	});
	$("#submit").click(function(){
		save();
		return false;
    });

    //$("#ledger").addClass("validate[required]");
    $("#supplierId").addClass("validate[required]");
    $("#validDate").addClass("validate[required,past[" + GetTodayDateStr() + "],custom[date]]");
    /*$("#supplierUl a").click(function(){
		if($("#ledger").val() != $(this).attr("labelId")){
			$("#ledinput").val("");
			$("#ledspan").text("请选择帐套");
			$("[id*=ledger]").attr("style", "display:none;");
			$("#ledger" + $(this).attr("labelId")).attr("style", "display:;");
		}
	});
	
	if($("#supplierId").val() != ""){
		$("#ledger" + $("#supplierId").val()).attr("style", "display:;");
	} */
});


function resetRowNO(){
	var len = $("#table tr").size();

	for(var i = len - 1; i >= 0; i--){
		var name = "salesQuotationDetails[" + i + "].";
		var tr = $("#table tr").eq(i);
		
		tr.find("input").each(function(){
			if($(this).attr("vhidden") != null && $(this).attr("vhidden") != ''){
				$(this).attr("name", name + $(this).attr("vhidden"));
				$(this).attr("id", $(this).attr("vhidden") + i);
			}
		});
		tr.find("[id*=rowNo]").val(i+1);
	    tr.find("#unitPrice" + i).addClass("validate[required,max[10000000],custom[positiveNumber]]");
	    tr.find("#dispatchDay" + i).addClass("validate[required,max[100],custom[positiveInteger]]");
	}

	$("#form").validationEngine('detach');
   	$("#form").validationEngine('attach');
}


function save(){
	if($("#form").validationEngine('validate')){
		$("#form").ajaxSubmit(function(returnStr){
	        if (returnStr != "error") {
	          dialog("成功！","success",true,1);
		      setTimeout(function(){window.location = "/approval/salesInquiry_index"},1000);	        
	        } else if(returnStr == "error"){
	         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
	        }
	      });
     }
}