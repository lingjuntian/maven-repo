$(function(){
	/**查询**/						
	$("#queryButton").click(function(){
		 $("#queryForm").submit();
	});
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findInventoryList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.inventoryList != null){
				inventoryList = data.inventoryList;
				setInventoryAutoComplete($("#inventoryCode"), data.inventoryList);
			}
		}
	}); 
	/*绑定回车事件*/
    $("#inventoryCode").keydown(function(event){
        if (event.keyCode == 13) {	  				
			setTimeout(function(){$("#queryForm").submit();},500);
		}
    }); 
    
    /**上传excel表格**/
    $("#importExcel").change(function(){
      if($(this).val() != "") {
        $("#uploadForm input").remove();
        var $submitFile = $(this).clone(true);
        $(this).before($submitFile);
        $(this).attr("id", "");
        $("#uploadForm").append($(this));
        $("#uploadForm").submit();
    }});  
    $("[id^=inventoryCode]").addClass("validate[required]");
    $("[id^=unitPrice]").addClass("validate[required,max[10000000],custom[positiveNumber]]");
    $("[id^=package_]").addClass("validate[max[10000000],custom[positiveInteger]]");
    $("[id^=update]").click(function(){
    	var $tr = $(this).parents("tr");
    	var $form = $("#form");
    	$form.append($tr.find("input").clone(true));
    	$form.attr("action", "/approval/salesInquiry_updatePriceList");
    	if($tr.validationEngine('validate')){
    		$form.submit();
    	} 
    });
    $("[id^=delete]").click(function(){
    	if (confirm("确定要删除这一行吗?")){
			var $tr = $(this).parents("tr");
	    	var $form = $("#form");
	    	$form.append($tr.find("input").clone(true));
	    	$form.attr("action", "/approval/salesInquiry_deletePriceList");
	    	$form.submit();
		}
    	return false;
    });
    
    $("#download").click(function(){
    	var url="/admin/exportExcel?whichPath=template&fileName=price_template.xls&downloadFileName=price_template.xls";
   		window.location.href=encodeURI(url);
    	return false;
    });
});

function setInventoryAutoComplete($input, list){
	$("#inventoryCode").unautocomplete().autocomplete(list, {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>产品型号</span> <span class='col-2'>产品类型</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.partNo + "</span> " + "<span class='col-2'>" + row.cinvName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.partNo;
		},
		formatResult: function(row) {
			return row.partNo;
		}
	});
}

function setPriceList(list){
	deleteEmptyTr();
	if(list != null){
		var len = list.length;
		var inquiryHistoryTable = $("#inquiryHistoryTable");
		for(var i = 0; i < len; i++){
			var inquiryDetail = list[i];
			var tr = $("#copyTr").clone(true);
			tr.attr("id", "");

			tr.find("[id*=inventoryCode]").val(resetNull(inquiryDetail.inventoryCode));
			tr.find("[id*=quantity]").val(resetNull(inquiryDetail.quantity));
			tr.find("[id*=expectDate]").val(resetDate(inquiryDetail.expectDate));
			
			inquiryHistoryTable.append(tr);
			tr.show();
			setInventoryAutoComplete(tr.find("[id*=inventoryCode]"));
		}
	}
    resetRowNO();
}