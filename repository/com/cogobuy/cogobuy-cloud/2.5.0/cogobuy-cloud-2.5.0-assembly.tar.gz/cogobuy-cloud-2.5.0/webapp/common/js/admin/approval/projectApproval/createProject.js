$(function() {

	$("#needTime").click(function() {
		WdatePicker();
	});
	/*
	 * $("#nei,#noGMV").click(function(){ alert("aaaa");
	 * $("#gmvLi").hide();$("#gmvConfirm_li").hide();
	 * $("#valueLi").show();$("#valueConfirm_li").show(); });
	 * $("#haveGMV").click(function(){ alert("aaaa");
	 * $("#valueLi").hide();$("#gmvConfirm_li").show();
	 * $("#gmvLi").show();$("#valueConfirm_li").hide(); });
	 */
	$("#nature").click(function() {
		if ($("#nature").val() == "对外服务(产生GMV)") {
			$("#valueLi").hide();
			$("#gmvConfirm_li").show();
			$("#gmvLi").show();
			$("#valueConfirm_li").hide();
		} else {
			$("#gmvLi").hide();
			$("#gmvConfirm_li").hide();
			$("#valueLi").show();
			$("#valueConfirm_li").show();
		}
	});

	// 添加验证
	$(
			"#deptName,#type,#nature,#needTime,#priority,#reason,#description,#target,#title")
			.addClass("validate[required]");
	$("#percentage,#value").addClass("validate[required,custom[number]]");
	/* 隐藏确定页面 */
	$("#confirm").hide();

	/* 点击下一步 */
	$("#next").click(function() {
		var error = validationInput();/* 验证输入 */
		if (error) {
			switchPageForConfirm();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
			copyValueToConfig();/* 将新建页面的数值写入确认页面 */
			getEmailList();/* 获取邮件发送列表 */
			copyFileList();/* 上传附件公用 */
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		$("#confirm").hide();
		$("#write").show();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit")
			.click(
					function() {
						// 获取已经选择的发送邮件对象
						var sendMail_check = $("input[type=checkbox][name='mails']"); // 得到所有被选中的checkbox
						sendMail_check
								.each(function(i) {// 循环拼装被选中项的值
									if ($(this).attr("checked")) {
										inputStr = "<input type=\"hidden\" name=\"mails\" value=\""
												+ $(this).val() + "\" />";
										$("#projectApprovalForm").append(
												inputStr);
									}
								});
						$("#submit").hide();
						$("#projectApprovalForm").attr("action",
								"/approval/project_create");
						$("#projectApprovalForm")
								.ajaxSubmit(
										function(returnStr) {
											var type = returnStr.split("_")[0];
											var id = returnStr.split("_")[1];
											if (type == "success") {
												dialog("成功", "success", true, 1);
												setTimeout(
														function() {
															window.location = "/approval/project_show?projectApproval.id="
																	+ id;
														}, 1000);
											} else {
												$("#submit").show();
												dialog(returnStr, "unsuccess",
														true, 2);
											}
											return false;
										});
					});

});

/* 验证输入 */
function validationInput() {
	return $("#projectApprovalForm").validationEngine('validate');
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/* 清空备注 */
	$("#remark_confirm").text("");
	/* 写值 */
	$("#buName_confirm").text($("#deptName").val());
	$("#type_confirm").text($("#type").val());
	$("#nature_confirm").text($("#nature").val());
	$("#location_confirm").text($("#location").val());
	$("#needTime_confirm").text($("#needTime").val());
	$("#priority_confirm").text($("#priority").val());
	$("#value_confirm").text($("#value").val() + "万");
	$("#percentage_confirm").text($("#percentage").val() + "%");
	$("#reason_confirm").text($("#reason").val());
	$("#description_confirm").text($("#description").val());
	$("#target_confirm").text($("#target").val());
	$("#remark_confirm").text($("#remark").val());
	$("#systemName_confirm").text($("#systemName").val());
}

/* 获取邮件发送列表 */
function getEmailList() {
	var deptId = $("#deptId").val();
	var systemName   = $("#systemName").val();
	var url = "/approval/project_showConfirmMail?deptId=" + deptId;
	url= url+"&projectApproval.systemName=" + systemName;
	$("#mailList").load(encodeURI(url), function() {
		/* 检测流程类型是否存在 */
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/* 检测流程节点是否都有审批人 */
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if (subCodeNotExisted) {
			$("#submit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程", "unsuccess", true, 5);
			return false;
		} else if (nodeNoApprovalUser) {
			$("#submit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程", "unsuccess", true, 5);
			return false;
		} else {
			$("#submit").show();
		}
	});
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").show();
	$("#write").hide();
}

/* 用于上传文件使用 */
function copyFileList() {
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function() {
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",
			function() {
				fileDownLoad($(this));
				return false;
			});
}
