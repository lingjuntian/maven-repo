$(function() {
	$("#credit").addClass("validate[required,custom[amountTen]]");
	/* 信息修改 */
	$(".edit-text").click(function(){
		var $id = $(this).attr("href");
		var $obj = $(this).parents(".form-customer-account").find("[sameName='formBox']");
		var $textObj = $(this).parents(".form-customer-account").find(".edit-text");
		var $isHidden = $($id).is(":hidden");
		if($isHidden){
			$obj.slideUp("slow");
			$($id).slideDown("slow");
			$textObj.text("取消修改");
		}else{
			$obj.slideDown("slow");
			$($id).slideUp("slow");
			$textObj.text("修改");
		}
		return false;
	});
	
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function() {
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=id]").val($(this).attr("vid"));
		$(this).parents(".options-select").find("input[tag=show]").val($(this).attr("vshow"));
		$(this).validationEngine('hidePrompt');
		return false;
	});
	
	
	/* 修改 */
	$("#updateCredit_submit").click(function() {
		var error = $("#updateCredit_form").validationEngine('validate');
		if(error){
			$("#updateCredit_submit").hide();
			$("#updateCredit_form").ajaxSubmit(function(returnStr) {
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					dialog("成功！","success",true,1);
					window.location = "/approval/caApproval_show?infoId="+id;
				}else{
					$("#updateCredit_submit").show();
					dialog(returnStr,"unsuccess",true,2);
				}
				return false;
			});
		}
	});
	
	/*附件下载*/
	$("a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
  		return false;
	});
	
	/*保存修改(附件)*/
	$("#attachmentButton").click(function(){
		var infoId =$("#caInfoId").val();
		setTimeout(function(){window.location = "/approval/caApproval_show?infoId="+infoId;},500);	
	});
});

/*附件下载*/
function fileDownLoad($obj){
	$("#fileNameDownId").val($obj.attr("fileName"));
	$("#srcNameDownId").val($obj.attr("srcName"));
	$("#fileDownloadForm").submit();
}


/*删除文件*/
function deleteFile(infoId,fileTag) {
	var data = {
		"infoId" : infoId,
		"fileTag" : fileTag
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/caApproval_deleteFile"),
		data : data,
		success : function(returnStr) {
			if(returnStr == "error"){
	        	dialog("删除失败","unsuccess",true,1);	    
			}else{
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					dialog("删除成功","success",true,1);
					setTimeout(function(){window.location = "/approval/caApproval_show?infoId="+id;},500);	
				}
			}
			return false;
		}
	});
}


/*作废*/
function invalidApproval(parent,parentId,redirect){
	var test = confirm("确定不通过审核吗？");
	if(test){
		flowApproval.invalid(parent,parentId,redirect);
	}else{
		return;
	}
}

/**
 * 客服建档时审核通过
 * @param parentId
 */
function caLastApproval(parentId,returnUrl) {
	var $ledger = $("#ledger").val();
	var $customerCode = $("#customerCode").val();
	if( $ledger == ""){
		dialog("账套不能为空","warning",false,2);
		return;
	}else if( $customerCode == ""){
		dialog("客户编码不能为空","warning",false,2);
		return;
	}else{
		$(".button-yellow").hide();
		var data = {
				"info.id" : parentId,
				"info.ledger" : $ledger,
				"info.customerCode" : $customerCode,
				"mails" : getApprovalMail()
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/approval/caApproval_caLastApproval"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					window.location.href = returnUrl;
				}else if(returnStr == 'code'){
					$(".button-yellow").show();
					dialog("客户编码已经存在", "unsuccess", true, 2);
				} else {
					$(".button-yellow").show();
					dialog("失败", "unsuccess", true, 2);
				}
			}
		});
	}
}

/**
 * 客服变更建档时审核通过
 * @param parentId
 */
function caChangeLastApproval(parentId,returnUrl) {
	var $ledger = $("#ledger").val();
	if( $ledger == ""){
		dialog("账套不能为空","warning",false,2);
		return;
	}else{
		$(".button-yellow").hide();
		var data = {
				"info.id" : parentId,
				"info.ledger" : $ledger,
				"mails" : getApprovalMail()
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/approval/caApproval_caChangeLastApproval"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					window.location.href = returnUrl;
				} else {
					$(".button-yellow").show();
					dialog("失败", "unsuccess", true, 2);
				}
			}
		});
	}
}