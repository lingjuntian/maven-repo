/**
 * crm 项目详情js
 */

$(function(){
	$("#editEmail").hide();
	$(".showHide").hide();
	//添加验证
	$("#visitDate,#reportCustomer,#content,#nextPlan,[tdtag=content],[tdtag=responsible],[tdtag=finishTime]").addClass("validate[required]");
	// 报告-编辑
	$('.item-add .edit').click(function(){
		$("#editEmail").show();
		$("#commentEmail").hide();
		$("#reportcontent").hide();
		$("#chance").hide();
		$("#showNextPlan").hide();
		$(".editNextPlan").show();
		$('.item-add table input,.item-add table textarea').attr('readonly','');

		$('.item-add table input,.item-add table textarea,.item-add table select option').css({'border':'1px solid #ccc','border-radius':'3px'});
		
		// 修改input框聚焦时的border-color
		$('.item-add table input,.item-add table textarea').focus(function(){
		    $(this).css({'border-color':'#03A1E8'});
		});
		$('.item-add table input,.item-add table textarea').blur(function(){
		    $(this).css({'border-color':'#ccc'});
		});

		var str1 = '<td colspan="4"  class="btn-td"><a href="#" title="保存" class="save btn-save ">保存</a><a href="#" title="取消" id="cancelBut" class="cancel btn-save">取消</a></td>';
		$('.item-add .edit').parent().replaceWith(str1);

		// select框的隐藏显示
		$('.item-add table select,.item-add table textarea').css({'display':'block'});
		//$('.item-add table td span').css({'display':'none'});
	    
		//显示联系人编辑框
		var $trs=$("#contactShow").find("input[tdTag=contactName]");
		var $trIds=$("#contactShow").find("input[tdTag=contactId]");
		var $trs2=$("#contactEdit").find("input[tdTag=contactName]");
		var $trIds2=$("#contactEdit").find("input[tdTag=contactId]");
		for ( var i = 0; i < $trs.size(); i++) {
			$trs2.eq(i).val($trs.eq(i).val());
			$trIds2.eq(i).val($trIds.eq(i).val());
		}
		$("#contactShow").hide();
		$("#contactEdit").removeAttr("style");
		$(".showHide").show();
		$(".editHide").hide();
		 customerAutoComplete($("#reportCustomer"));//公司补全
		 //联系人 补全
		 conatctAutoComplete($("#contact1"),$("#contactId1"));
		 conatctAutoComplete($("#contact2"),$("#contactId2"));
		 conatctAutoComplete($("#contact3"),$("#contactId3"));
		 projectAutoComplete($("#reportProject"));//项目补全   

         //下一步行动
        $("#nextplanTr").css({'display':'block'});

		   //拜访日期
		 $("#visitDate").addClass("input-text input-text-date");
		 $("#visitDate,[tdTag=finishTime]").mousedown(function(){
			WdatePicker({});
		 });

	});
	$('.item-add .edit').live('click',function(){
		$('.item-add table input,.item-add table textarea').attr('readonly','');

		$('.item-add table input,.item-add table textarea,.item-add table select option').css({'border':'1px solid #ccc'});
		
		// 修改input框聚焦时的border-color
		$('.item-add table input,.item-add table textarea').focus(function(){
		    $(this).css({'border-color':'#03A1E8'});
		});
		$('.item-add table input,.item-add table textarea').blur(function(){
		    $(this).css({'border-color':'#ccc'});
		});

		var str1 = '<td colspan="4"  class="btn-td"><a href="#" title="保存" class="save btn-save ">保存</a><a href="#" title="取消" class=" cancel btn-save">取消</a></td>';
		$('.item-add .edit').parent().replaceWith(str1);

	});

    //项目-编辑完成-保存/取消
	$('.item-add .save').live('click',function(){            // 保存
        clearNull();/* 清除空行 */
    	var isPass=validationInput();
     	if(isPass){
     		$(".item-add .save").hide();
     		//获取已经选择的发送邮件对象
        	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
        	sendMail_check.each(function(i){//循环拼装被选中项的值
        		if($(this).attr("checked")){
        			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
        			$("#reportForm").append(inputStr);
        		}
        	});
     		
     		$("#reportForm").attr("action","/crm/report_update");
     		$("#reportForm").ajaxSubmit(function(returnStr) {
    			var type = returnStr.split("_")[0];
     			var id = returnStr.split("_")[1];
     			if (type == "success") {
     				dialog("成功","success",true,1);
     				var str="/crm/report_show?visitReport.id="+id;
     				setTimeout(function(){window.location = str;},1000);	  
     			}else {
     				$(".item-add .save").show();
     				dialog(returnStr,"unsuccess",true,2);
     			}	
     	        return false;
     		});
     	}
	});
	$('#cancelBut').live('click',function(){                         // 取消
		dialog("您确定要放弃编辑吗？",null,true,null,function(){
			var id=$("#visitReportId").val();
	    	var str="/crm/report_show?visitReport.id="+id;
	    	window.location.href=str;
		});
	});
    
	
	/*联系人自动匹配*/
 	function conatctAutoComplete($input,$inputId){
 		     //  var cid=$("proCustomerId").val();
 		    $input.autocomplete(encodeURI("/crmAjax/contact_findConTop8"), {
 	        //**加自定义表头**//*
 	        minChars: 0,
 	        width: 130,
 	       //extraParams:{cid:$("proCustomerId").val()}, 
 	        matchContains: "true",
 	        autoFill: false,
 	        dataType: 'json',
 	        parse: function(data) {  
 	            var rows = [];  
 	            if(data == null || data.contacts == null){
 	            	return rows;
 	            }
 	            for(var i=0; i<data.contacts.length; i++){    
 	                rows[rows.length] = {    
 	                    data:data.contacts[i],              
 	                    value:data.contacts[i].chName,     
 	                    result:data.contacts[i].chName   
 	                };  
 	            }  
 	            return rows;  
 	        }, 
 	        formatItem: function(row, i, max) {
 	            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"</div>";
 	        },
 	        formatMatch: function(row, i, max) {
 	            return row.chName;
 	        }
 		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
 		    	$(this).val("");
 		    	$inputId.val("");
 		    	$(this).val(data.chName);
 		    	$inputId.val(data.id);
 		    }).bind("unmatch", function() {//**没有匹配时**//*
 		    	$(this).val("");
 		    	$inputId.val("");
 		    });
 	}
	
 	

	/*客户自动匹配*/
	function customerAutoComplete($input){
		    $input.autocomplete(encodeURI("/crmAjax/customer_findCusTop8"), {
	        //**加自定义表头**//*
		    //tableHead: "<div> <span class='col-3'>公司名称</div>",
	        minChars: 0,
	        width: 350,
	        matchContains: "true",
	        autoFill: false,
	        dataType: 'json',
	        parse: function(data) {  
	            var rows = [];  
	            if(data == null || data.customers == null){
	            	return rows;
	            }
	            for(var i=0; i<data.customers.length; i++){    
	                rows[rows.length] = {    
	                    data:data.customers[i],              
	                    value:data.customers[i].chName,     
	                    result:data.customers[i].chName   
	                };  
	            }  
	            return rows;  
	        }, 
	        formatItem: function(row, i, max) {
	            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"</div>";
	        },
	        formatMatch: function(row, i, max) {
	            return row.chName;
	        }
		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
		    	$(this).val("");
		    	$("#reportCustomerId").val("");
		    	$(this).val(data.chName);
		    	$("#reportCustomerId").val(data.id);
		    }).bind("unmatch", function() {//**没有匹配时**//*
		    	$(this).val("");
		    	$("#reportCustomerId").val("");
		    });
	}
 	
	/*项目自动匹配*/
	function projectAutoComplete($input){
		    $input.autocomplete(encodeURI("/crmAjax/report_autoProject"), {
	        //**加自定义表头**//*
	        minChars: 0,
	        width: 350,
	        matchContains: "true",
	        autoFill: false,
	        dataType: 'json',
	        parse: function(data) {  
	            var rows = [];  
	            if(data == null || data.projects == null){
	            	return rows;
	            }
	            for(var i=0; i<data.projects.length; i++){    
	                rows[rows.length] = {    
	                    data:data.projects[i],              
	                    value:data.projects[i].projectName,     
	                    result:data.projects[i].projectName   
	                };  
	            }  
	            return rows;  
	        }, 
	        formatItem: function(row, i, max) {
	            return "<div style='height: 20px;font-size: 12px;'>"+row.projectName+"</div>";
	        },
	        formatMatch: function(row, i, max) {
	            return row.projectName;
	        }
		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
		    	$(this).val("");
		    	$("#reportProjectId").val("");
		    	$(this).val(data.projectName);
		    	$("#reportProjectId").val(data.id);
		    }).bind("unmatch", function() {//**没有匹配时**//*
		    	$(this).val("");
		    	$("#reportProjectId").val("");
		    });
	}
 	
 	

    
    /* 验证输入 */
    function validationInput() {
    	return $("#reportForm").validationEngine('validate');
    };
    
});







