$(function () {
    var $iotEdit = $('.iot-edit'),
        $iotEditTable = $iotEdit.find('table'),
        $popupTable = $('.popup-box table');

    // // 项目详情-点击编辑
    $iotEdit.find('.fl .edit').click(function () {                            // "编辑"为已创建元素时直接click事件
        $(".editHide").hide();
        $(".editShow").show();
        if($("#ingDanSaleSer").val()==""){
            $("#saleCheckBok").hide();
        }
        // $customerEditTable.find('input,textarea').attr('readonly','').addClass('input-text').css({'border':'1px solid #ccc'});
        $iotEditTable.find('.iotInput,.iotArea').attr('readonly', '').css({'border': '1px solid #ccc'});
        //$iotEditTable.find('select option').css({'border':'1px solid #ccc'});

        // 修改input框聚焦时的border-color
        $iotEditTable.find('input,textarea').focus(function () {
            $(this).css({'border-color': '#03A1E8'});
        });
        $iotEditTable.find('input,textarea').blur(function () {
            $(this).css({'border-color': '#ccc'});
        });
        var str1 = '<td colspan="4" class="btn-td"><a href="#" title="保存" class="btn-save save">保存</a><a href="#" title="保存" class="cancel">取消</a></td>';
        $iotEdit.find('.edit').parent().replaceWith(str1);


        // 显示隐藏下拉框 复选框
        $('.iot-edit .iot-edit-dpnb').addClass('iot-edit-dpn');
        $('.iot-edit .iot-edit-dpnb2').addClass('iot-edit-dpb');

        //编辑时自动勾选已参与活动的复选框
        var activitys = $("#inActivityHide").val().split(';');
        var $activitysInput = $("#activitys").find("input");
        for (var i = 0; i < activitys.length - 1; i++) {
            for (var j = 0; j < $activitysInput.size(); j++) {
                var $input = $activitysInput.eq(j);
                if (activitys[i] == $input.val()) {
                    $input.attr("checked", "checked");//如果本项目参加了该活动，编辑时 将复选框默认选中
                }
            }
        }

        //编辑时自动勾选硬蛋销售服务
        var ingDanSaleVal = $("#ingDanSaleSer").val();
        if(ingDanSaleVal != ""){
            var ingDanSale = ingDanSaleVal.split(';');
            var ingdanCheck=$("[tdTag=ingdanSaleDetail]");
            for (var i = 0; i < ingDanSale.length - 1; i++) {
                for (var j = 0; j < ingdanCheck.size(); j++) {
                    var $input = ingdanCheck.eq(j);
                    if (ingDanSale[i] == $input.val()) {
                        $input.attr("checked", "checked");
                    }
                }
            }
        }



    });
    //目标市场下框
    $(".marketOption").click(function () {
        $("#market").val(this.text);
    });
    //销售渠道下框
    $(".saleTypeOption").click(function () {
        $("#saleType").val(this.text);
    });
    //分类下框
    $(".classifyOption").click(function () {
        $("#classify").val(this.text);
    });

    //联盟成员下框
    $(".isAllianceOption").click(function () {
        if (this.text == '是') {
            $("#isAlliance").val(1);
        } else {
            $("#isAlliance").val(0);
        }
    });
    //进展下框
    $(".progressOption").click(function () {
        $("#progress").val(this.text);
    });
    //主要联系人下拉 
    $(".mainConInfoOption").click(function () {
        $("#mainConInfoInput").val($(this).attr("tdTag"));
    });


    $iotEdit.find('.fl .edit').live('click', function () {// "编辑"为新创建元素时live绑定事件
        $iotEditTable.find('input,textarea').attr('readonly', '').css({'border': '1px solid #ccc'});
        $iotEditTable.find('select option').css({'border': '1px solid #ccc'});
        // 修改input框聚焦时的border-color
        $iotEditTable.find('input,textarea').focus(function () {
            $(this).css({'border-color': '#03A1E8'});
        });
        $iotEditTable.find('input,textarea').blur(function () {
            $(this).css({'border-color': '#ccc'});
        });
        var str1 = '<td colspan="4" class="btn-td"><a href="javascript:void(0)" title="保存" id="saveBut" class="btn-save save next-step">保存</a><a href="#" title="保存" class="cancel">取消</a></td>';
        $iotEdit.find('.edit').parent().replaceWith(str1);
        // 显示隐藏下拉框 复选框
        $('.iot-edit .iot-edit-dpnb').addClass('iot-edit-dpn');
        $('.iot-edit .iot-edit-dpnb2').addClass('iot-edit-dpb');

    });


    // 点击客户页面保存
    $('.iot-edit .fl .save').live('click', function () {

        var isPass = validationInput();
        if (isPass) {
            $(".iot-edit .fl .save").hide();
            $("#iotForm").attr("action", "/crm/iot_updateIot");
            $("#iotForm").ajaxSubmit(function (returnStr) {
                var type = returnStr.split("_")[0];
                var id = returnStr.split("_")[1];
                if (type == "success") {
                    dialog("成功", "success", true, 1);
                    var str = "/crm/iot_show?iot.id=" + id;
                    setTimeout(function () {
                        window.location = str;
                    }, 1000);
                } else {
                    $(".iot-edit .fl .save").show();
                    dialog(returnStr, "unsuccess", true, 2);
                }
                return false;
            });
        }
    });
    $('.iot-edit .fl .cancel').live('click', function () {
        dialog("您确定要放弃编辑吗？", null, true, null, function () {
            location.reload(true);
        });
    });

    //数据验证
    $("#iotProjectName,#classify").addClass("validate[required]");
    //联系人填出框数据验证
    $("#contactChName,#position,#contactEmail").addClass("validate[required]");
    $("#contactPhone").addClass("validate[required,custom[mobile]]");
    $("#contactEmail").addClass("validate[custom[email]]");
    /* 验证输入 */
    function validationInput() {
        if ($("#iotForm").validationEngine('validate') == false) {
            return false;
        };

        if (ingdanSaleSer() == false) {
            return false;
        }
        return true;
    };
    //参与活动多选框
    function activity() {
        var $activitys = $("#activitys").find("input");
        var activityVla = "";
        for (var i = 0; i < $activitys.size(); i++) {
            var $input = $activitys.eq(i);
            if ($input.attr("checked") == true) {
                activityVla = activityVla + $input.val() + ";";
            }
        }
        if (activityVla == "") {
            return false;
        }
        $("#inActivityHide").val(activityVla);
        return true;
    }

    //硬蛋销售服务
    function ingdanSaleSer(){
        var need=$('input:radio[name="neddSale"]:checked').val();
        var needVals ="";
        if(need == 'yes'){
            var needCheck=$('input:checkbox[tdTag="ingdanSaleDetail"]:checked');
            if(needCheck.size() == 0){ dialog("请选择需要的硬蛋提供的销售服务", "unsuccess", true, 2); return false;}
            for(var i = 0 ; i < needCheck.size() ; i++){
               var needVal=needCheck.eq(i).val();
               needVals = needVals + needVal + ";"
            }
            $("#ingDanSaleSer").val(needVals);
        }else{
            $("#ingDanSaleSer").val("");
        }

    }

    // 添加联系人填出框
    $('.customer-edit .add-text').click(function () {
        $('.btn-add-customer i').css({'display': 'inline'});
        $('.btn-add-customer').removeClass('none');
        $('#mask-div').css({'display': 'block', 'opacity': '0.6'});
        $('.customer-add .popup-box').css({'height': 428});
        $popupTable.find('input,textarea').focus(function () {       // 当鼠标聚焦或离开时修改边框颜色
            $(this).css({'border-color': '#03A1E8'});
        });
        $popupTable.find('input,textarea').blur(function () {
            $(this).css({'border-color': '#ccc'});
        });

    });
    //联系人弹出框返回
    $('#btn-cancle').click(function () {
        $("#contactChName").validationEngine('hidePrompt');
        $("#contactEmail").validationEngine('hidePrompt');
        $("#contactPhone").validationEngine('hidePrompt');
        $("#position").validationEngine('hidePrompt');
        $(this).parents('.box').css({'z-index': 66, 'position': 'static'});
        $(this).parents(".btn-add-customer").addClass("none");
        $('#mask-div').hide();
    });


    /**
     * 点击添加联系人按钮
     */
    $("#btn-save-contact").click(function () {
        var isPass = validationInputContact();
        if (isPass) {
            $("#btn-save-contact").hide();
            $("#savecontactForm").attr("action", "/crm/contact_save");
            var iid = $("#iotId").val();
            var inputStr = "<input type=\"hidden\" name=\"contact.iid\" value=\"" + iid + "\" />";
            $("#savecontactForm").append(inputStr);
            $("#savecontactForm").ajaxSubmit(function (returnStr) {
                var type = returnStr.split("_")[0];
                if (type == "success") {
                    dialog("成功", "success", true, 1);
                    setTimeout(function () {
                        window.location.reload(true);
                    }, 1000);
                } else {
                    $("#btn-save-contact").show();
                    dialog(returnStr, "unsuccess", true, 2);
                }
                return false;
            });
        }
    });

    /* 联系人验证输入 */
    function validationInputContact() {
        return $("#savecontactForm").validationEngine('validate');
    };


    //直接添加 iot 客户权限
    $("#addCustomerAccess").click(function () {
        var cid = $("#customerId").val();
        $.ajax({
            method: 'GET',
            url: "/crm/customer_addAccess",
            data: {cid: cid},
            success: function (returnStr) {
                var type = returnStr.split("_")[0];
                var id = returnStr.split("_")[1];
                if (type == "success") {
                    dialog("成功", "success", true, 1);
                    var str = "/crm/customer_show?customer.id=" + id;
                    setTimeout(function () {
                        window.location = str;
                    }, 1000);
                } else {
                    $("#saveBtn").show();
                    dialog(returnStr, "unsuccess", true, 2);
                }
                return false;
            }
        });

    });


    /**
     * 项目状态
     */
    $(".stateOption").click(function () {
        $("#state").val($(this).attr("vhidden"));
        if ($(this).attr("vhidden") == '其他') {
            $("#incalidReasonOpTr").show();
            if ($("#onIncalidReason").text() == '其他') {
                $("#incalidReasonInTr").show();
            }
        } else {
            $(".incalidReasonTr").hide();
        }
    });

    $(".incalidReasonOption").click(function () {
        if ($(this).attr("vhidden") == '其他') {
            $("#incalidReasonInput").val("");
            $("#incalidReasonInTr").show();
        } else {
            $("#incalidReasonInput").val($(this).attr("vhidden"));
            $("#incalidReasonInTr").hide();
        }
    });

    $("#saleYes").click(function () {
        $("#saleCheckBok").show();
    });

    $("#saleNo").click(function () {
        $("#saleCheckBok").hide();
    });

});








