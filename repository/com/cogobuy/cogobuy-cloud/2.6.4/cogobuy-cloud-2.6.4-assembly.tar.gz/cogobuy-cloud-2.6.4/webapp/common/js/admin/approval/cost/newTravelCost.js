var travelMax=$("#travelMax").val();
$(function(){
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		var $id = $(this).attr("vid");
		var $show = $(this).attr("vshow");
		var $rate = $(this).attr("vrate");
		$(this).parents(".options-select").find("input[tag=id]").val($id);
		$(this).parents(".options-select").find("input[tag=show]").val($show);
		$(this).parents(".options-select").find("input[tag=rate]").val($rate);
		var $selecttag = $(this).attr("selecttag");
		$("li ["+$selecttag+"]").hide();
		$("li ["+$selecttag+"="+$id+"]").show();
		return false;
	});
	
	//初始化时模拟点击BU，使其出现对应的Dep列表
	var buId = $("#buId").val();
	$("#buList").find("a[vid="+buId+"]").trigger("click");
	var costBuId = $("#costBuId").val();
	$("#costBuList").find("a[vid="+costBuId+"]").trigger("click");
	
	/* 日期控件*/
	$("[tag=date]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');},maxDate: GetTodayDateStr()});
	});
	$("#datetime1").click(function(){
		WdatePicker({onpicked:function(){},maxDate:getMinValue($('#datetime2').val(), GetTodayDateStr())});
	});
	$("#datetime2").click(function(){
		WdatePicker({onpicked:function(){},minDate:$('#datetime1').val(), maxDate:GetTodayDateStr()});
	});
	/*出差地点*/
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/findTravelCity"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.travelCityList != null){
            	travelCityList = data.travelCityList;
            	setPlaceAutoComplete($("#travelPlaceName"));
            }
        }
    });  
	 //上一步
    $("#upStep").click(function(){
    	//清空下一步列表
    	$("#ticketBody").find("tr[deleteFlag=yes]").remove();
    	$("#transportBody").find("tr[deleteFlag=yes]").remove();
    	$("#stayBody").find("tr[deleteFlag=yes]").remove();
    	$("#entertainBody").find("tr[deleteFlag=yes]").remove();
    	$("#othersBody").find("tr[deleteFlag=yes]").remove();
    	//清除住宿限制和提示
    	$("#prompt").text("");
		
		$("#twoStep").hide();
		$("#oneStep").show();
    });
    
	//下一步
    $("#nextStep").click(function(){
    	validateFunction();
    	changeIds();
    	var error = $("#historyForm").validationEngine('validate');
		if(error){
			if(JudgeAttachment()){ //判断附件
				//改名,并且计算
				changeNameAndCount();
				$("#showPrompt").validationEngine('hidePrompt');
				copyStyle();//复制表格 取回邮件列表
				$("#oneStep").hide();
				$("#twoStep").show();	
				copyFileList(); 
				return false;
			}
		}
		return false;
    });
    
    
    //备份草稿
    $("#backup").click(function(){
    	//改名,并且计算各类别的和
    	changeNameAndCount();
    	
    	//去掉复制用的tr
    	$("#historyForm").find("tr[hide=hide]").remove();
    	$("#historyForm").attr("action","/approval/costSave_create");
      	$("#historyForm").ajaxSubmit(function(returnStr){
			if(returnStr == "error"){
				dialog("数据库异常，请联系管理员或稍后再试","unsuccess",true,1);
			}else{
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					$("#backupId").val(id);
					dialog("草稿保存成功","success",true,1);
					$("#goTopButton").click();
				}
			}
			//补回隐藏的复制用的tr
			revert("transportTr","transportThead");
			revert("stayTr","stayThead");
			revert("entertainTr","entertainThead");
			revert("othersTr","othersThead");
			revert("ticketTr","ticketThead");
			
			//action地址改回
			$("#historyForm").attr("action","/approval/createCost_create");
	        return false;
		});
    	return false;
    });
});

//补回隐藏的复制用的tr
function revert(tr,thead){
	$detailTr = $(tr).clone(true);
	$detailTr.attr("id","");
	$detailThead = $(thead);
	$detailThead.append($detailTr);
}

//判断附件，并给出提示
function JudgeAttachment(){
	var attachmentNum = $("#fileListForCreate li").size();
	if(attachmentNum>0){
		return true;
	}else{//没有上传附件
		dialog("必须上传附件","warning",false,2);
		return false;
	}
}
function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}

//地点自动匹配
function setPlaceAutoComplete($input){
	$input.autocomplete(travelCityList, {
        /**加自定义表头**/
        tableHead: "<div><span class='col-1'>地名</span>",
        minChars: 0,
        width: 340,
        matchContains: "true",
        autoFill: false,
        formatItem: function(row, i, max) {
            return "<div><span class='col-1'>"+row.name+"</span></div>";
        },
        formatMatch: function(row, i, max) {
            return row.name;
        },
        formatResult: function(row) {
            return row.name;
        }
    }).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$("#travelPlaceName").val(data.name);
		$("#travelPlaceId").val(data.id);
		$("#subsidy").val(data.subsidy);//默认值
		$("#subsidySpan").text(data.subsidy);
		$("#subsidySelect").attr("vshow",data.subsidy);
		$("#subsidySelect").text(data.subsidy);
		$("#halfSubsidySelect").attr("vshow",data.halfSubsidy);
		$("#halfSubsidySelect").text(data.halfSubsidy);
		$.ajax({
	        type:"GET",
	        url:encodeURI("/approvalajax/findTravelMax?travelPlaceId="+data.id),
	        dataType:"json",
	        success:function(data, textStatus){
	            if(data != null && data.travelMax != null){
	            	travelMax = data.travelMax;
	            	//去掉住宿费验证（避免重复添加）
	            	$("input[limit=limit]").attr("class","input-text");
	            }
	        }
	    });  
		$(this).validationEngine('hidePrompt');
    }).bind("unmatch", function() {/**没有匹配时**/
    	$("#subsidySpan").text("");
		$("#subsidySelect").text("");
		$("#halfSubsidySelect").text("");
		
    	$("#travelPlaceName").val("");
		$("#travelPlaceId").val("");
		$("#subsidySelect").attr("vshow","");
		$("#halfSubsidySelect").attr("vshow","");
		$("#subsidy").val("");
    });
}

function copyStyle(){	
	var ticketSum = $("#ticketSum").val();
	var transportSum = $("#transportSum").val();
	var staySum =$("#staySum").val();
	var entertainSum = $("#entertainSum").val();
	var othersSum = $("#othersSum").val();
	var daysNum = $("#daysNum").val();
	var subsidy = $("#subsidy").val();
	var subsidySum = multiply(daysNum,subsidy);
	var totalSum = add(add(add(add(add(ticketSum,transportSum),staySum),entertainSum),othersSum),subsidySum);
	
	//复制单个
	$("#cName").text($("#createUserName").val());//姓名
	$("#cDepartment").text($("#buName").val()+" _ "+$("#departmentName").val());//部门
	//$("#cCost").text($("#").val());//费用
	var createDate = new Date();//申请日期
	$("#createDate").text(createDate.getFullYear()+" - "+(createDate.getMonth()+1)+" - "+createDate.getDate());
	var startDate = $("#datetime1").val();
	var endDate = $("#datetime2").val();
	$("#sYear").text(startDate.split("-")[0]);//出差计划
	$("#sMonth").text(startDate.split("-")[1]);
	$("#sDay").text(startDate.split("-")[2]);
	$("#eYear").text(endDate.split("-")[0]);
	$("#eMonth").text(endDate.split("-")[1]);
	$("#eDay").text(endDate.split("-")[2]);	
	$("#cTravelPlaceName").text($("#travelPlaceName").val());//出差地点
	$("#cTrvaelPurpose").text($("#travelPurpose").val());//出差目的
	
	
	//复制列表
	var trCopy;
	var rowNum;
	var costBuName = $("#costBuName").val();
	var costDepartmentName = $("#costDepartmentName").val();
	var currencyName = $("#currencyName").val();
	
	//交通
	rowNum =$("#transport").children("tr").size();
	$("#transportR1").attr("rowspan",rowNum+1);  //设置rowspan
	$("#transportR2").attr("rowspan",rowNum);
	for(var i = 0;i < rowNum; i++){
		$tr = $("#transport").children("tr").eq(i);
        trCopy = $("#transportCopy").clone(true);
    	trCopy.find("[flag=one]").text($tr.find("[name*=date]").val()); //日期
    	if($.trim($tr.find("[name*=sum]").val())!=""){
	    	trCopy.find("[flag=two]").text(costBuName); //费用BU
	    	trCopy.find("[flag=three]").text(costDepartmentName); //费用部门
	    	trCopy.find("[flag=seven]").text(currencyName);//币种
    	}
    	trCopy.find("[flag=four]").text($tr.find("[name*=transportName]").val()); //交通工具
    	trCopy.find("[flag=five]").text($tr.find("[name*=fromPlace]").val()); //出发地
    	trCopy.find("[flag=six]").text($tr.find("[name*=toPlace]").val());  //目的地
    	trCopy.find("[flag=eight]").text(fmoney($tr.find("[name*=sum]").val(),2));//金额
    	if(i == 0){ 
    		trCopy.find("[flag=nine]").text($tr.parents(["class=table-list"]).next().find("[name*=remark]").val()); //备注
    	}else{
    		trCopy.find("[id=transportR2]").remove();
    	}
    	trCopy.attr("id", "");
    	trCopy.attr("deleteFlag", "yes");
    	$("#transportBody").append(trCopy);
    	trCopy.show();
	}
	//住宿
	rowNum =$("#stay").children("tr").size();
	$("#stayR1").attr("rowspan",rowNum+1);  //设置rowspan
	$("#stayR2").attr("rowspan",rowNum);
	for(var i = 0;i < rowNum; i++){
		$tr = $("#stay").children("tr").eq(i);
        trCopy = $("#stayCopy").clone(true);
        var dateString = $tr.find("input[startDate=startDate]").val(); //起日期
        if($.trim($tr.find("[name*=endDate]").val())!=""){
        	dateString = dateString+ "<span class='split'>到</span>"+$tr.find("[name*=endDate]").val();
        }
    	trCopy.find("[flag=one]").html(dateString); //日期
    	if($.trim($tr.find("[name*=sum]").val())!=""){
	    	trCopy.find("[flag=two]").text(costBuName); //费用BU
	    	trCopy.find("[flag=three]").text(costDepartmentName); //费用部门
	    	trCopy.find("[flag=seven]").text(currencyName);//币种
    	}
    	trCopy.find("[flag=four]").text($tr.find("[name*=accommodation]").val()); //地点
    	trCopy.find("[flag=five]").text($tr.find("[name*=hotel]").val()); //酒店名称
    	trCopy.find("[flag=six]").text($tr.find("[name*=unitPrice]").val());//单价
    	trCopy.find("[flag=eight]").text(fmoney($tr.find("[name*=sum]").val(),2));//金额
    	if(i == 0){ 
    		trCopy.find("[flag=nine]").text($tr.parents(["class=table-list"]).next().find("[name*=remark]").val()); //备注
    	}else{
    		trCopy.find("[id=stayR2]").remove();
    	}
    	trCopy.attr("id", "");
    	trCopy.attr("deleteFlag", "yes");
    	$("#stayBody").append(trCopy);
    	trCopy.show();
	}
	//招待
	rowNum =$("#entertain").children("tr").size();
	$("#entertainR1").attr("rowspan",rowNum+1);  //设置rowspan
	$("#entertainR2").attr("rowspan",rowNum);
	for(var i = 0;i < rowNum; i++){
		$tr = $("#entertain").children("tr").eq(i);
        trCopy = $("#entertainCopy").clone(true);
    	trCopy.find("[flag=one]").text($tr.find("[name*=date]").val()); //日期
    	if($.trim($tr.find("[name*=sum]").val())!=""){
	    	trCopy.find("[flag=two]").text(costBuName); //费用BU
	    	trCopy.find("[flag=three]").text(costDepartmentName); //费用部门
	    	trCopy.find("[flag=seven]").text(currencyName);//币种
    	}
    	trCopy.find("[flag=four]").text($tr.find("[name*=accommodation]").val()); //地点
    	trCopy.find("[flag=five]").text($tr.find("[name*=customerName]").val()); //客户
    	trCopy.find("[flag=six]").text($tr.find("[name*=numOfperson]").val());//人数
    	trCopy.find("[flag=eight]").text(fmoney($tr.find("[name*=sum]").val(),2));//金额
    	if(i == 0){ 
    		trCopy.find("[flag=nine]").text($tr.parents(["class=table-list"]).next().find("[name*=remark]").val()); //备注
    	}else{
    		trCopy.find("[id=entertainR2]").remove();
    	}
    	trCopy.attr("id", "");
    	trCopy.attr("deleteFlag", "yes");
    	$("#entertainBody").append(trCopy);
    	trCopy.show();
	}
	//其它
	rowNum =$("#others").children("tr").size();
	$("#othersR1").attr("rowspan",rowNum+1);  //设置rowspan
	$("#othersR2").attr("rowspan",rowNum);
	for(var i = 0;i < rowNum; i++){
		$tr = $("#others").children("tr").eq(i);
        trCopy = $("#othersCopy").clone(true);
    	trCopy.find("[flag=one]").text($tr.find("[name*=date]").val()); //日期
    	if($.trim($tr.find("[name*=sum]").val())!=""){
	    	trCopy.find("[flag=two]").text(costBuName); //费用BU
	    	trCopy.find("[flag=three]").text(costDepartmentName); //费用部门
	    	trCopy.find("[flag=five]").text(currencyName);//币种
    	}
    	trCopy.find("[flag=four]").text($tr.find("[name*=others]").val()); //内容
    	trCopy.find("[flag=six]").text(fmoney($tr.find("[name*=sum]").val(),2));//金额
    	if(i == 0){ 
    		trCopy.find("[flag=seven]").text($tr.parents(["class=table-list"]).next().find("[name*=remark]").val()); //备注
    	}else{
    		trCopy.find("[id=othersR2]").remove();
    	}
    	trCopy.attr("id", "");
    	trCopy.attr("deleteFlag", "yes");
    	$("#othersBody").append(trCopy);
    	trCopy.show();
	}
	//补助
	var string = "（"+daysNum+"） 天 × 每天（"+subsidy+"）";
	$("#cSubsidy").text(string);
	$("#cCurrency").text(currencyName);
	$("#allSubsidy").text(fmoney(subsidySum,2));
	
	//机票
	rowNum =$("#ticket").children("tr").size();
	$("#ticketR1").attr("rowspan",rowNum+1);  //设置rowspan
	$("#ticketR2").attr("rowspan",rowNum);
	for(var i = 0;i < rowNum; i++){
		$tr = $("#ticket").children("tr").eq(i);
        trCopy = $("#ticketCopy").clone(true);
    	trCopy.find("[flag=one]").text($tr.find("[name*=date]").val()); //日期
    	if($.trim($tr.find("[name*=sum]").val())!=""){
    		trCopy.find("[flag=two]").text(costBuName); //费用BU
    		trCopy.find("[flag=three]").text(costDepartmentName); //费用部门
    		trCopy.find("[flag=seven]").text(currencyName);//币种
    	}
    	trCopy.find("[flag=four]").text($tr.find("[name*=fromPlace]").val()); //出发地
    	trCopy.find("[flag=five]").text($tr.find("[name*=transferPlace]").val()); //中转站
    	trCopy.find("[flag=six]").text($tr.find("[name*=toPlace]").val());  //目的地
    	trCopy.find("[flag=eight]").text(fmoney($tr.find("[name*=sum]").val(),2));//金额
    	
    	if(i == 0){ 
    		trCopy.find("[flag=nine]").text($tr.parents(["class=table-list"]).next().find("[name*=remark]").val()); //备注
    	}else{
    		trCopy.find("[id=ticketR2]").remove();
    	}
    	trCopy.attr("id", "");
    	trCopy.attr("deleteFlag", "yes");
    	$("#ticketBody").append(trCopy);
    	trCopy.show();
	}
	
	//单据
	$("#ccDepartment").text($("#buName").val()+" _ "+$("#departmentName").val());//部门
	$("#cYear").text(createDate.getFullYear());
	$("#cMonth").text(createDate.getMonth()+1);
	$("#cDay").text(createDate.getDate());
	
	$("#ticketCSum").text(fmoney(ticketSum,2));
	$("#transportCSum").text(fmoney(transportSum,2));
	$("#stayCSum").text(fmoney(staySum,2));
	$("#entertainCSum").text(fmoney(entertainSum,2));
	$("#othersCSum").text(fmoney(othersSum,2));
	$("#subsidyCSum").text(fmoney(subsidySum,2));
	$("#totalCSum").text(fmoney(totalSum,2));
	$("#cCost").text(fmoney(totalSum,2)); //费用
	$("#totalSumCopy").text(fmoney(totalSum,2));
	
	$("#ccName1").text($("#createUserName").val());
	$("#ccName2").text($("#createUserName").val());
	
	$("#currencyFlag").text(currencyName);
	$("#currencyFlagTwo").text(currencyName);
	lowToUpper(totalSum);
	
	//取回邮箱
	var createUserId = $("#createUserId").val();
	var departmentId = $("#departmentId").val();
	var buId = $("#buId").val();
	var costBuId = $("#costBuId").val();
	var costDepartmentId = $("#costDepartmentId").val();
	var regionId = $("#regionId").val();	
	var url = "/approval/cost_showConfirmMail?costApproval.createUserId=" + createUserId 
			+ "&costApproval.costDepartmentId=" + costDepartmentId
			+ "&costApproval.departmentId=" + departmentId 
			+ "&costApproval.buId=" + buId
			+ "&costApproval.costBuId=" + costBuId
			+ "&costApproval.regionId=" + regionId
			+ "&costApproval.totalSum=" + totalSum ;
			
	$("#mailList").load(encodeURI(url), function(){
		
    	//取得审批人
    	var labels = $("#mailList").find("label").size();
    	var names ="";
    	for(var i=0; i<labels ;i++){
    		var name= $("#mailList").find("label").eq(i).text();
    		if(i == labels-1){
    			names = names + "<li style='display:inline;'>"+ name +"</li>";
    		}else{
    			names = names + "<li style='display:inline;'>"+ name +",</li>";
    		}
    	}
    	$("#lead").html(names);
	});
}

//整理表格，去空行，至少保留一行
function cleanTbody(tbody){
	var trNum = tbody.find("tr").size();
	for(var i = trNum; i >= 0; i--){
		trNum = tbody.find("tr").size();
		var tr = tbody.find("tr").eq(i);
		if(checkEmptyTr(tr)){
			if(trNum > 1){ 
				//clearTrTips(tr);取消验证
				tr.remove();
			}
		}
	}
}

//验证空行
function checkEmptyTr(tr){
	var inputNum = tr.find("input[emptyFlag=emptyFlag]").size();
	var flag = true; //为空
	for(var i=0;i<inputNum;i++){
		var input = tr.find("input[emptyFlag=emptyFlag]").eq(i);
		if($.trim(input.val())!=""){
			flag = false; //不为空
			break;
		}
	}
	return flag;
}

/*改名,并且计算各类别的和,总额*/
function changeNameAndCount(){
	//整理5个表格,去空行
	cleanTbody($("#transport"));
	cleanTbody($("#stay"));
	cleanTbody($("#entertain"));
	cleanTbody($("#others"));
	cleanTbody($("#ticket"));
	
	var noNum =0;
	var tbodyNum = $("#tbodys tbody").size();
	//alert("tbody个数："+tbodyNum);
	for(var i = 0; i < tbodyNum; i++){
		var $tbody = $("#tbodys tbody").eq(i);
		var trNum = $tbody.children("tr").size();
		$tbody.parents(["class=table-list"]).next().find("[collect=rowNo]").val(trNum);//计算rowNO
		//alert("rowNo"+trNum);
		//alert("tr个数："+trNum);
		var collectSum =0;
		for(var j = 0; j < trNum; j++){
			var $tr = $tbody.children("tr").eq(j);
			var sum = $tr.find("[name*=sum]").val();
			collectSum = add(sum ,collectSum);
			//alert(collectSum);
			$tr.parents(["class=table-list"]).next().find("[collect=sum]").val(collectSum); //计算和
			var tdNum = $tr.children("td").size();
			//alert("td个数："+tdNum);
			for(var k = 0; k < tdNum; k++){
				var $td =  $tr.children("td").eq(k);
				var inputNum = $td.find("input").size();
				//alert("input个数："+inputNum);
				for(var v = 0; v < inputNum; v++){
					var $input = $td.find("input").eq(v);
					var name = $input.attr("name");
					var before= $.trim(name.split(".")[0]);
						var obefore =  $.trim(before.split("[")[0]); //避免重复添加[下标]
					var after= $.trim(name.split(".")[1]);
					var all = obefore+"["+noNum+"]"+"."+after;
					$input.attr("name",all);
				}
			}
			noNum++;
		}
	}
	var ticketSum = $("#ticketSum").val();
	var transportSum = $("#transportSum").val();
	var staySum =$("#staySum").val();
	var entertainSum = $("#entertainSum").val();
	var othersSum = $("#othersSum").val();
	var daysNum = $("#daysNum").val();
	var subsidy = $("#subsidy").val();
	var subsidySum = multiply(daysNum,subsidy);
	var totalSum = add(add(add(add(add(ticketSum,transportSum),staySum),entertainSum),othersSum),subsidySum);
	$("#totalSum").val(totalSum);
	$("#subsidySum").val(subsidySum);
}

function getCurrencyFlag(currencyName){
	var flag = "";
	if(null == currencyName || "" == currencyName || "undefined" == currencyName){
		flag = "¥";
	}else{
		if(currencyName == "人民币"){
			flag = "¥";
		}else if(currencyName == "美元"){
			flag = "$";
		}else if(currencyName == "港元"||currencyName == "港币"){
			flag = "HK$";
		}else if(currencyName == "欧元"){
			flag = "€";
		}else if(currencyName == "日元"){
			flag = "¥";
		}else if(currencyName == "澳元"){
			flag = "AU$";
		} else if (currencyName == "台币") {
			flag = "TWD";
		}else{
			flag = "¥";
		}
	}
	return flag;
}
function lowToUpper(num){
	if(!/^\d*(\.\d*)?$/.test(num)){
		
	}else{
		var UPPER = new Array("零","壹","贰","叁","肆","伍","陆","柒","捌","玖");
		var num_array = ("" + num).split(".");
		var defStr="零";
		/*小数位*/
		if(num_array[1] != null && num_array[1].length > 0){
			if(num_array[1].length < 2){
				$("#jiao").text(UPPER[num_array[1].charAt(0)]);
				$("#fen").text(defStr);
			}else{
				$("#jiao").text(UPPER[num_array[1].charAt(0)]);
				$("#fen").text(UPPER[num_array[1].charAt(1)]);
			}
		}else{
			$("#jiao").text(defStr);
			$("#fen").text(defStr);
		}
		/*整数位*/
		if(num_array[0] != null && num_array[0].length > 0){
			var intstr = "";
			if(num_array[0].length < 7){
				var temp = "";
				for(var i=0; i < 7 - num_array[0].length; i++){
					temp = temp + "0";
				}
				intstr = temp + num_array[0];
			}else{
				intstr = num_array[0].substring(num_array[0].length - 7);
			}
			$("#baiwan").text(UPPER[intstr.charAt(0)]);
			$("#shiwan").text(UPPER[intstr.charAt(1)]);
			$("#wan").text(UPPER[intstr.charAt(2)]);
			$("#qian").text(UPPER[intstr.charAt(3)]);
			$("#bai").text(UPPER[intstr.charAt(4)]);
			$("#shi").text(UPPER[intstr.charAt(5)]);
			$("#ge").text(UPPER[intstr.charAt(6)]);
		}else{
			$("#baiwan").text(defStr);
			$("#shiwan").text(defStr);
			$("#wan").text(defStr);
			$("#qian").text(defStr);
			$("#bai").text(defStr);
			$("#shi").text(defStr);
			$("#ge").text(defStr);
		}
		
	}
}

/* 添加一行 */
$("tr input").click(function(){
	var $tr = $(this).parents("tr");
	if($tr.nextAll().length==0){
		addTr($tr);
	}
});

$(".del-text").click(function(){
	var $obj = $(this).parents("tr");
	var $length = $obj.parents("tbody").find("tr").length;
	if($length<2){
		dialog("请最少保留1行","warning",false,2);
		return false;
	}
	delTr($obj);
});
/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.attr("hide","show");
	$copyTr.show();
	$tr.after($copyTr);
}
/* 删除行 */
function delTr($obj){
	$obj.remove();
}

function validateFunction(){
	$("#createUserName").addClass("validate[required]");
	$("#createUserId").addClass("validate[required]");
	
	$("#buName").addClass("validate[required]");
	$("#buId").addClass("validate[required]");
	
	$("#departmentName").addClass("validate[required]");
	$("#departmentId").addClass("validate[required]");
	
	$("#regionName").addClass("validate[required]");
	$("#regionId").addClass("validate[required]");
	
	$("#currencyName").addClass("validate[required]");
	$("#currencyId").addClass("validate[required]");
	
	$("#datetime1").addClass("validate[required]");
	$("#datetime2").addClass("validate[required]");
	
	$("#travelPlaceName").addClass("validate[required]");
	$("#travelPlaceId").addClass("validate[required]");
	$("#travelPurpose").addClass("validate[required]");
	
	$("#daysNum").addClass("validate[custom[positiveNumber]]");
	
	$("input[sumTag=sumTag]").addClass("validate[custom[positiveNumber]]"); //必须要有Id
	$("input[limit=limit]").addClass("validate[custom[positiveNumber]]");
	$("input[name*=numOfperson]").addClass("validate[custom[positiveNumber]]");
}
/*修改Id ,用于验证*/
function changeIds(){
	//改金额Id(因为验证的定位需要用Id)
	var sumTag = $("input[sumTag=sumTag]").size();
	for(var z=0;z<sumTag;z++){
		var sumInput = $("input[sumTag=sumTag]").eq(z);
		sumInput.attr("id","sumTag["+z+"]");
	}
	var limitTag = $("input[limit=limit]").size();
	for(var z=0;z<limitTag;z++){
		var limitInput = $("input[limit=limit]").eq(z);
		limitInput.attr("id","limitTag["+z+"]");
	}
	var personNumTag = $("input[name*=numOfperson]").size();
	for(var z=0;z<personNumTag;z++){
		var personNumInput = $("input[name*=numOfperson]").eq(z);
		personNumInput.attr("id","personNumTag["+z+"]");
	}
}