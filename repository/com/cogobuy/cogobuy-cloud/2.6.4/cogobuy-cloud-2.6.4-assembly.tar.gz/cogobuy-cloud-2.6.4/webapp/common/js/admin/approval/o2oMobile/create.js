$(function() {
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
		if (error) {
			getApprovalList();/* 获取邮件发送列表 */
			switchPageForCreate();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
			$("#fileId").remove();
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		switchPageForConfirm();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
    	$("#submit").hide();
		$("#o2oForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			var weixinId = returnStr.split("_")[2];
			if (type == "success") {
				setTimeout(function(){window.location = "/weixinApproval/o2oApproval_show?weixinId="+weixinId+"&approvalId="+id;},1000);	  
			}else{
				$("#submit").show();
				promptMessage($("#submitPromptMessage"),returnStr,2);
			}
	        return false;
		});
	});
	
	/* 点击提交 */
	$("#submitWeb").click(function() {
    	$("#submitWeb").hide();
		$("#o2oForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			var weixinId = returnStr.split("_")[2];
			if (type == "success") {
				setTimeout(function(){window.location = "/weixinApproval/o2oApproval_webshow?weixinId="+weixinId+"&approvalId="+id;},1000);	  
			}else{
				$("#submitWeb").show();
				promptMessage($("#submitPromptMessage"),returnStr,2);
			}
	        return false;
		});
	});
	
});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanSalesTeam();
	addIdAndNameForSalesTeam();
	cleanDetail();
	addIdAndNameForDetail();
}

/* 验证输入 */
function validationInput() {
	if($("#cusName").val() == ""){
		promptMessage($("#createPromptMessage"),"客户名称为空",2);
		addSalesTeamForValidation();
		addDetailListForValidation();
		return false;
	}
	if($("#detailList").find("section").length < 1){
		promptMessage($("#createPromptMessage"),"可推广型号为空",2);
		addSalesTeamForValidation();
		addDetailListForValidation();
		return false;
	}else{
		var $sectionNum = $("#detailList").find("section").size();
		for ( var i = $sectionNum-1; i >= 0; i--) {
			var $section = $("#detailList").find("section").eq(i);
			if ($.trim($section.find("input[tdTag=code]").val()) == "" || $.trim($section.find("input[tdTag=quantity]").val()) == "" ) {
				promptMessage($("#createPromptMessage"),"可推广型号中型号、数量不能为空",2);
				return false;
			}
		}
	}
	return true;
}

/**
 * 验证时最加协作人
 */
function addSalesTeamForValidation(){
	$copyp = $("#salesTeamHide").clone(true);
	$copyp.removeAttr("id");
	$copyp.removeAttr("style");
	$("#salesTeam").append($copyp);
	addUserAutoComplete($copyp.find("input[tdTag=name]"));
}

/**
 * 验证时最加可推广型号
 */
function addDetailListForValidation(){
	$copysection = $("#detailListHide").clone(true);
	$copysection.removeAttr("id");
	$copysection.removeAttr("style");
	$("#detailList").append($copysection);
}

/* 获取邮件发送列表 */
function getApprovalList() {
	var url = "/weixinApprovalAjax/o2o_showConfirmMail?opinion=aa";
	$("#detailList").find("input[tdTag=productLine]").each(function(){
		url+="&productLines="+$(this).val();
	});
	$.ajax({
        type:"GET",
        url:encodeURI(url),
        dataType:"json",
        success:function(data, textStatus){
        	if(data != null){
            	if(data.pmList != null){//动态填充PM
            		$.each(data.pmList,function(n,value) {
           			 	var listr = "<label><input type=\"checkbox\" checked=\"checked\" name=\"pmList\" value=\""+value.userMail+"\" /> "+value.enName+"</label>";
           			 	$("#pmlist").append(listr);
           	     	});
            	}
            	/* 20150124取消动态填充VP
            	if(data.vpList != null){//动态填充VP
            		$.each(data.vpList,function(n,value) {
            			var listr = "<label><input type=\"checkbox\" checked=\"checked\" name=\"vpList\" value=\""+value.userMail+"\" /> "+value.enName+"</label>";
           			 	$("#vplist").append(listr);
           	     	});
            	}
            	*/
            }
        }
    });
}


/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
function switchPageForCreate() {
	$("#write").hide();
	$("#confirm").show();
	return false;
}


/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").hide();
	$("#write").show();
}









