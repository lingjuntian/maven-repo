var autoCompleteInventoryList;
$(function() {
	/*增加验证*/
	$("[tdTag=inventoryCode]").addClass("validate[required]");
	$("[tdTag=taxUnitPrice],[tdTag=unitPrice]").addClass("validate[required,custom[amountSixPoint]]");
	$("[tdTag=restQuantity]").addClass("validate[required,custom[numberFormar]]");
	/*加载存货编码 可编辑 ashanahzhang 20160811*/
	addInventoryAutoCompleteChange($("#detailListTbody").find("input[tdTag=inventoryCode]"));
	/*增加日期控件*/
	$("input[tdTag=expectDate]").click(function() {
//		WdatePicker();
		
		//交期变化要写reason ashanahzhang 20160811
		WdatePicker({
			   onpicking:function(dp){
				   $(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
			       return false;
			     }
			   });

	});
	//$("input[tdTag=expectDate]:last").val(GetTodayDateStr());
	/*增加显示提交按钮*/
	$(document).keydown(function(event){ 
		 if (event.ctrlKey && event.keyCode == 122) {
			 $("#submit").show();
		 }
	});
	
	/* 添加一行 */
	/* 订单修改屏幕该功能，如有新的需提交新的订单审批 ashanahzhang 20160810
	$("tr input").click(function(){
		var $tr = $(this).parents("tr");
		$("[tdTag=autoItem]").val((parseInt($tr.find("input[tdTag=item]").val())+1).toString());
		if($tr.nextAll().length==0){
			addTr($tr);
		}
	});
	*/
	
	/*点击新增一行*/
	$("[data-name=addNewRow]").click(function(){
		if($(this).attr("data-val")==1){
			var $tr = $("#detailListTbody").find("tr:last");
			addTr($tr);
		}

	});
	
	/*取消拆行*/
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $length = $obj.parents("tbody").find("tr").length;
		if($length<2){
			dialog("请最少保留1行","warning",false,2);
			return false;
		}
		delTr($obj);
	});
	
	/*拆行 ashanahzhang 20160811*/
	$("[data-name=split]").click(function(){
		var $tr = $(this).parents("tr");
		var rowNo = $tr.find("input[tdTag=rowNo]").val();
		var inventoryCode = $tr.find("input[tdTag=inventoryCode]").val();
		var customerInventoryCode = $tr.find("input[tdTag=customerInventoryCode]").val();
		var inventoryName = $tr.find("input[tdTag=inventoryName]").val();
		var euc = $tr.find("input[tdTag=euc]").val();
		var license = $tr.find("input[tdTag=license]").val();
		var restQuantity = $tr.find("input[tdTag=restQuantity]").val();
		var shippedQuantity = $tr.find("input[tdTag=shippedQuantity]").val();
		var taxUnitPrice = $tr.find("input[tdTag=taxUnitPrice]").val();
		var unitPrice = $tr.find("input[tdTag=unitPrice]").val();
		var expectDate = $tr.find("input[tdTag=expectDate]").val();
		var oldId =  $tr.find("input[tdTag=oldId]").val();
		var cost =  $tr.find("input[tdTag=cost]").val();
		
		$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
		$copyTr.removeAttr("hide");
		$copyTr.removeAttr("style");
		$copyTr.find("input[tdTag=isAdd]").val(1);
		$copyTr.find("input[tdTag=rowNo]").val(rowNo);
		$copyTr.find("input[tdTag=inventoryCode]").val(inventoryCode);
		$copyTr.find("input[tdTag=changeInventoryCode]").val(inventoryCode);
		$copyTr.find("input[tdTag=customerInventoryCode]").val(customerInventoryCode);
		$copyTr.find("input[tdTag=inventoryName]").val(inventoryName);
		$copyTr.find("input[tdTag=euc]").val(euc);
		$copyTr.find("input[tdTag=license]").val(license);
		$copyTr.find("input[tdTag=restQuantity]").val(restQuantity);
		$copyTr.find("input[tdTag=restQuantityCopy]").val(restQuantity);
		$copyTr.find("input[tdTag=shippedQuantity]").val(0);
		$copyTr.find("input[tdTag=Quantity]").val(restQuantity);
		$copyTr.find("input[tdTag=taxUnitPrice]").val(taxUnitPrice);
		$copyTr.find("input[tdTag=changeTaxUnitPrice]").val(taxUnitPrice);
		$copyTr.find("input[tdTag=unitPrice]").val(unitPrice);
		$copyTr.find("input[tdTag=changeUnitPrice]").val(unitPrice);
		$copyTr.find("input[tdTag=expectDate]").val(expectDate);
		$copyTr.find("input[tdTag=changeExpectDate]").val(expectDate);
		$copyTr.find("input[tdTag=oldId]").val(oldId);
		$copyTr.find("input[tdTag=cost]").val(cost);
		
		$tr.after($copyTr);
		addInventoryAutoCompleteChange($copyTr.find("input[tdTag=inventoryCode]"));
		
	});
	
	/*打开、关闭行*/
	$("[data-name=work]").click(function(){
		var $obj = $(this).parents("tr");
		if($(this).hasClass("open-text")){//打开
			changeClosed($obj,"0","");
			$obj.find("[readOrChange]").attr("readonly",false).removeClass("disabled");
			$obj.find("input[tdTag=reason]").removeClass("validate[required]");
			$obj.find("input[tdTag=reason]").val("");
			$(this).removeClass("open-text");
		//	$(this).removeClass("order-close");
			$(this).text("关闭");
			$(this).attr("title","关闭");
			$obj.find("[data-name=split]").attr("style","display:inline");
			//新增一行链接有效
			$("#addNewRow").attr("data-val","1");
			$("#addNewRow").removeAttr("style");
			//改变整单关闭的状态以及验证
			if($("#closeSymbol").val()==1){				
				$("#closeSymbol").val("0");
				$("[data-name=closeOrder]").addClass("closeOrder-text");
				$("[data-name=closeOrder]").text("关闭订单");
				$("[data-name=closeOrder]").attr("title","关闭订单");
				$("input[tdTag=reasons]").removeClass("validate[required]");
				//给其他关闭的行加验证
				var $trs = $("#detailListTbody").find("tr");
				for ( var i = 0; i < $trs.size(); i++) {
					var $tr = $trs.eq(i);
					if($tr.find("input[tdTag=closed]").val()==1){
						$trs.find("input[tdTag=reason]").addClass("validate[required]");
					}
				}			
			}
			
			$obj.find("input[tdTag=reason]").removeClass("validate[required]");
			
		}else{//关闭
			changeClosed($obj,$("#closeStatus").val(),"");
			$obj.find("[readOrChange]").attr("readonly",true).addClass("disabled");
			$obj.find("input[tdTag=reason]").addClass("validate[required]");
			$(this).addClass("open-text");
			$(this).text("打开");
			$(this).attr("title","打开");
			$obj.find("[data-name=split]").attr("style","display:none");//关闭订单即不可拆行
			//删除该行拆出的行
			var rowNo = $obj.find("input[tdTag=rowNo]").val();
			var $trs = $("#detailListTbody").find("tr");
			for ( var i = 0; i < $trs.size(); i++) {
				var $tr = $trs.eq(i);
				if($tr.find("input[tdTag=isAdd]").val()==1 && $tr.find("input[tdTag=rowNo]").val()==rowNo){
					$tr.remove();
				}
			}
			
		}
	});
	
	/*关闭订单*/
	$("[data-name=closeOrder]").click(function(){
			if($(this).hasClass("closeOrder-text")){//关闭
				var $trs = $("#detailListTbody").find("tr");
				for ( var i = 0; i < $trs.size(); i++) {
					var $tr = $trs.eq(i);
					if($tr.find("input[tdTag=isAdd]").val()==1 ||  $tr.find("input[tdTag=isNewRow]").val()==1){
						$tr.remove();//删除拆除的行
					}
					changeClosed($tr,$("#closeStatus").val(),"");			
					$tr.find("[readOrChange]").attr("readonly",true).addClass("disabled");
					$("input[tdTag=pm]").val("Yes");
					
					//改变每一行的可操作为打开
					$tr.find("[data-name=work]").addClass("open-text");
					$tr.find("[data-name=work]").text("打开");
					$tr.find("[data-name=work]").attr("title","打开");
					
					$tr.find("[data-name=split]").attr("style","display:none");//关闭订单即不可拆行
				}
				
				//新增一行链接无效
				$("#addNewRow").attr("data-val","0");
				$("#addNewRow").attr("style","color:gray");
				
				$("[tdTag=reasons]").addClass("validate[required]");
				$("#closeSymbol").val("1")				
				$(this).removeClass("closeOrder-text");
				$(this).text("取消关闭");
				$(this).attr("title","取消关闭");
			}else{//打开	
				var $trs = $("#detailListTbody").find("tr");
				for ( var i = 0; i < $trs.size(); i++) {
					var $tr = $trs.eq(i);
					
					changeClosed($tr,$tr.find("input[tdTag=changeClosed]").val(),"");	//如果erp这行是关闭的，整单打开也不改变原来的状态
					if($tr.find("input[tdTag=changeClosed]").val()==0){	//如果erp这行是关闭的，整单打开也不改变原来的状态
						$tr.find("[readOrChange]").attr("readonly",true).removeClass("disabled");
					}	
					
					$("input[tdTag=pm]").val("");
					
					//改变每一行的可操作为关闭
					$tr.find("[data-name=work]").removeClass("open-text");
					$tr.find("[data-name=work]").text("关闭");
					$tr.find("[data-name=work]").attr("title","关闭");
						
					$tr.find("[data-name=split]").attr("style","display:inline");					
				}
				//新增一行链接有效
				$("#addNewRow").attr("data-val","1");
				$("#addNewRow").removeAttr("style");
				
				$(this).parents("tr").find("input[tdTag=reasons]").removeClass("validate[required]");
				$(this).parents("tr").find("input[tdTag=reasons]").val("");
				$("#closeSymbol").val("0")
				$(this).addClass("closeOrder-text");
				$(this).text("关闭订单");
				$(this).attr("title","关闭订单");
			}
		});
	
	/*型号替换 ashanahzhang 20160811*/
	$("input[tdTag=inventoryCode]").bind("change",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
	});
	
	/*绑定数量每条详情的合计*/
	$("input[tdTag=restQuantity]").bind("change",function(){ 
		calTaxSum($(this).parents("tr"));
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
	});
	/*绑定根据含税单价、税率 算无税单价、合计*/
	$("input[tdTag=taxUnitPrice]").bind("change",function(){ 
		/* 税率 */
		var taxRate = changeNum($("#taxRate").val());
		/*含税单价*/
		var taxUnitPrice = changeNum($(this).parents("tr").find("input[tdTag=taxUnitPrice]").val());
		/*无税单价*/
		var unitPrice = FloatDiv(multiply(taxUnitPrice,100),add(100,taxRate));
		$(this).parents("tr").find("input[tdTag=unitPrice]").val(changeSixDecimal(unitPrice));
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
		calTaxSum($(this).parents("tr"));
	});
	/*绑定根据无税单价、税率 算含税单价、合计*/
	$("input[tdTag=unitPrice]").bind("change",function(){ 
		/* 税率 */
		var taxRate = changeNum($("#taxRate").val());
		/*无税单价*/
		var unitPrice = changeNum($(this).parents("tr").find("input[tdTag=unitPrice]").val());
		/*含税单价*/
		var taxUnitPrice = multiply(unitPrice,FloatDiv(add(100,taxRate),100));
		$(this).parents("tr").find("input[tdTag=taxUnitPrice]").val(changeSixDecimal(taxUnitPrice));
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
		calTaxSum($(this).parents("tr"));
	});
	/*交期 ashanahzhang 20160811*/
	$("input[tdTag=expectDate]").bind("input propertychange",function(){ 
		$(this).parents("tr").find("input[tdTag=reason]").addClass("validate[required]");
	});
	
	
});

/*计算行含税总和、税额等*/
function calTaxSum($tr){
	/*在途数量*/
	var restQuantity = $tr.find("input[tdTag=restQuantity]").val();
	/*数量*/
	var quantity =parseFloat($tr.find("input[tdTag=restQuantity]").val())+parseFloat($tr.find("input[tdTag=shippedQuantity]").val());
	$tr.find("input[tdTag=Quantity]").val(quantity);
	/*含税单价*/
	var taxUnitPrice = changeNum($tr.find("input[tdTag=taxUnitPrice]").val());
	/*无税单价*/
	var unitPrice = changeNum($tr.find("input[tdTag=unitPrice]").val());
	/*含税总额*/
	var taxSum = multiply(restQuantity,taxUnitPrice);
	/*无税总额*/
	var sum = multiply(restQuantity,unitPrice);
	/*税额*/
	var tax = FloatSub(taxSum,sum);
	$tr.find("input[tdTag=taxSum]").val(changeFourDecimal(taxSum));
	$tr.find("input[tdTag=sum]").val(changeFourDecimal(sum));
	$tr.find("input[tdTag=tax]").val(changeFourDecimal(tax));
}

/*增加存货编码自动匹配*/
function addInventoryAutoComplete($input){
	$input.autocomplete(encodeURI("/approvalajax/salesOrderApproval_findInventoryList?ledger=" + $("#ledger").val()+"&customerCode="+$("#customerCode").val()), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>存货编码</span> <span class='col-2'>存货名称</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.inventoryList == null){
            	return rows;
            }
            for(var i=0; i<data.inventoryList.length; i++){    
                rows[rows.length] = {    
                    data:data.inventoryList[i],              //下拉框显示数据格式   
                    value:data.inventoryList[i].invCode,     //选定后实际数据格式  
                    result:data.inventoryList[i].invCode   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.invCode + "</span> " + "<span class='col-2'>" + row.invName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.invCode + row.invName;;
		},
		formatResult: function(row) {
			return row.invCode;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		clearTr($(this).parents("tr"));
		$(this).parents("tr").find("[tdTag=inventoryCode]").val(data.invCode);
		$(this).parents("tr").find("[tdTag=cusInvName]").val(data.erpCusInvName);
		$(this).parents("tr").find("[tdTag=eccn]").val(data.eccnNo);
		if(data.mpq != null){
			$(this).parents("tr").find("[tdTag=mpq]").val(data.mpq);
		}
		$(this).parents("tr").find("[tdTag=productLineName]").val(data.unionName);
		$(this).parents("tr").find("[tdTag=customerInventoryCode]").val(data.erpCusInvCode);
		$(this).parents("tr").find("[tdTag=inventoryName]").val(data.invName);
		$(this).parents("tr").find("[tdTag=cost]").val(data.cost);
	}).bind("unmatch", function(){
		clearTr($(this).parents("tr"));
	});
}


/*增加存货编码自动匹配*/
function addInventoryAutoCompleteChange($input){
	$input.autocomplete(encodeURI("/approvalajax/salesOrderApproval_findInventoryList?ledger=" + $("#ledger").val()+"&customerCode="+$("#customerCode").val()), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>存货编码</span> <span class='col-2'>存货名称</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.inventoryList == null){
            	return rows;
            }
            for(var i=0; i<data.inventoryList.length; i++){    
                rows[rows.length] = {    
                    data:data.inventoryList[i],              //下拉框显示数据格式   
                    value:data.inventoryList[i].invCode,     //选定后实际数据格式  
                    result:data.inventoryList[i].invCode   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.invCode + "</span> " + "<span class='col-2'>" + row.invName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.invCode + row.invName;;
		},
		formatResult: function(row) {
			return row.invCode;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		//clearTr($(this).parents("tr"));
		$(this).parents("tr").find("[tdTag=inventoryCode]").val(data.invCode);
		$(this).parents("tr").find("[tdTag=cusInvName]").val(data.erpCusInvName);
		$(this).parents("tr").find("[tdTag=eccn]").val(data.eccnNo);
		if(data.mpq != null){
			$(this).parents("tr").find("[tdTag=mpq]").val(data.mpq);
		}
		$(this).parents("tr").find("[tdTag=productLineName]").val(data.unionName);
		$(this).parents("tr").find("[tdTag=customerInventoryCode]").val(data.erpCusInvCode);
		$(this).parents("tr").find("[tdTag=inventoryName]").val(data.invName);
		$(this).parents("tr").find("[tdTag=cost]").val(data.cost);
	}).bind("unmatch", function(){
		//clearTr($(this).parents("tr"));
		$(this).parents("tr").find("[tdTag=inventoryCode]").val("");
	});
}

/*修改关闭人*/
function changeClosed($tr,closed,colseUserName){
	$tr.find("[tdTag=closed]").val(closed);
	$tr.find("[tdTag=closeUserName]").val(colseUserName);
}

/*清除行的数据*/
function clearTr($tr){
	$tr.find("input[filterNull!=true]").val("");
	$tr.find("[tdTag=shippedQuantity]").val(0);
	$tr.find("[tdTag=inventoryCode]").validationEngine('hidePrompt');
}

/*取回数值，没有值的为0*/
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}

/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.removeAttr("hide");
	$copyTr.removeAttr("style");
	$copyTr.find("input[tdTag=expectDate]").val(GetTodayDateStr());
	$copyTr.find("input[tdTag=rowNo]").val(parseInt($tr.find("[tdTag=rowNo]").val())+1);
	$copyTr.find("input[tdTag=shippedQuantity]").val(0);
	$copyTr.find("input[tdTag=isNewRow]").val(1);
	//把链接文字改成删除
	$copyTr.find("a").text("删除");	
	$copyTr.find("a").attr("title","删除");
	$tr.after($copyTr);
	addInventoryAutoCompleteChange($copyTr.find("input[tdTag=inventoryCode]"));
}
/* 删除行 */
function delTr($obj){
	$obj.validationEngine('hidePrompt');
	$obj.remove();
}

/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
	var $trNum = $tbody.find("tr").size();
	for ( var i = $trNum; i >= 0; i--) {
		$trNum = $tbody.find("tr").size();
		var $tr = $tbody.find("tr").eq(i);
		if (checkEmptyTr($tr)) {
			if ($trNum > 1) {
				$tr.remove();
			}
		}
	}
}

/* 验证空行 */
function checkEmptyTr($tr) {
	var $inputNum = $tr.find("input").size();
	var flag = true; // 为空
	for ( var i = 0; i < $inputNum; i++) {
		var $input = $tr.find("input[filterNull!=true]").eq(i);
		if ($.trim($input.val()) != "") {
			flag = false; // 不为空
			break;
		}
	}
	return flag;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
	var $trs = $tbody.find("tr");/* 获取所有tr */
	var firstName = "salesOrderChange.orderDetails";/* 前缀名称 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $inputNum = $tr.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $tr.find("input").eq(j);
			$input.attr("id", $input.attr("tdTag") + numtag);
			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
			
		}
		$tr.find("input[tdTag=sub_index]").val(i);
		$tr.find("input[tdTag=item]").val(i+1)
		$tr.find("input[tdTag=quantity]").addClass("validate[required,min["+changeNum($tr.find("input[tdTag=shipQuantity]").val())+"]]");
	}
}

/*用于上传文件使用*/
function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[onclick]").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}
