$(function() {
	/*隐藏确定页面*/
	$("#confirm").hide();
	/* 点击下一步 */
	$("#next").click(function() {
    	clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
		if (error) {
			switchPageForConfirm();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
            copyValueToConfig();/* 将新建页面的数值写入确认页面 */
            getEmailList();/* 获取邮件发送列表 */
            copyFileList();/*上传附件公用*/
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		$("#confirm").hide();
		$("#write").show();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});

	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#edpPortalForm").append(inputStr);
    		}
    	});
		
    	$("#submit").hide();
    	$("#edpPortalForm").attr("action","/approval/edpPortal_create");
		$("#edpPortalForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/edpPortal_show?edpPortalApproval.id="+id;},1000);
			}else {
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}	
	        return false;
		});
	});

});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#edpPortalForm").validationEngine('validate');
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*写值*/
     $("#title_confirm").text($("#title").val());
	 $("#location_confirm").text($("#location").val());
	 $("#roles_confirm").text($("#roles").val());
	 $("#ledger_confirm").text($("#ledger").val());
	 $("#productLine_confirm").text($("#productLine").val());
    $("#remark_confirm").text($("#remark").val());
	 /*写表格详细值*/
		var $trs = $("#detailListTbody").find("tr");
		for ( var i = 0; i < $trs.size(); i++) {
			var $tr = $trs.eq(i);
			var trString = 
				"<tr><td style='text-align: center'><div>"+$tr.find("select[tdTag=func]").val()+"</div></td>"
				+ "<td style='text-align: center'><div>"+$tr.find("input[tdTag=reason]").val()+"</div></td></tr>";
			    $("#detailListTbody_confirm").append(trString);
		}
}

/* 获取邮件发送列表 */
function getEmailList() {
	var url = "/approval/edpPortal_showConfirmMail";
	$("#mailList").load(encodeURI(url));
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").show();
	$("#write").hide();
}


