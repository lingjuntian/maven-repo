$(function(){
	
});

function orderApproval(action){
	$("#form").attr("action", action);
	$("#form").ajaxSubmit(function(returnStr){
       if (returnStr == "success") {
         dialog("成功！","success",true,1);
      setTimeout(function(){window.location = "/approval/orderApproval_index"},1000);	        
       } else if(returnStr == "error"){
        dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
       }
     });
}
