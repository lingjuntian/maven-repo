$(function () {
	/**
	 * 新建付款单确认页面
	 */
	completemail("sendMailForConfirm");
	$("#addEmailForConfirm").click(function(){
		addmail("addEmailForConfirm", "mailsForConfirm", "");
	});
	/**
	 * 详情页审核通过
	 */
	completemail("sendMailForApproval");
	$("#addEMailForApproval").click(function(){
		addmail("addEMailForApproval", "mailsForApproval", "userMails");
	});
	/**
	 * 详情页评论信息
	 */
	completemail("sendMailForComment");
	$("#addEMailForComment").click(function(){
		addmail("addEMailForComment", "mailsForComment", "userMails");
	});
	/**
	 * 详情页库存评论
	 */
	completemail("sendMailForStockComment");
	$("#addEMailForStockComment").click(function(){
		addmail("addEMailForStockComment", "mailsForStockComment", "mails");
	});
});

function completemail(inputid){
	$.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findAllUser"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.userList != null){
                $("#"+inputid).autocomplete(data.userList, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-3'>邮箱</span> <span class='col-4'>英文名</span></div>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-3'>"+row.userMail+"</span> <span class='col-4'>"+row.enName+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.enName;
                    },
                    formatResult: function(row) {
                        return row.enName;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                	$("#"+inputid).parent(".addemail").find("input[type=hidden]").remove();
                	var inputstr = "<input type=\"hidden\" userenname=\""+data.enName+"\" usermail=\""+data.userMail+"\"/>";
                	$("#"+inputid).parent(".addemail").append(inputstr);
                }).bind("unmatch", function() {/**没有匹配时**/
                	$("#"+inputid).val("");
                	$("#"+inputid).parent(".addemail").find("input[type=hidden]").remove();
                });
            }
        }
    }); 
}


function addmail(aid, spanid, name){
	if($("#"+aid).parent(".addemail").find("input[type=hidden]").length){
		var enName = $("#"+aid).parent(".addemail").find("input[type=hidden]").attr("userenname");
		var userMail = $("#"+aid).parent(".addemail").find("input[type=hidden]").attr("usermail");
		if($("#"+spanid).find("input[type=checkbox][value="+userMail+"]").length){
			$("#"+spanid).find("input[type=checkbox][value="+userMail+"]").attr("checked",true);
		}else{
			var labelstr = "<label for=\"name1\"><input type=\"checkbox\" name=\""+name+"\" tag=\"sendmail_mail\"" +
			" value=\""+userMail+"\" checked=\"true\" />"+enName+"</label>";
			$("#"+spanid).append(labelstr);
		}
		$("#"+aid).parent(".addemail").find("input[type=text]").val("");
		$("#"+aid).parent(".addemail").find("input[type=hidden]").remove();
	}
}