/* 填充确认页面邮箱列表 */
function fillMaillList() {
	var createUserId = $("#createUserId").val();
	var departmentId = $("#departmentId").val();
	var buId = $("#buId").val();
	var regionName = $("#regionName").val();
	var chargePersonEmail = $("#chargePersonEmail").val();
	var url = "/approval/budgetCost_showConfirmMail?budgetCostApproval.createUserId="+ createUserId
			+ "&budgetCostApproval.departmentId=" + departmentId
			+ "&budgetCostApproval.buId=" + buId 
			+ "&budgetCostApproval.regionName=" + regionName
			+ "&budget.chargePersonEmail=" + chargePersonEmail;
	$("#mailList").load(encodeURI(url));
}