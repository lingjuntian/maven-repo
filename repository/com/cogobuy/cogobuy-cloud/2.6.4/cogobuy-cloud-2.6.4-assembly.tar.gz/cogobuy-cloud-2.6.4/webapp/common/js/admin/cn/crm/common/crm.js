$(function(){
    completUser("shareInput");
    completUser("allotInput");

})

/*自动匹配用户*/
function completUser(container){
    $.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findAllUser"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.userList != null){
                var input = $("#"+container);
                input.autocomplete(data.userList, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-3'>中文名</span> <span class='col-4'>英文名</span></div>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-3'>"+row.name+"</span> <span class='col-4'>"+row.enName+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.name+row.enName;
                    },
                    formatResult: function(row) {
                        return row.name;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                    input.val(data.name);
                    $("#shareHide").val(data.id);
                    $("#allotHide").val(data.id);
                }).bind("unmatch", function() {/**没有匹配时**/
                input.val("");
                    $("#shareHide").val("");
                    $("#allotHide").val("")
                });
            }
        }
    });
}
