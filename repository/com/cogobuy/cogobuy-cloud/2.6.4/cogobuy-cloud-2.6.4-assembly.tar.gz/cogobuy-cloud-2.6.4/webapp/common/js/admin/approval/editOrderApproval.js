var inventoryList;
var customerInventoryList;
$(function(){
	initTrEvents();
 	resetRowNO();
    commonReady();
    
    var ajaxCustomerInventoryUrl = "/adminajax/master_findCustomerInventoryList"
		+ "?customerId=" + $("#customerId").val();
	$.ajax({
		type:"GET",
		url:encodeURI(ajaxCustomerInventoryUrl),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.list != null){
				customerInventoryList = data.list;
				setCustomerInventoryAutoComplete($("#table [id^=customerInventoryCode]"));
			}
		}
	});    
});

function save(){
	var error1 = checkPartNo("table", true);
	var error2 = $("#form").validationEngine('validate');
	showLineTips("table", "inventoryCode");
	if(error1 && error2 == true){
		return check();
	}
}

function checkCallBack(){
	$("[id^=inventoryCode]").validationEngine('hidePrompt');
	$("#copyTr").remove();
	$("#form").attr("action", "/approval/orderApproval_update");
	//$("#orderForm").attr("action", "/admin/orderToken_create");
	$("#form").ajaxSubmit(function(returnStr){
        if (returnStr == "success") {
          dialog("成功！","success",true,1);
	      setTimeout(function(){window.location = "/approval/orderApproval_show?id=" + $("#orderApprovalId").val();},1000);	        
        } else if(returnStr == "error"){
         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
        }
  	});
}