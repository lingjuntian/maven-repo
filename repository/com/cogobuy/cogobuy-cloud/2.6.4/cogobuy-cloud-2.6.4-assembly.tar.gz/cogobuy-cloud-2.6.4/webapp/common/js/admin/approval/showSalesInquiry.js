$(function(){
 	resetRowNO();
	$("#submit").click(function(){
		save();
		return false;
    }); 
});


function resetRowNO(){
	var len = $("#table tr").size();

	for(var i = len - 1; i >= 0; i--){
	    $("#pmUnitPrice" + i).addClass("validate[required,max[10000000],custom[positiveNumber]]");
	    $("#dispatchDay" + i).addClass("validate[max[100],custom[positiveInteger]]");
	}
   	$("#form").validationEngine('attach');
}


function save(){
	if($("#form").validationEngine('validate')){
		$("#form").ajaxSubmit(function(returnStr){
	        if (returnStr != "error") {
	          dialog("成功！","success",true,1);
		      setTimeout(function(){window.location = "/approval/salesInquiry_index"},1000);	        
	        } else if(returnStr == "error"){
	         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
	        }
	      });
     }
}