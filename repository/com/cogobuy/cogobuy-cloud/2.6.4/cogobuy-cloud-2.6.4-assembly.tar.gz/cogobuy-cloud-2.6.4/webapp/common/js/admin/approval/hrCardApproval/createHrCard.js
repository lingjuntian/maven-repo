$(function() {
	/*隐藏确定页面*/
	$("#confirm").hide();
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */	
		if (error) {
			switchPageForConfirm();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
            copyValueToConfig();/* 将新建页面的数值写入确认页面 */
            getEmailList();/* 获取邮件发送列表 */
            copyFileList();/*上传附件公用*/
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		$("#confirm").hide();
		$("#write").show();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#itEquipmentForm").append(inputStr);
    		}
    	});
		
    	$("#submit").hide();
    	$("#itEquipmentForm").attr("action","/approval/hrCard_create");
		$("#itEquipmentForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/hrCard_show?hrCardApproval.id="+id;},1000);	  
			}else {
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}	
	        return false;
			
		});
	});

});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#itEquipmentForm").validationEngine('validate');
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
    /*清空备注*/
	$("#remark_confirm").text("");
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*写值*/
     $("#nameChina_confirm").text($("#nameChina").val());
	 $("#nameEnglish_confirm").text($("#nameEnglish").val());
	 $("#firstDepartment_confirm").text($("#firstDepartment").val());
	 $("#companyBelong_confirm").text($("#companyBelong").val());
	 $("#companyNameChina_confirm").text($("#companyNameChina").val());
	 $("#positionChina_confirm").text($("#positionChina").val());
	 $("#positionEnglish_confirm").text($("#positionEnglish").val());
	 $("#mainLine_confirm").text($("#mainLine").val());
	 $("#fax_confirm").text($("#fax").val());
	 $("#directLine_confirm").text($("#directLine").val());
	 $("#printType_confirm").text($("#printType").val());
	 $("#printMount_confirm").text($("#printMount").val());
	 $("#phone_confirm").text($("#phone").val());
	 $("#cause_confirm").text($("#cause").val());
	 $("#remark_confirm").text($("#remark").val());
}

/* 获取邮件发送列表 */
function getEmailList() {
	var url = "/approval/hrCard_showConfirmMail";
	$("#mailList").load(encodeURI(url));
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").show();
	$("#write").hide();
}

