$(function() {
	/*隐藏确定页面*/
	$("#confirm").hide();
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */	
		if (error) {
			switchPageForConfirm();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
            copyValueToConfig();/* 将新建页面的数值写入确认页面 */
            getEmailList();/* 获取邮件发送列表 */
            copyFileList();/*上传附件公用*/
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		$("#confirm").hide();
		$("#write").show();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#staffEnrollingForm").append(inputStr);
    		}
    	});
		
    	$("#submit").hide();
    	$("#staffEnrollingForm").attr("action","/approval/staffEnrolling_create");
		$("#staffEnrollingForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/staffEnrolling_show?staffEnrollingApproval.id="+id;},1000);	  
			}else {
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}	
	        return false;
			
		});
	});

});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}
function edit()
{
   var input = document.getElementsByTagName("input");
   var count = 0;
   var txt1=document.getElementById("emailGroup_confirm");
   var r=document.getElementsByName("emailGroup"); 
   stars="" 
   for(var i = 0; i < input.length; i ++)
   {    
       if(input[i].type == "checkbox" && input[i].name.indexOf("emailGroup") != -1)
        { 
          if (input[i].checked)
          {    //这个地方是获取你选定了的的checkbox的Value
              stars=stars+input[i].value;
              stars=stars + ",";
          }
        }
   }
   txt1.innerText= stars;
   $("#emailGroup").val(stars)
}
function editName()
{
   var input = document.getElementsByTagName("input");
   var count = 0;
   var txt1=document.getElementById("computerArrangement_confirm");
   var r=document.getElementsByName("computerArrangement"); 
   stars="" 
   for(var i = 0; i < input.length; i ++)
   {    
       if(input[i].type == "checkbox" && input[i].name.indexOf("computerArrangement") != -1)
        { 
          if (input[i].checked)
          {    //这个地方是获取你选定了的的checkbox的Value
              stars=stars+input[i].value;
              stars=stars + ",";
          }
        }
   }
   txt1.innerText= stars;
   $("#computerArrangement").val(stars);
}
/* 验证输入 */
function validationInput() {
	return $("#staffEnrollingForm").validationEngine('validate');
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
    /*清空备注*/
	$("#remark_confirm").text("");
	/*清空列表*/
	$("#enName_confirm").text($("#enName").val());
	$("#name_confirm").text($("#name").val());
	$("#firstDepartment_confirm").text($("#firstDepartment").val());
	$("#secondDepartment_confirm").text($("#secondDepartment").val());
	$("#position_confirm").text($("#position").val());
	$("#domainName_confirm").text($("#domainName").val());
	$("#directLeader_confirm").text($("#directLeader").val());
	$("#costBelong_confirm").text($("#costBelong").val());
	$("#companyBelong_confirm").text($("#companyBelong").val());
	$("#officePlace_confirm").text($("#officePlace").val());
	$("#accessPermission_confirm").text($("#accessPermission").val());
	$("#remarks_confirm").text($("#remarks").val());
	$("#forecastDutyDate_confirm").text($("#forecastDutyDate").attr("realvalue"))
	$("#forecastDutyDate").val($("#forecastDutyDate").attr("realvalue"))
	edit();
	editName();
	
	/*写值*/
/*	 $("#remark_confirm").text($("#remark").val());*/
     //如果不是申请电脑，隐藏电脑配置
	 if($("#laptopEquiment").val()==null||$("#laptopEquiment").val()==""){
		 $("#laptopEquiment_li").hide();
	 }else{
		 $("#laptopEquiment_li").show();
	 }
	 
	 /*写表格详细值*/
		var $trs = $("#detailListTbody").find("tr");
		for ( var i = 0; i < $trs.size(); i++) {
			var $tr = $trs.eq(i);
			var trString = 
				"<tr><td class=\"equiment\"><div>"+$tr.find("input[tdTag=equipment]").val()+"</div></td>"
				+ "<td class=\"remark\"><div>"+$tr.find("input[tdTag=remark]").val()+"</div></td>"
				+ "<td class=\"\"><div>"+$tr.find("input[tdTag=quantity]").val()+"</div></td>"
				+ "<td class=\"currency\"><div>"+$tr.find("select[tdTag=currency]").val()+"</div></td>"
				+ "<td class=\"\" style=\"text-align: center\"><div>"+$tr.find("input[tdTag=price]").val()+"</div></td></tr>";
			   $("#detailListTbody_confirm").append(trString);
		}
}

/* 获取邮件发送列表 */
function getEmailList() {
	var url = "/approval/staffEnrolling_showConfirmMail";
	$("#mailList").load(encodeURI(url));
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").show();
	$("#write").hide();
}

