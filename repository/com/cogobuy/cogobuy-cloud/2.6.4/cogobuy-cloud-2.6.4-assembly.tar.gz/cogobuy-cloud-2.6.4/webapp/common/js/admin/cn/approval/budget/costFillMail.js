/* 填充确认页面邮箱列表 */
function fillMaillList() {
	var createUserId = $("#createUserId").val();
	var departmentId = $("#departmentId").val();
	var buId = $("#buId").val();
	var totalSum =$("#totalSum").val();
	var regionName = $("#regionName").val();
	var chargePersonEmail = $("#chargePersonEmail").val();
	var chargePersonNickName = $("#chargePersonNickName").val();
	var url = "/approval/budget_showConfirmMail?budgetApproval.createUserId="+ createUserId 
			+ "&budgetApproval.departmentId=" + departmentId
			+ "&budgetApproval.buId=" + buId
			+ "&budgetApproval.budgetSum=" + totalSum
			+ "&budgetApproval.chargePersonEmail=" + chargePersonEmail
			+ "&budgetApproval.chargePersonNickName=" + chargePersonNickName
			+ "&region=" + regionName;
	$("#mailList").load(encodeURI(url));
}