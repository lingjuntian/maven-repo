$(function() {
	// 公司信息中相关验证
	// 公司全称
	// $("#fullNameEn").addClass("validate[required]");
	// $("#fullNameCh").addClass("validate[required]");
	// 客户营业执照号
	$("#licenseNo").addClass("validate[required]");
	// 客户编码
	// $("#customerCode").addClass("validate[required]");
	// 公司电话
	// $("#companyTel").addClass("validate[required,custom[phoneNumber]]");
	// 公司区域
	// $("#provinceId").addClass("validate[required]");
	// $("#cityId").addClass("validate[required]");
	// 公司地址
	// $("#companyAddress").addClass("validate[required]");
	// 法人
	// $("#corporation").addClass("validate[required]");
	// 采购
	// $("#purchase").addClass("validate[required]");
	// 成立时间
	// $("#date").addClass("validate[required]");
	// $("#companyInfoDate").addClass("validate[required]");
	// 员工人数
	// $("#employeeNum").addClass("validate[required,custom[creditLimit]]");
	// 注册资金
	// $("#registeredCapital").addClass("validate[required]");
	// 注册地
	// $("#registration").addClass("validate[required]");

	// 银行信息中相关验证
	// 银行名称
	// $("#bankName").addClass("validate[required]");
	// 公司名称
	// $("#accountName").addClass("validate[required]");
	// 银行账号
	// $("#account").addClass("validate[required]");
	// 纳税人识别号
	// $("#taxpayerIdentification").addClass("validate[required]");
	// 电话
	// $("#tel").addClass("validate[required,custom[phoneNumber]]");

	// 内部信息中相关验证
	// PO
	// $("[validatortag=po]").addClass("validate[minCheckbox[1]]");
	// invoice
	// $("[validatortag=invoice]").addClass("validate[minCheckbox[1]]");
	// 业务往来产品类型
	// $("#mainProductType").addClass("validate[required]");
	// 原厂商
	// $("#supplier").addClass("validate[required]");
	// 预计毛利率
	// $("#profit").addClass("validate[required]");
	// 金额
	// $("[validatortag=ammount]").addClass("validate[required]");
	// 账套
	// $("#ledger").addClass("validate[required]");
	// 申请销售额度
	// $("#creditnum").addClass("validate[required]");
	// 业务员
	$("#person_show").addClass("validate[required]");

	// 客户委托证明
	// $("[validatortag=file]").addClass("validate[required]");
});

/**
 * 验证checkbox是否选中
 * 
 * @param tagname
 *            验证项
 * @param minnumber
 *            最小选择数
 * @param msgshowid
 *            信息显示地ID
 * @returns {Boolean}
 */
function validatorCheckbox(tagname, minnumber, msgshowid) {
	if ($("input[validatortag=" + tagname + "]:checked").length < minnumber) {
		$("#" + msgshowid).validationEngine("showPrompt",
				"*最少选择 " + minnumber + " 项", "error", "", true);
		return false;
	} else {
		return true;
	}
}

/**
 * 当CheckboxID对应选中时验证inputID对应是否为空
 * 
 * @param conditionId
 *            CheckboxID
 * @param validatorId
 *            inputID
 */
function validatorInputByCheckbox(checkboxId, validatorId) {
	if ($("#" + checkboxId + ":checked").length > 0) {
		if ($("#" + validatorId).val().length < 1) {
			$("#" + validatorId).validationEngine("showPrompt", "* 此处不可空白",
					"error", "", true);
			return false;
		}
	}
	return true;
}