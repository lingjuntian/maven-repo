var inventoryList;
var customerInventoryList;
$(function(){
    $("#buSelect,#shippingTypeSelect,#payTypeSelect,#saleTypeSelect,#currencySelect").each(function(){
    	if($(this).find("input[id!=Id]").val() == null || $(this).find("input[id!=Id]").val() == ""){
	    	$(this).find("span").text($(this).find("li:eq(1)").find("a").attr("vhidden"));
	    	$(this).find("input[id!=Id]").val($(this).find("li:eq(1)").find("a").attr("vhidden"));
	    	$(this).find("input[id$=Id]").val($(this).find("li:eq(1)").find("a").attr("labelId"));
    	}
    });

	initTrEvents();
	for(var i = 0; i < 5; i++){
		var tr = $("#copyTr").clone(true);
	   	tr.attr("id", "");	
	 	tr.appendTo($("#table"));
	 	tr.show();
 	}
 	resetRowNO();
	setItaxRate($("#currencySelect span").text(), $("#saleTypeSelect span").text());
	
	$("#gotoStep2").click(function(){
    	gotoStep2();
    	return false;
    });
    
    $("#gotoStep1").click(function(){
    	gotoStep1();
    	return false;
    });

	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findCustomerList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.customerList != null){
				$("#customerName").autocomplete(data.customerList, {
					/**加自定义表头**/
					tableHead: "<div><span style='width:40%' class='col-1'>客户编码</span> <span style='width:58%' class='col-2'>客户名称</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span  style='width:40%' class='col-1'>" + row.customerCode + "</span> " + "<span style='width:58%' class='col-2'>" + row.fullName + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.fullName;
					},
					formatResult: function(row) {
						return row.fullName;
					}
					/*formatInputResult: function(data){
                    	autoCompleteCustomer(data)					
					},*/
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					autoCompleteCustomer(data);
				}).bind("unmatch", function(){
					clearCustomerInfo();
				});
			}
		}
	});
	
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findPersonList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.personList != null){
				$("#person").autocomplete(data.personList, {
					/**加自定义表头**/
					tableHead: "<div><span class='col-1'>部门名称</span> <span class='col-2'>业务员名称</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span class='col-1'>" + row.TDepartment.departmentName + "</span> " + "<span class='col-2'>" + row.personName + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.personName;
					},
					formatResult: function(row) {
						return row.personName;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#personId").val(data.id);
					$("#person").val(data.personName);
					$("#person").validationEngine('hidePrompt');
					$("#departmentId").val(data.TDepartment.id);
				}).bind("unmatch", function(){
					$("#personId").val("");
					$("#departmentId").val("");
				});
			}
		}
	}); 
    commonReady();
});

//确认订单，进入下一步
function gotoStep2(){
	
	var error1 = checkPartNo("table", true);
	var error2 = $("#form").validationEngine('validate');
	showLineTips("table", "inventoryCode");
	
	//$("#form").attr("action", "/adminajax/order_checkOrder");
	/*$("#orderForm").ajaxSubmit(function(data,status){
		var result = eval('(' + data + ')');
		
		if(result != null && result.order != null){
			var order = result.order;
			if(!order.validSaleOrderNo){
				$("#saleOrderNo").validationEngine("showPrompt", "您输入的订单号已存在", 'error', "", true);
			}
			if(!order.validCustomer){
				if($("#customerName")[0] != null){
					$("#customerName").validationEngine("showPrompt", "您输入的用户在" + $("#ledger").val() + "帐套中不存在或您无权操作此用户", 'error', "", true);
				} else {
					$("#customerNameSpan").validationEngine("showPrompt", "您输入的用户在" + $("#ledger").val() + "帐套中不存在或您无权操作此用户", 'error', "", true);
				}
			} else if(!order.privilegeCustomer){
				if($("#customerName")[0] != null){
					$("#customerName").validationEngine("showPrompt", "您无权处理该用户", 'error', "", true);
				} else {
					$("#customerNameSpan").validationEngine("showPrompt", "您无权处理该用户", 'error', "", true);
				}
			}
			if(!order.validPerson){
				$("#personName").validationEngine("showPrompt", "您输入的业务员在" + $("#ledger").val() + "帐套中不存在", 'error', "", true);
			}
			var orderDetailList = order.orderDetailList;
			//alert(orderDetailList);
			if(orderDetailList != null && orderDetailList.length > 0){
				var len = orderDetailList.length;
				for(var i = 0; i < len; i++){
					var orderDetail = orderDetailList[i];
					//alert(orderDetail.validPartNo);
					if(!orderDetail.validPartNo && orderDetail.partNo != null && orderDetail.partNo != ""){
						$("#orderDetailTable tr:eq(" + i + ") [name*=.partNo]").addClass("error");
						$("#orderDetailTable tr:eq(" + i + ") [name*=.partNo]").validationEngine("showPrompt", "您输入的厂商型号在" + $("#ledger").val() + "帐套中不存在", 'error', "", true);
					}else if(!orderDetail.privilegePartNo && orderDetail.partNo != null && orderDetail.partNo != ""){
						$("#orderDetailTable tr:eq(" + i + ") [name*=.partNo]").addClass("error");
						$("#orderDetailTable tr:eq(" + i + ") [name*=.partNo]").validationEngine("showPrompt", "您无权使用该厂商型号", 'error', "", true);
					}else if(!orderDetail.validCustomerPartNo && 
						orderDetail.customerPartNo != null && orderDetail.customerPartNo != ""){
						$("#orderDetailTable tr:eq(" + i + ") [name*=.customerPartNo]").validationEngine("showPrompt", "您输入的客户物料号在" + $("#ledger").val() + "帐套中不存在", 'error', "", true);
					}
				}
			}
			return false;
		}else if(error1 && error2 == true){
			copyData();
			$(".custom-service").addClass("custom-service-order-info");
			$("#step1").hide();
			$("#step2").show();	
		}
	});*/
	
	if(error1 && error2 == true){
		/*$("#form").attr("action", "/approvalajax/orderApproval_check");
		$("#form").ajaxSubmit(function(data,status){
			var result = eval('(' + data + ')');
			if(result != null && result.orderApprovalDetailList != null && result.orderApprovalDetailList.length > 0){
				var detailList = result.orderApprovalDetailList;
				var len = detailList.length;
				for(var i = 0; i < len; i++){
					var detail = detailList[i];
					if(detail.productLineId == null){
//						$("#inventoryCode" + i).addClass("error");
						$("#inventoryCode" + i).validationEngine("showPrompt", "您输入的厂商型号在" + $("#buName").val() + "中不存在对应的产品线", 'error', "", true);
					}else{
						$("#productLine" + i).val(detail.productLineId);
					}
				}
				return false;
			}else{
				
			}
		});*/
		return check();
	}
}

function save(){
	$("#copyTr").remove();
	$("#form").attr("action", "/approval/orderApproval_create");
	$("#form").ajaxSubmit(function(returnStr){
        if (returnStr != "error") {
          dialog("成功！","success",true,1);
	      setTimeout(function(){window.location = "/approval/orderApproval_index"},1000);	        
        } else if(returnStr == "error"){
         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
        }
      });
}

function checkCallBack(){
	$("[id^=inventoryCode]").validationEngine('hidePrompt');
	copyData("form");
	copyTableData("table");
	$("#step1").hide();
	$("#step2").show();
	copyFileList();//copy attachment list
	var url = "/approval/approval_emailList?approvalType="+ $("#approvalType").val() + "&parent=T_OrderApproval";
	$("[id^=inventoryClassId]").each(function(){
		url += "&inventoryClassIdList=" + $(this).val();
	});
	/*$("#mailList").load(encodeURI(url), function(){
		
	});	*/
}