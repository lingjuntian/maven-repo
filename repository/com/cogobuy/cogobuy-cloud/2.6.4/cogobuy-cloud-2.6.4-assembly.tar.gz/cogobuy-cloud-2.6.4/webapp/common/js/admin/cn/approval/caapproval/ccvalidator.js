function debug() {
       if (window.console && window.console.log) {
            window.console.log(arguments);
      }
}

$(function() {
	//基本信息页面
	$("[validatortag=text]").addClass("validate[required]");
	$("[validatortag=number]").addClass("validate[required,custom[amountTen]]");
	//联系人
	$("#contactsName").addClass("validate[required]");
	//联系人电话
	$("#contactsTel").addClass("validate[required]");
	//联系人微信号
	$("#weixinId").addClass("validate[required]");
	//公司区域
	$("#provinceName").addClass("validate[required]");
	$("#cityName").addClass("validate[required]");
	//公司地址
	$("#companyAddress").addClass("validate[required]");
	//采购列必填
	$("#purchase").addClass("validate[required]");
	$("#purchasepost").addClass("validate[required]");
	$("#purchasetel").addClass("validate[required]");
	$("#purchasemail").addClass("validate[required]");
	//成立时间
	$("#foundedTime").addClass("validate[required]");
	//员工人数
	$("#employeeNum").addClass("validate[required]");
	
	// BU
	$("#buName").addClass("validate[required]");
	// 业务员
	$("#person_show").addClass("validate[required]");
	
	// 内地注册公司 和 硬蛋商城客户 使用页面一样，必须输入的项不一样
	$("input:radio[name='info.companyType']").change(function(){
		if ($(this).val() == "0") {   //内地注册公司
			$("#licenseNo").addClass("validate[required]");
			$("#licenseValidity").addClass("validate[required]");
			$("#lastRhpj").addClass("validate[required]");
			$("#registeredCapital").addClass("validate[required,custom[amountTen]]");
			$("#rcCurrencyName").addClass("validate[required]");
			$("#foundedTime").addClass("validate[required]");
			$("#employeeNum").addClass("validate[required]");
		} else if ($(this).val() == "1") {
			$("#companyName").removeClass("validate[required]");
		} else if ($(this).val() == "2") {   //硬蛋商城客户
			$("#licenseNo").removeClass("validate[required]");
			$("#licenseValidity").removeClass("validate[required]");
			$("#lastRhpj").removeClass("validate[required]");
			$("#registeredCapital").removeClass("validate[required,custom[amountTen]]");
			$("#rcCurrencyName").removeClass("validate[required]");
			$("#foundedTime").removeClass("validate[required]");
			$("#employeeNum").removeClass("validate[required]");
		} 
	});
	
	//倒回来时
	if ($("#companyType").val() == "0" || $("#companyTypeStr").val() == "0") {
		$("#foundedTime").addClass("validate[required]");
		$("#employeeNum").addClass("validate[required]");
		$("#licenseNo").addClass("validate[required]");
		$("#licenseValidity").addClass("validate[required]");
		$("#lastRhpj").addClass("validate[required]");
		$("#registeredCapital").addClass("validate[required,custom[amountTen]]");
		$("#rcCurrencyName").addClass("validate[required]");
		$("#foundedTime").addClass("validate[required]");
		$("#employeeNum").addClass("validate[required]");
	} else if ($("#companyType").val() == "1" || $("#companyTypeStr").val() == "1") {
		$("#companyName").removeClass("validate[required]");
	} else if ($("#companyType").val() == "2" || $("#companyTypeStr").val() == "2") {
		$("#foundedTime").removeClass("validate[required]");
		$("#employeeNum").removeClass("validate[required]");
		$("#licenseNo").removeClass("validate[required]");
		$("#licenseValidity").removeClass("validate[required]");
		$("#lastRhpj").removeClass("validate[required]");
		$("#registeredCapital").removeClass("validate[required,custom[amountTen]]");
		$("#rcCurrencyName").removeClass("validate[required]");
		$("#foundedTime").removeClass("validate[required]");
		$("#employeeNum").removeClass("validate[required]");
	} 
	
});
/*验证基本信息页面*/
function validationBaseFrom(formId){
	var formError = $("#"+formId).validationEngine('validate');
	var type = validatorCheckbox("payType", 1, "payType");
	var credit = validationCredit();
	var other = validatorInputByCheckbox("countDay5", "countDay5Value");
	return formError && type && credit && other;
}

/*验证账期*/
function validationCredit(){
	var $radioPs = $("#credListTbody").find("p[data-two-input=radio]");
	for ( var i = 0; i < $radioPs.size(); i++) {
		var $radioP = $radioPs.eq(i);
		var $radioInput = $radioP.find("input[type=radio]");
		var $radioValue = $radioP.find("input[type=text]");
		if ($radioInput.attr("checked")) {
			if ($radioValue.val().length < 1) {
				$radioValue.validationEngine("showPrompt", "* 此处不可空白", "error", "", true);
				return false;
			}
		}
	}
	return true;
}

/**
 * 验证checkbox是否选中
 * @param tagname 验证项
 * @param minnumber 最小选择数
 * @param msgshowid 信息显示地ID
 * @returns {Boolean}
 */
function validatorCheckbox(tagname, minnumber, msgshowid) {
	if ($("input[validatortag=" + tagname + "]:checked").length < minnumber) {
		$("#" + msgshowid).validationEngine("showPrompt","*最少选择 " + minnumber + " 项", "error", "", true);
		return false;
	} else {
		return true;
	}
}

/**
 * 当CheckboxID对应选中时验证inputID对应是否为空
 * @param conditionId CheckboxID
 * @param validatorId inputID
 */
function validatorInputByCheckbox(checkboxId, validatorId) {
	if ($("#" + checkboxId + ":checked").length > 0) {
		if ($("#" + validatorId).val().length < 1) {
			$("#" + validatorId).validationEngine("showPrompt", "* 此处不可空白", "error", "", true);
			return false;
		}
	}
	return true;
}

$(window).load(function () {
	$("[validatortag=nocbd]").addClass("validate[required]");
});