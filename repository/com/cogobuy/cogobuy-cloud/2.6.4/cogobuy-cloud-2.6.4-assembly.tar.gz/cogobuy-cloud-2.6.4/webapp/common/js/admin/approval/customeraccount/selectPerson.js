$(function () {
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/findAllPerson"),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.personList != null){
            	$("#person_show").autocomplete(data.personList, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-1'>姓名</span> <span class='col-2'>部门</span></div>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-1'>"+row.personName+"</span> <span class='col-2'>"+row.TDepartment.departmentName+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.personName;
                    },
                    formatResult: function(row) {
                        return row.personName;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                	$("#person_show").val(data.personName);
                	$("#dept_show").val(data.TDepartment.departmentName);
                	$("#person_input").val(data.id);
                	$("#dept_input").val(data.TDepartment.id);
                }).bind("unmatch", function() {/**没有匹配时**/
                	$("#person_show").val("");
                	$("#dept_show").val("");
                	$("#person_input").val("");
                	$("#dept_input").val("");
                });
            }
        }
    });
});