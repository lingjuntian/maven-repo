$(function () {
	/**
     * 文件上传
     */
    $("input[type=file]").change(function(){
    	fileUpload($(this));
	});
});

function fileUpload(obj){
	var _fileName = obj.val().substring(obj.val().lastIndexOf("\\") + 1);
	obj.siblings("input[type=text]").val(_fileName);
	var extend = _fileName.substring(_fileName.lastIndexOf(".")+1).toLowerCase();
	if(extend == "pdf"){
		var testpdf = confirm("PDF文件建议压缩后上传,是否继续上传");
		if(testpdf){
			addLoading("文件上传中，请等待...");
			obj.parents("form").ajaxSubmit(function(returnStr){
		        if(returnStr == "1"){
		        	var fileinput = "<input type=\"file\" size=\"45\" class=\"input-file\" name=\"file\" />";
		        	obj.parent("div").append(fileinput);
		        	obj.remove();
		        	$("input[type=file]").unbind("change");
		        	$("input[type=file]").bind("change",function(){
		        		fileUpload($(this));
		        		return false;
		        	});
		        	removeLoading("");
		        	dialog("上传成功","success",true,2);
			    	return;
		        }else{
		        	obj.siblings("input[type=text]").val("");
		        	removeLoading("");
			    	dialog("文件上传失败","unsuccess",true,2);
			        return;
		        }
			});
		}else{
			return;
		}
	}else{
		addLoading("文件上传中，请等待...");
		obj.parents("form").ajaxSubmit(function(returnStr){
	        if(returnStr == "1"){
	        	var fileinput = "<input type=\"file\" size=\"45\" class=\"input-file\" name=\"file\" />";
	        	obj.parent("div").append(fileinput);
	        	obj.remove();
	        	$("input[type=file]").unbind("change");
	        	$("input[type=file]").bind("change",function(){
	        		fileUpload($(this));
	        		return false;
	        	});
	        	removeLoading("");
	        	dialog("上传成功","success",true,2);
		    	return;
	        }else{
	        	obj.siblings("input[type=text]").val("");
	        	removeLoading("");
		    	dialog("文件上传失败","unsuccess",true,2);
		        return;
	        }
		});
	}
}
