/**
 * crm 项目详情js
 */

$(function(){
	//添加验证
	$("#projectName,#proCustomer,#projectStage,#contact1").addClass("validate[required]");
	$("[tdTag=expectedNum]").addClass("validate[custom[creditLimit]]");
	$("#discriptionEdit").hide();
	// 项目-编辑
	$('.item-add .edit').click(function(){
		$('.item-add table input,.item-add table textarea').attr('readonly','');

		$('.item-add table input,.item-add table textarea,.item-add table select option').css({'border':'1px solid #ccc','border-radius':'3px'});
		
		// 修改input框聚焦时的border-color
		$('.item-add table input,.item-add table textarea').focus(function(){
		    $(this).css({'border-color':'#03A1E8'});
		});
		$('.item-add table input,.item-add table textarea').blur(function(){
		    $(this).css({'border-color':'#ccc'});
		});

		var str1 = '<td colspan="4"  class="btn-td"><a href="#" title="保存" class="save btn-save ">保存</a><a href="#" title="取消" id="cancelBut" class=" cancel btn-save">取消</a></td>';
		$('.item-add .edit').parent().replaceWith(str1);

		// select框的隐藏显示
		$('.item-add table select,.item-add table textarea').css({'display':'block'});
		$('.item-add table td span').css({'display':'none'});
		//显示删除操作
		$("#detailTable").find("[hide=opearHide]").removeAttr("style").removeAttr("hide");
	    //详细加个空行
		addTr($("#hideTr"));
		//显示联系人编辑框
		var $trs=$("#contactShow").find("input[tdTag=contactName]");
		var $trIds=$("#contactShow").find("input[tdTag=contactId]");
		var $trs2=$("#contactEdit").find("input[tdTag=contactName]");
		var $trIds2=$("#contactEdit").find("input[tdTag=contactId]");
		for ( var i = 0; i < $trs.size(); i++) {
			$trs2.eq(i).val($trs.eq(i).val());
			$trIds2.eq(i).val($trIds.eq(i).val());
		}
		$("#contactShow").hide();
		$("#contactEdit").removeAttr("style");
		
		 /* 添加一行 */
	    $("tr input").click(function () {
	        var $tr = $(this).parents("tr");
	        if ($tr.nextAll().length == 0) {
	            addTr($tr);
	        }
	    });
	        
	});
	$('.item-add .edit').live('click',function(){
		$('.item-add table input,.item-add table textarea').attr('readonly','');

		$('.item-add table input,.item-add table textarea,.item-add table select option').css({'border':'1px solid #ccc'});
		
		// 修改input框聚焦时的border-color
		$('.item-add table input,.item-add table textarea').focus(function(){
		    $(this).css({'border-color':'#03A1E8'});
		});
		$('.item-add table input,.item-add table textarea').blur(function(){
		    $(this).css({'border-color':'#ccc'});
		});

		var str1 = '<td colspan="4"  class="btn-td"><a href="#" title="保存" class="save btn-save ">保存</a><a href="#" title="取消" class=" cancel btn-save">取消</a></td>';
		$('.item-add .edit').parent().replaceWith(str1);

		// select框的隐藏显示
		$('.item-add table select,.item-add table textarea').css({'display':'block'});
		$('.item-add table td span').css({'display':'none'});
	});

	// 项目-编辑完成-保存/取消
	$('.item-add .save').live('click',function(){                          // 保存
		clearNull();
    	var isPass=validationInput();
     	if(isPass){
     		$(".item-add .save").hide();
     		$("#projectForm").attr("action","/crm/project_update");
     		$("#projectForm").ajaxSubmit(function(returnStr) {
    			var type = returnStr.split("_")[0];
     			var id = returnStr.split("_")[1];
     			if (type == "success") {
     				dialog("成功","success",true,1);
     				var str="/crm/project_show?project.id="+id;
     				setTimeout(function(){window.location = str;},1000);	  
     			}else {
     				$(".item-add .save").show();
     				dialog(returnStr,"unsuccess",true,2);
     			}	
     	        return false;
     		});
     	}
	});
	$('#cancelBut').live('click',function(){                         // 取消
		/*$('.item-add table input,.item-add table textarea').attr('readonly','readonly');
		$('.item-add table input,.item-add table textarea,.item-add table select option').css({'border':'none'});
		var str2 = '<td colspan="4"  class="btn-td"><a href="#" title="编辑" class="edit btn-save">编辑</a></td>';
		$('.item-add .save').parent().replaceWith(str2);
		//添加边框样式
		$('.item-add table select,.item-add table textarea').css({'display':'none'});
		$('.item-add table td span').css({'display':'block'});
		alert('已取消');*/
		dialog("您确定要放弃编辑吗？",null,true,null,function(){
			var id=$("#projectId").val();
	    	var str="/crm/project_show?project.id="+id;
	    	window.location.href=str;
		});
	});
    
	conatctAutoComplete($("#contact1"),$("#contactId1"));
 	conatctAutoComplete($("#contact2"),$("#contactId2"));
 	conatctAutoComplete($("#contact3"),$("#contactId3"));
	/*联系人自动匹配*/
 	function conatctAutoComplete($input,$inputId){
 		     //  var cid=$("proCustomerId").val();
 		    $input.autocomplete(encodeURI("/crmAjax/contact_findConTop8"), {
 	        //**加自定义表头**//*
 		    tableHead: "<div> <span class='col-3'> 姓名 -----------手机</div>", 	
 	        minChars: 0,
 	        width: 230,
 	       //extraParams:{cid:$("proCustomerId").val()}, 
 	        matchContains: "true",
 	        autoFill: false,
 	        dataType: 'json',
 	        parse: function(data) {  
 	            var rows = [];  
 	            if(data == null || data.contacts == null){
 	            	return rows;
 	            }
 	            for(var i=0; i<data.contacts.length; i++){    
 	                rows[rows.length] = {    
 	                    data:data.contacts[i],              
 	                    value:data.contacts[i].chName,     
 	                    result:data.contacts[i].chName   
 	                };  
 	            }  
 	            return rows;  
 	        }, 
 	        formatItem: function(row, i, max) {
 	        	 return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"---"+row.phone+"</div>";
 	        },
 	        formatMatch: function(row, i, max) {
 	            return row.chName;
 	        }
 		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
 		    	$(this).val("");
 		    	$inputId.val("");
 		    	$(this).val(data.chName);
 		    	$inputId.val(data.id);
 		    }).bind("unmatch", function() {//**没有匹配时**//*
 		    	$(this).val("");
 		    	$inputId.val("");
 		    });
 	}
	
	
	
   
    /*删除一行*/
    $(".del-text").click(function () {
        var $obj = $(this).parents("tr");
        var $length = $obj.parents("tbody").find("tr").length;
        if ($length < 2) {
            dialog("请最少保留1行", "warning", false, 2);
            return false;
        }
        $obj.remove();
    });
    /*清除行的数据*/
    function clearTr($tr){
    	$tr.find("input[filterNull!=true]").val("");
    	$tr.find("[tdTag=inventoryCode]").validationEngine('hidePrompt');
    }

    /* 克隆行 */
    function addTr($tr){
    	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
    	$copyTr.removeAttr("hide");
    	$copyTr.removeAttr("style");
    	$("#detailListTbody").append($copyTr);
    }
    /* 清除空行 、且修改相应字段的name+id属性 */
    function clearNull() {
    	cleanTbody($("#detailListTbody"));
    	addIdAndNameForInput($("#detailListTbody"));
    }
    /* 整理表格，去空行，至少保留一行 */
    function cleanTbody($tbody) {
    	var $trNum = $tbody.find("tr").size();
    	for ( var i = $trNum-1; i >= 0; i--) {
    		$trNum = $tbody.find("tr").size();
    		var $tr = $tbody.find("tr").eq(i);
    		if (checkEmptyTr($tr)) {
    			if ($trNum > 1) {
    				$tr.remove();
    			}
    		}
    	}
    }
    /* 验证空行 */
    function checkEmptyTr($tr) {
    	var $inputNum = $tr.find("input").size();
    	var flag = true; // 为空
    	for ( var i = 0; i < $inputNum; i++) {
    		var $input = $tr.find("input[filterNull!=true]").eq(i);
    		if ($.trim($input.val()) != "") {
    			flag = false; // 不为空
    			break;
    		}
    	}
    	return flag;
    }
    
    /* 增加新建页面列表的name,id属性 */
    function addIdAndNameForInput($tbody) {
    	var $trs = $tbody.find("tr");/* 获取所有tr */
    	var firstName = "project.detail";/* 前缀名称 */
    	for ( var i = 0; i < $trs.size(); i++) {
    		var numtag = "[" + i + "]";
    		var $tr = $trs.eq(i);
    		var $inputNum = $tr.find("input").size();
    		var $select=$tr.find("select");
    		$select.attr("name", firstName + numtag + "." + $select.attr("tdTag"));
    		$select.attr("id",$select.attr("tdTag")+numtag);
    		for ( var j = 0; j < $inputNum; j++) {
    			var $input = $tr.find("input").eq(j);
    			$input.attr("id", $input.attr("tdTag") + numtag);
    			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
    		}
    	}
    }
    
    /* 验证输入 */
    function validationInput() {
    	return $("#projectForm").validationEngine('validate');
    };
    
});







