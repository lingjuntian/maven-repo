$(function(){
	$("[id^=requestDate]").addClass("validate[required,custom[date]]");
	$("[id^=quantity]").addClass("validate[required,custom[integer],min[1]]]");
	
	$("#backlogForCusDetailForm").validationEngine({
		validationEventTriggers : "blur", //触发的事件  validationEventTriggers:"keyup blur",  
		inlineValidation : false,// 是否即时验证，false为提交表单时验证,默认true
		success : false,// 为true时即使有不符合的也提交表单,false表示只有全部通过验证了才能提交表单,默认false
		promptPosition : "topLeft",//提示所在的位置，topLeft, topRight, bottomLeft,  centerRight, bottomRight
	});
	
	 $("#blgForCus_submitBtn").unbind("click").click(function(){
          $("#backlogForCusDetailForm").submit();
      });
      $("#blgCusEdit tbody :text").bind("click",function(){
      	$("#backlogForCusDetailForm").validationEngine("hideAll");
      });
      $("#cancel").click(function(){
      	$("#backlogForCusDetailForm").validationEngine("hideAll");
		closeLayer();          
      });
      $(".del").click(function(){
      		delTr(this);
      		return false;
      });
      $(".add").click(function(){
      	addTr(this);
      	return false;
      });
      $('input[id^=requestDate]').click(function(){
      /*	var now = new Date();
      	var year = now.getFullYear();
      	var month = now.getMonth()+1;
      	var day = now.getDate();
      	now = year+"-"+month+"-"+day;
      	WdatePicker({ minDate:now,readOnly:true});*/
      	WdatePicker({onpicked:function(){}});
      });
      
});
/**
  *添加一行
  */
function addTr(obj){
	var idx = $(".popup-content tbody tr").length;
	$("#backlogForCusDetailForm").validationEngine("hideAll");
	if($(".popup-content tbody tr").size()==1){
		$(".popup-content tbody tr td").find(".del").show();
		//$(this).parent().parent().find(".del").show();
	}
	var tr = $('<tr>' +
				'<td><input type="text" id="requestDate'+idx+'" name="editBlgForCusDetail['+idx+'].requestDate" size="15"  onclick="selectDate()" class="input-text"/></td>'
				+'<td><input type="text" id="quantity'+idx+'" size="15" name="editBlgForCusDetail['+idx+'].quantity"  class="input-text"/></td>'
				+'<td><input type="text" id="mark'+idx+'" size="15" name="editBlgForCusDetail['+idx+'].mark"  class="input-text"/></td>'
				+'<td><a href="#" title="删除" class="del">删除</a><a href="#" title="添加" class="add">添加</a></td>'
			+'</tr>');
	tr.appendTo("#blgCusEdit");
	//tr.insertAfter($(obj).parent().parent("tr"));
	resetRowNo();
	return false;
}
/**
  *删除一行
  */
function delTr(obj){
	var length = $(".popup-content tbody tr").length;
	if(length <= 1){
		return ;
	}
	$("#backlogForCusDetailForm").validationEngine("hideAll");
	if(confirm("确定要删除这一行吗?")){
		if($(".popup-content tbody tr").size() == 2){
		//$(object).parents("tr").siblings().find(".del").hide();
			$(obj).parent().parent().siblings().find(".del").hide();
		}
		$(obj).parent().parent().remove();
		resetRowNo();
	}
}

//选择日期
function selectDate(){
	WdatePicker({onpicked:function(){}});
}
function resetRowNo(){
	var lineIdx = $(".popup-content tbody tr").length;
	for(var i=lineIdx-1;i>=0;i--){
		var tr = $(".popup-content tbody tr").eq(i);
		tr.find("[name*=requestDate]").attr("name","editBlgForCusDetail["+i+"].requestDate");
		tr.find("[name*=quantity]").attr("name","editBlgForCusDetail["+i+"].quantity");
		tr.find("[name*=mark]").attr("name","editBlgForCusDetail["+i+"].mark");
		
		tr.find("[id*=requestDate]").attr("id","requestDate"+i);
		tr.find("[id*=quantity]").attr("id","quantity"+i);
		tr.find("[id*=mark]").attr("id","mark"+i);
		
		tr.find("[id*=requestDate]").addClass("validate[required,custom[date]]");
		tr.find("[id*=quantity]").addClass("validate[required,custom[integer],min[1]]]");
		
		$(".popup-content tbody tr .add").unbind("click").click(function(){
			addTr(this);
			return false;
		});
		$(".popup-content tbody tr .del").unbind("click").click(function(){
			delTr(this);
			return false;	
		});
		$("[id^=requestDate]").unbind("click").click(function(){
			$("#backlogForCusDetailForm").validationEngine("hideAll");
			return false;
		});
		$("[id^=quantity]").unbind("click").click(function(){
			$("#backlogForCusDetailForm").validationEngine("hideAll");
			return false;
		});
		$("[id^=mark]").unbind("click").click(function(){
			$("#backlogForCusDetailForm").validationEngine("hideAll");
			return false;
		});
	}
}