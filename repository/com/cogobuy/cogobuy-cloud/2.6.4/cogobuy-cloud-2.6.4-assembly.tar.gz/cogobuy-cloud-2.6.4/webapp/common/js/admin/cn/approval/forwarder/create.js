function debug() {
       if (window.console && window.console.log) {
            window.console.log(arguments);
      }
}

$(function() {
	
	// 客户名称自动提示
	autoCompleteCustomerName();
	
	//业务员自动提示
	autoCompletePerson();
	
	//添加验证项
	validateFunction();

	/* 日期控件 */
	/*
	 * $("#budgetStartDate").click(function(){
	 * WdatePicker({onpicked:function(){},minDate:getMinValue($('#budgetStartDate').val(),
	 * GetTodayDateStr())}); });
	 */

	// 上一步
	$("#upStep").click(function() {

		$("#costBody").find("tr[deleteFlag=yes]").remove();
		// 隐藏的Collect表单清空
		$("#collectDiv").empty();
		// 清除提示
		$("#prompt").text("");

		$("#twoStep").hide();
		$("#oneStep").show();
	});

	// 下一步
	$("#nextStep").click(function() {
		//cleanPage();
		validateFunction();
		
		var personCode = $("#personCode").val();
		if (personCode == null || personCode.length == 0) {
			dialog("输入的业务员信息无效，请输入业务员姓名（中文或英文）后，从提示框选择！","unsuccess",true,3);
			return false;
		}
		
		var error1 = $("#historyForm").validationEngine('validate');
		if (error1) {
			//验证有木有上传附件
			//判断UL ID = fileListForCreate下面有没有li标签，有就表示已经上传过附件了。
			if($("#cpKey").val() == "" && $("#fileListForCreate li").size() == 0){
				dialog("必须提供客户的收货委托书或者特批邮件！","unsuccess",true,3);
				return false;
			} else {
				//不能超过系统定义的允许新建的货代个数，B2BMASTER.dbo.Customer表的allowForwarderCount
				if($("#existsForwarderCount").val() <= $("#allowForwarderCount").val()-1){
					//count();
					//copyStyle();// 复制表格 取回邮件列表
					//验证是否有审批节点
					getEmailList();/* 获取邮件发送列表 */
					
					showConfirmMsg();
					$("#oneStep").hide();
					$("#twoStep").show();
					copyFileList();
					return false;	
				} else {
					dialog("系统允许该客户收货单位的个数：【"+$("#allowForwarderCount").val()+"】，超过该个数，无法继续绑定，请先作废其中一个！","unsuccess",true,3);
					return false;
				}
			}
		}
		return false;
	});
	
	//确认提交
    $("#allSubmit").click(function(){
    	//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#historyForm").append(inputStr);
    		}
    	});
    	$("#allSubmit").hide();
		$("#historyForm").attr("action","/approval/caForwarderApproval_create");
		$("#historyForm").ajaxSubmit(function(returnStr){
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功！","success"+id,true,1);
				setTimeout(function(){window.location = "/approval/caForwarderApproval_show?forwarderInfo.id="+id;},1000);	  
			}else{
				$("#allSubmit").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
    });

	// 备份草稿
	$("#backup").click(function() {
		cleanPage();
		validateFunction();
		var error1 = $("#historyForm").validationEngine('validate');
		if (error1) {
			//count();
			// 去掉复制用的tr
			$("#historyForm").attr("action", "/approval/caForwarderApproval_createDraft");
			$("#historyForm").ajaxSubmit(function(returnStr) {
				$("#backup").hide();
				var type = returnStr.split("_")[0];
				if (type == "success") {
					var type = returnStr.split("_")[0];
					var id = returnStr.split("_")[1];
					if (type == "success") {
						//$("#budgetBackupId").val(id);
						dialog("草稿保存成功", "success", true, 1);
						window.location = "/approval/caForwarderApproval_listDraft";
					}
				} else {
					dialog(returnStr, "unsuccess", true, 1);
				}

				// action地址改回
				//$("#historyForm").attr("action", "/approval/budget_create");
				return false;
			});
			return false;
		}
	});
	
	/*上传委托书*/
	$("#fileCp").change(function(){
    	fileCpUpload($(this));
	});
	
	/*下载附件*/
	$("a[downFileTag=downFileTag]").bind("click",
		function() {
			fileDownLoad($(this));
			return false;
	});

});

/*上传委托书*/
function fileCpUpload(obj){
	var _fileName = obj.val().substring(obj.val().lastIndexOf("\\") + 1);
	obj.siblings("input[type=text]").val(_fileName);
	var extend = _fileName.substring(_fileName.lastIndexOf(".")+1).toLowerCase();
	if(extend == "pdf"){
		var testpdf = confirm("PDF文件建议压缩后上传,是否继续上传");
		if(testpdf){
			addLoading("文件上传中，请等待...");
			$("#fileCpUploadForm").ajaxSubmit(function(returnStr){
		        if(returnStr == "1" || returnStr != "0"){
		        	var fileinput = "<input type=\"file\" size=\"45\" class=\"input-file\" name=\"file\" />";
		        	obj.parent("div").append(fileinput);
		        	obj.remove();
		        	$("input[type=file]").unbind("change");
		        	$("input[type=file]").bind("change",function(){
		        		fileUpload($(this));
		        		return false;
		        	});
		        	removeLoading("");
		        	if(returnStr != "0"){
		        		$("#cpKey").val(returnStr);
		        		$("#spanCp").text(_fileName);
		        	}
		        	dialog("上传成功","success",true,2);
			    	return;
		        }else{
		        	obj.siblings("input[type=text]").val("");
		        	removeLoading("");
			    	dialog("文件上传失败","unsuccess",true,2);
			        return;
		        }
			});
		}else{
			return;
		}
	}else{
		addLoading("文件上传中，请等待...");
		$("#fileCpUploadForm").ajaxSubmit(function(returnStr){
	        if(returnStr == "1" || returnStr != "0"){
	        	var fileinput = "<input type=\"file\" size=\"45\" class=\"input-file\" name=\"file\" />";
	        	obj.parent("div").append(fileinput);
	        	obj.remove();
	        	$("input[type=file]").unbind("change");
	        	$("input[type=file]").bind("change",function(){
	        		fileUpload($(this));
	        		return false;
	        	});
	        	removeLoading("");
	        	if(returnStr != "0"){
	        		$("#cpKey").val(returnStr);
	        		$("#spanCp").text(_fileName);
	        	}
	        	dialog("上传成功","success",true,2);
		    	return;
	        }else{
	        	obj.siblings("input[type=text]").val("");
	        	removeLoading("");
		    	dialog("文件上传失败","unsuccess",true,2);
		        return;
	        }
		});
	}
}

/*加载业务员的自动匹配功能*/
function autoCompletePerson(){
	$("#personName").autocomplete(encodeURI("/approvalajax/salesOrderApproval_findPersonList"), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>业务员(名称|CODE)</span><span  class='col-2'>业务员部门</span><span  class='col-3'>业务员Email</span></div>",
		minChars: 0,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		onBegin: function(options) { //修改--用于动态改变ledger的值
            options.extraParams.ledger= $("#u8ledger").val();
            return options;
        },
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.personList == null){
            	return rows;
            }
            for(var i=0; i<data.personList.length; i++){    
                rows[rows.length] = {    
                    data:data.personList[i],              //下拉框显示数据格式   
                    value:data.personList[i].erpPersonName,     //选定后实际数据格式  
                    result:data.personList[i].erpPersonName   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.erpPersonName+ " | " + row.erpPersonCode + "</span>"+ "<span class='col-2'>" + row.erpDeptName + "</span>"+ "<span class='col-3'>" + row.erpPersonEmail + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.erpPersonName + " | " + row.erpPersonCode + " | " + row.erpPersonEmail;
		},
		formatResult: function(row) {
			return row.erpPersonName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$("#personName").val(data.erpPersonName);
		$("#personCode").val(data.erpPersonCode);
		$("#personMail").val(data.erpPersonEmail);
	}).bind("unmatch", function(){
		$("#personName").val("");
		$("#personCode").val("");
		$("#personMail").val("");
	});
}

//获取当前业务员对的流程是否存在
function getEmailList(){
	var url = "/approval/caForwarderApproval_showConfirmMail";
	$("#mailList").load(encodeURI(url),{"personMail":$("#personMail").val()});
}

//显示需要确认单信息
function showConfirmMsg(){
	$("#confirmCustomerName").text($("#customerName").val());
	$("#confirmCustomerAbbName").text($("#customerAbbName").val());
	$("#personNameConfirm").text($("#personName").val());
	$("#confirmDeliverUnit").text($("#deliverUnit").val());
	$("#confirmDeliverAdd").text($("#dliverAdd").val());
	$("#confirmDeliverEnAdd").text($("#dliverEnAdd").val());
	$("#confirmContact").text($("#contactName").val());
	$("#confirmContactPhone").text($("#contactPhone").val());
	$("#belongCompanyConfirm").text("["+$("#u8ledger").val()+"]"+$("#companyName").val());
}

//客户名称自动提示
function autoCompleteCustomerName() {
	$("#customerName").autocomplete(encodeURI("/approvalajax/caForwarder_findCustomer"),
		{
			/** 加自定义表头* */
			tableHead : "<div><span class='col-1'>客户编码</span><span class='col-1'>客户名称</span><span class='col-2'>(账套)所属公司</span></div>",
			minChars : 1,
			width : 500,
			matchContains : "true",
			autoFill : false,
			dataType : 'json',
			parse : function(data) {
				var rows = [];
				if (data == null || data.customerList == null) {
					return rows;
				}
				for ( var i = 0; i < data.customerList.length; i++) {
					rows[rows.length] = {
						data : data.customerList[i],
						value : data.customerList[i].cusName,
					};
				}
				return rows;
			},
			formatItem : function(row, i, max) {
				return "<span class='col-1'>" + row.cusCode + "</span><span class='col-1'>" + row.cusName + "</span><span class='col-2'>("+row.u8ledger+")" + row.u8ledgerName + "</span>";
			},
			formatMatch : function(row, i, max) {
				return row.cusName;
			},
			formatResult : function(row) {
				return row.cusName;
			}
		}).result(function(e, cus, value, sec) {
			/** 加选中后的回调函数* */
			$("#customerAbbName").val(cus.cusAbbName);
			$("#customerName").val(cus.cusName);
			$("#u8ledger").val(cus.u8ledger);
			$("#customerCode").val(cus.cusCode);
			$("#companyName").val(cus.u8ledgerName);
			$("#allowForwarderCount").val(cus.allowForwarderCount);
			
			$("#divLedgerInfo").html("账套："+cus.u8ledger+"   所属公司："+cus.u8ledgerName);
			
			loadExistsForwarderList(cus.u8ledger,cus.cusCode);
			
		}).bind("unmatch", function() {
			/** 没有匹配时* */
			$("#customerAbbName").val("");
			$("#customerName").val("");
			$("#u8ledger").val("");
			$("#customerCode").val("");
			$("#companyName").val("");
			$("#divLedgerInfo").html("");
		});
}

//根据u8ledger和ccuscode加载已经存在的收货单位
function loadExistsForwarderList(u8ledger,cCusCode){
	//根据账套和客户编码,显示当前客户已经新建的货代列表
	$.post("/approvalajax/caForwarder_findForwarderListByLedgerAndCustomer",{"forwarderInfo.u8ledger":u8ledger,"forwarderInfo.customerCode":cCusCode},function(data){
		//debug(data);
		//debug(data.forwarderList);
		//debug(data.forwarderList.length);
		$("#bodyExistsForwarderList").html("");
		$("#existsForwarderCount").val(data.forwarderList.length);
		
		if(data.forwarderList.length > 0){
			for(var i=0;i<data.forwarderList.length;i++){
				//debug(data.forwarderList[i]);
				var obj = data.forwarderList[i];
				debug(obj.id+"\t"+obj.deliverUnit+"\t"+obj.deliverAdd+"\t"+obj.deliverEnAdd+"\t"+obj.contactName+"\t"+obj.officePhone);

				$("#bodyExistsForwarderList").append("<tr>");
				$("#bodyExistsForwarderList").append("<td class=\"first serial-number\"><div>"+obj.deliverUnit+"</div></td>");
				$("#bodyExistsForwarderList").append("<td class=\"first serial-number\"><div>"+obj.deliverAdd+"</div></td>");
				$("#bodyExistsForwarderList").append("<td class=\"first serial-number\"><div>"+obj.deliverEnAdd+"</div></td>");
				$("#bodyExistsForwarderList").append("<td class=\"first serial-number\"><div>"+obj.contactName+"</div></td>");
				$("#bodyExistsForwarderList").append("<td class=\"first serial-number\"><div>"+obj.officePhone+"</div></td>");
				//$("#bodyExistsForwarderList").append("<td class=\"first serial-number\"><div>"+obj.isEnable+"</div></td>");
				
				var optionurl = "<a href=\"javascript:updateForwarderInfoByID("+obj.id+","+u8ledger+",'"+cCusCode+"')\">作废</a>";
				/*if(obj.isEnable == "可用"){
					optionurl = 
				}
				else{
					optionurl = "<a href=\"/approvalajax/caForwarder_updateForwarderByID?forwarderInfo.id="+obj.id+"&forwarderInfo.flag=1\">启用</a>";
				}*/
				
				$("#bodyExistsForwarderList").append("<td class=\"first serial-number\"><div>"+optionurl+"</div></td>");
				$("#bodyExistsForwarderList").append("</tr>");
			}
		}else{
			$("#bodyExistsForwarderList").append("<tr><td colspan=\"6\"><center>该客户暂未绑定任何收货单位信息.</center></td></tr>");
		}
		
	},"json");
}

//更新收货单位的状态
function updateForwarderInfoByID(id,u8ledger,customerCode){
	debug(id+"\t"+u8ledger+"\t"+customerCode);
	$.post("/approvalajax/caForwarder_updateForwarderByID",{"forwarderInfo.id":id,"forwarderInfo.flag":0},function(data){
		loadExistsForwarderList(u8ledger,customerCode);
	},"json");
}

function copyFileList() {
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function() {
		$(this).hide();
	});
	/*$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",
		function() {
			fileDownLoad($(this));
			return false;
	});*/
	
}

function fileDownLoad($obj){
	$("#fileNameDownId").val($obj.attr("fileName"));
	$("#srcNameDownId").val($obj.attr("srcName"));
	$("#fileDownloadForm").submit();
}

//添加验证选项
function validateFunction() {
	$("#customerName").addClass("validate[required]");
	$("#customerAbbName").addClass("validate[required]");
	$("#personName").addClass("validate[required]");
	
	$("#deliverUnit").addClass("validate[required]");
	$("#dliverAdd").addClass("validate[required]");
	$("#contactName").addClass("validate[required]");
	$("#contactPhone").addClass("validate[required]");
}