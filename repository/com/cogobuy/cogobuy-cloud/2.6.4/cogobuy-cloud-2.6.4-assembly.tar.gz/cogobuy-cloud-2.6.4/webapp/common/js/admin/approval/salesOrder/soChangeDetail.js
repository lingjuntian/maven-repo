/**
 * PM审核通过
 * @param parent
 */
function soPmApproval(parentId,returnUrl) {
	var $postinput = $("body").find("input[posttag^=Sandisk]");/* 获取所有tr */
	
	var $postinput_margin = $("body").find("input[posttag^=margin]");/* 获取所有tr */
	//验证毛利是否符合要求，毛利小于0 or 毛利大于30%，则提示
	for ( var i = 0; i < $postinput_margin.size(); i++) {
		var $input_margin = $postinput_margin.eq(i);
		var $inputMarginVal = $input_margin.val();  //每一行的毛利
		if($inputMarginVal == "" || $inputMarginVal >= 30 || $inputMarginVal < 0){
			//dialog("第【"+ (i+1) +"】行毛利不符合要求，请检查输入的实际COST是否输入有误.","warning",false,6);
			alert("第【"+ (i+1) +"】行毛利不符合要求，请检查输入的实际COST是否输入有误.");
			// return;
		}
	}
	
	$(".button-yellow").hide();
	var data = {
			"salesOrderChange.id" : parentId,
			"mails" : getApprovalMail()
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/changeOrder_pmApproval"),
		data : data,
		success : function(returnStr) {
			if (returnStr == 'success') {
				dialog("成功", "success", true, 2);
				window.location.href = returnUrl;
			} else {
				$(".button-yellow").show();
				dialog(returnStr, "unsuccess", true, 10);
			}
		}
	});
	//}
}


/**
 * CT审核通过
 * @param parent
 */
function soCtApproval(parentId,returnUrl) {
	$(".button-yellow").hide();
	var data = {
			"salesOrderChange.id" : parentId,
			"mails" : getApprovalMail()
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/changeOrder_ctApproval"),
		data : data,
		success : function(returnStr) {
			if (returnStr == 'success') {
				dialog("成功", "success", true, 2);
				window.location.href = returnUrl;
			} else {
				$(".button-yellow").show();
				dialog(returnStr, "unsuccess", true, 10);
			}
		}
	});
}


/**
 * pm审核通过
 * @param parent
 */
function soPmApprovalAll(parentId,returnUrl) {
	$(".button-yellow").hide();
	var data = {
			"salesOrderChange.id" : parentId,
			"mails" : getApprovalMail()
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/changeOrder_pmApprovalAll"),
		data : data,
		success : function(returnStr) {
			if (returnStr == 'success') {
				dialog("成功", "success", true, 2);
				window.location.href = returnUrl;
			} else {
				$(".button-yellow").show();
				dialog(returnStr, "unsuccess", true, 10);
			}
		}
	});
}

