/**
 * crm show 拜访报告util js
 */

$(function(){

    /* 添加一行 */
    $("tr input").click(function () {
        var $tr = $(this).parents("tr");
        if ($tr.nextAll().length == 0) {
            addTr($tr);
        }
    });

});

/*清除行的数据*/
function clearTr($tr){
    $tr.find("input[filterNull!=true]").val("");
    $tr.find("[tdTag=inventoryCode]").validationEngine('hidePrompt');
}

/* 克隆行 */
function addTr($tr){
    $copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
    $copyTr.removeAttr("hide");
    $copyTr.removeAttr("style");
    $("#detailListTbody").append($copyTr);
}
/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
    cleanTbody($("#detailListTbody"));
    addIdAndNameForInput($("#detailListTbody"));
}
/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
    var $trNum = $tbody.find("tr").size();
    for ( var i = $trNum-1; i >= 1; i--) {
        $trNum = $tbody.find("tr").size();
        var $tr = $tbody.find("tr").eq(i);
        if (checkEmptyTr($tr)) {
            $tr.remove();
        }
    }
}
/* 验证空行 */
function checkEmptyTr($tr) {
        // var $inputNum = $tr.find("input").size();
        // var flag = true; // 为空
        var $input = $tr.find("input");
        if ($.trim($input.eq(0).val()) != "") {
            return false; // 不为空
        }
          return true;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
    var $trs = $tbody.find("tr");/* 获取所有tr */
    var firstName = "visitReport.nextPlans";/* 前缀名称 */
    for ( var i = 0; i < $trs.size(); i++) {
        var numtag = "[" + i + "]";
        var $tr = $trs.eq(i);
        var $inputNum = $tr.find("input").size();
        for ( var j = 0; j < $inputNum; j++) {
            var $input = $tr.find("input").eq(j);
            $input.attr("id", $input.attr("tdTag") + numtag);
            $input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
        }
    }
}
