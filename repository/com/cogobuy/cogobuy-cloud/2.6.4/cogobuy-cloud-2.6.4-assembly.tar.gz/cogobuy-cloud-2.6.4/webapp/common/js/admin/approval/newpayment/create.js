$(function () {	
	/*初始化付款通知书日期*/
	var myDate = new Date();
	$("#year").text(myDate.getFullYear());
	$("#month").text(myDate.getMonth() + 1);
	$("#day").text(myDate.getDate());
	
	//绑定下拉事件
	bindselect();
	bindBankList();
	/*产品线 多选的请情况下，点击清空时间*/
	$("#pLinesUl .input-checkbox").live("click",function(){
		clearTime();
	});
	
	/*入库单全选*/
	$("#selectPurchaseAll").click(function(){
		if($(this).attr("checked")){
			$("#purchaseUL").find("input").attr("checked",true);
		}else{
			$("#purchaseUL").find("input").attr("checked",false);
		}
		calculateSum();
		var purchaseNum = $("#purchaseUL").find("input[checked=true]").size();
		if(purchaseNum>0){
			$("#numSpan").text("共选择"+purchaseNum+"个");
		}else{
			$("#numSpan").text("请选择");
		}
	});
	
	/*绑定查询事件*/
	$("#datetime1").click(function(){
		WdatePicker({onpicked:function(){recordCodes();},maxDate:getMinValue($('#datetime2').val(), GetTodayDateStr())});
	});
	
	$("#datetime2").click(function(){
		WdatePicker({onpicked:function(){recordCodes();},minDate:$('#datetime1').val(), maxDate:GetTodayDateStr()});
	});
	
	$("#dateForecast").click(function(){
		WdatePicker();
	});
	
	/*验证信息*/
	/*付款单信息*/
	$("#inventoryClass").addClass("validate[required]");
	$("#vendorName").addClass("validate[required]");
	$("#bankAccount").addClass("validate[required]");
	$("#bankName").addClass("validate[required]");
	$("#sumprice").addClass("validate[required,custom[amount]]");
	$("#unitprice").addClass("validate[custom[amount]]");
	$("#quantity").addClass("validate[custom[numberTen]]");
	/*银行信息增加*/
	$("#vendorBankName").addClass("validate[required]");
	$("#payCompanyName").addClass("validate[required]");
	$("#payCompanyId").addClass("validate[required]");
	$("#dateForecast").addClass("validate[required]");
    
    /*确认*/
    $("#confirmButton").click(function(){
    	var error1 = $("#createForm").validationEngine('validate');
    	if(error1){
    		/*头部 -- BU、账套、付款公司、水单*/
    		$("#confirmBU").text($("#bussinessUnit").val());
    		$("#confirmLedger").text($("#ledger").val());
    		$("#confirmPayCompany").text($("#payCompanyName").val());
    		var needBankBill = $('input[type=radio][name=payment.needBankBill][checked]').val();
    		var billText = "需要";
    		if(needBankBill=="0"){
    			billText = "不"+billText;
    		}
    		$("#confirmNeedBankBill").text(billText);
    		/*币种*/
    		var currency = $('input[type=radio][name=payment.currency][checked]').val();
    		$("span[id^=curFlag]").text(getCurrencyFlag(currency));
    		/*付款单类型*/
    		var type = $('input[type=radio][name=payment.type][checked]').val();
    		$("input[type=radio][name=confirmType][value="+type+"]").attr("checked",true); 
    		/*收款单位*/
    		$("#confirmVendorBankName").text($("#vendorBankName").val());//收款单位
    		/*开户行*/
    		$("#confirmBankName").text($("#bankName").val());
    		/*账号*/
    		$("#confirmBankAccount").text($("#bankAccount").val());
    		/*付款方式*/
    		var paymentType = $('input[type=radio][name=payment.paymentType][checked]').val();
    		$("input[type=checkbox][name=confirmPaymentType]").attr("checked",false);
    		$("input[type=checkbox][name=confirmPaymentType][value="+paymentType+"]").attr("checked",true);
    		/*品种*/
    		$("#confirmProductName").text($("#productName").val());
    		/*数量*/
    		$("#confirmQuantity").text($("#quantity").val());
    		/*单价*/
    		$("#confirmUnitprice").text($("#unitprice").val());
    		/*金额小写*/
    		$("#confirmSumprice").text($("#sumprice").val());
    		/*金额大写*/
    		lowToUpper($("#sumprice").val());
    		/*备注*/
    		$("#confirmNotes").text($("#notes").val());
    		$("#confirmNotes").append("<p>付款公司："+$("#payCompanyName").val()+"</p>"); 
    		/*预计付款时间*/
    		$("#dateForecastCon").val($("#dateForecast").val()); 
    		/*供应链金融业务*/
    		if($("#supplyChainFinance:checked").length > 0){
    			$("#scf_Confirm").show();
    		}else{
    			$("#scf_Confirm").hide();
    		}
    		/*copy attachment list*/
    		copyFileList();
    		/*获得邮件列表*/
    		getEmailList();
    		$("#write").hide();
    		$("#confirm").show();
    		/*置顶*/
    		$("#goTopButton").trigger("click");
    	}
    });
    
    /**
     * 返回
     */
    $("#backButton").click(function(){
    	$("#confirm").hide();
    	$("#write").show();
    });
    
    /**
     * 提交付款单
     */
    $("#createButton").click(function(){
    	$("#createButton").hide();
    	//把隐藏的名字去掉，以防提交 
    	$("#purchaseCopy").find("input").attr("name",""); 
    	//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#createForm").append(inputStr);
    		}
    	});
		$("#createForm").ajaxSubmit(function(returnStr){
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功！","success",true,1);
				setTimeout(function(){window.location = "/approval/payment_show?id="+id;},1000);
				return;
			}else{
				$("#createButton").show();
				dialog(returnStr,"unsuccess",true,1);
				return;
			}
		});
    });
    currencyClick();
});

/**
 * 绑定下拉列表方法
 */
function bindselect(){
	$(".options-select .options a").unbind("click");
	$(".options-select .options a").bind("click",function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input").val($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input[id$=Id]").val($(this).attr("tagValue"));
		if($(this).attr("tagN") == "bu"){
			$("#inventoryClass").val("");
			$("#inventoryClassId").val("");
			var buId = $(this).attr("tagValue");
			if(buId=='1' || buId=='8'){//世晓
				$("#accountType").show();
			}else{
				initAccountType();
			}
			findLedgerByBuForSelect($(this).attr("tagValue"),"ledgerForSelect");
			findProductLineByBuForSelect($(this).attr("tagValue"),"productLineForSelect");
		}
		if($(this).attr("ledger") == "ledger"){
			$("#vendorName").val("");
            $("#vendorId").val("");
            $("#vendorCode").val("");
            findCompanyByBuForSelect($(this).attr("tagValue"),"companyForSelect");
            clearTime();
		}
		if($(this).attr("clearTag") == "clear"){
			clearTime();
		}
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	});
}

/**
 * 初始化账户类型
 */
function initAccountType(){
	var html = "<label><input class=\"input-radio\" type=\"radio\" name=\"payment.accountType\" value=\"1\" checked=\"checked\" />对公</label>"+
			   "<label><input class=\"input-radio\" type=\"radio\" name=\"payment.accountType\" value=\"0\" />对私</label>";
	$("#accountType").html(html);
	$("#accountType").hide();
}

/**
 * 根据BU查找账套,并填充selectId对应的select值
 * @param buId
 * @param selectId
 */
function findLedgerByBuForSelect(buId, selectId){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/payment_findLedgerByBu?buId="+buId),
        dataType:"json",
        success:function(data, textStatus){
        	clearSelect(selectId,"ledger");
            if(data != null){
            	if(data.ledgerList != null){//动态填充流程
            		$.each(data.ledgerList,function(n,value) { 
           			 	var listr = "<li><a href=\"#\" ledger=\"ledger\" tagN=\"ledger\" tagValue=\""+value+"\" vhidden=\""+value+"\">"+value+"</a></li>";
           			 	$("#"+selectId).append(listr);
           	     	});
            		bindselect();
            	}
            }
        }
    });
}

/**
 * 根据BU查找对应的产品线,并填充产品线列表
 * @param buId
 * @param selectId
 */
function findProductLineByBuForSelect(buId ,selectId){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/payment_findProductLineByBu?buId="+buId),
        dataType:"json",
        success:function(data, textStatus){
        	$("#"+selectId).html("");//清除以前的值
        	$("#selectedPL").text("请选择");
            if(data != null){
        		var listr = "";
        		if(buId==1 || buId==8){
        			listr = "<div class=\"options-checkbox none\"><div class=\"actions clearfix\"><span class=\"show-text\">请选择产品线，可多选</span>"+
							"<button type=\"button\"  id=\"plSelect\" class=\"button button-options-sure\" data-display-type=\"num\" data-initial-value=\"请选择产品线\">确定</button>"+
							"</div><div class=\"options-list-box\"><ul class=\"options-list clearfix\" id=\"pLinesUl\">";
        			if(data.productLineList != null){//动态填充流程
            			$.each(data.productLineList,function(n,value) { 
            				listr += "<li class=\"options-item\"><label class=\"label\">"+
			  						"<input type=\"checkbox\" class=\"input-checkbox\" name=\"productLines\" plName=\""+value.name+"\" value=\""+value.id+":"+value.name+"\"/>"+
				  					"<span title='"+value.name+"'>"+value.name+"</span></label></li>";
               	     	});
        			}else{
        				listr += "<li class=\"options-item\">没有相关产品线！</li>";
        			}
        			listr += "</ul></div></div>";
        		}else{
        			listr = "<div class=\"options none\"><input type=\"text\" name=\"payment.inventoryClass\" id=\"inventoryClass\" />"+
                			"<input type=\"text\" name=\"payment.inventoryClassId\" id=\"inventoryClassId\" />"+
                            "<ul><li><a href=\"#\" tagN=\"pl\" tagValue=\"\" vhidden=\"请选择产品线\">请选择产品线</a></li>";
        			if(data.productLineList != null){//动态填充流程
            			$.each(data.productLineList,function(n,value) { 
                			listr += "<li><a href=\"#\" clearTag=\"clear\" tagValue=\""+value.id+"\" vhidden=\""+value.name+"\">"+value.name+"</a></li>";
               	     	});
        			}
        			listr += "</ul></div>";
        		}
        		$("#"+selectId).html(listr);
        		bindselect();
            }
        }
    });
}

/**
 * 根据帐套,查找对应的供应商,并填充供应商列表
 * @param buId
 * @param selectId
 */
function findCompanyByBuForSelect(ledger,selectId){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/payment_findAllVendor?ledger="+ledger),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.vendorList != null){
            	$("#vendorName").unautocomplete();
                $("#vendorName").autocomplete(data.vendorList,{
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-1'>编码</span> <span class='col-2'>名称</span></div>",
                    minChars: 0,
                    width: 310,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-1'>"+row.code+"</span> <span class='col-2'>"+row.name+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.name;
                    },
                    formatResult: function(row) {
                        return row.name;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                    $("#vendorName").val(data.name);
                    $("#vendorId").val(data.id);
                    $("#vendorCode").val(data.code);
                    $("#vendorBank_vendorId").val(data.id);
                    clearAccount();
                    clearTime();
                    paddingAccount(data.id, true);//根据供应商填充账号
                }).bind("unmatch", function() {/**没有匹配时**/
                	$("#vendorName").val("");
                    $("#vendorId").val("");
                    $("#vendorCode").val("");
                    $("#vendorBank_vendorId").val("");
                    clearAccount();
                    clearTime();
                });
            }
        }
    });
}

/**
 * @param id  清空select
 */
function clearSelect(id, tag){
	$("#"+id).empty();
	$("#"+id).append("<li><a href=\"#\" tagN=\""+tag+"\" tagValue=\"\" vhidden=\"请选择\">请选择</a></li>");
	$("#"+id).parents(".options-select").find(".select").find("span").text("请选择");
	$("#"+id).parents(".options-select").find("input").val("");
}

/**
 * 清空开始时间
 */
function clearTime(){
	$('#datetime1').val("");
	$('#datetime2').val("");
	clearPayRecord();
}

/**
 * 清空入库单列表
 */
function clearPayRecord(){
	$("#numSpan").text("");
	$("#purchaseUL").empty();
}

/**
 * 清除已经填充的供应商账号 
 */
function clearAccount(){
	$("#optionsList").empty();
}

/**
 * 填充供应商对应账号
 * @param vendorid
 * @param isClick
 */
function paddingAccount(vendorid, isClick){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/payment_findVendorBack?vendorid="+vendorid),
        dataType:"json",
        success:function(data, textStatus){
        	if(isClick){
    			clearAccount();
    		}
            if(data != null){
            	if(data.payee != null){
            		$("#vendorBankName").val(data.payee);
            		unEditPayee();
            	}else{
            		editPayee();
            	}
            	if(data.bankList != null && data.bankList.length >0){//填充账号
            		$.each(data.bankList,function(n,value) {
            			var index = n+1;
            			 var listr = "<li class='clearfix'><label for='vb"+index+"'><input type='radio' bank='"+value.bank+"' account='"+value.account+"' id='vb"+index+"' value='' /><span class='abank'>"
            			 			+value.bank+"</span><span class='account'>"+value.account+"</span> </label></li>";
            	           $("#optionsList").append(listr);
            	     });
            		$("#accountDiv").show();
            		bindBankList();//绑定填充账号操作
            	}else{
            		$("#accountDiv").hide();
            	}
            }
        }
    });
}

/**
 * 取消编辑收款单位
 */
function unEditPayee(){
	$("#payee_edit").show();
	$("#payee_cancel").hide();
	$("#vendorBankName").attr("readonly","readonly");
	$("#vendorBankName").addClass("disabled");
}

/**
 * 收款单位可编辑
 */
function editPayee(){
	$("#payee_edit").hide();
	$("#payee_cancel").show();
	$("#vendorBankName").attr("readonly",false);
	$("#vendorBankName").removeClass("disabled");
	$("#vendorBankName").select();
	$("#addPayee").val("add");
}

/**
 * 绑定填充账号操作
 */
function bindBankList(){
	$("input[id^=vb]").unbind("click");
	$("input[id^=vb]").bind("click",function(){
		$("input[id^=vb]").attr("checked",false);
		$("#bankAccount").val($(this).attr("account"));
		$("#bankName").val($(this).attr("bank"));
		$(this).attr("checked",true);
		return ;
	});
}

/**
 * 计算入库单总金额
 */
function calculateSum(){  
	var $amount = 0;
	$("#purchaseUL").find("input[checked=true]").each(function(index, element) {
		var num =Number($(this).attr("data-amount")); //偶尔会有负数
		$amount =add($amount,num);
	}); 
	$("#purchasePrice").val(changeTwoDecimal($amount));
}

/**
 * 币种点击
 */
function currencyClick(){
	$("input[name='payment.currency']").bind("click",function(){
		$("input[name='payment.currency']").attr("checked",false);
		$("input[name='payment.currencyId']").val($(this).attr("curId"));
		$(this).attr("checked",true);
		return;
	});
}

/**
 * 添加新账号
 */
function addAccount(){
	var vendorId = $("#vendorId").val()+"";
	if(""==vendorId||"undefined"==vendorId){
		dialog("请选择供应商！","unsuccess",true,2);
		return ;
	}
	var bank = $("#bankName_add").val();
	if(""==bank||"undefined"==bank){
		dialog("请输入开户行！","unsuccess",true,2);
		return ;
	}
	var account = $("#bankAccount_add").val()+"";
	if(""==account||"undefined"==account){
		dialog("请输入账号！","unsuccess",true,2);
		return ;
	}
	$.ajax({
        type:"GET",
        url:encodeURI("/approval/payment_addBank"),
        dataType:"json",
        data:{"vendorBank.vendorId":vendorId,"vendorBank.bank":bank,"vendorBank.account":account},
        success:function(returnStr){
        	if(returnStr == "0"){
        		var n = $("#optionsList li").length+1;
        		var listr = "<li class='clearfix'><label for='vb'"+n+"><input type='radio' bank='"+bank+"' account='"+account+"' id='vb"+n+"' value='' /><span class='abank'>"
        		+bank+"</span><span class='account'>"+account+"</span> </label></li>";
        		$("#optionsList").append(listr);
        		$("#accountDiv").show();
        		bindBankList();//绑定填充账号操作
        	}else{
        		dialog(returnStr,"unsuccess",true,2);
        	}
        }
    });
}

/**
 * @param 小写转大写
 */
function lowToUpper(num){
	if(!/^\d*(\.\d*)?$/.test(num)){
		
	}else{
		var UPPER = new Array("零","壹","贰","叁","肆","伍","陆","柒","捌","玖");
		var num_array = ("" + num).split(".");
		var defStr="零";
		/*小数位*/
		if(num_array[1] != null && num_array[1].length > 0){
			if(num_array[1].length < 2){
				$("#jiao").text(UPPER[num_array[1].charAt(0)]);
				$("#fen").text(defStr);
			}else{
				$("#jiao").text(UPPER[num_array[1].charAt(0)]);
				$("#fen").text(UPPER[num_array[1].charAt(1)]);
			}
		}else{
			$("#jiao").text(defStr);
			$("#fen").text(defStr);
		}
		/*整数位*/
		if(num_array[0] != null && num_array[0].length > 0){
			var intstr = "";
			if(num_array[0].length < 8){
				var temp = "";
				for(var i=0; i < 8 - num_array[0].length; i++){
					temp = temp + "0";
				}
				intstr = temp + num_array[0];
			}else{
				intstr = num_array[0].substring(num_array[0].length - 8);
			}
			$("#qianwan").text(UPPER[intstr.charAt(0)]);
			$("#baiwan").text(UPPER[intstr.charAt(1)]);
			$("#shiwan").text(UPPER[intstr.charAt(2)]);
			$("#wan").text(UPPER[intstr.charAt(3)]);
			$("#qian").text(UPPER[intstr.charAt(4)]);
			$("#bai").text(UPPER[intstr.charAt(5)]);
			$("#shi").text(UPPER[intstr.charAt(6)]);
			$("#ge").text(UPPER[intstr.charAt(7)]);
		}else{
			$("#qianwan").text(defStr);
			$("#baiwan").text(defStr);
			$("#shiwan").text(defStr);
			$("#wan").text(defStr);
			$("#qian").text(defStr);
			$("#bai").text(defStr);
			$("#shi").text(defStr);
			$("#ge").text(defStr);
		}
		
	}
}

/**
 * 根据币种名称获得币种符号
 * @param currencyName
 * @returns {String}
 */
function getCurrencyFlag(currencyName){
	var flag = "";
	if(null == currencyName || "" == currencyName || "undefined" == currencyName){
		flag = "¥";
	}else{
		if(currencyName == "人民币"){
			flag = "¥";
		}else if(currencyName == "美元"){
			flag = "$";
		}else if(currencyName == "港元"||currencyName == "港币"){
			flag = "HK$";
		}else if(currencyName == "欧元"){
			flag = "€";
		}else if(currencyName == "日元"){
			flag = "¥";
		}else if(currencyName == "澳元"){
			flag = "AU$";
		}else{
			flag = "¥";
		}
	}
	return flag;
}

/**
 * 查询入库单号
 * @returns {Boolean}
 */
function recordCodes(){ 
	var startDate = $.trim($("#datetime1").val()).substr(0,10);
	var endDate =  $.trim($("#datetime2").val()).substr(0,10);
	var ledger = $.trim($("#ledger").val());
	var vendorCode = $.trim($("#vendorCode").val());
	if(startDate==''||endDate==''||ledger==''||vendorCode==''){
		return false;
	}
	//查询样式改变
	$("#waitDisable").addClass("disabled");
	$("#numSpan").text("正在加载...");
	$("#waitSpan").show();
	
	var buId = $("#buId").val();		//判断产品线是多选还是单选
	if(buId != 1 && buId != 8){  //产品线单选
		var inventoryClass = $.trim($("#inventoryClass").val()); 
		inventoryClass = changeAtmel(inventoryClass);
		findRecordCodeList(startDate,endDate,ledger,vendorCode,"'"+inventoryClass+"'");
	}else{ //产品线多选
		var inventoryClassStr = "";
		var num= $("#productLineForSelect").find("input[checked=true]").size();
		for(var i=0;i<num;i++){
			var pl = $("#productLineForSelect").find("input[checked=true]").eq(i);
			pl = changeAtmel(pl);
			if(i==num-1){
				inventoryClassStr = inventoryClassStr + "'"+pl.attr("plName")+"'" ;
			}else{
				inventoryClassStr = inventoryClassStr +"'"+ pl.attr("plName")+"'," ;
			}
		}
		findRecordCodeList(startDate,endDate,ledger,vendorCode,inventoryClassStr);
	}  
}

/**
 * 特殊处理Atmel产品线
 * @param inventoryClass
 * @returns
 */
function changeAtmel(inventoryClass){
	if(inventoryClass == 'Atmel（NC）' ||inventoryClass == 'Atmel（SC）'){
		inventoryClass ='Atmel';
	}
	return inventoryClass;
}

/**
 * 根据条件查询入库单
 * @param startDate
 * @param endDate
 * @param ledger
 * @param vendorCode
 * @param inventoryClass
 */
function findRecordCodeList(startDate,endDate,ledger,vendorCode,inventoryClass){
	if(startDate != null && endDate != null && ledger != null && vendorCode!= null && inventoryClass !=null){
		$.ajax({
	        type:"GET",
	        url:encodeURI("/approvalajax/payment_findRecordCodeList?ledger="+ledger+"&startDate="+startDate+"&endDate="+endDate+"&vendorCode="+vendorCode+"&inventoryClass="+inventoryClass),
	        dataType:"json",
	        success:function(data, textStatus){
	            if(data != null){
	            	//清空入库单
	            	$("#purchaseUL").empty();
	            	$("#purchasePrice").val("");
	            	$("#selectPurchaseAll").attr("checked",false);
	            	var recordCodeList = data.recordCodeList;
	            	for(var i=0;i<recordCodeList.length;i++){
	            		var recordCode = recordCodeList[i];
		            	$copyLi = $("#purchaseCopy").clone(true);
		            	$copyLi.attr("id","");
		            	$copyLi.find("input").attr("data-amount",recordCode.sum).val(recordCode.recordCode);
		            	$copyLi.find("span").attr("title",recordCode.recordCode).text(recordCode.recordCode);
		            	$copyLi.find("input").bind("click",function(){
		            		checkboxBind();
		            	});
		            	$copyLi.show();
		            	$("#purchaseUL").append($copyLi);
	            	}
	            	//查询样式改变
	            	$("#waitDisable").removeClass("disabled");
	            	if(recordCodeList.length>0){
	            		$("#numSpan").text("请选择");
	            	}else{
	            		$("#numSpan").text("没有相关入库单");
	            	}
	            	$("#waitSpan").hide();
	            }
	        }
	    });
	} 
}

/**
 * 给入库单的 checkbox绑定click事件:决定全选是否勾上，计算和；"共选择XX个"样式那边控制
 */
function checkboxBind(){
	var isAll = true ;
	$(".purchase-receipt-select .options-item input:checkbox").each(function(index, element) {
		if(!$(this).attr("checked")){
			isAll = false;
		}
		$("#selectPurchaseAll").attr("checked",isAll);
	});
	calculateSum();
}

/**
 * 获取邮件列表
 */
function getEmailList(){
	/*BU*/
	var buId = $("#buId").val();
	/*付款类型*/
	var accountType = $('input[name="payment.accountType"]:checked').val();
	/*单条产品线*/
	var productLine = $("#inventoryClass").val();
	var url = "/approval/payment_showConfirmMail?payment.bussinessUnitId="+buId;
	if((typeof(accountType) != 'undefined') && (accountType.length > 0)){
		url +="&payment.accountType="+accountType;
	}
	if((typeof(productLine) != 'undefined') && (productLine.length > 0)){
		url +="&productLines="+productLine;
	}
	$("input[name='productLines']").each(function(){
		if($(this).attr("checked")){
			var pl = $(this).val().split(":")[1];
			url+="&productLines="+pl;
		}
	});
	if($("#supplyChainFinance:checked").length > 0){
		url = url + "&payment.supplyChainFinance="+$("#supplyChainFinance").val();
	}
	if($("#supplyChainFinance1:checked").length > 0){
		url = url + "&payment.supplyChainFinance="+$("#supplyChainFinance1").val();
	}
	$("#mailList").load(encodeURI(url));
}