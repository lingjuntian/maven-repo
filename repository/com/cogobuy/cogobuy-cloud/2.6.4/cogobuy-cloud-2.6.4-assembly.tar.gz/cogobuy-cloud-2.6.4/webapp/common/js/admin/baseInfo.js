//与客户相关的开始
/**查找客户**/
function findCustomerList(event){
	var ledger = $("#ledgerSelect").text();
	var customerName = $("#customerName").val();
	var findFor = $("#findFor").val();//例如：createCustomer
	var url='/admin/baseInfo_findCustomerList?pageSize=6';
	if(customerName!=null){
		url+='&customerName='+customerName;
	}
	if(ledger!=null){
		url+='&ledger='+ledger;
	}
	if(findFor!=null){
		url+='&findFor='+findFor;
	}
	showlayer(event,'选择客户',null,null,500,null
	,url,false);
}

 /**Layer框中查询客户**/
function findCustomerListLayer(pageNo,pageSize){
        var url="/admin/baseInfo_findCustomerList?";
        url+="customerName="+$.trim($("#customerNameLayer").val());
        url+="&ledger="+$.trim($("#ledger").val());
        url+="&pageSize="+8;
        $("#queryList").load(encodeURI(url));
}

/**Layer框中分页查询客户**/
function findCustomerPaging(pageNo,pageSize){
        var url="/admin/baseInfo_findCustomerList?";
        url+="customerName="+$.trim($("#customerNameLayer").val());
        url+="&ledger="+$.trim($("#ledger").val());
        url+="&pageNo="+pageNo;
        url+="&pageSize="+pageSize;
        $("#queryList").load(encodeURI(url));
}

//与业务员相关的开始
/*
查找业务员
*/
function findPersonList(event){
	var departmentName = $("#departmentName").val();
	var personName= $("#personName").val();
	var findFor = $("#findFor").val();//例如：createCustomer
	var url='/admin/baseInfo_findPersonList?pageSize=6';
	if(personName!=null){
		url+='&personName='+personName;
	}
	if(departmentName!=null){
		url+='&departmentName='+departmentName;
	}
	if(findFor!=null){
		url+='&findFor='+findFor;
	}
	showlayer(event,'选择订单的业务员及部门',null,null,500,null,url,false);
}

/**查询业务员**/
 function findPersonListLayer(){
       var url="/admin/baseInfo_findPersonList?";
       url+="departmentName="+$.trim($("#departmentNameLayer").val());
       url+="&personName="+$.trim($("#personNameLayer").val());
       url+="&pageSize="+8;
       $("#queryList").load(encodeURI(url));
 }
/**查询业务员分页**/
function findPersonListPaging(pageNo,pageSize){
        var url="/admin/baseInfo_findPersonList?";
       	url+="departmentName="+$.trim($("#departmentNameLayer").val());
       	url+="&personName="+$.trim($("#personNameLayer").val());
        url+="&pageNo="+pageNo;
        url+="&pageSize="+pageSize;
        $("#queryList").load(encodeURI(url));
}
