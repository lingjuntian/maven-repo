$(function() {
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
		
		if(error){
			var isChange = false;
			if($("input[tdTag=reasons]").val()!=""){
				isChange = true;
			}else{
				$("#detailListTbody").find("input[tdTag=reason]").each(function(){
					if($(this).val()!=""){
						isChange = true;
						return;
					}
				});
			}
			if(isChange){//当修改时
					countData(); /* 统计数量、金额合计等 */
					writeCloseReasons();/*整单关闭时，将原因写入每个detail的原因中*/
					copyValueToConfig();/* 将新建页面的数值写入确认页面 */
					getEmailList();/* 获取邮件发送列表 */
					switchPageForCreate();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
					copyFileList();/*上传附件公用*/
			}else{
				dialog("您并没有进行修改","unsuccess",true,2);
			}
		}
		

	});
	/* 点击上一步 */
	$("#previous").click(function() {
		switchPageForConfirm();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#salesOrderForm").append(inputStr);
    		}
    	});
		
    	$("#submit").hide();
		$("#salesOrderForm").ajaxSubmit(function(returnStr) {
			if(returnStr == "error"){
				$("#submit").show();
				dialog("修改失败，请稍后再试","unsuccess",true,1);
			}else{
				var type = returnStr.split("_")[0];
				var id = returnStr.split("_")[1];
				if (type == "success") {
					dialog("修改成功","success",true,1);
					setTimeout(function(){window.location = "/approval/changeOrder_show?salesOrderChange.id="+id;},1000);	  
				}
			}
	        return false;
		});
	});
});

function writeCloseReasons(){
	if(!$("[data-name=closeOrder]").hasClass("closeOrder-text")){
		var reasons = $("[tdTag=reasons]").val();
		var $trs = $("#detailListTbody").find("tr");
		for ( var i = 0; i < $trs.size(); i++) {
			var $tr = $trs.eq(i);
			$tr.find("[tdTag=reason]").val(reasons);
		}
	}
}

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	//cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#salesOrderForm").validationEngine('validate');
}

/*判断是否只需要PM审批即可*/
function isOnlyPmApproval(){
	var ret = true;
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
	
		//是否是新增型号
		if($tr.find("[tdTag=isNewRow]").val()==1){
			ret=false;
			return ret;
		}
		
		if($tr.find("[tdTag=closed]").val() != $("#closeStatus").val()){/*2，关闭*/
			//是否是新增行
			if($tr.find("[tdTag=isAdd]").val()==1){
				ret=false;
				return ret;
			}
			
			//是否修改在途数量
			if($tr.find("[tdTag=restQuantity]").val()!=$tr.find("[tdTag=restQuantityCopy]").val()){
				ret=false;
				return ret;
			}
			//是否修改单价
			if($tr.find("[tdTag=taxUnitPrice]").val()!=$tr.find("[tdTag=changeTaxUnitPrice]").val()){
				ret=false;
				return ret;
			}
		}
	}
	return ret;
}

/* 获取邮件发送列表 */
function getEmailList() {

	var personEmail = $("#personEmail").val();
	var url = "/approval/changeOrder_showConfirmMail?salesOrderChange.personEmail="+personEmail;
	$("input[tdTag=pm]").val("");
	if(isOnlyPmApproval()){//如果只需要PM审批，则赋该字段为Yes
		$("input[tdTag=pm]").val("Yes");
		url=url+"&salesOrderChange.pm=Yes";
	}
	var isUpdate=0;//判断是否修改
	$("#detailListTbody").find("input[tdTag=productLineName]").each(function(){
		if( $(this).parents("tr").find("input[tdTag=changeType]").val()!=""){
			url+="&productLines="+$(this).val();
			isUpdate=1;
		}
		
	});
	//alert(url);
	/*
	if($("#supplyChainFinance:checked").length > 0){
		url = url + "&salesOrder.supplyChainFinance="+$("#supplyChainFinance").val();
	}*/
	if(isUpdate==1){//修改了才进行以下操作
		$("#mailList").load(encodeURI(url));
	}else{//没有修改提示
		dialog("您并没有进行修改","unsuccess",true,2);
	}

}


/* 统计数量、金额合计等 */
function countData() {
	/* 总数量 */
	var totalQuantity = 0;
	/* 含税总额 */
	var totalTaxSum = 0;
	/* 无税总额 */
	var totalSum = 0;
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		calTaxSum($tr);
		totalQuantity = add(totalQuantity, changeNum($tr.find("input[tdTag=quantity]").val()));
		totalTaxSum = add(totalTaxSum, changeNum($tr.find("input[tdTag=taxSum]").val()));
		totalSum = add(totalSum, changeNum($tr.find("input[tdTag=sum]").val()));
	}
	$("#totalQuantity").val(changeTwoDecimal(totalQuantity));
	$("#totalTaxSum").val(changeFourDecimal(totalTaxSum));
	$("#totalSum").val(changeFourDecimal(totalSum));
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*######################详情列表BEGIN*/
	/*详情*/
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		if($tr.find("input[tdTag=changeClosed]").val()!=1){
			
		//这行是否做了修改，没有修改，则不用显示
		var isUpdate = 0;
		//变更类型
		var changeType = "";
		
		/*1，新增行*/
		var red_tr = "";
		
		/*2，关闭*/
		var closeStr = "";
		
		/*3，型号替换*/
		
		/*4，内容修改*/
		//是否修改在途数量
		var oldRestQuantity = "";
		var red_RestQuantity = "";
		//是否修改单价
		var oldTaxUnitPrice = "";
		var oldUnitPrice = "";
		var red_Price = "";
		//是否修改总价
		var oldTaxSum = "";
		var red_TaxSum = "";
		//是否修改交期
		var oldExpectDate = ""
		var red_expectDate = "";
		
		var borderStr = "";
		if($tr.next().find("[tdTag=isAdd]").val()==1){
			borderStr = " tr-style";
		}
		if($tr.find("[tdTag=isNewRow]").val()==1){
			isUpdate=1;
			changeType="新增型号";
			red_tr=" style=\"color:red\"";
				
		}else if($tr.find("[tdTag=isAdd]").val()==1){/*1，新增行*/
			isUpdate=1;
			changeType="新增行";
			red_tr = " style=\"color:red\"";
			//去掉行上方的border
			
		}else if($tr.find("[tdTag=closed]").val() == $("#closeStatus").val()){/*2，关闭*/
			isUpdate=1;
			changeType="关闭";
			closeStr = "order-close";
		}else if($tr.find("[tdTag=inventoryCode]").val() != $tr.find("[tdTag=changeInventoryCode]").val()){/*3，型号替换*/
			isUpdate=1;
			changeType="新替换";
			red_tr = " style=\"color:red\"";
			
		}else{/*4，内容修改*/
			//是否修改在途数量
			if($tr.find("[tdTag=restQuantity]").val()!=$tr.find("[tdTag=restQuantityCopy]").val()){
				isUpdate=1;
				oldRestQuantity = "<span style=\"text-decoration:line-through;color:gray\">"+fmoney(changeNum($tr.find("[tdTag=restQuantityCopy]").val()),0)+"</span>&nbsp;&nbsp;&nbsp;";
				red_RestQuantity = "style=\"color:red\"";
			}
			//是否修改单价
			if($tr.find("[tdTag=taxUnitPrice]").val()!=$tr.find("[tdTag=changeTaxUnitPrice]").val()){
				isUpdate=1;
				oldTaxUnitPrice = "<span style=\"text-decoration:line-through;color:gray\">"+fmoney(changeNum($tr.find("[tdTag=changeTaxUnitPrice]").val()),6)+"</span>&nbsp;&nbsp;&nbsp;";
				oldUnitPrice = "<span style=\"text-decoration:line-through;color:gray\">"+fmoney(changeNum($tr.find("[tdTag=changeUnitPrice]").val()),6)+"</span>&nbsp;&nbsp;&nbsp;";
				red_Price = "style=\"color:red\"";
			}
			//是否修改总价
			if($tr.find("[tdTag=taxSum]").val()!=$tr.find("[tdTag=changeTaxSum]").val()){
				isUpdate=1;
				oldTaxSum = "<span style=\"text-decoration:line-through;color:gray\">"+fmoney(changeNum($tr.find("[tdTag=changeTaxSum]").val()),4)+"</span>&nbsp;&nbsp;&nbsp;";
				red_TaxSum = "style=\"color:red\"";
			}
			//是否修改交期
			if($tr.find("[tdTag=expectDate]").val()!=$tr.find("[tdTag=changeExpectDate]").val()){
				isUpdate=1;
				oldExpectDate = "<span style=\"text-decoration:line-through;color:gray\">"+$tr.find("[tdTag=changeExpectDate]").val()+"</span>&nbsp;&nbsp;&nbsp;";
				red_expectDate = "style=\"color:red\"";
			}
			
			if(isUpdate==1){//如果是被拆的行，则不显示内容变更，显示拆行
				if($tr.next().find("[tdTag=isAdd]").val()==1){
					changeType="拆行";
				}else{
					changeType="内容变更";
				}
			}else{//如果没有变更，但是属于被拆的行，也要显示
				if($tr.find("[tdTag=rowNo]").val()==$tr.next().find("[tdTag=rowNo]").val()){
					isUpdate=1;
					changeType="拆行";
				}
			}
		}
						
		if(changeType=="新替换"){
			var trString = "<tr class=\"order-close tr-style\" title=\"关闭\">" 
		 	+ "<td class=\"first num\" style=\"text-decoration:none\"><div>"+"型号替换"+"</div></td>"
			+ "<td class=\"supplier-model\"><div>"+$tr.find("input[tdTag=changeInventoryCode]").val()+"</div></td>"
			+ "<td class=\"quantity\"><div>"+oldRestQuantity+"<span "+red_RestQuantity+">"+fmoney(changeNum($tr.find("input[tdTag=restQuantityCopy]").val()),0)+"</span>"+"</div></td>"
			+ "<td class=\"price price0\"><div>"+oldTaxUnitPrice+"<span "+red_Price+">"+fmoney(changeNum($tr.find("input[tdTag=changeTaxUnitPrice]").val()),6)+"</span>"+"</div></td>"
			+ "<td class=\"price price1\"><div>"+oldUnitPrice+"<span "+red_Price+">"+fmoney(changeNum($tr.find("input[tdTag=changeUnitPrice]").val()),6)+"</span>"+"</div></td>"
			+ "<td class=\"price price2\"><div>"+oldTaxSum+"<span "+red_TaxSum+">"+fmoney(changeNum($tr.find("input[tdTag=changeTaxSum]").val()),4)+"</span>"+"</div></td>"
			+ "<td class=\"last time\"><div>"+oldExpectDate+"<span "+red_expectDate+">"+$tr.find("input[tdTag=changeExpectDate]").val()+"</span>"+"</div></td>"
			+ "<td class=\"last time\" style=\"text-decoration:none\"><div>"+"</div></td></tr>";
			
			$("#detailListTbody_confirm").append(trString);
		}
		
		if(isUpdate==1){
			
			//存入数据库的changeType
			$tr.find("[tdTag=changeType]").val(changeType);
			
			var trString = "<tr class=\""+closeStr+borderStr+"\""+red_tr+">" 
		 	+ "<td class=\"first num\" style=\"text-decoration:none\"><div>"+changeType+"</div></td>"
			+ "<td class=\"supplier-model\"><div>"+$tr.find("input[tdTag=inventoryCode]").val()+"</div></td>"
			+ "<td class=\"quantity\"><div>"+oldRestQuantity+"<span "+red_RestQuantity+">"+fmoney(changeNum($tr.find("input[tdTag=restQuantity]").val()),0)+"</span>"+"</div></td>"
			+ "<td class=\"price price0\"><div>"+oldTaxUnitPrice+"<span "+red_Price+">"+fmoney(changeNum($tr.find("input[tdTag=taxUnitPrice]").val()),6)+"</span>"+"</div></td>"
			+ "<td class=\"price price1\"><div>"+oldUnitPrice+"<span "+red_Price+">"+fmoney(changeNum($tr.find("input[tdTag=unitPrice]").val()),6)+"</span>"+"</div></td>"
			+ "<td class=\"price price2\"><div>"+oldTaxSum+"<span "+red_TaxSum+">"+fmoney(changeNum($tr.find("input[tdTag=taxSum]").val()),4)+"</span>"+"</div></td>"
			+ "<td class=\"last time\"><div>"+oldExpectDate+"<span "+red_expectDate+">"+$tr.find("input[tdTag=expectDate]").val()+"</span>"+"</div></td>"
			+ "<td class=\"last time\" style=\"text-decoration:none\"><div>"+$tr.find("input[tdTag=reason]").val()+"</div></td></tr>";
			
			$("#detailListTbody_confirm").append(trString);
		}
		
	}
	/*合计行
	var totalString = "<tr class=\"total\"><td class=\"first num\"><div></div></td><td class=\"supplier-model\"><div></div></td>"
			+ "<td class=\"material-number\"><div></div></td>"
			+ "<td class=\"product-desc\"><div></div></td>"
			+ "<td class=\"euc-number\"><div></div></td>"
			+ "<td class=\"license-number\"><div>总计：</div></td>"
			+ "<td class=\"quantity\"><div>"+fmoney($("#totalQuantity").val(),0)+"</div></td>"
			+ "<td class=\"price price0\"><div></div></td>"
			+ "<td class=\"price price1\"><div></div></td>"
			+ "<td class=\"price price2\"><div>"+fmoney($("#totalTaxSum").val(),4)+"</div></td>"
			+ "<td class=\"eccn-number\"><div></div></td>"
			+ "<td class=\"mpq\"><div></div></td>"
			+ "<td class=\"last time\"><div></div></td></tr>";
	$("#detailListTbody_confirm").append(totalString);*/
	/*######################详情列表END*/
	}
	$("#remark_confirm").text($("#remark").val());
}

/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
function switchPageForCreate() {
	
	var $trs=$("#detailListTbody_confirm").find("tr");
	if($trs.size()>0){//判断是否有值
		$("#write").hide();
		$("#confirm").show();
	}else{
		dialog("您并没有进行修改","unsuccess",true,2);
	}
	
	return false;
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").hide();
	$("#write").show();
}