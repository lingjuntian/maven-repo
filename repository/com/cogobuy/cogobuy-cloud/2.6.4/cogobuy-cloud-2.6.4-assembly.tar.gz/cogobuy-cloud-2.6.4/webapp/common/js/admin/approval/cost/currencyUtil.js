/* 根据币种名称转换为标识 */
function getCurrencyFlag(currencyName) {
	var flag = "";
	if (null == currencyName || "" == currencyName
			|| "undefined" == currencyName) {
		flag = "¥";
	} else {
		if (currencyName == "人民币") {
			flag = "¥";
		} else if (currencyName == "美元") {
			flag = "$";
		} else if (currencyName == "港元" || currencyName == "港币") {
			flag = "HK$";
		} else if (currencyName == "欧元") {
			flag = "€";
		} else if (currencyName == "日元") {
			flag = "¥";
		} else if (currencyName == "澳元") {
			flag = "AU$";
		} else if (currencyName == "台币") {
			flag = "TWD";
		} else {
			flag = "¥";
		}
	}
	return flag;
}

/* 金额小写转成大写 */
function lowToUpper(num) {
	if (!/^\d*(\.\d*)?$/.test(num)) {

	} else {
		var UPPER = new Array("零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖");
		var num_array = ("" + num).split(".");
		var defStr = "零";
		/* 小数位 */
		if (num_array[1] != null && num_array[1].length > 0) {
			if (num_array[1].length < 2) {
				$("#jiao").text(UPPER[num_array[1].charAt(0)]);
				$("#fen").text(defStr);
			} else {
				$("#jiao").text(UPPER[num_array[1].charAt(0)]);
				$("#fen").text(UPPER[num_array[1].charAt(1)]);
			}
		} else {
			$("#jiao").text(defStr);
			$("#fen").text(defStr);
		}
		/* 整数位 */
		if (num_array[0] != null && num_array[0].length > 0) {
			var intstr = "";
			if (num_array[0].length < 7) {
				var temp = "";
				for ( var i = 0; i < 7 - num_array[0].length; i++) {
					temp = temp + "0";
				}
				intstr = temp + num_array[0];
			} else {
				intstr = num_array[0].substring(num_array[0].length - 7);
			}
			$("#baiwan").text(UPPER[intstr.charAt(0)]);
			$("#shiwan").text(UPPER[intstr.charAt(1)]);
			$("#wan").text(UPPER[intstr.charAt(2)]);
			$("#qian").text(UPPER[intstr.charAt(3)]);
			$("#bai").text(UPPER[intstr.charAt(4)]);
			$("#shi").text(UPPER[intstr.charAt(5)]);
			$("#ge").text(UPPER[intstr.charAt(6)]);
		} else {
			$("#baiwan").text(defStr);
			$("#shiwan").text(defStr);
			$("#wan").text(defStr);
			$("#qian").text(defStr);
			$("#bai").text(defStr);
			$("#shi").text(defStr);
			$("#ge").text(defStr);
		}

	}
}