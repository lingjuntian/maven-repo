$(function() {
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
		
//		if (error) {
//			countData(); /* 统计数量、金额合计等 */
//			copyValueToConfig();/* 将新建页面的数值写入确认页面 */
//			isApproval();
//			if($("[tdTag=isApproval]").val()=="Y"){
//				getEmailList();/* 获取邮件发送列表 */
//			}	
//			switchPageForCreate();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
//			copyFileList();/*上传附件公用*/
//		}
		
		if(error){
			var isChange = false;
			$("#detailListTbody").find("input[tdTag=reason]").each(function(){
				if($(this).val()!=""){
					isChange = true;
					return;
				}
			});
			
			var isSameErpPoNo = true;
			var erpPoNo="";
			$("#detailListTbody").find("input[tdTag=reason]").each(function(){
				if($(this).val()!=""){
					if(erpPoNo==""){
						erpPoNo=$(this).parents("tr").find("input[tdTag=erpPoNo]").val();
					}else{
						if(erpPoNo!=$(this).parents("tr").find("input[tdTag=erpPoNo]").val()){
							isSameErpPoNo=false;
							return;
						}
					}
				}
			});
			
			if(isChange){//当修改时
					if(isSameErpPoNo){
						countData(); /* 统计数量、金额合计等 */
						copyValueToConfig();/* 将新建页面的数值写入确认页面 */
						getApprovalType();/*获取获取审批流类型*/
						getEmailList();/* 获取邮件发送列表 */
						switchPageForCreate();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
						copyFileList();/*上传附件公用*/
					}else{
						dialog("你变更了多张ERP采购订单的内容，请一次变更一张PR单采购订单的信息！","unsuccess",true,2);
					}
			}else{
				dialog("您并没有进行修改","unsuccess",true,2);
			}
		}
		
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		switchPageForConfirm();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#prForm").append(inputStr);
    		}
    	});
    	$("#submit").hide();
		$("#prForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/prChangeApproval_show?prChangeMain.id="+id;},1000);	  
			}else{
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
	});
});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#prForm").validationEngine('validate');
}

/* 统计数量、金额合计等 */
function countData() {
	/* 无税总额 */
	var totalSum = 0;
	var totalQuantity = 0;
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		totalSum = add(totalSum, changeNum($tr.find("input[tdTag=sum]").val()));
		totalQuantity = add(totalQuantity,changeNum($tr.find("input[tdTag=quantity]").val()));
	}
	$("#totalSum").val(changeFourDecimal(totalSum));
	$("#totalQuantity").val(totalQuantity);
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*######################详情列表BEGIN*/
	/*详情*/
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		$("#plname").val($tr.find("input[tdTag=productLineName]").val());//查邮件列表的时候需要传产品线过去
		if($tr.find("input[tdTag=changeClosed]").val()!=1){
			
		//这行是否做了修改，没有修改，则不用显示
		var isUpdate = 0;
		//变更类型
		var changeType = "";
		
		/*1，新增行*/
		var red_tr = "";
		
		/*2，关闭*/
		var closeStr = "";
		
		/*3，型号替换*/
		
		/*4，内容修改*/
		//是否修改套片
		var oldInventorySpecfName = "";
		var red_inventorySpecfName = "";
		//是否修改SlCode
		var oldSlCode = "";
		var red_slCode = ""
		//是否修改在途数量
		var oldRestQuantity = "";
		var red_RestQuantity = "";
		//是否修改含税单价
		var oldTaxUnitPrice = "";
		var red_taxUnitPrice = "";
		//是否修改无税单价
		var oldUnitPrice = "";
		var red_unitPrice = "";
		//是否修改总价
		var oldSum = "";
		var red_sum = "";
		//是否修改Quote
		var oldQuote = "";
		var red_quote = "";
		//是否修改交期
		var oldExpectDate = ""
		var red_expectDate = "";
		
		var borderStr = "";
		if($tr.next().find("[tdTag=isAdd]").val()==1){
			borderStr = " tr-style";
		}

		if($tr.find("[tdTag=isAdd]").val()==1){/*1，新增行*/
			isUpdate=1;
			changeType="新增行";
			red_tr = " style=\"color:red\"";
			//去掉行上方的border
			
		}else if($tr.find("[tdTag=closed]").val() == $("#closeStatus").val()){/*2，关闭*/
			isUpdate=1;
			changeType="关闭";
			closeStr = "order-close";
		}else if($tr.find("[tdTag=inventoryCode]").val() != $tr.find("[tdTag=changeInventoryCode]").val()){/*3，型号替换*/
			isUpdate=1;
			changeType="新替换";
			red_tr = " style=\"color:red\"";
			
		}else{/*4，内容修改*/
			//是否修改套片
			if($tr.find("[tdTag=inventorySpecfName]").val()!=$tr.find("[tdTag=changeInventorySpecfName]").val()){
				isUpdate=1;
				oldInventorySpecfName = "<span style=\"text-decoration:line-through;color:gray\">"+$tr.find("[tdTag=changeInventorySpecfName]").val()+"</span>&nbsp;&nbsp;&nbsp;";
				red_inventorySpecfName = "style=\"color:red\"";
			}
			//是否修改SlCode
			if($tr.find("[tdTag=slCode]").val()!=$tr.find("[tdTag=changeSlCode]").val()){
				isUpdate=1;
				oldSlCode = "<span style=\"text-decoration:line-through;color:gray\">"+$tr.find("[tdTag=changeSlCode]").val()+"</span>&nbsp;&nbsp;&nbsp;";
				red_slCode = "style=\"color:red\"";
			}
			//是否修改在途数量
			if($tr.find("[tdTag=restQuantity]").val()!=$tr.find("[tdTag=changeRestQuantity]").val()){
				isUpdate=1;
				oldRestQuantity = "<span style=\"text-decoration:line-through;color:gray\">"+fmoney(changeNum($tr.find("[tdTag=changeRestQuantity]").val()),0)+"</span>&nbsp;&nbsp;&nbsp;";
				red_RestQuantity = "style=\"color:red\"";
				red_sum = "style=\"color:red\"";
			}
			//是否修改含税单价
			if($tr.find("[tdTag=taxUnitPrice]").val()!=$tr.find("[tdTag=changeTaxUnitPrice]").val()){
				isUpdate=1;
				oldTaxUnitPrice = "<span style=\"text-decoration:line-through;color:gray\">"+fmoney(changeNum($tr.find("[tdTag=changeTaxUnitPrice]").val()),6)+"</span>&nbsp;&nbsp;&nbsp;";
				red_taxUnitPrice = "style=\"color:red\"";
				red_sum = "style=\"color:red\"";
			}
			//是否修改无税单价
			if($tr.find("[tdTag=unitPrice]").val()!=$tr.find("[tdTag=changeUnitPrice]").val()){
				isUpdate=1;
				oldUnitPrice = "<span style=\"text-decoration:line-through;color:gray\">"+fmoney(changeNum($tr.find("[tdTag=changeUnitPrice]").val()),6)+"</span>&nbsp;&nbsp;&nbsp;";
				red_unitPrice = "style=\"color:red\"";
				red_sum = "style=\"color:red\"";
			}
			//是否修改quote
			if($tr.find("[tdTag=quote]").val()!=$tr.find("[tdTag=changeQuote]").val()){
				isUpdate=1;
				oldQuote = "<span style=\"text-decoration:line-through;color:gray\">"+$tr.find("[tdTag=changeQuote]").val()+"</span>&nbsp;&nbsp;&nbsp;";
				red_quote = "style=\"color:red\"";
			}
			//是否修改交期
			if($tr.find("[tdTag=expectDate]").val()!=$tr.find("[tdTag=changeExpectDate]").val()){
				isUpdate=1;
				oldExpectDate = "<span style=\"text-decoration:line-through;color:gray\">"+$tr.find("[tdTag=changeExpectDate]").val()+"</span>&nbsp;&nbsp;&nbsp;";
				red_expectDate = "style=\"color:red\"";
			}

			if(isUpdate==1){//如果是被拆的行，则不显示内容变更，显示拆行
				if($tr.next().find("[tdTag=isAdd]").val()==1){
					changeType="拆行";
				}else{
					changeType="内容变更";
				}
			}else{//如果没有变更，但是属于被拆的行，也要显示
				if($tr.find("[tdTag=rowNo]").val()==$tr.next().find("[tdTag=rowNo]").val()){
					isUpdate=1;
					changeType="拆行";
				}
			}
		}
		
		if(changeType=="新替换"){
			var trString = "<tr class=\"order-close tr-style\" title=\"关闭\">" 
		 	+ "<td class=\"first num\" style=\"text-decoration:none\"><div>"+"型号替换"+"</div></td>"
			+ "<td class=\"supplier-model\"><div>"+$tr.find("input[tdTag=changeInventoryCode]").val()+"</div></td>"//型号
			+ "<td class=\"last time\"><div>"+oldInventorySpecfName+"<span "+red_inventorySpecfName+">"+$tr.find("input[tdTag=changeInventorySpecfName]").val()+"</span>"+"</div></td>"//套片
			+ "<td class=\"last time\"><div>"+oldSlCode+"<span "+red_slCode+">"+$tr.find("input[tdTag=changeSlCode]").val()+"</span>"+"</div></td>"//SL Code
			+ "<td class=\"quantity\"><div>"+oldRestQuantity+"<span "+red_RestQuantity+">"+fmoney(changeNum($tr.find("input[tdTag=changeRestQuantity]").val()),0)+"</span>"+"</div></td>"//在途数量
			+ "<td class=\"price price0\"><div>"+oldTaxUnitPrice+"<span "+red_taxUnitPrice+">"+fmoney(changeNum($tr.find("input[tdTag=changeTaxUnitPrice]").val()),6)+"</span>"+"</div></td>"//含税单价
			+ "<td class=\"price price1\"><div>"+oldUnitPrice+"<span "+red_unitPrice+">"+fmoney(changeNum($tr.find("input[tdTag=changeUnitPrice]").val()),6)+"</span>"+"</div></td>"//无税单价
			+ "<td class=\"price price2\"><div><span "+red_sum+">"+fmoney(changeNum($tr.find("input[tdTag=changeSum]").val()),4)+"</span>"+"</div></td>"//金额
			+ "<td class=\"last time\"><div>"+oldQuote+"<span "+red_quote+">"+$tr.find("input[tdTag=changeQuote]").val()+"</span>"+"</div></td>"//Quote
			+ "<td class=\"last time\"><div>"+oldExpectDate+"<span "+red_expectDate+">"+$tr.find("input[tdTag=changeExpectDate]").val()+"</span>"+"</div></td>"//交期
			+ "<td class=\"last time\"><div><span>"+$tr.find("input[tdTag=erpPoNo]").val()+"</span>"+"</div></td>"//ERP采购订单号
			+ "<td class=\"last time\" style=\"text-decoration:none\"><div>"+$tr.find("input[tdTag=reason]").val()+"</div></td></tr>";
			
			$("#detailListTbody_confirm").append(trString);
		}
		
		if(isUpdate==1){
			//存入数据库的changeType
			$tr.find("[tdTag=changeType]").val(changeType);
			
			var trString = "<tr class=\""+closeStr+borderStr+"\""+red_tr+">" 
		 	+ "<td class=\"first num\" style=\"text-decoration:none\"><div>"+changeType+"</div></td>"//变更类型
			+ "<td class=\"supplier-model\"><div>"+$tr.find("input[tdTag=inventoryCode]").val()+"</div></td>"//型号
			+ "<td class=\"last time\"><div>"+oldInventorySpecfName+"<span "+red_inventorySpecfName+">"+$tr.find("input[tdTag=inventorySpecfName]").val()+"</span>"+"</div></td>"//套片
			+ "<td class=\"last time\"><div>"+oldSlCode+"<span "+red_slCode+">"+$tr.find("input[tdTag=slCode]").val()+"</span>"+"</div></td>"//SL Code
			+ "<td class=\"quantity\"><div>"+oldRestQuantity+"<span "+red_RestQuantity+">"+fmoney(changeNum($tr.find("input[tdTag=restQuantity]").val()),0)+"</span>"+"</div></td>"//在途数量
			+ "<td class=\"price price0\"><div>"+oldTaxUnitPrice+"<span "+red_taxUnitPrice+">"+fmoney(changeNum($tr.find("input[tdTag=taxUnitPrice]").val()),6)+"</span>"+"</div></td>"//含税单价
			+ "<td class=\"price price1\"><div>"+oldUnitPrice+"<span "+red_unitPrice+">"+fmoney(changeNum($tr.find("input[tdTag=unitPrice]").val()),6)+"</span>"+"</div></td>"//无税单价
			+ "<td class=\"price price2\"><div><span "+red_sum+">"+fmoney(changeNum($tr.find("input[tdTag=sum]").val()),4)+"</span>"+"</div></td>"//金额
			+ "<td class=\"last time\"><div>"+oldQuote+"<span "+red_quote+">"+$tr.find("input[tdTag=quote]").val()+"</span>"+"</div></td>"//Quote
			+ "<td class=\"last time\"><div>"+oldExpectDate+"<span "+red_expectDate+">"+$tr.find("input[tdTag=expectDate]").val()+"</span>"+"</div></td>"//交期
			+ "<td class=\"last time\"><div><span>"+$tr.find("input[tdTag=erpPoNo]").val()+"</span>"+"</div></td>"//ERP采购订单号
			+ "<td class=\"last time\" style=\"text-decoration:none\"><div>"+$tr.find("input[tdTag=reason]").val()+"</div></td></tr>";
			
			$("#detailListTbody_confirm").append(trString);
		}
		$("#remark_confirm").text($("#remark").val());
	}
	}
}

function isApproval(){
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		if($tr.find("[tdTag=restQuantity]").val() > $tr.find("[tdTag=restQuantityCopy]").val()){
			$("[tdTag=isApproval]").val("Y");			
		}	
		if($tr.find("[tdTag=taxUnitPrice]").val() > $tr.find("[tdTag=changeTaxUnitPrice]").val()){
			$("[tdTag=isApproval]").val("Y");			
		}
		if($tr.find("[tdTag=changeInventoryCode]").val()!=null&&$tr.find("[tdTag=inventoryCode]").val() != $tr.find("[tdTag=changeInventoryCode]").val()){
			$("[tdTag=isApproval]").val("Y");			
		}
	}
		
}

function getApprovalType(){
	var type1 = 1;//不需要审批
	var type2 = 0;//只需PM审批
	var type3 = 0;//走PR订单审批流程
	var $trs = $("#detailListTbody").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);		
		if($tr.find("[tdTag=changeClosed]").val()!=1){
			if($tr.find("[tdTag=closed]").val()==1){
				type2=1;
			}else{				
				if(parseFloat($tr.find("[tdTag=restQuantity]").val()) > parseFloat($tr.find("[tdTag=changeRestQuantity]").val())){
					type3=1;
					break;
				}
				if(parseFloat($tr.find("[tdTag=unitPrice]").val()) > parseFloat($tr.find("[tdTag=changeUnitPrice]").val())){
					type3=1;
					break;
				}
				if(parseFloat($tr.find("[tdTag=taxUnitPrice]").val()) > parseFloat($tr.find("[tdTag=changeTaxUnitPrice]").val())){
					type3=1;
					break;
				}
				if($tr.find("[tdTag=inventoryCode]").val() != $tr.find("[tdTag=changeInventoryCode]").val()){	
					type3=1;
					break;
				}

				if($tr.find("[tdTag=changeType]").val()=="拆行"){
					var splitSum = 0;
					var rowNo = $tr.find("[tdTag=rowNo]").val();					
					$("#detailListTbody").find("input[tdTag=rowNo]").each(function(){						
						if($(this).val()==rowNo){
							splitSum=splitSum+parseFloat($(this).parents("tr").find("input[tdTag=restQuantity]").val());
						}
					});
					if(splitSum > $tr.find("[tdTag=changeRestQuantity]").val()){
						type3=1;
						break;
					}					
				}							
			}				
		}		
	}
	if(type3==1){//走正常订单审批流
		$("input[tdTag=approvalType]").val(2);
		//alert("type3");
	}else if(type2==1){//只由PM审批
		$("input[tdTag=approvalType]").val(1);
		//alert("type2");
	}else{//不需要审批
		$("input[tdTag=approvalType]").val(0);
		//alert("type1");
	}
}

/* 获取邮件发送列表 */
function getEmailList() {
	
	var buId = $("#buId").val();
	var plName = $("#plname").val();
	var personEmail = $("#personEmail").val();
	var url = "/approval/prChangeApproval_showConfirmMail?prChangeMain.buId="+buId+"&prChangeMain.productLineName="+plName+"&prChangeMain.personEmail="+personEmail;
	url = url + "&prChangeMain.sample="+$("#sample").val();
	url = url + "&prChangeMain.byd="+$("#byd").val();
	url = url + "&prChangeMain.office="+$("#office").val();
	url = url + "&prChangeMain.salesTag="+$("#salesTag").val();
	url = url + "&prChangeMain.agentPurchasing="+$("#agentPurchasing").val();
	url = url + "&prChangeMain.supplyChainFinance="+$("#supplyChainFinance").val();
	url = url + "&prChangeMain.condition4="+$("#condition4").val();
	url = url + "&prChangeMain.approvalType="+$("input[tdTag=approvalType]").val();
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#submit").hide();
			dialog("未找到流程，请联系Winney Liu修改","unsuccess",true,2);
			return false;
		}else if(nodeNoApprovalUser){
			$("#submit").hide();
			dialog("存在没有审批人的节点，请联系Winney Liu修改","unsuccess",true,2);
			return false;
		}else{
			$("#submit").show();
		}
	});
}

/* 获取销售订单号、且写入页面 */
function getSalesOrderSO() {
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/salesOrder_createSalesOrderNo"),
		success : function(returnStr) {
			$("#salesOrderNo").val(returnStr);
			$("#so_confirm").text(returnStr);
		}
	});
}

/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
function switchPageForCreate() {
	$("#write").hide();
	$("#confirm").show();
}


/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").hide();
	$("#write").show();
}