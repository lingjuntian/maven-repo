$(function(){
    // 弹窗-分配
    $(".iot-allot").click(function(e){
        var $this = $(this);
        if(closeClick){
            closeClick = false;
            $('.div-lookfor,.share-aside').remove();
            return false;
        }
        //如果页面已经存在弹窗，则不执行
        if($this.parent().find('.div-lookfor').length > 0){
            // $('.div-lookfor,.share-aside').show();
            return false;
        }
        $('.div-lookfor,.share-aside').remove();
        /* 分配 */
        var iid=$(this).attr("tdTag");
        var pname="项目名称："
        pname+=$(this).closest("tr").find("[tdTag=projectName]").text();
        var str =   '<div class="div-lookfor">'
            +'    <h2>'+pname+'</h2>'
            +'    <input type="text" id="allotUser" placeholder="客户经理" class="input-text" />'
            +'    <input type="hidden" id="allotUserId"  class="input-text" />'
            +'    <div class="actions">'
            +'        <a href="#" title= "分配" class="button button-allot" onclick="buttonAllot('+iid+')"><span><span>分配</span></span></a>'
            +'        <a href="#" title= "取消" class="button button-cancel" onclick="buttonCancel(this)"><span><span>取消</span></span></a>'
            +'    </div>'
            +'    <a onclick="closelookfor(this)" class="close" title="关闭">关闭</a>'
            +'</div>'
            +'<div class="share-aside">'
            +'    <span><img src="/common/img/crm/triangle-l2.png" alt="" /></span>'
            +'</div>';
        var $iotAllot = $('.iot-allot');
        $this.parent().addClass('ps-r');
        $this.parent().append(str);
        // console.log($this);
        $('.div-lookfor,.share-aside').show();
        completUser("allotUser");
        return false;
    });




    $('.div-lookfor').live('click',function(){
        return false;
    });

    /**查询**/
    $("#iotFormSubmit").click(function(){
        citySelect();
        classifySelect();
        inActivitySelect();
        buisnessSelect();
        if($("#pageNo").val()!=null&&$("#pageNo").val()!=""){
            //验证页码输入框是否数字
            var reg = new RegExp("^[0-9]*$");
            if(reg.test($("#pageNo").val())){
                $("#pageNoInp").val($("#pageNo").val());
            }
        }if($("#pageSize").val()!=null&&$("#pageSize").val()!=""){
            //验证pageSize输入框是否数字
            var reg = new RegExp("^[0-9]*$");
            if(reg.test($("#pageSize").val())){
                $("#pageSizeInp").val($("#pageSize").val());
            }
        }
          $("#startDateInp").val($("#startDate").val());
          $("#endDateInp").val($("#endDate").val());
          $("#followUserInp").val($("#followUser").val());
//        $("#iotForm").append($("#startDate"));
//        $("#iotForm").append($("#endDate"));
        $("#iotForm").submit();
    });
    /*导出所有*/
    $("#download").click(function(){
        $("#iotForm").attr("action","/crm/download_iot_list");
        $("#iotForm").submit();
        $("#iotForm").attr("action","/crm/iot_index");
    });


    /**删除**/
    /*$(".deleteBut").click(function(){
        var iotId=$(this).attr("tdTag")
        dialog("你确定要删除该项目吗？",null,true,null,function(){
            //ajax 提交删除项目
            $.ajax({
                url:"/crm/iot_deleteIot?iot.id="+iotId,
                method:'GET',
                success:function(returnStr){
                    if (returnStr == "success") {
                        dialog("成功","success",true,1);
                        setTimeout(function(){location.reload(true);},1000);
                    }else {
                        dialog(returnStr,"unsuccess",true,2);
                    }
                    return false;
                }
            });

        })
    });*/

   $(".allotIot").click(function(){
       var id=$(this).attr("tdTag");
       var pname=$(this).closest("tr").find("[tdTag=projectName]").text();

   });



    /**
     * 是否联盟
     */

    $("[name=isAlliance]").click(function(){
        if($(this).attr("vhidden")=='是'){
            $("#iotiIsAlliance").val("1");
        }
        if($(this).attr("vhidden")=='否'){
            $("#iotiIsAlliance").val("0");
        }
        if($(this).attr("vhidden")=='不限'){
            $("#iotiIsAlliance").val("");
        }
    });

    /**
     * 是否分配
     */

    $("[name=allotState]").click(function(){
        if($(this).attr("vhidden")=='已分配'){
            $("#allotState").val("1");
        }
        if($(this).attr("vhidden")=='未分配'){
            $("#allotState").val("0");
        }
        if($(this).attr("vhidden")=='不限'){
            $("#allotState").val("");
        }
    });

    /**
     * 状态
     */
    $("[name=state]").click(function(){
        if($(this).attr("vhidden")=='已跟进'){
            $("#iotState").val("已跟进");
        }
        if($(this).attr("vhidden")=='未跟进'){
            $("#iotState").val("未跟进");
        }if($(this).attr("vhidden")=='其他'){
            $("#iotState").val("其他");
        }
        if($(this).attr("vhidden")=='不限'){
            $("#iotState").val("");
        }
    });

    /**
     * 勾选下拉框的值
     */
    autoChecked();

    /**
     * 全选
     */
    $("#allSelChe").click(function(){
        if($("#allSelChe").attr("checked")){
            $(".selCheck").attr("checked",true);
        }else{
            $(".selCheck").attr("checked",false);
        }

    });


})

/**
 * 区域下拉框选值
*/
function citySelect(){
    var cityCheckBox=$("[name=citys]")
    var citys="";
    for(var i=0;i<cityCheckBox.size();i++){
        if(cityCheckBox.eq(i).attr("checked")==true){
            citys+="'"+cityCheckBox.eq(i).val()+"',";
        }
    }
        $("#citys").val(citys.substring(0,citys.length-1));
}
/**
 * 分类下拉框选值
 */
function classifySelect(){
    var classifyCheckBox=$("[name=classify]")
    var classify="";
    for(var i=0;i<classifyCheckBox.size();i++){
        if(classifyCheckBox.eq(i).attr("checked")==true){
            classify+="'"+classifyCheckBox.eq(i).val()+"',";
        }
    }
        $("#classify").val(classify.substring(0,classify.length-1));
}

/**
 * 参与活动下拉框选值
 */
function inActivitySelect(){
    var inActivityCheckBox=$("[name=inActivity]")
    var inActivity="";
    for(var i=0;i<inActivityCheckBox.size();i++){
        if(inActivityCheckBox.eq(i).attr("checked")==true){
            inActivity+=inActivityCheckBox.eq(i).val()+",";
        }
    }
        $("#inActivity").val(inActivity.substring(0,inActivity.length-1));
}

/**
 * 业务机会下拉框选值
 */
function buisnessSelect(){
    var buinessCheckBox=$("[name=buinessChance]");
    var buinessChance="'";
    for(var i=0;i<buinessCheckBox.size();i++){
        if(buinessCheckBox.eq(i).attr("checked")==true){
            buinessChance+=buinessCheckBox.eq(i).val()+"','";
        }
    }
    $("#busniessChance").val(buinessChance.substring(0,buinessChance.length-2));
}



//当点击查询时，页面刷新，将已选中的多选框自动选中
function autoChecked(){
    if($("#citys").val()!=null&&$("#citys").val()!=""){
         var citysCheckBox=$("[name=citys]")
         var k=0;
        for(var i=0;i<$("#citys").val().split(",").length;i++){
          var city=$("#citys").val().split(",")[i];
            for(var j=0;j<citysCheckBox.size();j++){
                if(city.substring(1,city.length-1)==citysCheckBox.eq(j).val()){
                    citysCheckBox.eq(j).attr("checked","checked");
                    k++;
                };
            }
        }
        if(k>0){$("#selectedCT").text("共选择"+k+"个");}
    }

    if($("#classify").val()!=null&&$("#classify").val()!=""){
        var classifyCheckBox=$("[name=classify]")
        var k=0;
        for(var i=0;i<$("#classify").val().split(",").length;i++){
            var classify=$("#classify").val().split(",")[i];
            for(var j=0;j<classifyCheckBox.size();j++){
                if(classify.substring(1,classify.length-1)==classifyCheckBox.eq(j).val()){
                    classifyCheckBox.eq(j).attr("checked","checked");
                    k++;
                };
            }
        }
        if(k>0){$("#selectedCL").text("共选择"+k+"个");}
    }

    if($("#inActivity").val()!=null&&$("#inActivity").val()!=""){
        var inActivityCheckBox=$("[name=inActivity]")
        var k=0;
        for(var i=0;i<$("#inActivity").val().split(",").length;i++){
            var inActivity=$("#inActivity").val().split(",")[i];
            for(var j=0;j<inActivityCheckBox.size();j++){
                if(inActivity==inActivityCheckBox.eq(j).val()){
                    inActivityCheckBox.eq(j).attr("checked","checked");
                    k++;
                };
            }
        }
        if(k>0){$("#selectedIA").text("共选择"+k+"个");}
    }

    if($("#busniessChance").val()!=null&&$("#busniessChance").val()!=""){
        var buinessBox=$("[name=buinessChance]");
        var busVal=$("#busniessChance").val()
        busVal=busVal.substring(1,busVal.length-1);
        var k=0;
        for(var i=0;i<busVal.split("','").length;i++){
            var buiness=busVal.split("','")[i];
            for(var j=0;j<buinessBox.size();j++){
                if(buiness==buinessBox.eq(j).val()){
                    buinessBox.eq(j).attr("checked","checked");
                    k++;
                };
            }
        }
        if(k>0){$("#selectedBC").text("共选择"+k+"个");}
    }
}

// 关闭弹窗
function closelookfor(obj){
    closeClick = true;
    // console.log('close:' + closeClick);
    $(obj).parents('td').find('.div-lookfor,.share-aside').hide();
}

// 点击分配按钮
/*
function buttonAllot(iid){
    closeClick = true;
    var userName=$("#allotUser").val();
    var userId=$("#allotUserId").val();
    if(userName==null||userName==''){dialog("请填写要分配的客户经理", "unsuccess", true, 2);return}
    $('.div-lookfor,.share-aside').hide();
    //提交分配信息
    var data = {
        "userName" : userName,
        "userId" : userId,
        "iid" : iid
    };
    $.ajax({
        type:"GET",
        url:encodeURI("/crm/iot_addAllot"),
        dataTye:'josn',
        data :data,
        success:function(returnStr){
            var type = returnStr.split("_")[0];
            var id = returnStr.split("_")[1];
            if (type == "success") {
                dialog("成功","success",true,1);
                var str="/crm/iot_index";
                setTimeout(function(){window.location = str;},1000);
            }else {
               // $("#addIotBut").show();
                dialog(returnStr,"unsuccess",true,2);
            }
        }
    });

}
*/

// 点击取消按钮
function buttonCancel(obj){
    closeClick = true;
    $('.div-lookfor,.share-aside').hide();


}



/**
 * 获取选中checkbox 的Id值
 */
function getCheckedId(){
    var $check=$(".selCheck:checked");
    var iIds="";
    for(var i=0;i<$check.size();i++){
        var id=$check.eq(i).attr("tdTag");
        iIds=iIds+id+","
    }
    iIds=iIds.substr(0,iIds.length-1);
    return iIds;
}

/**
 * 批量 添加共享，和分配
 */
// 公共弹窗-添加分享人和查看人
(function(){
    var commonPopboxEvn = {
        // 添加共享人
        addShare : function(){
            $('.js-share-btn').click(function(){
                var $sleChe=$(".selCheck:checked");
                var size= $sleChe.size();
                if(size == 0 ){dialog("请至少勾选一个以上项目","unsuccess",true,2); return}
                $("#shareSumMes").text("共选择"+size+"个项目");
                $('.mask-div-fff,.pop-box,.pop-box .div-lookfor').hide();
                $('.mask-div-fff,.pop-box,.pop-box .div-shareperple').show();
                $(this).parents('.pop-box').find('.share-aside,.actions').show();
            });
        },
        // 添加查看人
        addLook : function(){
            $('.js-look-btn').click(function(){
                var $sleChe=$(".selCheck:checked");
                var size= $sleChe.size();
                if(size == 0 ){dialog("请至少勾选一个以上项目","unsuccess",true,2); return}
                $("#allotSumMes").text("共选择"+size+"个项目");
                $('.mask-div-fff,.pop-box .div-shareperple,.pop-box').hide();
                $('.mask-div-fff,.pop-box,.pop-box .div-lookfor').show();
                $(this).parents('.pop-box').find('.share-aside,.actions').show();
                console.log('ok');
            });
        },

        // 关闭弹窗
        closePopbox : function(){
            $('.pop-box .close').click(function(){
                var e=window.event || event;

                $(this).parents('.pop-box').hide();
                $('.mask-div-fff').hide();
            });

            $('.mask-div-fff').click(function(){
                $('.mask-div-fff,.pop-box').hide();
            });
        },
        // 添加按钮
        popboxAdd : function(){
            //共享
            $('#shareOkBut').click(function(){
                var iid=getCheckedId();
                var userId=$("#shareHide").val();
                var userName=$("#shareInput").val();
                var accessType="SHARE"
                if(userName==""){dialog("请填写共享人配人","unsuccess",true,2); return}
                $('#shareOkBut').hide();
                var data = {
                    "userName" : userName,
                    "userId" : userId,
                    "accessType":accessType,
                    "iid" : iid
                };
                $.ajax({
                    type:"GET",
                    url:encodeURI("/crm/iot_addAccess"),
                    dataTye:'josn',
                    data :data,
                    success:function(returnStr){
                        var type = returnStr.split("_")[0];
                        var id = returnStr.split("_")[1];
                        if (type == "success") {
                            dialog("成功","success",true,1);
                            //var str="/crm/iot_index";
                            setTimeout(function(){window.location.reload(true);},1000);
                        }else {
                            // $("#addIotBut").show();
                            $('#shareOkBut').show();
                            dialog(returnStr,"unsuccess",true,2);
                        }
                    }
                });

            });
            //分配
            $('#allotOkBut').click(function(){
                var iid=getCheckedId();
                var userId=$("#allotHide").val();
                var userName=$("#allotInput").val();
                if(userName==""){dialog("请填写分配人","unsuccess",true,2); return}
                var data = {
                    "userName" : userName,
                    "userId" : userId,
                    "iid" : iid
                };
                $('#allotOkBut').hide();
                $.ajax({
                    type:"GET",
                    url:encodeURI("/crm/iot_addAllot"),
                    dataTye:'josn',
                    data :data,
                    success:function(returnStr){
                        var type = returnStr.split("_")[0];
                        var id = returnStr.split("_")[1];
                        if (type == "success") {
                            dialog("成功","success",true,1);
                            //var str="/crm/iot_index";
                            setTimeout(function(){window.location.reload(true);},1000);
                        }else {
                            $('#allotOkBut').show();
                            // $("#addIotBut").show();
                            dialog(returnStr,"unsuccess",true,2);
                        }
                    }
                });
            });
        }
    }
    window.commonPopboxEvn =  commonPopboxEvn;
})();







































