
$(function(){
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		var $id = $(this).attr("vid");
		var $show = $(this).attr("vshow");
		var $rate = $(this).attr("vrate");
		$(this).parents(".options-select").find("input[tag=id]").val($id);
		$(this).parents(".options-select").find("input[tag=show]").val($show);
		$(this).parents(".options-select").find("input[tag=rate]").val($rate);
		var $selecttag = $(this).attr("selecttag");
		$("li ["+$selecttag+"]").hide();
		$("li ["+$selecttag+"="+$id+"]").show();
		$(this).validationEngine('hidePrompt');
		return false;
	});
	//初始化时模拟点击BU，使其出现对应的Dep列表
	var buId = $("#buId").val();
	$("#buList").find("a[vid="+buId+"]").trigger("click");
	
	 //上一步
    $("#upStep").click(function(){

    	$("#costBody").find("tr[deleteFlag=yes]").remove();
    	//隐藏的Collect表单清空
    	$("#collectDiv").empty(); 
    	//清除提示
    	$("#prompt").text("");
    	
		$("#twoStep").hide();
		$("#oneStep").show();
    });
    
    
	//下一步
    $("#nextStep").click(function(){
    	cleanPage();
    	validateFunction();
    	var error1 = $("#historyForm").validationEngine('validate'); 	
		if(error1){
			count();
			copyStyle();//复制表格 取回邮件列表
			$("#oneStep").hide();
			$("#twoStep").show();
			copyFileList();  
			return false;
		}
		return false;
    });
    
});

function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}

function cleanPage(){
	//取消所有验证（其实是针对表格中填了数据又去掉的情况）
	$("#historyForm").validationEngine("hideAll");
	//整理2个表格,去空行
	cleanTbody($("#costTable"));
	//改名
	changeName();
}

/*计算和*/
function count(){
	//隐藏的Collect表单清空
	$("#collectDiv").empty(); 
	
	var rowNum =$("#costTable").children("tr").size();
	var totalSum = 0;  //
	for(var i = 0;i < rowNum; i++){
		$tr = $("#costTable").children("tr").eq(i);
    	var budgetval = $tr.find("[id*=useMoney]").val();
    	totalSum = add(totalSum,budgetval);
	}
		
	//总和
	$("#totalSum").val(totalSum);
}


//复制
function copyStyle(){
	//取回邮箱
	fillMaillList();
	
	var trCopy;
	var rowNum;
	//复制项目主体
	$('#prebudgetNo').text($('#budgetNo').val());
	$('#preBudgetName').text($('#budgetName').val());
	if (document.getElementById("payType0").checked){
		$('#prepaytype').text('对公');
	}else{
		$('#prepaytype').text('对私');
	}
	$('#prebankaccount').text($('#bankaccount').val());
	$('#prebankname').text($('#bankname').val());
	$('#preaccountname').text($('#accountName').val());
	
	//复制项目预算明细
	rowNum =$("#costTable").children("tr").size();
	for(var i = 0;i < rowNum; i++){
		$tr = $("#costTable").children("tr").eq(i);
        trCopy = $("#costCopy").clone(true);
    	trCopy.find("[flag=one]").text($tr.find("[name*=description]").val()); //
	    trCopy.find("[flag=two]").text($tr.find("[name*=memo]").val()); //
	    trCopy.find("[flag=three]").text($tr.find("[name*=useMoney]").val()); //
    	trCopy.attr("id", "");
    	trCopy.attr("deleteFlag", "yes");
    	$("#costBody").append(trCopy);
    	trCopy.show();
	}
	
	var copySumDiv = $("#sumTr").clone(true);
	copySumDiv.attr("id","");
	copySumDiv.attr("deleteFlag", "yes");
	copySumDiv.find("[valueTag=valueTag]").text($("#totalSum").val());
	$("#costBody").append(copySumDiv);
	copySumDiv.show();
}

function changeName(){
	var tbodyNum = $("#tbodys tbody").size();
	//alert("tbody个数："+tbodyNum);
	for(var i = 0; i < tbodyNum; i++){
		var $tbody = $("#tbodys tbody").eq(i);
		var trNum = $tbody.children("tr").size();
		for(var j = 0; j < trNum; j++){
			var $tr = $tbody.children("tr").eq(j);
			var tdNum = $tr.children("td").size();
			for(var k = 0; k < tdNum; k++){
				var $td =  $tr.children("td").eq(k);
				var inputNum = $td.find("input").size();
				//alert("input个数："+inputNum);
				for(var v = 0; v < inputNum; v++){
					var $input = $td.find("input").eq(v);
					var name = $input.attr("name");
					var before= $.trim(name.split(".")[0]);
						var obefore =  $.trim(before.split("[")[0]); //避免重复添加[下标]
					var after= $.trim(name.split(".")[1]);
					var all = obefore+"["+j+"]"+"."+after;
					$input.attr("name",all);
					var id = $input.attr("id");
					var idBefore= $.trim(id.split("_")[0]);
					var  idNew = idBefore+"_"+j;
					$input.attr("id",idNew); //改Id,验证时使用
				};
			};
		};
	};
}
//整理表格，去空行，至少保留一行
function cleanTbody(tbody){
	var trNum = tbody.find("tr").size();
	for(var i = trNum-1; i >= 0; i--){
		trNum = tbody.find("tr").size();
		var tr = tbody.find("tr").eq(i);
		if(checkEmptyTr(tr)){
			if(trNum > 1){ 
				//clearTrTips(tr);取消验证
				tr.remove();
			};
		};
	};
}
//验证空行
function checkEmptyTr(tr){
	var flag = true; //为空
	var input = tr.find("input").eq(1);
	if($.trim(input.val())!=""){
		flag = false; //不为空
		tr.find("input[id*=memo]").addClass("validate[required,maxSize[200]]");
		tr.find("input[id*=useMoney]").addClass("validate[required]");
		return flag;
	};
	//为空行，去掉验证
	tr.find("input[id*=memo]").removeClass("validate[required,maxSize[200]]");
	tr.find("input[id*=useMoney]").removeClass("validate[required]");
	return flag;
}
/* 添加一行 */
$("tr input").click(function(){
	var $tr = $(this).parents("tr");
	if($tr.nextAll().length==0){
		addTr($tr);
	};
});

$(".del-text").click(function(){
	var $obj = $(this).parents("tr");
	var $length = $obj.parents("tbody").find("tr").length;
	if($length<2){
		dialog("请最少保留1行","warning",false,2);
		return false;
	}
	delTr($obj);
});
/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.attr("hide","show");
	$copyTr.show();
	$tr.after($copyTr);
}
/* 删除行 */
function delTr($obj){
	$obj.remove();
	$obj.validationEngine('hidePrompt');
}
function getCurrencyFlag(currencyName){
	var flag = "";
	if(null == currencyName || "" == currencyName || "undefined" == currencyName){
		flag = "¥";
	}else{
		if(currencyName == "人民币"){
			flag = "¥";
		}else if(currencyName == "美元"){
			flag = "$";
		}else if(currencyName == "港元"||currencyName == "港币"){
			flag = "HK$";
		}else if(currencyName == "欧元"){
			flag = "€";
		}else if(currencyName == "日元"){
			flag = "¥";
		}else if(currencyName == "澳元"){
			flag = "AU$";
		} else if (currencyName == "台币") {
			flag = "TWD";
		}else{
			flag = "¥";
		}
	}
	return flag;
}
function lowToUpper(num){
	if(!/^\d*(\.\d*)?$/.test(num)){
		
	}else{
		var UPPER = new Array("零","壹","贰","叁","肆","伍","陆","柒","捌","玖");
		var num_array = ("" + num).split(".");
		var defStr="零";
		/*小数位*/
		if(num_array[1] != null && num_array[1].length > 0){
			if(num_array[1].length < 2){
				$("[jiao=jiao]").text(UPPER[num_array[1].charAt(0)]);
				$("[fen=fen]").text(defStr);
			}else{
				$("[jiao=jiao]").text(UPPER[num_array[1].charAt(0)]);
				$("[fen=fen]").text(UPPER[num_array[1].charAt(1)]);
			}
		}else{
			$("[jiao=jiao]").text(defStr);
			$("[fen=fen]").text(defStr);
		}
		/*整数位*/
		if(num_array[0] != null && num_array[0].length > 0){
			var intstr = "";
			if(num_array[0].length < 7){
				var temp = "";
				for(var i=0; i < 7 - num_array[0].length; i++){
					temp = temp + "0";
				}
				intstr = temp + num_array[0];
			}else{
				intstr = num_array[0].substring(num_array[0].length - 7);
			}
			$("[baiwan=baiwan]").text(UPPER[intstr.charAt(0)]);
			$("[shiwan=shiwan]").text(UPPER[intstr.charAt(1)]);
			$("[wan=wan]").text(UPPER[intstr.charAt(2)]);
			$("[qian=qian]").text(UPPER[intstr.charAt(3)]);
			$("[bai=bai]").text(UPPER[intstr.charAt(4)]);
			$("[shi=shi]").text(UPPER[intstr.charAt(5)]);
			$("[ge=ge]").text(UPPER[intstr.charAt(6)]);
		}else{
			$("[baiwan=baiwan]").text(defStr);
			$("[shiwan=shiwan]").text(defStr);
			$("[wan=wan]").text(defStr);
			$("[qian=qian]").text(defStr);
			$("[bai=bai]").text(defStr);
			$("[shi=shi]").text(defStr);
			$("[ge=ge]").text(defStr);
		}
		
	}
}
//取回数值，没有值的为0
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}

function changePaytype(t){
	if (t==0){//对公
		$("#bankaccount").val("");
		$("#bankname").val("");
		$("#accountName").val("");
		$("#bankaccount").removeAttr("readonly");
		$("#bankname").removeAttr("readonly");
		$("#accountName").removeAttr("readonly");
	}else{
		$("#bankaccount").val("-");
		$("#bankname").val("-");
		$("#accountName").val("-");
		$("#bankaccount").attr("readonly","readonly");
		$("#bankname").attr("readonly","readonly");
		$("#accountName").attr("readonly","readonly");
	}
}

function validateFunction(){
	$("#createUserId").addClass("validate[required]");
	
	$("#buName").addClass("validate[required]");
	$("#buId").addClass("validate[required]");
	
	$("#departmentName").addClass("validate[required]");
	$("#departmentId").addClass("validate[required]");
	
	$("#regionName").addClass("validate[required]");
	$("#regionId").addClass("validate[required]");
	
	$("#currencyName").addClass("validate[required]");
	$("#currencyId").addClass("validate[required]");
	
	$("#bankaccount").addClass("validate[required,maxSize[100]]");
	$("#bankname").addClass("validate[required,maxSize[150]]");
	$("#accountName").addClass("validate[required,maxSize[200]]");
}