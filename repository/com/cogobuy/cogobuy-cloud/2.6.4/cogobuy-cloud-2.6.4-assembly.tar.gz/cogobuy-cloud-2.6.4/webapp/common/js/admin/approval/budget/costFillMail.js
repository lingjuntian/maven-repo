/* 填充确认页面邮箱列表 */
function fillMaillList() {
	var createUserId = $("#createUserId").val();
	var departmentId = $("#departmentId").val();
	var buId = $("#buId").val();
	var totalSum =$("#totalSum").val();
	var regionId = $("#regionId").val();
	var url = "/approval/budget_showConfirmMail?budgetApproval.createUserId="+ createUserId 
			+ "&budgetApproval.departmentId=" + departmentId
			+ "&budgetApproval.buId=" + buId 
			+ "&budgetApproval.regionId=" + regionId
			+ "&budgetApproval.budgetSum=" + totalSum ;
	$("#mailList").load(encodeURI(url));
}