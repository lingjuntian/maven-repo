/**
 * crm 客户列表页js
 */

$(function(){
	// 点击全选按钮
	$('input#rss-i1').click(function(){
		$('input[name="rss-i"]').attr('checked',this.checked);          // jq1.6+ 使用prop
	});

	// 点击复选框，修改全选按钮的状态
	var $rssBox = $('input[name="rss-i"]');
	$rssBox.click(function(){
		$('input#rss-i1').attr('checked',$rssBox.length == $('input[name="rss-i"]:checked').length ? true:false);
	});


	// 发短信
	$('#send-msg').click(function(){
		$("#mask-div,.msg-popup,.msg-popup-btn").show();
		var $tbody=$("#tbody").find("tr");
		for(var i=0;i<$tbody.size();i++){
			var $tr=$tbody.eq(i);
			//判断该联系人是否选中
			if($tr.find("input").attr("checked")==true){
				var str="<span>" +
				        "<input type='hidden' name='' tdTag='conid' value='"+$tr.find('[tdTag=conid]').val()+"'></input>" +
				        "<input type='hidden' name='' tdTag='conName' value='"+$tr.find('[tdTag=contactName]').text()+"'></input>" +
				        "<input type='hidden' name='' tdTag='phoneNum' value='"+$tr.find('[tdTag=phoneNum]').text()+"'></input>"+
						"<em>"+$tr.find("[tdTag=contactName]").text()+"</em><img style='cursor:pointer' class='deleteCon' src='/common/img/crm/del.png'/></span>";
				$("#showConName").prepend(str);
			 /*	var input="<input type='text' name='shortMeses.conid' value='"+$tr.find('[tdTag=conid]').val()+"'></input>" +
				          "<input type='text' name='shortMeses.conName' value='"+$tr.find('[tdTag=contactName]').text()+"'></input>" +
						  "<input type='text' name='shortMeses.phoneNum' value='"+$tr.find('[tdTag=phoneNum]').text()+"'></input>";
				$("#ShortMesForm").append(input);*/ 
			}
		}
		
		$('.msg-popup,.msg-popup-btn').show();//显示弹出框 

		$(".deleteCon").click(function(){
			$(this).closest("span").remove();//移除联系人
		});
	});	
	
	/**
	 * 添加其他短信接收者（输入框添加收件人）
	 */
	conatctAutoComplete($("#addContactInput"));
	/*联系人自动匹配*/
 	function conatctAutoComplete($input){
 		    //var cid=$("proCustomerId").val();
 		    $input.autocomplete(encodeURI("/crmAjax/contact_findContact"), {
 	        //**加自定义表头**//*
 		    //tableHead: "<div> <span class='col-3' style='width:300px'>请核对用户的手机号码</div>",
 	        minChars: 0,
 	        width: 360,
 	       //  extraParams:{cid:$("proCustomerId").val()}, 
 	        matchContains: "true",
 	        autoFill: false,
 	        dataType: 'json',
 	        parse: function(data) {  
 	            var rows = [];  
 	            if(data == null || data.contacts == null){
 	            	return rows;
 	            }
 	            for(var i=0; i<data.contacts.length; i++){    
 	                rows[rows.length] = {    
 	                    data:data.contacts[i],              
 	                    value:data.contacts[i].chName,     
 	                    result:data.contacts[i].chName   
 	                };  
 	            }  
 	            return rows;  
 	        }, 
 	        formatItem: function(row, i, max) {
 	            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"--"+row.phone+"--"+row.customerName+"</div>";
 	        },
 	        formatMatch: function(row, i, max) {
 	            return row.chName;
 	        }
 		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
 		    	$(this).val(data.chName);
 		    	$("#addcontactId").val(data.id);
 		    	$("#addcontactPhone").val(data.phone);
 		    	
 		    }).bind("unmatch", function() {//**没有匹配时**//*
 		    	$(this).val("");
 		    	$("#addcontactId").val("");
 		    	$("#addcontactPhone").val("");
 		    });
 	}
	
	
	$('#btn-cancel').click(function(){
		 location.reload();
		//$('.msg-popup,.msg-popup-btn').hide();
	});
	
	
	//点击添加联系人图标
	$('.add-msg-recive').click(function(){
		if($("#addContactInput").val()==""){return;}
		var str="<span>" +
        "<input type='hidden' name='' tdTag='conid' value='"+$("#addcontactId").val()+"'></input>" +
        "<input type='hidden' name='' tdTag='conName' value='"+$("#addContactInput").val()+"'></input>" +
        "<input type='hidden' name='' tdTag='phoneNum' value='"+$("#addcontactPhone").val()+"'></input>"+
		"<em>"+$("#addContactInput").val()+"</em><img style='cursor:pointer' class='deleteCon' src='/common/img/crm/del.png'/></span>";
		$("#showConName").prepend(str); 
	    $("#addContactInput").val("");
    	$("#addcontactId").val("");
    	$("#addcontactPhone").val("");
    	$(".deleteCon").click(function(){
			$(this).closest("span").remove();//移除联系人
		});
	});
   /**查询**/						
	$("#selectBut").click(function(){
		 $("#selectForm").submit();
	});
	
	
	/**
	 * 点击发送短信sendMes
	 */
	$("#content").addClass("validate[required]");
	 /* 验证输入 */
    function validationInput() {
    	return $("#ShortMesForm").validationEngine('validate');
    };
	$("#sendMes").click(function(){
		if(validationInput()){
		addNameForInput($("#ShortMesForm"));
		$("#sendMes").hide();
		$("#ShortMesForm").attr("action","/crm/contact_sendShortMes");
		$("#ShortMesForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			//var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				location.reload(true);
				//setTimeout(function(){window.location="/crm/contact_show?contact.id="+id;},1000);	  
			}else {
				$("#sendMes").show();
				dialog(returnStr,"unsuccess",true,2);
			}	
	        return false;
		});
		}
	});
	
	 /* 发送短信的隐藏表单添加的name属性 */
    function addNameForInput($form) {
    	var $spans = $form.find("span");/* 获取所有tr */
    	var firstName = "shortMeses";/* 前缀名称 */
    	for ( var i = 0; i < $spans.size(); i++) {
    		var numtag = "[" + i + "]";
    		var $span = $spans.eq(i);
    		var $inputNum = $span.find("input").size();
    		for ( var j = 0; j < $inputNum; j++) {
    			var $input = $span.find("input").eq(j);
    			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
    		}
    	}
    }
	
	
	
	
	

});