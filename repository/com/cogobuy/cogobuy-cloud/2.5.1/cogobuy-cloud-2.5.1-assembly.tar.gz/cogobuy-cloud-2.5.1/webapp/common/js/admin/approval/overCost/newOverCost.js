$(function(){
	 /*填充月份和年份*/
	var myDate = new Date();
	$("#thisYear").text(myDate.getFullYear());
	$("#lastYear").text(myDate.getFullYear()-1).attr("vshow",myDate.getFullYear()-1);
	$("#thisYear2").text(myDate.getFullYear()).attr("vshow",myDate.getFullYear());
	$("#nextYear").text(myDate.getFullYear()+1).attr("vshow",myDate.getFullYear()+1);
	$("#thisMonth").text(myDate.getMonth() + 1);
	$("#year").val(myDate.getFullYear());
	$("#month").val(myDate.getMonth() + 1);
	
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		var $id = $(this).attr("vid");
		var $show = $(this).attr("vshow");
		var $rate = $(this).attr("vrate");
		$(this).parents(".options-select").find("input[tag=id]").val($id);
		$(this).parents(".options-select").find("input[tag=show]").val($show);
		$(this).parents(".options-select").find("input[tag=rate]").val($rate);
		return false;
	});
	
	/*下一步*/
	$("#nextStep").click(function(){
		validateFunction();
		var error = $("#historyForm").validationEngine('validate'); 	
		if(error){
			//复制填充内容
			$("#createUserNameC").text($("#createUserName").val());
			$("#buNameC").text($("#buName").val());
			$("#deptNameC").text($("#deptName").val());
			$("#regionNameC").text($("#regionName").val());
			$("#currencyNameC").text($("#currencyName").val());
			$("#yearC").text($("#year").val());
			$("#monthC").text($("#month").val());
			$("#limitC").text($("#limit").val());
			$("#remarkC").text($("#remark").val());
			//取回邮箱
			fillMaillList();
			$("#stepOne").hide();
			$("#stepTwo").show();
		}
	});
	
	/*上一步*/
	$("#lastStep").click(function(){
		$("#stepOne").show();
		$("#stepTwo").hide();
	});
	
	//确认提交
    $("#allSubmit").click(function(){
    	//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#historyForm").append(inputStr);
    		}
    	});
    	$("#allSubmit").hide();
		$("#historyForm").ajaxSubmit(function(returnStr){
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功！","success",true,1);
				setTimeout(function(){window.location = "/approval/overCost_show?overCostApproval.id="+id;},1000);	  
			}else{
				dialog(returnStr,"error",true,1);
			}
			$("#allSubmit").show();
	        return false;
		});
    });
});


/* 填充确认页面邮箱列表 */
function fillMaillList() {
	var createUserId = $("#createUserId").val();
	var buId = $("#buId").val();
	var deptId = $("#deptId").val();
	var regionId = $("#regionId").val();
	var url = "/approval/overCost_showConfirmMail?overCostApproval.createUserId="+ createUserId 
			+ "&overCostApproval.deptId=" + deptId
			+ "&overCostApproval.buId=" + buId 
			+ "&overCostApproval.regionId=" + regionId;
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#allSubmit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,10);
			return false;
		}else if(nodeNoApprovalUser){
			$("#allSubmit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,10);
			return false;
		}else{
			$("#allSubmit").show();
		}
	});
}
function validateFunction(){
	$("#createUserName").addClass("validate[required]");
	$("#createUserId").addClass("validate[required]");
	
	$("#buName").addClass("validate[required]");
	$("#buId").addClass("validate[required]");
	
	$("#deptName").addClass("validate[required]");
	$("#deptId").addClass("validate[required]");
	
	$("#regionName").addClass("validate[required]");
	$("#regionId").addClass("validate[required]");
	
	$("#currencyName").addClass("validate[required]");
	//$("#currencyId").addClass("validate[required]");
	
	$("#year").addClass("validate[required]");
	$("#month").addClass("validate[required]");
	$("#limit").addClass("validate[required,custom[positiveNumber]]");
	$("#remark").addClass("validate[required]");
}