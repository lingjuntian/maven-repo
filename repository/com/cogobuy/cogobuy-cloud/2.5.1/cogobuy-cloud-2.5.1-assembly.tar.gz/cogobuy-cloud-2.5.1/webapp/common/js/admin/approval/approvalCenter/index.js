/**
 * Created by shunwang on 2016/4/11.
 */
$(function () {
    var pnames=$("#pnames").val();
    var $check = $(".approvalType");
    var allSelect=true;
    if(pnames!=""){
       var atype=pnames.split(",");
       for(var j=0 ;j<$check.length;j++){
          for(var k=0 ;k<atype.length;k++){
              if(atype[k]==$check.eq(j).attr("tdTag")){
                  $check.eq(j).attr("checked","true");
              }
          }
       }
    }
    for(var t=0 ;t<$check.length;t++){
        if($check.eq(t).attr("checked")==false){
            allSelect=false;
            break;
        }
    }
    if(allSelect==true){$("#allSelect").attr("checked",true)}

    //拼装returnRul
     var a =$(".retureUrl");
       for(var c=0;c< a.length;c++){
           var url=a.eq(c).attr("tdTag");
           if(pnames!=""){
               url=url+"/approval/approvalCenter_index?pnames="+pnames;
           }
           a.eq(c).attr("href",url)
       }




    //勾选一个
    $(".approvalType").click(function () {
        execSelect();
    });
    //勾选查询所有单据
    $("#allSelect").click(function(){
        var $check = $(".approvalType");
        if($(this).attr("checked")==true){
            $check.attr("checked",true);
        }else{
            $check.attr("checked",false);
        }
        execSelect();
    })

    function execSelect(){
        var approvalTypes = "";
        for (var i = 0; i < $check.length; i++) {
            if ($check.eq(i).attr("checked") == true) {
                var approvalType = $check.eq(i).attr("tdTag")+',';
                approvalTypes = approvalTypes+approvalType ;
            }
        }
        approvalTypes=approvalTypes.substring(0,approvalTypes.length-1);
        var url="/approval/approvalCenter_index?pnames="+approvalTypes;
        window.location=url;
    }



});


