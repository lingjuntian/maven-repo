/*全选、反选js*/
$(function () {
    /*全选*/
	$("[selectTag='select-all']").click(function(){
        $("[type='checkbox']").attr("checked",true);
    });
    
    /*反选*/
    $("[selectTag='select-opposite']").click(function(){
    	$("[type='checkbox']").each(function(){   
    		if($(this).attr("checked")){
    			$(this).attr("checked",false);
    		}else{
    			$(this).attr("checked",true);
    		} 
	  	}); 
    });
});

/* 监控复选框中的父选框（id为parentId），当父选框选中时，子选框（name为subName）全部选中，反之全取消选中*/
function parentSelect(parentId, subName){
	if($("#"+parentId).attr("checked")){
		$("[type=checkbox][name="+subName+"]").each(function(){   
			$(this).attr("checked",true);
		}); 
	}else{
		$("[type=checkbox][name="+subName+"]").each(function(){   
			$(this).attr("checked",false);
		}); 
	}
}
/* 监控复选框中的子选框（name为subName），当子选框全部选中时，父选框（id为parentId）选中，反之取消选中*/
function subSelect(subName, parentId){
	var isCheckedForSub = true;
	$("[type=checkbox][name="+subName+"]").each(function(){   
		if(!$(this).attr("checked")){
			isCheckedForSub = false;
		} 
  	});
  	if(isCheckedForSub){
  		$("#"+parentId).attr("checked",true);
  	}else{
  		$("#"+parentId).attr("checked",false);
  	}
}
