$(function(){
	/* 模拟select下拉列表 */
	$(".options-select .select").click(function(event){
		event.stopPropagation();
		$(".popup-tips").fadeOut("slow");
		$(".input-box").css({zIndex:"0"});
		$(this).parents(".input-box").css({zIndex:"88"});
		var optionsObj = $(this).parent(".options-select").find(".options") ;
		$(".options-select .options").hide();
		if(optionsObj.hasClass("none")){
			optionsObj.show();
			optionsObj.removeClass("none");
		}else{
			optionsObj.hide();
			optionsObj.addClass("none");
		}
	})
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input").val($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input[id$=Id]").val($(this).attr("labelId"));
		if($(this).attr("tagN") == "buY"){
			$("#dispathNo").val("");
			ajaxByBu($("#ybuId").val(),"buY");
		}
		if($(this).attr("tagN") == "buN"){
			$("#person_Name").val("");
        	$("#person_Id").val("");
			ajaxByBu($("#nbuId").val(),"buN");
		}
		$(this).parents(".options-select").find(".options").hide();
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	});
	
	$(".options-select .options,.popup-tips").click(function(event) {
		event.stopPropagation();
	});
	
	$(document).click(function(event) {
		$(".options-select .options").hide();
		$(".options-select .options").addClass("none");
		$(".popup-tips").fadeOut("slow");
	});
    /**给表单元素添加验证**/
    $("#dispathNo").addClass("validate[required]");
    $("#reason").addClass("validate[required]");
    $("#datepay").addClass("validate[required]");
    
    $("#person_Name").addClass("validate[required]");
    $("#customerName").addClass("validate[required]");
    $("#currencyId").addClass("validate[required]");
    $("#sum").addClass("validate[required],custom[positiveNumber]");
    $("#date").addClass("validate[required]");
    $("#reason3").addClass("validate[required]");
    $("#datepay3").addClass("validate[required]");
	
	
	/* 无发货单号 */
	$(".no-delivery").click(function(){
		var getID = $(this).attr("href");
		var $obj = $(this).parents(".form-credit-hold").find(".ul-list");
		$obj.hide();
		$("#"+getID).show();
	    $("#state").val(getID);
		return false;
	});
    /*确认*/
    $("#confirm").click(function(){
    	if($("#state").val()=="hasDeliveryNote"){ //有发货单
    		var error = $("#form1").validationEngine('validate');
    		if(error){
        		var dispatchNo=$("#dispathNo").val();
        		var url="/approval/creditHold_findDispatch?";
    		        url+="dispatchNo=" + dispatchNo;		    				
    			$("#show").load(url, function(data){	
    			});	 			   		
        		$("#datepay1").text($("#datepay").val());
        		$("#reason1").text($("#reason").val());
        		$("#notes1").text($("#notes").val());
        		$("#noDispath").hide();
    			$("#hasDispath").show();
    			$("#step1").hide();
    			$("#step2").show();
    			copyFileList();    
    		}
    	}else{                          //无发货单
    		var error = $("#form2").validationEngine('validate');
    		if(error){
    		$("#person2").text($("#person_Name").val());
    		$("#customerName2").text($("#customerName").val());
    		$("#currencyName2").text($("#currencyName").val());
    		$("#sum2").text($("#sum").val());
    		$("#date2").text($("#date").val());
    		$("#reason2").text($("#reason3").val());
    		$("#datepay2").text($("#datepay3").val());
    		$("#notes2").text($("#notes3").val());
    		$("#hasDispath").hide();
			$("#noDispath").show();
			$("#step1").hide();
			$("#step2").show();
			copyFileList();
    		}
    	}			
    });
	/* 上一步*/
	$("#stepOne").click(function(){
		$("#step2").hide();
    	$("#step1").show();
	});
	/* 提交*/
	$("#submit").click(function(){
		if($("#state").val()=="hasDeliveryNote"){
			$("#form1").ajaxSubmit(function(returnStr){
		        if (returnStr == "success") {
		          dialog("成功！","success",true,1);
			      setTimeout(function(){window.location = "/approval/creditHold_list";},1000);	        
		        } else if(returnStr == "error"){
		         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
		        }
			});
		}else{  
			$("#form2").ajaxSubmit(function(returnStr){
		        if (returnStr == "success") {
		          dialog("成功！","success",true,1);
		          setTimeout(function(){window.location = "/approval/creditHold_list";},1000);       
		        } else if(returnStr == "error"){
		         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
		        }
			});
		}
	});
	
	
	/* 日期控件*/
	$("input[id^=date]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}});
	});
	/* 客户名称 */
    $.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findCustomerList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.customerList != null){
				$("#customerName").autocomplete(data.customerList, {
					/**加自定义表头**/
					tableHead: "<div><span style='width:58%' class='col-2'>客户名称</span><span style='width:40%' class='col-1'>客户编码</span></div>",
					minChars: 0,
					width: 330,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span style='width:58%' class='col-2'>" + row.fullName + "</span>" +"<span  style='width:40%' class='col-1'>" + row.customerCode + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.fullName;
					},
					formatResult: function(row) {
						return row.fullName;
					}
					/*formatInputResult: function(data){
                    	autoCompleteCustomer(data)					
					},*/
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#customerId").val(data.id);
					$("#customerName").val(data.fullName);
				}).bind("unmatch", function(){
					$("#customerName").val("");
					$("#customerId").val("");
				});
			}
		}
	});    
});
function copyFileList(){
	var html = $("#fileListForCreate").html();
	if(html==""){
		$("#confirm_listBox").removeClass("box-content");
	}
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}
function ajaxByBu(buId,state){	
	if(state=="buY"){
		/* 发货单号 */
		$("#dispathNo").unautocomplete();
		$.ajax({
	        type:"GET",
	        //url:encodeURI("/approvalajax/findAllDispatch"),
	        url:encodeURI("/approvalajax/findDispatchByBu?buId="+buId),
	        dataType:"json",
	        success:function(data, textStatus){
	            if(data != null && data.dispatchList != null){
	            	$("#dispathNo").autocomplete(data.dispatchList, {
	                    /**加自定义表头**/
	                    tableHead: "<div><span class='col-1'>发货单号</span></div>",
	                    minChars: 0,
	                    width: 330,
	                    matchContains: "true",
	                    autoFill: false,
	                    formatItem: function(row, i, max) {
	                        return "<div><span class='col-1'>"+row.dispatchNumber+"</span></div>";
	                    },
	                    formatMatch: function(row, i, max) {
	                        return row.dispatchNumber;
	                    },
	                    formatResult: function(row) {
	                        return row.dispatchNumber;
	                    }
	                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
	                	$("#dispathNo").val(data.dispatchNumber);
	                }).bind("unmatch", function() {/**没有匹配时**/
	                	$("#dispathNo").val("");
	                }).bind("unautocomplete", function() {              	
	            		select.unbind();
	            		$input.unbind();
	            		$(input.form).unbind(".autocomplete"); 
	            		/**当unautocomplete时将select中的数据清空**/
	            		cache.flush();
	            	});
	            }
	        }
	    });  
	}else if(state=="buN"){
		$("#person_Name").unautocomplete();
		/* 业务员 */
		$.ajax({
	        type:"GET",
	       // url:encodeURI("/approvalajax/findAllPerson"),
	        url:encodeURI("/approvalajax/findPersonListByBu?buId="+buId),
	        dataType:"json",
	        success:function(data, textStatus){
	            if(data != null && data.personList != null){
	            	$("#person_Name").autocomplete(data.personList, {
	                    /**加自定义表头**/
	                    tableHead: "<div><span>姓名</span></div>",
	                    minChars: 0,
	                    width: 300,
	                    matchContains: "true",
	                    autoFill: false,
	                    formatItem: function(row, i, max) {
	                        return "<div><span>"+row.personName+"</span></div>";
	                    },
	                    formatMatch: function(row, i, max) {
	                        return row.personName;
	                    },
	                    formatResult: function(row) {
	                        return row.personName;
	                    }
	                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
	                	$("#person_Name").val(data.personName);
	                	$("#person_Id").val(data.id);
	                }).bind("unmatch", function() {/**没有匹配时**/
	                	$("#person_Name").val("");
	                	$("#person_Id").val("");
	                });
	            }
	        }
	    });  
	}
}
