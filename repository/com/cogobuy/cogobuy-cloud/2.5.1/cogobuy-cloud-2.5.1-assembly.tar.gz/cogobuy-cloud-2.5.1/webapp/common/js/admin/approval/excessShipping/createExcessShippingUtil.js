var autoCompleteInventoryList;
$(function() {
	/*增加验证*/
	$("#ledger,#customerFullName,#personName,#currencyName,#currencyCode,#cdlcode,[tdTag=inventoryCode]").addClass("validate[required]");
	$("[tdTag=unitPrice]").addClass("validate[required,custom[amountSixPoint]]");
	$("[tdTag=quantity]").addClass("validate[required,custom[creditLimit]]");
	/* 模拟select下拉列表选择值 */
	optionsaBind();
	/*增加显示提交按钮*/
	$(document).keydown(function(event){ 
		 if (event.ctrlKey && event.keyCode == 122) {
			 $("#submit").show();
		 }
	});
	/* 隐藏查询提示信息*/
	$("#msg").hide();
    /*改变发货单号时填充详细表内容*/
    $("#cdlcode").bind('change',autoAddDetail);
     
});

/*计算行含税总和、税额等*/
function calTaxSum($trs){
    var sum=0;
	for(var i=0;i<$trs.size();i++ ){
		var $tr = $trs.eq(i);
		/*数量*/
		var quantity = changeNum($tr.find("input[tdTag=quantity]").val());
		/*无税单价*/
		var unitPrice = changeNum($tr.find("input[tdTag=unitPrice]").val());
		/*无税总额*/
		sum = multiply(quantity,unitPrice);
		$tr.find("input[tdTag=sum]").val(changeFourDecimal(sum));
	}	
}

/*绑定下拉选项*/
function optionsaBind(){
	$(".options-select .options a").unbind("click");
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=show]").val($(this).attr("vshow"));
		var $vid = $(this).attr("vid");
		$(this).parents(".options-select").find("input[tag=id]").val($vid);
		var $selectTag = $(this).attr("selectTag");
		/*当改变账套时，需要重新加载页面,重新加载详细表内容*/
		if($selectTag == 'ledger'){
			/*重新加载页面内容*/
			autoAddDetail();
		}
		$(this).parents(".options-select").find("input[tag=show]").validationEngine('hidePrompt');
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	});
}


/*取回数值，没有值的为0*/
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}



/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
	var $trNum = $tbody.find("tr").size();
	for ( var i = $trNum-1; i >= 0; i--) {
		$trNum = $tbody.find("tr").size();
		var $tr = $tbody.find("tr").eq(i);
		if (checkEmptyTr($tr)) {
			if ($trNum > 1) {
				$tr.remove();
			}
		}
	}
}

/* 验证空行 */
function checkEmptyTr($tr) {
	var $inputNum = $tr.find("input").size();
	var flag = true; // 为空
	for ( var i = 0; i < $inputNum; i++) {
		var $input = $tr.find("input[filterNull!=true]").eq(i);
		if ($.trim($input.val()) != "") {
			flag = false; // 不为空
			break;
		}
	}
	return flag;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
	var $trs = $tbody.find("tr");/* 获取所有tr */
	var firstName = "esMain.detailList";/* 前缀名称 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $inputNum = $tr.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $tr.find("input").eq(j);
			$input.attr("id", $input.attr("tdTag") + numtag);
			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
		}
		$tr.find("input[tdTag=sub_index]").val(i);
	}
}

/*用于上传文件使用*/
function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}

//判断是否为非负整数
function isInteger(num){
    return /^\+?[1-9][0-9]*$/.test(num);
}

//自动填充内容
function autoAddDetail(){
if($("#cdlcode").val()!=''&&$("#cdlcode").val()!=null&&$("#ledger").val()!=null&&$("#ledger").val()!=''){
	//清空页面数据
	$("#detailListTbody").empty();
	$("#customerFullName").val("");
	$("#customerShortName").val("");
	$("#customerCode").val("");
	$("#licensecode").val("");
	$("#personName").val("");
	$("#personCode").val("");
	$("#depCode").val("");
	$("#personEmail").val("");
	$("#currencyName").val("");
    //异步请求自动填充详细表格内容
	 $("#msg").show();
     $.ajax({
       url:encodeURI("/approvalajax/esApproval_autoAddDetail"),
       type:"post",
       data:{ledger:$("#ledger").val(),cdlcode:$("#cdlcode").val()},
       dataType:"json",
       success:function(data){
    	   $("#msg").hide();
           if(data.list.length!=null&&data.list.length!=0){
               /*自动填充业务员、客户名称、币种*/
               var detail=data.list[0];
               $("#customerFullName").val(detail.customerFullName);
               $("#customerShortName").val(detail.customerShortName);
               $("#customerCode").val(detail.customerInventoryCode);
               $("#licensecode").val(detail.licensecode);
               $("#currencyName").val(detail.currencyName);
               $("#currencyCode").val(detail.currencyCode);
               $("#personName").val(detail.personName);
               $("#personCode").val(detail.personCode);
               $("#personEmail").val(detail.personEmail);
               /*自动填充详细表内容*/
               for(var i=0;i<data.list.length;i++){
                   var tdStr="<tr><td class='first supplier-model'><div> "+
                       "<input type='text' tdTag='inventoryCode' class='input-text disabled' value='"+data.list[i].inventoryCode+"'/> "+
                       "<input type='hidden' tdTag='cusInvName' class='input-text disabled' value=''/> "+
                       "<input type='hidden' tdTag='sum' class='input-text' value='' /> "+
                       "<input type='hidden' tdTag='productLineName' class='input-text' value='' /> "+
                       "<input type='hidden' tdTag='sub_index' value='' /></div></td> "+
                       "<td class='material-number'><div><input type='text' tdTag='customerInventoryCode' class='input-text disabled' readonly='readonly' value='"+data.list[i].customerInventoryCode+"'/></div></td> "+
                       "<td class='product-desc'><div><input type='text' tdTag='inventoryName' class='input-text disabled' readonly='readonly' value='"+data.list[i].inventoryName+"'/></div></td> "+
                       "<td class='quantity'><div><input type='text' tdTag='quantity' maxlength='12' class='input-text disabled' value='"+data.list[i].iquantity+"' /></div></td> "+
                       "<td class='price price0'><div><input type='text' tdTag='unitPrice'  class='input-text disabled' value='"+data.list[i].unitPrice+"' /></div></td></tr>";
                   $("#detailListTbody").append(tdStr);
               }
               //计算合计
               calTaxSum($("#detailListTbody").find("tr"));
               
           }else{
               dialog("该帐套和发货单下没有超期超额详细列表！请重新填写或联系管理员");
           }

       },
       error:function(){
    	   $("#msg").hide();
           dialog("服务器异常！请联系管理员");
               }

       });
	 }
	
	}





