
$(function () {
    
    //添加一行银行信息
	$("#addBankInfoButton").unbind("click").click(function () {
		addBankInfo();
		return false;
	});
	//添加一行帐套信息
	$("#addLedgerInfoButton").unbind("click").click(function () {
		addLedgerInfo();
		return false;
	});
	
});

//添加一行银行信息
function addBankInfo(object){ 
   	var count = $("#bankInfoListCount").val();
   	if(object==null){
   		object=$("#bankInfo ul:last");
   	}
	count++;
	$("#bankInfoListCount").val(count);		
	var ul = $("#copybankInfo").clone();
	//alert(ul.html());					
    ul.insertAfter($(object));
    ul.show();
	$("#creatCustomer_form").validationEngine('hide');
    resetBankInfoListNO();
}

//删除银行信息
function delBankInfo(index){
	
}
//重置银行信息的行号
function resetBankInfoListNO(){
	var len = $("#bankInfo ul").size();
	//alert(len);
	for(var i = len - 1; i >= 0; i--){
		var ul = $("#bankInfo ul").eq(i);
		ul.find("[name$=bank]").attr("name", "bankInfoList[" + i + "].bank");
		ul.find("[name$=bankAccount]").attr("name", "bankInfoList[" + i + "].bankAccount");
	}
}
/**
	添加一个供应商
	action1：copy one
	action2: hidden one
	action3: add one link
	action4: resetNo
**/
//添加一个供应商关联信息
function addLedgerInfo(object){ 
	//firstLedgerInfo
   	var count = $("#addLedgerInfoCount").val();
   	if(object==null){
   		object=$("div.[name=ledgerInfo]:last");
   	}
	count++;
	$("#addLedgerInfoCount").val(count);		
	var newLedgerInfo = $("#firstLedgerInfo").clone();
    newLedgerInfo.insertAfter($(object));
    
    $("div.[name=ledgerInfo]").hide();
	newLedgerInfo.show();
	$("#creatCustomer_form").validationEngine('hide');
    addLedgerLink();
    resetLedgerInfoListNO();//重置供应商关联信息的行号,link
    resetEleFunction();//为新的标签绑定事件
    
    //高亮链接标签
    var listIndex=newLedgerInfo.find("[name$=ledger][name^=customerLedgerList]").attr("index");
    $("[name=Ledger_Link_A]").removeClass('selected');
    $("[name=Ledger_Link_A][index="+listIndex+"]").addClass("selected");
    
}

//添加一个查看已经关联帐套的链接的名字
function  addLedgerLink(){
	//<a href="#connection1" title="关联1">关联1</a>
	
	var ledgers=$("[name$=ledger]").attr("value");
	var object=$("#Ledger_Link_P a:first");
	//copy first one
	var newLedgerLink = object.clone();
    newLedgerLink.insertAfter($(object));
}



//重置供应商关联信息的行号,link
function resetLedgerInfoListNO(){
	var len = $("[name=ledgerInfo]").size();
	//alert(len);
	for(var i = len - 1; i >= 0; i--){
		var ledgerInfo = $("[name=ledgerInfo]").eq(i);
		
		ledgerInfo.attr("index", "" + i + "");
		
		ledgerInfo.find("[name=ledgerTitle]").attr("index", "" + i + "");
		
		ledgerInfo.find("[class=del]").attr("index", "" + i + "");
		ledgerInfo.find("[class=del]").unbind("click");
		ledgerInfo.find("[class=del]").bind("click",function(){
			delLedger($(this).attr("index"));
		});
		
		ledgerInfo.find("[name$=ledger]").attr("name", "customerLedgerList[" + i + "].ledger");
		ledgerInfo.find("[name$=ledger]").attr("index", "" + i + "");
		
		ledgerInfo.find("[name$=shippingTypeId]").attr("name", "customerLedgerList[" + i + "].shippingTypeId");
		ledgerInfo.find("[name$=TShippingType.shippingName]").attr("name", "customerLedgerList[" + i + "].TShippingType.shippingName");
		ledgerInfo.find("[name$=credit]").attr("name", "customerLedgerList[" + i + "].credit");
		
		ledgerInfo.find("[name$=payConditionId]").attr("name", "customerLedgerList[" + i + "].payConditionId");
		ledgerInfo.find("[name$=TPayCondition.payName]").attr("name", "customerLedgerList[" + i + "].TPayCondition.payName");
		
		ledgerInfo.find("[name$=chineseAddress]").attr("name", "customerLedgerList[" + i + "].shipAddressList[0].chineseAddress");
		ledgerInfo.find("[name$=englishAddress]").attr("name", "customerLedgerList[" + i + "].shipAddressList[0].englishAddress");
		ledgerInfo.find("[name$=unit]").attr("name", "customerLedgerList[" + i + "].shipAddressList[0].unit");
		
		ledgerInfo.find("[name$=name]").attr("name", "customerLedgerList[" + i + "].shipAddressList[0].TCustomerContact.name");
		ledgerInfo.find("[name$=phone]").attr("name", "customerLedgerList[" + i + "].shipAddressList[0].TCustomerContact.phone");
		ledgerInfo.find("[name$=fax]").attr("name", "customerLedgerList[" + i + "].shipAddressList[0].TCustomerContact.fax");
	}
	//link
	for(var j = len - 1; j >= 0; j--){
		//alert(j);
		var ledgerA = $("[name=Ledger_Link_A]").eq(j);
		ledgerA.attr("index", "" + j + "");
		ledgerA.html("关联"+$("[name=customerLedgerList[" + j + "].ledger]").attr("value"));
		ledgerA.attr("title","关联"+$("[name=customerLedgerList[" + j + "].ledger]").attr("value"));
		ledgerA.unbind("click");
		ledgerA.bind("click",function(){
			showLedger($(this).attr("index"));
		});
	}
	
}
//切换显示不同的帐套信息
function showLedger(index){
	$("[name=ledgerInfo]").hide();
	$("[name=ledgerInfo][index="+index+"]").show();
	$("[name=Ledger_Link_A]").removeClass('selected');
    $("[name=Ledger_Link_A][index="+index+"]").addClass("selected");
	return false;
}
//删除一个帐套信息
function delLedger(index){
	if(!confirm('确定删除吗?')){
		return false;
	}
	var count=$("#addLedgerInfoCount").val();
	count--;
	$("#addLedgerInfoCount").val(count);
	$("[name=ledgerInfo][index="+index+"]").remove();
	$("[name=Ledger_Link_A][index="+index+"]").remove();
	
	resetLedgerInfoListNO();//重置供应商关联信息的行号,link
    resetEleFunction();//为新的标签绑定事件
    
    showLedger(0);
    
}

//检查是否有相同的帐套
function checkLedger(){
	var ledgers=$("[name$=ledger][name^=customerLedgerList]");
	alert(ledgers.size());

}
 
//为新的标签绑定事件
function resetEleFunction(){
	/* 点击收缩 */
	$(".auto-info .updown").unbind("click").click(function(){
		var $a = $(this) ;
		if($a.hasClass("up")){
			$a.next("").slideUp("slow",function(){$a.removeClass("up")});
		}else{
			$a.next("").slideDown("slow",function(){$a.addClass("up")});
		}
	});
	
	/* 模拟select下拉列表 */
	$(".options-select .select").unbind("click").click(function(event){
		event.stopPropagation();
		$(".input-box").css({zIndex:"1"});
		$(this).parents(".input-box").css({zIndex:"88"});
		var optionsObj = $(this).parent(".options-select").find(".options") ;
		$(".options-select .options").hide();
		if(optionsObj.hasClass("none")){
			optionsObj.show();
			optionsObj.removeClass("none")
		}else{
			optionsObj.hide();
			optionsObj.addClass("none")
		}
	})
	$(".options-select .options a").unbind("click").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vhidden"));
		//$(this).parents(".options-select").find("input[type='hidden']").val($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input[type='hidden'][id='selectedId']").val($(this).attr("vhiddenId"));
		$(this).parents(".options-select").find("input[type='hidden'][id='selectedValue']").val($(this).attr("vhidden"));
		//触发修改 关联帐套的链接的名字
		if(this.name="select_ledger_options"){
			var listIndex=$(this).parents(".options-select").find("input[type='hidden'][id='selectedId']").attr("index");
			$("#Ledger_Link_P [index="+listIndex+"]").html("关联"+$(this).attr("vhiddenId"));
			$("#Ledger_Link_P [index="+listIndex+"]").attr("title","关联"+$(this).attr("vhiddenId"));
			$("[name=ledgerTitle][index="+listIndex+"]").html("关联供应商"+$(this).attr("vhiddenId"));
		}
		$(this).parents(".options-select").find(".options").hide();
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	})
	
	$(".options-select .options").unbind("click").click(function(event) {
		event.stopPropagation();
	});
	
	$(document).unbind("click").unbind("click").click(function(event) {
		$(".options-select .options").hide();
		$(".options-select .options").addClass("none");
	});
	
	/* 币种选择 */
	$(".currency").unbind("focus").focus(function(){
		$(".input-box").css({zIndex:"1"});
		$(this).parents(".input-box").css({zIndex:"88"});
		$(".input-box .popup-tips").fadeOut("slow");
		$(this).next(".popup-tips").fadeIn("slow");
	}).unbind("blur").blur(function(){
		$(".input-box .popup-tips").fadeOut("slow");
	});
	$(".input-box .popup-tips label").unbind("click").click(function(){
		$(this).parents(".popup-tips").prev().val($(this).attr("vhidden"));
		$(this).parents(".popup-tips").fadeOut("slow");
	});
} 
 
/**Layer框中选中某个客户**/
function createCustomerSelectCustomer(customerId, customerName, customerCode){
	$("[name=customer.parentCustomerId]").val(customerId);
	$("#customerName").val(customerName);
}

/**Layer框中选中某个业务员**/
function createCustomerSelectPerson(personId, personName, departmentName, departmentId){
	$("#personName").val(personName);
	$("[name=customerLedger.personId]").val(personId);
}
