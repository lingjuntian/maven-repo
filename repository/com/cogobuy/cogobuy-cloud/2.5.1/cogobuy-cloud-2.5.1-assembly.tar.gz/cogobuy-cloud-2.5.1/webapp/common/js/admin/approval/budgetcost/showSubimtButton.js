$(function(){
	/*增加显示提交按钮*/
	$(document).keydown(function(event){ 
		 if (event.ctrlKey && event.keyCode == 122) {
			 $("#allSubmit").show();
		 }
	});
	
	//确认提交
    $("#allSubmit").click(function(){
    	//去掉复制用的tr
    	$("tr[hide=hide]").remove();
    	//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#historyForm").append(inputStr);
    		}
    	});
    	$("#allSubmit").hide();
		$("#historyForm").attr("action","/approval/budgetCost_create");
		$("#historyForm").ajaxSubmit(function(returnStr){
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功！","success",true,1);
				setTimeout(function(){window.location = "/approval/budgetCost_show?budgetCostApproval.id="+id;},1000);	  
			}else{
				$("#allSubmit").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
    });
});