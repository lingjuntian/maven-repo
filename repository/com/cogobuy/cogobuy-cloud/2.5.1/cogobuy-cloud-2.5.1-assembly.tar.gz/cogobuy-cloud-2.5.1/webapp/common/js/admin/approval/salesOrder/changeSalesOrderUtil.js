var autoCompleteInventoryList;
$(function() {
	/*增加验证*/
	$("[tdTag=inventoryCode]").addClass("validate[required]");
	$("[tdTag=taxUnitPrice],[tdTag=unitPrice]").addClass("validate[required,custom[amountSixPoint]]");
	$("[tdTag=quantity]").addClass("validate[required,custom[creditLimit]]");
	/*加载存货编码*/
	addInventoryAutoComplete($("#defAddTr").find("input[tdTag=inventoryCode]"));
	/*增加日期控件*/
	$("input[tdTag=expectDate]").click(function() {
		WdatePicker();
	});
	$("input[tdTag=expectDate]:last").val(GetTodayDateStr());
	/*增加显示提交按钮*/
	$(document).keydown(function(event){ 
		 if (event.ctrlKey && event.keyCode == 122) {
			 $("#submit").show();
		 }
	});
	/* 添加一行 */
	$("tr input").click(function(){
		var $tr = $(this).parents("tr");
		if($tr.nextAll().length==0){
			addTr($tr);
		}
	});
	/*删除一行*/
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $length = $obj.parents("tbody").find("tr").length;
		if($length<2){
			dialog("请最少保留1行","warning",false,2);
			return false;
		}
		delTr($obj);
	});
	/*打开、关闭行*/
	$("[data-name=work]").click(function(){
		var $obj = $(this).parents("tr");
		if($(this).hasClass("open-text")){
			changeClosed($obj,"","");
			$obj.find("[readOrChange]").attr("readonly",false).removeClass("disabled");
			$(this).removeClass("open-text");
			$(this).text("关闭");
			$(this).attr("title","关闭");
		}else{
			changeClosed($obj,$("#closeStatus").val(),"");
			$obj.find("[readOrChange]").attr("readonly",true).addClass("disabled");
			$(this).addClass("open-text");
			$(this).text("打开");
			$(this).attr("title","打开");
		}
	});
	/*绑定根据含税单价、税率 算无税单价、合计*/
	$("input[tdTag=taxUnitPrice]").bind("change",function(){ 
		/* 税率 */
		var taxRate = changeNum($("#taxRate").val());
		/*含税单价*/
		var taxUnitPrice = changeNum($(this).parents("tr").find("input[tdTag=taxUnitPrice]").val());
		/*无税单价*/
		var unitPrice = FloatDiv(multiply(taxUnitPrice,100),add(100,taxRate));
		$(this).parents("tr").find("input[tdTag=unitPrice]").val(changeSixDecimal(unitPrice));
		calTaxSum($(this).parents("tr"));
	});
	/*绑定根据无税单价、税率 算含税单价、合计*/
	$("input[tdTag=unitPrice]").bind("change",function(){ 
		/* 税率 */
		var taxRate = changeNum($("#taxRate").val());
		/*无税单价*/
		var unitPrice = changeNum($(this).parents("tr").find("input[tdTag=unitPrice]").val());
		/*含税单价*/
		var taxUnitPrice = multiply(unitPrice,FloatDiv(add(100,taxRate),100));
		$(this).parents("tr").find("input[tdTag=taxUnitPrice]").val(changeSixDecimal(taxUnitPrice));
		calTaxSum($(this).parents("tr"));
	});
	/*绑定数量每条详情的合计*/
	$("input[tdTag=quantity]").bind("change",function(){ 
		calTaxSum($(this).parents("tr"));
	});
});

/*计算行含税总和、税额等*/
function calTaxSum($tr){
	/*数量*/
	var quantity = changeNum($tr.find("input[tdTag=quantity]").val());
	/*含税单价*/
	var taxUnitPrice = changeNum($tr.find("input[tdTag=taxUnitPrice]").val());
	/*无税单价*/
	var unitPrice = changeNum($tr.find("input[tdTag=unitPrice]").val());
	/*含税总额*/
	var taxSum = multiply(quantity,taxUnitPrice);
	/*无税总额*/
	var sum = multiply(quantity,unitPrice);
	/*税额*/
	var tax = FloatSub(taxSum,sum);
	$tr.find("input[tdTag=taxSum]").val(changeFourDecimal(taxSum));
	$tr.find("input[tdTag=sum]").val(changeFourDecimal(sum));
	$tr.find("input[tdTag=tax]").val(changeFourDecimal(tax));
}

/*增加存货编码自动匹配*/
function addInventoryAutoComplete($input){
	$input.autocomplete(encodeURI("/approvalajax/salesOrderApproval_findInventoryList?ledger=" + $("#ledger").val()+"&customerCode="+$("#customerCode").val()), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>存货编码</span> <span class='col-2'>存货名称</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.inventoryList == null){
            	return rows;
            }
            for(var i=0; i<data.inventoryList.length; i++){    
                rows[rows.length] = {    
                    data:data.inventoryList[i],              //下拉框显示数据格式   
                    value:data.inventoryList[i].invCode,     //选定后实际数据格式  
                    result:data.inventoryList[i].invCode   //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.invCode + "</span> " + "<span class='col-2'>" + row.invName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.invCode + row.invName;;
		},
		formatResult: function(row) {
			return row.invCode;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		clearTr($(this).parents("tr"));
		$(this).parents("tr").find("[tdTag=inventoryCode]").val(data.invCode);
		$(this).parents("tr").find("[tdTag=cusInvName]").val(data.erpCusInvName);
		$(this).parents("tr").find("[tdTag=eccn]").val(data.eccnNo);
		if(data.mpq != null){
			$(this).parents("tr").find("[tdTag=mpq]").val(data.mpq);
		}
		$(this).parents("tr").find("[tdTag=productLineName]").val(data.unionName);
		$(this).parents("tr").find("[tdTag=customerInventoryCode]").val(data.erpCusInvCode);
		$(this).parents("tr").find("[tdTag=inventoryName]").val(data.invName);
		$(this).parents("tr").find("[tdTag=cost]").val(data.cost);
	}).bind("unmatch", function(){
		clearTr($(this).parents("tr"));
	});
}

/*修改关闭人*/
function changeClosed($tr,closed,colseUserName){
	$tr.find("[tdTag=closed]").val(closed);
	$tr.find("[tdTag=closeUserName]").val(colseUserName);
}

/*清除行的数据*/
function clearTr($tr){
	$tr.find("input[filterNull!=true]").val("");
	$tr.find("[tdTag=inventoryCode]").validationEngine('hidePrompt');
}

/*取回数值，没有值的为0*/
function changeNum(num){
	if($.trim(num)==''){
		return 0;
	}
	return $.trim(num);
}

/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.removeAttr("hide");
	$copyTr.removeAttr("style");
	$copyTr.find("input[tdTag=expectDate]").val(GetTodayDateStr());
	$tr.after($copyTr);
	addInventoryAutoComplete($copyTr.find("input[tdTag=inventoryCode]"));
}
/* 删除行 */
function delTr($obj){
	$obj.validationEngine('hidePrompt');
	$obj.remove();
}

/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
	var $trNum = $tbody.find("tr").size();
	for ( var i = $trNum; i >= 0; i--) {
		$trNum = $tbody.find("tr").size();
		var $tr = $tbody.find("tr").eq(i);
		if (checkEmptyTr($tr)) {
			if ($trNum > 1) {
				$tr.remove();
			}
		}
	}
}

/* 验证空行 */
function checkEmptyTr($tr) {
	var $inputNum = $tr.find("input").size();
	var flag = true; // 为空
	for ( var i = 0; i < $inputNum; i++) {
		var $input = $tr.find("input[filterNull!=true]").eq(i);
		if ($.trim($input.val()) != "") {
			flag = false; // 不为空
			break;
		}
	}
	return flag;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput($tbody) {
	var $trs = $tbody.find("tr");/* 获取所有tr */
	var firstName = "salesOrder.orderDetails";/* 前缀名称 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $inputNum = $tr.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $tr.find("input").eq(j);
			$input.attr("id", $input.attr("tdTag") + numtag);
			$input.attr("name", firstName + numtag + "." + $input.attr("tdTag"));
			
		}
		$tr.find("input[tdTag=sub_index]").val(i);
		$tr.find("input[tdTag=rowNo]").val(i+1);
		$tr.find("input[tdTag=quantity]").addClass("validate[required,min["+changeNum($tr.find("input[tdTag=shipQuantity]").val())+"]]");
	}
}

/*用于上传文件使用*/
function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[onclick]").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}
