$(function() {
	$("#ledger").addClass("validate[required]");
	$("#vendorName").addClass("validate[required]");
	$("#personName").addClass("validate[required]");
	$("#maker").addClass("validate[required]");
	$("#procurementType").addClass("validate[required]");
	//$("#shippingTypeName").addClass("validate[required]");
	$("input[id^=updateQ]").addClass("validate[required,custom[numberFormar]]");
	$("input[id^=updateU]").addClass("validate[custom[amountSixPoint]]");
	/* 日期控件*/
	$("input[id^=updateD]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}});
	});
	
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		var $show = $(this).attr("vshow");
		var $id = $(this).attr("vid");
		$(this).parents(".options-select").find("input[tag=show]").val($show);
		$(this).parents(".options-select").find("input[tag=id]").val($id);
		if($(this).attr("tag")=="ledger"){ //帐套
			addPersonAutoComplete($("#personName"),$show);/*业务员*/
			addVendorAutoComplete($("#vendorName"),$show);/*供应商*/
			addShippingTypeList($show); /*发货方式*/
		}
		return false;
	});
	
	/* 弹出框 */
	$(".edit-text").click(function(){
 		var attr = $(this).attr("update");
 		var arry = attr.split("_");
 		$("div[show *= show]").show();
 		$("div[show *= update]").hide();
 		$.each(arry,function(i,k){
 			$("div[show = update"+arry[i]+"]").show();
 			$("div[show = show"+arry[i]+"]").hide();
 		});
		pagePopup(".popup-edit-qty",true);
	});
	
	/*修改*/
	$("#updateButton").click(function(){
		var error = $("#updateForm").validationEngine('validate'); 	
		if(error){
			$("#updateForm").ajaxSubmit(function(returnStr) {
				if(returnStr == "success"){
					dialog("成功","success",true,1);
					window.location.reload();	  
				}else{
					dialog("服务器繁忙，请联系管理员或稍后再试","unsuccess",true,1);
				}
		        return false;
			});
		}
	});
	
	/*取消*/
	$("#reset").click(function(){
		$("#updateForm").validationEngine("hide");
	});
		
	/*显示详情页面详细列表中Forecast的月份*/
	var myDate_detil = new Date($("#newDate").val());
	$("span[tag=month_detil]").each(function(i){
		var month = myDate_detil.getMonth()+ i + 2;
		if(month > 12){
			var newDate = new Date();
			newDate.setMonth(month);
			$(this).text(newDate.getMonth());
		}else{
			$(this).text(month);
		}
	});
	
	/*显示详情页面相关产品库存中PO、SO、Forecast的月份*/
	$("[tag=month1]").text($("#month_detil1").text());
	$("[tag=month2]").text($("#month_detil2").text());
	$("[tag=month3]").text($("#month_detil3").text());
	
	/*制单人*/
	autoCompleteMaker();
	
});
/*作废*/
function invalidApproval(parent,parentId,redirect){
	var test = confirm("确定不通过审核吗？");
	if(test){
		flowApproval.invalid(parent,parentId,redirect);
	}else{
		return;
	}
}

/*审批通过，直接到CSR*/
function approvalToCsr(parentId,redirect) {
	$(".button-yellow").hide();
	var data = {
		"prId" : parentId,
		"mails" : getApprovalMail()
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/pr_approvalToCsr"),
		data : data,
		success : function(returnStr) {
			if (returnStr == 'success') {
				dialog("成功！", "success", true, 2);
				window.location.href = redirect;
			} else {
				$(".button-yellow").show();
				dialog(returnStr, "unsuccess", true, 2);
			}
		}
	});
}

/*导入ERP*/
function erpApproval(redirect){
	var error = $("#erpForm").validationEngine('validate'); 	
	if(error){
		$("#erpApproval_id").hide();
		$("#erpForm").ajaxSubmit(function(returnStr) {
			if(returnStr == "success"){
				dialog("成功","success",true,1);
				window.location.href = redirect;  
			}else{
				$("#erpApproval_id").show();
				dialog(returnStr,"unsuccess",true,10);
			}
	        return false;
		});
	}
}

/*加载发货方式*/
function addShippingTypeList(ledger){
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/prApproval_findShippingTypeList?ledger="+ledger),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.shippingTypeList != null){
				$("#shippingTypeSelect").empty();
				setShippingTypeListSelect(data.shippingTypeList);
			}
		}
	}); 
}	

function setShippingTypeListSelect(shippingTypeList){
	var len = shippingTypeList.length;
	if(shippingTypeList != null && len > 0){
		$("#shippingTypeSelect").append("<li><a></a></li>");
		for(var i = 0; i < len; i++){
			$("#shippingTypeSelect").append("<li><a href=\"javascript:;\" vid=\"" + shippingTypeList[i].erpShipCode + "\" vshow=\""+shippingTypeList[i].erpShipName+"\">" + shippingTypeList[i].erpShipName + "</a></li>");
		}
	}
	$("#shippingTypeSelect a").unbind("click").bind("click", function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		var $show = $(this).attr("vshow");
		var $id = $(this).attr("vid");
		$(this).parents(".options-select").find("input[tag=show]").val($show);
		$(this).parents(".options-select").find("input[tag=id]").val($id);
	});
}

/*增加供应商自动匹配*/
function addVendorAutoComplete($input,ledger){
	$input.autocomplete(encodeURI("/approvalajax/prApproval_findVendorList?ledger="+ledger), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>供应商名称</span><span class='col-2'>供应商编码</span></div>",
		minChars: 0,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.vendorList == null){
            	return rows;
            }
            for(var i=0; i<data.vendorList.length; i++){    
                rows[rows.length] = {    
                    data:data.vendorList[i],              //下拉框显示数据格式   
                    value:data.vendorList[i].code,     //选定后实际数据格式  
                    result:data.vendorList[i].code     //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.venName + "</span> " + "<span class='col-2'>" + row.code + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.venName;
		},
		formatResult: function(row) {
			return row.venName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$("#vendorCode").val(data.code);
		$("#vendorName").val(data.venName);
	}).bind("unmatch", function(){
		$("#vendorCode").val("");
		$("#vendorName").val("");
	});
}
/*增加业务员自动匹配*/
function addPersonAutoComplete($input,ledger){
	$input.autocomplete(encodeURI("/approvalajax/prApproval_findPersonList?ledger="+ledger), {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>业务员名称</span><span class='col-2'>业务员CODE</span></div>",
		minChars: 0,
		width: 310,
		multiple: false,
		mustMatch: false,
		matchContains: false,
		matchSubset: false,
		autoFill: false,
		dataType: 'json',
		parse: function(data) {  
            var rows = [];  
            if(data == null || data.personList == null){
            	return rows;
            }
            for(var i=0; i<data.personList.length; i++){    
                rows[rows.length] = {    
                    data:data.personList[i],              //下拉框显示数据格式   
                    value:data.personList[i].erpPersonCode,     //选定后实际数据格式  
                    result:data.personList[i].erpPersonCode     //选定后输入框显示数据格式  
                };  
            }  
            return rows;  
        }, 
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.erpPersonName + "</span> " + "<span class='col-2'>" + row.erpPersonCode + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.erpPersonName;
		},
		formatResult: function(row) {
			return row.erpPersonName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$("#personCode").val(data.erpPersonCode);
		$("#personName").val(data.erpPersonName);
	}).bind("unmatch", function(){
		$("#personCode").val("");
		$("#personName").val("");
	});
}

/*制单人自动匹配*/
function autoCompleteMaker(){
	$.ajax({
		type:"GET",
		url:encodeURI("/erpsupportajax/cooperative_findErpUser"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.erpUserListAjax != null){
				$("#maker").autocomplete(data.erpUserListAjax, {
					/**加自定义表头**/
					tableHead:  "<div><span class='col-1'>制单人</span> <span class='col-2'>部门</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span class='col-1'>" + row.cuser_Name + "</span> " + "<span class='col-2'>" + row.cdept + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.cuser_Name;
					},
					formatResult: function(row) {
						return row.cuser_Name;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#maker").val(data.cuser_Name);
					$("#maker").validationEngine('hidePrompt');
				}).bind("unmatch", function(){
					$("#maker").val("");
				});
			}
		}
	});
}