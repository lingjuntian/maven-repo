$(document).ready(function () {

    //编辑情况下删除知会人
    $(".initReport").click(function(){
        delNotice($(this)[0],$(this).attr("tdTag"));
        $(this).closest("div").remove();
    })

    /*绑定回车事件*/
    $("#searchProjectForm [name^=keyword]").keydown(function (event) {
        if (event.keyCode == 13) {
            $("#searchProjectForm").submit();
            return false;
        }
    });
    /*绑定回车事件*/
    $("#searchProjectForm [name^=personCharge]").keydown(function (event) {
        if (event.keyCode == 13) {
            $("#searchProjectForm").submit();
            return false;
        }
    });
    //下拉框选值
    $(".oldRemindCycle").click(function () {
        $("#oldRemindCycle").val($(this).attr("vhiddenId"));
    })
    $(".remindCycleDay").click(function () {
        $("#remindCycleDay").val($(this).attr("vhiddenId"));
    })
    $(".priorityId").click(function () {
        $("#priorityId").val($(this).attr("vhiddenId"))
    })
    $(".effectId").click(function () {
        $("#effectId").val($(this).attr("vhiddenId"))
    })
    $(".status").click(function () {
        $("#status").val($(this).attr("vhiddenId"))
    })
    //人员提示
    initFindUser();
    /* 日期控件 */
    $("#startTime").click(function () {
        WdatePicker();
    });
    $("#endTime").click(function () {
        WdatePicker({
            onpicked: function () {
            },
            minDate: $('#startTime').val()
        });

    });

    $(".table-summary .add-text").click(function (event) {
        event.stopPropagation();
        $(this).parents(".projects-list").css({"z-index": 99, "position": 'relative'});
        $(".poptip-project-add").removeClass("none");
    });
    $(".poptip-actions .cancel-text,.poptip-close").click(function () {
        $(this).parents(".projects-list").css({"z-index": 66, "position": 'static'});
        $(this).parents(".poptip").addClass("none");
        hideViladata();
    });
    /* 模拟select下拉列表 */
    $(".options-select .select").click(
        function (event) {
            if ($(this).parents(".options-select").hasClass("disabled")) {
                return false;
            }
            event.stopPropagation();
            $(".options-select .select").removeClass("select-focus");
            $(this).addClass("select-focus");
            $(".input-box").css({
                zIndex: "0",
                position: "relative"
            });
            $(this).parents(".input-box").css({
                zIndex: "88"
            });
            var $optionsObj = $(this).parent(".options-select").find(
                ".options");
            $optionsObj = $optionsObj.length ? $optionsObj : $(this)
                .parent(".options-select").find(".options-checkbox");
            $(".options-select .options,.options-select .options-checkbox")
                .addClass("none");
            $optionsObj.removeClass("none");
        });
    $(".options-select .options a").click(function () {
        var $obj = $(this).parents(".options-select");
        $obj.find(".select").removeClass("select-focus");
        $obj.find(".select").find("span").text($(this).attr("vhidden"));
        // 把选择框的labelId的值赋值给input（id中含有Id）
        if ($obj.find("input[id=remindCycleId]").val() < 100) {
            swtcihAndBindselect($(this).attr("vhiddenId"));
            $("[name='serviceFollow.remindCycle']").validationEngine('hidePrompt');
        }
        $obj.find("input[id$=Id]").val($(this).attr("vhiddenId"));

        $obj.find(".options").addClass("none");
        $obj.find(".options").find("a").removeAttr("data-selected");
        $(this).attr("data-selected", "selected");
        return false;
    });

    /** * 创建project ********* */
    $("[id='showAdd']").click(function () {
//		alert('dddd');
        initFindUser();
    });
    /* 日期控件 */
    $("[name='serviceFollow.startTime']").click(
        function () {
            WdatePicker();
        });
    $("[name='serviceFollow.endTime']").click(function () {
        WdatePicker({
            onpicked: function () {
            },
            minDate: $("[name='serviceFollow.startTime']").val()
        });
    });
    /** * 创建project ********* */
    /* 日期控件 */
    $("[name='project.planStartTime']").click(
        function () {
            WdatePicker();
        });
    $("[name='project.planEndTime']").click(function () {
        WdatePicker({
            onpicked: function () {
            },
            minDate: $("[name='project.planStartTime']").val()
        });
    });
    $("[name=project.name]").click(function () {
        $("[name='project.name']").validationEngine('hidePrompt');
    });
    $("[name=project.planStartTime]").click(function () {
        $("[name='project.planStartTime']").validationEngine('hidePrompt');
    });
    $("[name=project.planEndTime]").click(function () {
        $("[name='project.planEndTime']").validationEngine('hidePrompt');
    });
    $("[name=project.projectType.name]").click(function () {
        $("[name='project.projectType.name']").validationEngine('hidePrompt');
    });
//	$("[name=project.needFunds]").click(function() {$("[name='project.needFunds']").validationEngine('hidePrompt');});
    $("[name=project_reUserFollowID]").click(function () {
        $("[name='project_reUserFollowID']").validationEngine('hidePrompt');
    });
    $("[name=serviceFollow.startTime]").click(function () {
        $("[name='serviceFollow.startTime']").validationEngine('hidePrompt');
    });
    $("[name=serviceFollow.endTime]").click(function () {
        $("[name='serviceFollow.endTime']").validationEngine('hidePrompt');
    });
    $("[name=serviceFollow.remindCycle]").click(function () {
        $("[name='serviceFollow.remindCycle']").validationEngine('hidePrompt');
    });
    $("[name=serviceFollow.personChargeName]").click(function () {
        $("[name='serviceFollow.personChargeName']").validationEngine('hidePrompt');
    });
    $("[name=serviceFollow.follwerName]").click(function () {
        $("[name='serviceFollow.follwerName']").validationEngine('hidePrompt');
    });
    $("[name=serviceFollow.remindCycleDay]").click(function () {
        $("[name='serviceFollow.remindCycleDay']").validationEngine('hidePrompt');
    });


    $("#newProjectForm [name=serviceFollow.topic]").addClass("validate[required,minSize[2],maxSize[10]]");
    if ($("#newProjectForm").attr('name') == 'newProjectBuildingForm') {
        $("#newProjectForm [name=project.planStartTime]").addClass("validate[required]");
        $("#newProjectForm [name=project.planEndTime]").addClass("validate[required]");
        $("#newProjectForm [name=project.projectType.name]").addClass("validate[required,minSize[2],maxSize[5]]");
//		$("#newProjectForm [name=project.needFunds]").addClass("validate[required,custom[positiveNumber]]");
        $("#newProjectForm [name=project_reUserFollowID]").addClass("validate[required]");
    } else {
        $("#newProjectForm [name=serviceFollow.startTime]").addClass("validate[required]");
        $("#newProjectForm [name=serviceFollow.endTime]").addClass("validate[required]");
    }
    $("#newProjectForm [name=serviceFollow.remindCycle]").addClass("validate[required]");
    $("#newProjectForm [name=serviceFollow.personChargeName]").addClass("validate[required]");
    $("#newProjectForm [name=serviceFollow.follwerName]").addClass("validate[required]");
    $("#newProjectForm [name=serviceFollow.remindCycleDay]").addClass("validate[required]");

//	$("#newProjectForm [name=project_reUserReportID]").addClass("validate[required]");
    $("#newProjectForm").validationEngine({
        validationEventTriggers: "blur", //触发的事件  validationEventTriggers:"keyup blur",
        inlineValidation: false,// 是否即时验证，false为提交表单时验证,默认true
        success: false,// 为true时即使有不符合的也提交表单,false表示只有全部通过验证了才能提交表单,默认false
        promptPosition: "topRight" //提示所在的位置，topLeft, topRight, bottomLeft,  centerRight, bottomRight
    });

    /** 提交表单 * */
    $("[id='createProjectButton']").click(function () {
//		alert($("[id=project.reUserFollowID]").val().length);
        if ($("[id=project.reUserFollowID]").val() != null && $("[id=project.reUserFollowID]").val() != 'undefined' && $("[id=project.reUserFollowID]").val().length > 0) {
            $("#project_reUserFollowID").val("dd");
        }
        $("#createProjectButton").hide();
        $("#newProjectForm").attr("action", "/crm/serviceChance_addServiceFollow");
        $("#newProjectForm").ajaxSubmit(function (returnStr) {
            if (returnStr == "success") {
                dialog("成功", "success", true, 1);
                window.location.reload(true);
            } else {
                $("#createProjectButton").show();
                dialog(returnStr, "unsuccess", true, 2);
            }
            return false;
        });
    });
    $("#cancelBtu").click(function () {
        hideViladata();
    });

    //影藏，打开详细
    $(".view-open").click(function () {
        $(this).closest(".serviceChance").find(".swHide").show(500);
        $(this).closest(".serviceChance").find(".view-close").show();
        $(this).hide();
    });
    $(".view-close").click(function () {
        $(this).closest(".serviceChance").find(".swHide").hide(500);
        $(this).hide();
        $(this).closest(".serviceChance").find(".view-open").show();
    });

    //编辑跟进
    $(".edit-follow").click(function () {
        var $serviceChance = $(this).closest(".serviceChance")
        $serviceChance.find(".EditHide").hide();
        $serviceChance.find(".EditShow").show();
    });
    //取消编辑
    $(".cancel-follow").click(function () {
        var $serviceChance = $(this).closest(".serviceChance")
        $serviceChance.find(".EditHide").show();
        $serviceChance.find(".EditShow").hide();
    });


});

function hideViladata() {
    $("#newProjectForm [name=serviceFollow.topic]").validationEngine('hidePrompt');
    $("#newProjectForm [name=project.planStartTime]").validationEngine('hidePrompt');
    $("#newProjectForm [name=project.planEndTime]").validationEngine('hidePrompt');
    $("#newProjectForm [id='projectTypeName']").validationEngine('hidePrompt');
//		$("#newProjectForm [name=project.needFunds]").validationEngine('hidePrompt');
    $("#newProjectForm [name=project_reUserFollowID]").validationEngine('hidePrompt');

    $("#newProjectForm [name='project.name']").validationEngine('hidePrompt');
    $("#newProjectForm [name='serviceFollow.startTime']").validationEngine('hidePrompt');
    $("#newProjectForm [name='serviceFollow.endTime']").validationEngine('hidePrompt');
    $("#newProjectForm [name='serviceFollow.remindCycle']").validationEngine('hidePrompt');
    $("#newProjectForm [name='serviceFollow.personChargeName']").validationEngine('hidePrompt');
    $("#newProjectForm [name='serviceFollow.follwerName']").validationEngine('hidePrompt');
//		$("#newProjectForm [name=project_reUserReportID]").addClass("validate[required]");
    $("#addRemarkForm [name='premark.remark']").validationEngine('hidePrompt');
    $("#newProjectForm [name=serviceFollow.remindCycleDay]").validationEngine('hidePrompt');

}


//删除知会人
function delNotice(a, id) {
    var $ids = $(a).closest("li").find("[name='serviceFollow.reportTo']");
    var ids = $ids.val();
    var arr = ids.split(",");
    var arr2 = new Array();
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] != id) {
            arr2.push(arr[i]);
        }
    }
    $ids.attr("value", arr2);
    $("[name='" + id + "']").empty();
    $("[name='" + id + "']").remove();
}

function initFindUser() {
    /** 负责人 * */
    $.ajax({
        type: "GET",
        url: encodeURI("/adminajax/project_findUser"),
        dataType: "json",
        success: function (data, textStatus) {
            if (data != null && data.userListAjax != null) {
                $("[name='serviceFollow.personChargeName']")
                    .autocomplete(
                    data.userListAjax,
                    {
                        /** 加自定义表头* */
                        tableHead: "<div><span style='width:40%' class='col-1'>name</span> <span style='width:58%' class='col-2'>email</span></div>",
                        minChars: 0,
                        width: 400,
                        mustMatch: true,
                        matchContains: "true",
                        autoFill: false,
                        formatItem: function (row, i, max) {
                            return "<span  style='width:40%' class='col-1'>"
                                + row.name + "/" + row.enName
                                + "</span> "
                                + "<span style='width:58%' class='col-2'>"
                                + row.userMail + "</span>";
                        },
                        formatMatch: function (row, i, max) {
                            return row.name + '/' + row.enName + '/'
                                + row.userMail;
                        },
                        formatResult: function (row) {
                            return row.name + '/' + row.enName;
                        }
                    })
                    .result(
                    function (event, item) {
                        var $personCharge = $(this).closest("li").find("[name='serviceFollow.personCharge']");
                        if (item != null && item != 'undefined') {
                            $personCharge.attr("value", item.id);
                        } else {
                            $personCharge.attr("value", "");
                        }
                    });

            }
        }
    });

    /** 跟进人 * */
    $.ajax({
        type: "GET",
        url: encodeURI("/adminajax/project_findUser"),
        dataType: "json",
        success: function (data, textStatus) {
            if (data != null && data.userListAjax != null) {
                $("[name=serviceFollow.follwerName]")
                    .autocomplete(
                    data.userListAjax,
                    {
                        /** 加自定义表头* */
                        tableHead: "<div><span style='width:40%' class='col-1'>name</span> <span style='width:58%' class='col-2'>email</span></div>",
                        minChars: 0,
                        width: 400,
                        mustMatch: true,
                        matchContains: "true",
                        autoFill: false,
                        formatItem: function (row, i, max) {
                            return "<span  style='width:40%' class='col-1'>"
                                + row.name + "/" + row.enName
                                + "</span> "
                                + "<span style='width:58%' class='col-2'>"
                                + row.userMail + "</span>";
                        },
                        formatMatch: function (row, i, max) {
                            return row.name + '/' + row.enName + '/'
                                + row.userMail;
                        },
                        formatResult: function (row) {
                            return row.name + '/' + row.enName;
                        }
                    })
                    .result(
                    function (event, item) {
                        var $follower = $(this).closest("li").find("[name='serviceFollow.follwer']")
                        if (item != null && item != 'undefined') {
                            $follower.attr("value", item.id);
                        } else {
                            $follower.attr("value", "");
                        }
                    });

            }
        }
    });

    /** 知会对象 * */
    $.ajax({
        type: "GET",
        url: encodeURI("/adminajax/project_findUser"),
        dataType: "json",
        success: function (data, textStatus) {
            if (data != null && data.userListAjax != null) {
                $("[name=sagsfj]")
                    .autocomplete(
                    data.userListAjax,
                    {
                        /** 加自定义表头* */
                        tableHead: "<div><span style='width:40%' class='col-1'>name</span> <span style='width:58%' class='col-2'>email</span></div>",
                        minChars: 0,
                        width: 400,
                        mustMatch: true,
                        matchContains: "true",
                        autoFill: false,
                        formatItem: function (row, i, max) {
                            return "<span  style='width:40%' class='col-1'>"
                                + row.name + "/" + row.enName
                                + "</span> "
                                + "<span style='width:58%' class='col-2'>"
                                + row.userMail + "</span>";
                        },
                        formatMatch: function (row, i, max) {
                            return row.name + '/' + row.enName + '/'
                                + row.userMail;
                        },
                        formatResult: function (row) {
                            return row.name + '/' + row.enName;
                        }
                    })
                    .result(
                    function (event, item) {
                        var $reUserID = $(this).closest("li").find("[name='serviceFollow.reportTo']")
                        if (item != null && item != 'undefined') {

                            var ids = $reUserID.val();
                            var arr = ids.split(",");
                            var flag = true;
                            for (var i = 0; i < arr.length; i++) {
                                if (arr[i] == item.id) {
                                    flag = false;
                                }
                            }
                            if (flag) {
                                $reUserID.attr("value", ids + item.id + ",");
                                $(this).val("");
                                $(this).hide();
                                var $html = "<div class='value-box'>" + item.name + "/" + item.enName + "<a title='删除' href='javascript:;' onclick='delNotice(this," + item.id + ");' class='icon icon-close-values'>删除</a></div>";
                                $(this).before($html);
                                $multipleH = $(this).parents(".multiple-values").height();
                                $row = $multipleH / $(this).outerHeight(true);
                                $valueW = 0;
                                $valueBoxes = $(this).parents(".multiple-values").find(".value-box");
                                $valueBoxes.each(function (index, element) {
                                    if ($(this).position().top - 2 == $row * $("[data-input-multiple='true']").outerHeight(true) - $(this).outerHeight(true)) {
                                        $valueW = $valueW + $(this).outerWidth(true);
                                    }
                                });
                                $inputW = $(this).parents(".multiple-values").width() - $valueW;
                                if ($inputW <= 20) {
                                    $inputW = $(this).parents(".multiple-values").width()
                                }
                                ;
                                $(this).width($inputW).show();
                                $(".value-box .icon-close-values").click(function () {
                                    $(this).parent(".value-box").remove();
                                });
                            } else {
//												alert("您已经添加了该知会对象");
                                dialog("您已经添加了该知会对象:" + item.name, "success", true, 1);
                                $(this).val("");
                            }
                        }
                    });

            }
        }
    });


    /** 跟进人多选 * */
    $.ajax({
        type: "GET",
        url: encodeURI("/adminajax/project_findUser"),
        dataType: "json",
        success: function (data, textStatus) {
            if (data != null && data.userListAjax != null) {
                $("#project_reUserFollowID")
                    .autocomplete(
                    data.userListAjax,
                    {
                        /** 加自定义表头* */
                        tableHead: "<div><span style='width:40%' class='col-1'>name</span> <span style='width:58%' class='col-2'>email</span></div>",
                        minChars: 0,
                        width: 400,
                        mustMatch: true,
                        matchContains: "true",
                        autoFill: false,
                        formatItem: function (row, i, max) {
                            return "<span  style='width:40%' class='col-1'>"
                                + row.name + "/" + row.enName
                                + "</span> "
                                + "<span style='width:58%' class='col-2'>"
                                + row.userMail + "</span>";
                        },
                        formatMatch: function (row, i, max) {
                            return row.name + '/' + row.enName + '/'
                                + row.userMail;
                        },
                        formatResult: function (row) {
                            return row.name;
                        }
                    })
                    .result(
                    function (event, item) {
                        if (item != null && item != 'undefined') {
                            var ids = $("[name='project.reUserFollowID']").val();
                            var arr = ids.split(",");
                            var flag = true;
                            for (var i = 0; i < arr.length; i++) {
                                if (arr[i] == item.id) {
                                    flag = false;
                                }
                            }
                            if (flag) {
                                $("[name='project.reUserFollowID']").attr("value", ids + item.id + ",");
                                $(this).val("");
                                $(this).hide();
                                var $html = "<div class='value-box'>" + item.name + "<a title='删除' href='javascript:;' onclick='delFollow(" + item.id + ");' class='icon icon-close-values'>删除</a></div>";
                                $(this).before($html);
                                $multipleH = $(this).parents(".multiple-values").height();
                                $row = $multipleH / $(this).outerHeight(true);
                                $valueW = 0;
                                $valueBoxes = $(this).parents(".multiple-values").find(".value-box");
                                $valueBoxes.each(function (index, element) {
                                    if ($(this).position().top - 2 == $row * $("[data-input-multiple='true']").outerHeight(true) - $(this).outerHeight(true)) {
                                        $valueW = $valueW + $(this).outerWidth(true);
                                    }
                                });
                                $inputW = $(this).parents(".multiple-values").width() - $valueW;
                                if ($inputW <= 20) {
                                    $inputW = $(this).parents(".multiple-values").width()
                                }
                                ;
                                $(this).width($inputW).show();
                                $(".value-box .icon-close-values").click(function () {
                                    $(this).parent(".value-box").remove();
                                });
                            } else {
//												alert("您已经添加了该汇报对象");
                                dialog("您已经添加了该跟进对象:" + item.name, "success", true, 1);
                                $(this).val("");
                            }
                        }
                    });

            }
        }
    });


}