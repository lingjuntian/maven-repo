function fileUpload(fileName,type,parentId){
	$("#fileNameId").val(fileName);
	var extend = fileName.substring(fileName.lastIndexOf(".")+1).toLowerCase();
	if(extend == "pdf"){
		var testpdf = confirm("PDF文件建议压缩后上传,是否继续上传");
		if(testpdf){
			addLoading("文件上传中，请等待...");
			console.log($("#fileUploadForm"+parentId).html())
			$("#fileUploadForm"+parentId).ajaxSubmit(function(returnStr){
				if(returnStr == "0"){
					removeLoading("");
					dialog("文件上传失败","unsuccess",true,2);
					return;
				}else{
					$("#noAttach").remove();
					addFile(returnStr,fileName,type,parentId);
					removeLoading("");
					dialog("上传成功","success",true,2);
					return;
				}
			});
		}else{
			return;
		}
	}else{
		addLoading("文件上传中，请等待...");
		console.log($("#fileUploadForm"+parentId).html());
		$("#fileUploadForm"+parentId).ajaxSubmit(function(returnStr){
			if(returnStr == "0"){
				removeLoading("");
				dialog("文件上传失败","unsuccess",true,2);
				return;
			}else{
				$("#noAttach").remove();
				addFile(returnStr,fileName,type);
				removeLoading("");
				dialog("上传成功","success",true,2);
				return;
			}
		});
	}
}
function fileDownLoad($obj){
	$("#fileNameDownId"+parentId).val($obj.attr("fileName"));
	$("#srcNameDownId"+parentId).val($obj.attr("srcName"));
	$("#fileDownloadForm"+parentId).submit();
}

/**
 * 文件上传显示
 */
function addFile(returnStr, fileName,type,parentId){
	var array = returnStr.split("##");
	var attachKey = $("#key"+parentId).val()+"";
	var delAction = "/approval/attach_delFromSession?attachPath="+array[0];
	var changeAction = "/approval/attach_changeSessionFileType?attachPath="+array[0];
	if(attachKey != 'undefined'){
		delAction += "&key="+attachKey;
		changeAction += "&key="+attachKey;
	}
	var path = array[0];
	if(type != 'session'){
   		delAction = "/approval/attach_delete?id="+array[1];
   		changeAction = "/approval/attach_changeFileType?id="+array[1];
   	}
	var _fileName = fileName.substring(fileName.lastIndexOf("\\") + 1);
	var liStr = "<li path='"+path+"'>" +
					"<a downFileTag='downFileTag' fileName='"+path+"' srcName='"+_fileName+"' href=\"javascript:;\">"+_fileName+"</a>" +
       			"<span class='uploader'>"+array[2]+"</span><span class='time'>"+array[3]+"</span>";
	liStr +="<a tag='del' href=\"javascript:;\">删除</a></li>";
   	$("#fileListForCreate"+parentId).prepend(liStr);
   	$("#listBox"+parentId).addClass("box-content");
   	bindFileList(delAction,changeAction);
 	/*重新生成文件上传按钮*/
	var filestr = "<input type='file' name='file' id='fileId"+parentId+"' class='input-file' />";
	$("#fileId"+parentId).remove();
	$("#fileCreate"+parentId).append(filestr);
	$("#fileId"+parentId).unbind("change");
	$("#fileId"+parentId).bind("change",function(){
		fileUpload($(this).val(),type);
	  	return false;
	});
	return;
}


/**
 * 删除文件
 * @param filePath
 */
function delFile(obj,action){
	$.ajax({
        type:"GET",
        url:encodeURI(action),
        success:function(returnStr){
        	if (returnStr == "2") {
        		$(obj).remove();
        		if($("#fileListForCreate li").length <= 0)
        			$("#listBox").removeClass("box-content");
        		return;
  	        } else{
  	        	dialog("删除出错","unsuccess",true,2);
  	        	return;
  	        }
        }
    });
}

function copyFileList(){
	var html = $("#fileListForCreate").html();
	if(html==""){
		$("#confirm_listBox").removeClass("box-content");
	}
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}
/**
 * 绑定填充文件操作
 */
function bindFileList(delAction,changeAction){
	$("#fileListForCreate a[tag='del']").unbind("click");
   	$("#fileListForCreate a[tag='fileType']").unbind("click");
	$("#fileListForCreate a[tag='del']").bind("click",function(){
		delFile($(this).parent("li"),delAction);
	  	return false;
	});
	$("#fileListForCreate a[tag='fileType']").bind("click",function(){
		var li = $(this).parent("li");
		changeFileType(li,changeAction);
		return false;
	});
	$("#fileListForCreate a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}

/**
 * 改变文件类型
 * @param filePath
 */
function changeFileType(obj,action){
	$.ajax({
        type:"GET",
        url:encodeURI(action),
        success:function(returnStr){
        	if (returnStr == "2") {
        		var li = $(obj).find("a[tag='fileType']");
        		if(li.hasClass("priority-yes")){
        			li.removeClass("priority-yes");
        			li.attr("title","普通");
        		}else{
        			li.addClass("priority-yes");
        			li.attr("title","重要");
        		}
        		return;
  	        } 
  	        if(returnStr == "0"){
  	           dialog("设置出错","unsuccess",true,2);
  	           return;
  	        }
        }
    });
}

function changeAttachType(id){
	var obj = $("#attach_"+id);
	var action = "/approval/attach_changeFileType?id="+id;
	return changeFileType(obj,action);
}

function delAttach(id){
	var obj = $("#attach_"+id);
	var action = "/approval/attach_delete?id="+id;
	return delFile(obj,action);
}
