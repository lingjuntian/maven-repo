$(function () {
    var nodeUserIput = $("[tdTag=nodeUser]");
    completUser(nodeUserIput);

    //点击修改
    $(".updateBut").click(function () {
        var $li = $(this).closest("li");
        $li.find("[tdTag=edit]").show();
        $li.find("[tdTag=show]").hide();
    });
    //点击取消
    $(".canceBut").click(function () {
        var $li = $(this).closest("li");
        $li.find("[tdTag=edit]").hide();
        $li.find("[tdTag=show]").show();
    });
    //添加节点按钮
    $(".addNodeBut").click(function () {
        var but = $(this);
        var $li = $(this).closest("li");
        var idVal = $li.find("[tdTag=id]").val();
        var $addNodeLi = $("#addNodeDl").clone();
        if (idVal == 0) {
            //添加的节点为第一个节点，将后一个节点的Id 带上
            var $firstNode = $li.next("li");
            idVal = $firstNode.find("[tdTag=id]").val();
            $addNodeLi.find("[tdTag=afterId]").val(idVal);
        } else {
            //添加的节点不是第一个节点，将前一个节点的Id 带上
            $addNodeLi.find("[tdTag=beforId]").val(idVal);
        }
        $addNodeLi.css("display", "block");
        completUser($addNodeLi.find("[tdTag=nodeUser]"));
        $li.after($addNodeLi);
        but.hide();
        $addNodeLi.find("[tdTag=addCancerbut]").click(function () {
            $(this).closest("li").remove();
            but.show()
        });
        $addNodeLi.find("[tdTag=addSavebut]").click(function () {
            var nodeUser = $(this).closest("li").find("[tdTag=nodeUser]").val();
            var beforId = $(this).closest("li").find("[tdTag=beforId]").val();
            var afterId = $(this).closest("li").find("[tdTag=afterId]").val();
            var nodeName = $(this).closest("li").find("[tdTag=nodeName]").val();
            if (nodeUser == "") {
                dialog("请选择该节点的审批人");
                return false;
            }
            if (beforId == "" && afterId == "") {
                dialog("数据有BUG,没有找到节点审批顺序", "unsuccess", true, 2);
                return false;
            }
            var nodeCode = "";
            if (nodeName == "") {
                dialog("要下拉框中选一个审批名称噢");
                return false;
            } else {
                var nodeNames = nodeName.split(",");
                nodeCode = nodeNames[0];
                nodeName = nodeNames[1];
            }
            var parm = {
                'node.nodeUser': nodeUser,
                'node.nodeCode': nodeCode,
                'node.nodeName': nodeName,
                'node.beforId': beforId,
                'node.afterId': afterId
            };
            updateOrSaveNode(parm);
        });
    });

    //点击提交修改节点按钮
    $(".updateSaveBut").click(function () {
        var id = $(this).closest("li").find("[tdTag=id]").val();
        var nodeUser = $(this).closest("li").find("[tdTag=nodeUser]").val();
        var nodeName = $(this).closest("li").find("[tdTag=nodeName]").val();
        if (nodeUser == "") {
            dialog("请选择该节点的审批人");
            return false;
        }
        if (id == "") {
            dialog("数据有BUG,没有找到该节点的Id", "unsuccess", true, 2);
            return false;
        }
        var nodeCode = "";
        if (nodeName == "") {
            dialog("要下拉框中选一个审批名称噢");
            return false;
        } else {
            var nodeNames = nodeName.split(",");
            nodeCode = nodeNames[0];
            nodeName = nodeNames[1];
        }
        var parm = {
            'node.nodeUser': nodeUser,
            'node.nodeCode': nodeCode,
            'node.nodeName': nodeName,
            'node.id': id
        };
        updateOrSaveNode(parm);
    })

    $(".delNodeBut").click(function () {
        var id = $(this).closest("li").find("[tdTag=id]").val();
        var nodeSize = $("#nodeUl").find("li").size();
        if (nodeSize < 5) {
            dialog("删了这个就没节点了，不可以删了！");
        } else if (id == "") {
            dialog("数据有BUG,没有找到该节点的Id", "unsuccess", true, 2);
        }else{
            var url="/approval/nodeApproval_deleteNode?node.id="+id;
            $.ajax({
                url: url,
                type: "GET",
                success: function (reslut) {
                    if (reslut == "success") {
                        dialog("成功！", "success", true, 0.5);
                        window.location.reload(true);
                    } else {
                        dialog(reslut, "unsuccess", true, 2);
                    }
                }

            })
        }

    })

});


function updateOrSaveNode(parm) {
    $.ajax({
        url: "/approval/nodeApproval_updateOrSaveNode",
        type: "GET",
        data: parm,
        success: function (reslut) {
            if (reslut == "success") {
                dialog("成功！", "success", true, 0.5);
                window.location.reload(true);
            } else {
                dialog(reslut, "unsuccess", true, 2);
            }
        }

    })
}

/*自动匹配用户*/
function completUser(container) {
    $.ajax({
        type: "GET",
        url: encodeURI("/adminajax/findAllUser"),
        dataType: "json",
        success: function (data, textStatus) {
            if (data != null && data.userList != null) {
                container.autocomplete(data.userList, {
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-3'>昵称</span> <span class='col-4'>中文名</span></div>",
                    minChars: 0,
                    width: 350,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function (row, i, max) {
                        return "<div><span class='col-3'>" + row.nickName + "</span> <span class='col-4'>" + row.name + "</span></div>";
                    },
                    formatMatch: function (row, i, max) {
                        return row.name + row.enName;
                    },
                    formatResult: function (row) {
                        return row.name;
                    }
                }).result(function (e, data, value, sec) {
                    /**加选中后的回调函数**/
                    $(this).val(data.nickName);
                }).bind("unmatch", function () {
                    /**没有匹配时**/
                    $(this).val("");
                });
            }
        }
    });
}

function confirmCreateNode(id,returnUrl){

	var $input=$(".nodeUserVila");
	for(var i=0 ; i< $input.size() ; i++){
		if($input.eq(i).val()==""){
			dialog("您还需要为  ’"+$input.eq(i).attr("title")+"‘ 选择一个审批人", "unsuccess", true, 2);
			return ;
		}
	}
	var url="/approval/nodeApproval_confirmCreateNode?nodeApproval.id="+id;
	//异步请求添加流程
	$.ajax({
        url:    url,
        type:  "GET",
        success: function (reslut) {
            if (reslut == "success") {
                dialog("成功！", "success", true, 2);
                window.location.href  =returnUrl;
                
            } else {
                dialog(reslut, "unsuccess", true, 2);
            }
        }

    })
	
}


