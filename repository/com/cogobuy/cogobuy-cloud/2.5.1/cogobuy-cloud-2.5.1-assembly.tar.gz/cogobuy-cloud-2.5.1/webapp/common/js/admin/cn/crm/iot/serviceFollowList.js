$(function () {
    if ($("#lableNameIds").val() != "") {
        var labels = $("#lableNameIds").val().split(",");
        var sum = 0;
        for (var i = 0; i < labels.length; i++) {
            $("[name=serviceChance]").each(function () {
                if ($(this).val() == labels[i]) {
                    $(this).attr("checked", true);
                    sum++;
                }
            })
        }
        $("#selChance").text("共选择" + sum + "个");
    }

    if ($("#status").val() != "") {
        var status = $("#status").val().split(",");
        var sum2 = 0;
        for (var i = 0; i < status.length; i++) {
            $("[name=status]").each(function () {
                if ("'" + $(this).val() + "'" == status[i]) {
                    $(this).attr("checked", true);
                    sum2++;
                }
            })
        }
        $("#selectedIA").text("共选择" + sum2 + "个");
    }

})
/*表格修饰*/
$(".table-list > table").decorateList();
/*日期*/
$("#startTime").click(function () {
    WdatePicker({maxDate: $('#endTime').val()});
});
$("#endTime").click(function () {
    WdatePicker({minDate: $('#startTime').val()});
});
/**查询**/
$("#selectButton").click(function () {
    //服务机会
    var ids = "";
    $("[name=serviceChance]").each(function () {
        if ($(this).attr("checked") == true) {
            ids = ids + $(this).val() + ","
        }
    })
    if (ids.length > 1) {
        ids = ids.substring(0, ids.length - 1);
    }
    $("#lableNameIds").val(ids);
    //项目状态
    var status = "";
    $("[name=status]").each(function () {
        if ($(this).attr("checked") == true) {
            status = status + "'" + $(this).val() + "'" + ","
        }
    });
    if (status.length > 1) {
        status = status.substring(0, status.length - 1);
    }
    $("#status").val(status);
    $("#selectForm").submit();
});
/*绑定回车事件*/
$("#titile,#createUserName").keydown(function (event) {
    if (event.keyCode == 13) {
        $("#selectForm").submit();
    }
});

