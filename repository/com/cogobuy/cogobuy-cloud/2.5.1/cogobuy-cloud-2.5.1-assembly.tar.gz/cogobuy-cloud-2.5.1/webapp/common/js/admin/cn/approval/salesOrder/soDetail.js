/**
 * PM审核通过
 * @param parent
 */
function soPmApproval(parentId,returnUrl) {
	var $postinput = $("body").find("input[posttag^=Sandisk]");/* 获取所有tr */
	for ( var i = 0; i < $postinput.size(); i++) {
		var $input = $postinput.eq(i);
		var $inputVal = $input.val();
		if($inputVal==""){
			dialog("Sandisk产品线必须维护POS成本和参考成本","warning",false,2);
			return;	
		}
	}
	var orderBa = $("input[name=orderBa]:checked").val();
	if( orderBa == undefined){
		dialog("请选择订单属性","warning",false,2);
		return;
	}else{
		$(".button-yellow").hide();
		var data = {
				"salesOrder.id" : parentId,
				"orderBa" : orderBa,
				"mails" : getApprovalMail()
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/approval/salesOrder_pmApproval"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					window.location.href = returnUrl;
				} else {
					$(".button-yellow").show();
					dialog(returnStr, "unsuccess", true, 10);
				}
			}
		});
	}
}


/**
 * CT审核通过
 * @param parent
 */
function soCtApproval(parentId,returnUrl) {
	$(".button-yellow").hide();
	var data = {
			"salesOrder.id" : parentId,
			"mails" : getApprovalMail()
	};
	$.ajax({
		type : "GET",
		url : encodeURI("/approval/salesOrder_ctApproval"),
		data : data,
		success : function(returnStr) {
			if (returnStr == 'success') {
				dialog("成功", "success", true, 2);
				window.location.href = returnUrl;
			} else {
				$(".button-yellow").show();
				dialog(returnStr, "unsuccess", true, 10);
			}
		}
	});
}
