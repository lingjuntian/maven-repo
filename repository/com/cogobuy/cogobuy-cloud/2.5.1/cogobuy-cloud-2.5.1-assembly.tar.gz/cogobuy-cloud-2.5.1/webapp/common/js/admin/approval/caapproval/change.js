var autoCompleteplList;
$(function() {
	$("#registerCapital,#paidInCapital,#cusSourceFunds,#foundedTime,#employeeNum,#investor,#annualSales,#majorProduct,#majorCus,#fieldScale,#industryPosition,#chance").addClass("validate[required]");
	$("#changeCredit,[id^=pass],[id^=fc]").addClass("validate[custom[amountTen]]");
	/*隐藏确认页面*/
	$("#changeConfirm").hide();	
	
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(function() {
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vshow"));
		$(this).parents(".options-select").find("input[tag=id]").val($(this).attr("vid"));
		$(this).parents(".options-select").find("input[tag=show]").val($(this).attr("vshow"));
		$(this).validationEngine('hidePrompt');
		return false;
	});
	
	/*客户成立时间*/
	$("#foundedTime").click(function(){
		WdatePicker();
	});
	
	/* 添加一行 */
	$(".add-text").click(function(){
		var $tr = $(this).parents("tr");
		addTr($tr);
	});
	
	/*删除一行*/
	$(".del-text").click(function(){
		var $obj = $(this).parents("tr");
		var $length = $obj.parents("tbody").find("tr").length;
		if($length<2){
			dialog("请最少保留1行","warning",false,2);
			return false;
		}
		delTr($obj);
	});
	
	/* 自动匹配产品线 */
	setPlAutoComplete();
	
	/*下一步信息确认*/ 
	$("#next").click(function(){
		clearNull();/* 清除空行 */
	  	var error = validationChangeFrom();
		if(error){
			copyValueToConfig(); /*将变更页面的数值写入确认页面*/ 
			getEmailList(); /*获取邮件发送列表 */
			copyFileList();/*上传附件公用*/
			$("#write").hide();/*显示确认页面，隐藏变更页面*/
			$("#changeConfirm").show();
		}	
	});
	
	/*上一步*/
	$("#back").click(function(){
		/*增加新增行*/
		$copyTr = $("#credListTbody").parents("table").find("tr[hide=hide]").clone(true);
		$copyTr.removeAttr("hide");
		$copyTr.removeAttr("style");
		$copyTr.attr("changeTag","tr");
		$("#credListTbody").append($copyTr);
		addPlAutoComplete($copyTr.find("input[changeTag=productLine]"));
		addIdAndNameForInput();
		/*隐藏确认页面，显示变更页面*/
		$("#write").show();
		$("#changeConfirm").hide();	
	});
	
	/*确认提交*/
	$("#submit").click(function(){
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#submitForm").append(inputStr);
    		}
    	});
		$("#submit").hide();/*隐藏确认按钮*/
		var $subForm=$("#submitForm");
		$subForm.attr("action","/approval/caChangeApproval_create");
		$subForm.ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);	  
				setTimeout(function(){window.location = "/approval/caChangeApproval_detail?mainInfo.id="+id;},1000);	  
			}
			else{
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
		
	});
});



/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
	/*清空变更额度*/
	$("span[id$=confirm]").text("");
	/*清空列表*/
	$("#changeMainCredit_confirm").empty();
	$("#credListTbody_confirm").empty();
	/*######################列表*/
	$("#changeCredit_confirm").text($("#changeCredit").val()+$("#changeCurrencyName").val());
	$("#changeLiZhang_confirm").text($("#changeLiZhang").val());
	
	$("#registerCapital_confirm").text($("#registerCapital").val());
	$("#paidInCapital_confirm").text($("#paidInCapital").val());
	$("#cusSourceFunds_confirm").text($("#cusSourceFunds").val());
	$("#foundedTime_confirm").text($("#foundedTime").val());
	$("#employeeNum_confirm").text($("#employeeNum").val());
	
	$("#investor_confirm").text($("#investor").val());
	$("#annualSales_confirm").text($("#annualSales").val());
	$("#majorProduct_confirm").text($("#majorProduct").val());
	$("#majorCus_confirm").text($("#majorCus").val());
	$("#fieldScale_confirm").text($("#fieldScale").val());
	$("#industryPosition_confirm").text($("#industryPosition").val());
	$("#chance_confirm").text($("#chance").val());
	
	$("#pass1_confirm").text($("#pass1").val());
	$("#pass2_confirm").text($("#pass2").val());
	$("#pass3_confirm").text($("#pass3").val());
	$("#pass4_confirm").text($("#pass4").val());
	$("#pass5_confirm").text($("#pass5").val());
	$("#pass6_confirm").text($("#pass6").val());
	$("#fc1_confirm").text($("#fc1").val());
	$("#fc2_confirm").text($("#fc2").val());
	$("#fc3_confirm").text($("#fc3").val());
	
	var $trs = $("#changeMainCredit").find("tr");
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		/*如果账期变更未填写变更则变更值为原值*/
		var newCreditValue="";
		if(getNewCreditValue($tr)!=null){
			if(getNewCreditDayValue($tr) != ""){
				newCreditValue=getNewCreditValue($tr)+"/ "+getNewCreditDayValue($tr);
			}else{
				newCreditValue=getNewCreditValue($tr);
			}
		}
		var $productLine = $tr.find("input[changeTag=productLine]").val();
		if($tr.find("input[changeTag=rowNum]").val() == 1){
			$productLine = "主账期";
		}
		var trString = "<tr><td class=\"first product-line\"><div>"+$productLine+"</div></td>"
			+ "<td class=\"old\"><div>"+$tr.find("input[changeTag=periodType]").val()+"/"+$tr.find("input[changeTag=periodDays]").val()+"</div></td>"
			+ "<td class=\"new\"><div>"+newCreditValue+"</div></td>"
			+ "<td class=\"last remark\"><div>"+$tr.find("input[changeTag=remark]").val()+"</div></td></tr>";
		$("#changeMainCredit_confirm").append(trString);
	}
	
	/*新增产品线表信息确认*/
	var $trs_n = $("#credListTbody").find("tr");
	for ( var i = 0; i < $trs_n.size(); i++) {
		var $tr_n = $trs_n.eq(i);
		var $newCreditValue_n="";
		if(getNewCreditValue($tr_n)!=null){
			if(getNewCreditDayValue($tr_n) != ""){
				$newCreditValue_n=getNewCreditValue($tr_n)+"/ "+getNewCreditDayValue($tr_n);
			}else{
				$newCreditValue_n=getNewCreditValue($tr_n);
			}
		}
	    var trString_n = "<tr><td class=\"first product-line\"><div>"+$tr_n.find("input[changeTag=productLine]").val()+"</div></td>"
		+ "<td class=\"sales-figures\"><div>"+$newCreditValue_n+"</div></td>"
		+ "<td class=\"last remark\"><div>"+$tr_n.find("input[changeTag=remark]").val()+"</div></td></tr>";
		$("#credListTbody_confirm").append(trString_n);
	}
}

/*获取账期修改值*/
  function  getNewCreditValue($tr){
	if($tr.find("input[type=radio][value=NET]").attr("checked")){
		return "NET";
	} else if($tr.find("input[type=radio][value=AMS]").attr("checked")){
		return "月结";
	}  else if($tr.find("input[type=radio][value=CBD]").attr("checked")){
		return "CBD";
	}else if($tr.find("input[type=radio][value=COD]").attr("checked")){
    	 return "COD";
     }else {
    	 return null;
     } 	  
  }
  
 /*获取账期修改天数*/
  function getNewCreditDayValue($tr){
	  if($tr.find("input[type=radio][value=NET]").attr("checked")){
		  return $tr.find("input[changeTag=netValue]").val()+"天";
	  }else if($tr.find("input[type=radio][value=AMS]").attr("checked")){
		  return $tr.find("input[changeTag=amsValue]").val()+"天";
	  }else{
		  return "";
	  }
  }
 

  /*验证账期*/
  function validationCredit(){
  	var $radioPs = $("#changeForm").find("p[data-two-input=radio]");
  	for ( var i = 0; i < $radioPs.size(); i++) {
  		var $radioP = $radioPs.eq(i);
  		var $radioInput = $radioP.find("input[type=radio]");
  		var $radioValue = $radioP.find("input[type=text]");
  		if ($radioInput.attr("checked")) {
  			if ($radioValue.val().length < 1) {
  				$radioValue.validationEngine("showPrompt", "* 此处不可空白", "error", "", true);
  				return false;
  			}
  		}
  	}
  	return true;
  }
  
/*验证修改信息页面*/
function validationChangeFrom(){
	var formError = $("#submitForm").validationEngine('validate');
	var credit = validationCredit();
	return formError && credit;
}

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#credListTbody"));
	addIdAndNameForInput();
}

/* 整理表格，去空行，至少保留一行 */
function cleanTbody($tbody) {
	var $trNum = $tbody.find("tr").size();
	for ( var i = $trNum; i >= 0; i--) {
		$trNum = $tbody.find("tr").size();
		var $tr = $tbody.find("tr").eq(i);
		if (checkEmptyTr($tr)) {
			$tr.remove();
		}
	}
}

/* 验证空行 */
function checkEmptyTr($tr) {
	var $input = $tr.find("input[changeTag=productLine]");
	if ($.trim($input.val()) != "") {
		return false; // 不为空
	}
	return true;
}


/* 克隆行 */
function addTr($tr){
	$copyTr = $tr.parents("table").find("tr[hide=hide]").clone(true);
	$copyTr.removeAttr("hide");
	$copyTr.removeAttr("style");
	$copyTr.attr("changeTag","tr");
	$("#credListTbody").append($copyTr);
	addPlAutoComplete($copyTr.find("input[changeTag=productLine]"));
	addIdAndNameForInput();
}

/* 删除行 */
function delTr($obj){
	$obj.validationEngine('hidePrompt');
	$obj.remove();
	addIdAndNameForInput();
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput() {
	var $trs = $("#changeForm").find("tr[changeTag=tr]");/* 获取所有tr */
	var firstName = "mainInfo.creditList";/* 前缀名称 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $inputNum = $tr.find("input").size();
		for ( var j = 0; j < $inputNum; j++) {
			var $input = $tr.find("input").eq(j);
			$input.attr("id", $input.attr("changeTag") + numtag);
			$input.attr("name", firstName + numtag + "." + $input.attr("changeTag"));
		}
	}
}

/*加载产品线*/
function setPlAutoComplete(){
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/custAApproval_findAllErpPL"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.erppl != null){
				autoCompleteplList = data.erppl;
				addPlAutoComplete($("#credListTbody").find("input[changeTag=productLine]"));
			}
		}
	});
}

/*增加产品线自动匹配*/
function addPlAutoComplete($input){
	$input.autocomplete(autoCompleteplList, {
		/**加自定义表头**/
		tableHead:  "<div><span class='col-1'>CODE</span> <span class='col-2'>产品线</span></div>",
		minChars: 1,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.unionCode + "</span> " + "<span class='col-2'>" + row.unionName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.unionName;
		},
		formatResult: function(row) {
			return row.unionName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$input.val(data.unionName);
		$input.validationEngine('hidePrompt');
	}).bind("unmatch", function(){
		$input.val("");
	});
}

/* 获取邮件发送列表 */
function getEmailList() {
	var url = "/approval/caChangeApproval_showConfirmMail";
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#submit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else if(nodeNoApprovalUser){
			$("#submit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else{
			$("#submit").show();
		}
	});
}