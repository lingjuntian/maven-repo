$(function() {
	/*提交修改、增加出货计划*/
	$("#submitButton").click(function(){
		$("#updateForm").ajaxSubmit(function(returnStr){
			if (returnStr == "success") {        	
	      		dialog("成功！","success",true,1);
	      		var id=$("#paymentId").val();
	      		setTimeout(function(){window.location = "/approval/payment_show?id="+id;},1000);
	        }else{
	         	dialog(returnStr,"unsuccess",true,1);
	         	$("#closeButton").trigger("click");
	        }
		 }); 
	});
	
	/* 表格修饰 */
	$(".table-list > table").decorateList();

	/* 新增出货计划 */
	$(".add-text").click(function(){
		$("#pPlan").val("");
		changeContent(".popup-payment-detail-plan","添加出货计划","#pProductLineERP");
		$("#updateId").val($(this).attr("changeId"));
		pagePopup(".popup-payment-detail-plan",true);
	});

	/* 修改出货计划 */
	$(".edit-text").click(function(){
		changeContent(".popup-payment-detail-plan","修改出货计划","#pProductLineERP");
		var $pPlan = $(this).parents("td").find(".plan-text").text();
		$("#pPlan").val($pPlan);
		$("#updateId").val($(this).attr("changeId"));
		pagePopup(".popup-payment-detail-plan",true);
	});
	
	/*更新库存 */
	$("#updateInventory").click(function(){
		addLoading("正在更新，请等待。");
		var url = "/approval/payment_updateInventory?id=" + $("#paymentId").val();	
		$("#inventoryDiv").load(url, function(response,status){
			if(status == "success"){
				removeLoading("更新成功");
			}else if(status == "timeout"){
			 	removeLoading("更新超时，请稍后再试");
			}else{
				removeLoading("更新失败，请截屏并联系管理员");
			}
		});	
		return false;
	});
	
	/*增加时间控件*/
	$("#dateForecastUpdate").click(function(){
		WdatePicker();
	});
});

/*修改弹出框名称*/
function changeContent(element,action,readonlyElement){
	$(element+" input").val("");
	$("#popupTitle,#popupPost").text(action);
	$(readonlyElement).removeAttr("readonly").removeClass("disabled");
	if(action=="修改"){
		$(readonlyElement).attr("readonly","readonly").addClass("disabled");
	}
}


/**
 * 作废
 * @param parent
 * @param parentId
 * @param redirect
 */
function invalidApproval(parent,parentId,redirect){
	var test = confirm("确定不通过审核吗？");
	if(test){
		flowApproval.invalid(parent,parentId,redirect);
	}else{
		return;
	}
}

/**
 * 账务付款审批
 * @param parentId
 * @param redirect
 */
function cwApproval(parentId,redirect){
	$(".button-yellow").hide();
	var paidTime = $("#paidTime").val();
	if((typeof(paidTime) == 'undefined') || (paidTime.length < 1)){
		dialog("付款时间不能为空","unsuccess",false,2);
		$(".button-yellow").show();
	}else{
		var test = confirm("确定要通过审批吗？");
		if(test){
			var data = {
				"payment.id" : parentId,
				"payment.paidTime" : paidTime,
				"mails" : getApprovalMail()
			};
			$.ajax({
				type : "GET",
				url : encodeURI("/approval/payment_cwApproval"),
				data : data,
				success : function(returnStr) {
					if (returnStr == 'success') {
						dialog("成功", "success", true, 2);
						window.location.href = redirect;
					} else {
						$(".button-yellow").show();
						dialog(returnStr, "unsuccess", true, 10);
					}
				}
			});
		}else{
			$(".button-yellow").show();
			return;
		}
	}
}

/**
 * AP审批
 * @param parentId
 * @param redirect
 */
function apApproval(parentId,redirect){
	var dateForecastUpdate = $("#dateForecastUpdate").val();
	if((typeof(dateForecastUpdate) == 'undefined') || (dateForecastUpdate.length < 1)){
		dialog("预计付款时间不能为空","unsuccess",false,2);
	}else{
		var test = confirm("确定要通过审批吗？");
		if(test){
			var data = {
					"payment.id" : parentId,
					"payment.dateForecast" : dateForecastUpdate,
					"mails" : getApprovalMail()
				};
				$.ajax({
					type : "GET",
					url : encodeURI("/approval/payment_apApproval"),
					data : data,
					success : function(returnStr) {
						if (returnStr == 'success') {
							dialog("成功", "success", true, 2);
							window.location.href = redirect;
						} else {
							$(".button-yellow").show();
							dialog(returnStr, "unsuccess", true, 10);
						}
					}
				});
		}else{
			return;
		}
	}
}

/**
 * PM审批
 * @param parent
 * @param parentId
 * @param redirect
 */
function pmApproval(parent,parentId,redirect){
	var shipPlan = true;
	$("td[mustRequired]").each(function(){
		var must = $(this).attr("mustRequired");
		if(must=="false"){
			shipPlan = false;
			return;
		}
	});
	if(shipPlan!=true){
		dialog("出货计划不能为空！","unsuccess",false,2);
	}else{
		var test = confirm("确定要通过审批吗？");
		if(test){
			flowApproval.approval(parent,parentId,redirect);
		}else{
			return;
		}
	}
}


/**
 * SCT审批————审批通过并通知财务付款
 * @param parentId
 * @param redirect
 */
function sctApproval(parentId,redirect){
	
var test = confirm("确定要审批通过,并跳过后面的节点直达“财务付款”？");
if(test){
	var data = {
			"payment.id" : parentId,
			"mails" : getApprovalMail()
		};
		$.ajax({
			type : "GET",
			url : encodeURI("/approval/payment_sctApproval"),
			data : data,
			success : function(returnStr) {
				if (returnStr == 'success') {
					dialog("成功", "success", true, 2);
					window.location.href = redirect;
				} else {
					$(".button-yellow").show();
					dialog(returnStr, "unsuccess", true, 10);
				}
			}
		});
}
}
	
	
