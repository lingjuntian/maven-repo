/**
 * crm 拜访报告添加js
 */

$(function(){
	$("#reportCustomer,#visitDate,#content,#chance,#contact1,#visitWay,[tdTag=content],[tdTag=responsible],[tdTag=finishTime]").addClass("validate[required]");
    $('.report-add form .btn-save').click(function(){                     // 添加
        clearNull();/* 清除空行 */
    	var isPass=validationInput();
     	if(isPass){
     		$(".report-add form .btn-save").hide();
     		//获取已经选择的发送邮件对象
        	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
        	/*sendMail_check.each(function(i){//循环拼装被选中项的值
        		if($(this).attr("checked")){
        			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
        			$("#reportForm").append(inputStr);
        		}
        	});*/
     		$("#reportForm").attr("action","/crm/report_save");
     		$("#reportForm").ajaxSubmit(function(returnStr) {
    			var type = returnStr.split("_")[0];
     			var id = returnStr.split("_")[1];
     			if (type == "success") {
     				dialog("成功","success",true,1);
     				var str="/crm/report_show?visitReport.id="+id;
     				setTimeout(function(){window.location = str;},1000);	  
     			}else {
     				$(".report-add form .btn-save").show();
     				dialog(returnStr,"unsuccess",true,2);
     			}	
     	        return false;
     		});
     	}
    }); 
   
    /**
     * 公司自动补全contactCus
     */ 
	 customerAutoComplete($("#reportCustomer"));

	/*客户自动匹配*/
	function customerAutoComplete($input){
		    $input.autocomplete(encodeURI("/crmAjax/customer_findCusTop8"), {
	        //**加自定义表头**//*
	        minChars: 0,
	        width: 350,
	        matchContains: "true",
	        autoFill: false,
	        dataType: 'json',
	        parse: function(data) {  
	            var rows = [];  
	            if(data == null || data.customers == null){
	            	return rows;
	            }
	            for(var i=0; i<data.customers.length; i++){    
	                rows[rows.length] = {    
	                    data:data.customers[i],              
	                    value:data.customers[i].chName,     
	                    result:data.customers[i].chName   
	                };  
	            }  
	            return rows;  
	        }, 
	        formatItem: function(row, i, max) {
	            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"</div>";
	        },
	        formatMatch: function(row, i, max) {
	            return row.chName;
	        }
		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
		    	$(this).val("");
		    	$("#reportCustomerId").val("");
		    	$(this).val(data.chName);
		    	$("#reportCustomerId").val(data.id);
		    }).bind("unmatch", function() {//**没有匹配时**//*
		    	$(this).val("");
		    	$("#reportCustomerId").val("");
		    });
	}
	
	/**
     * 项目自动补全contactCus
     */ 
	 projectAutoComplete($("#reportProject"));

	/*项目自动匹配*/
	function projectAutoComplete($input){
		    $input.autocomplete(encodeURI("/crmAjax/report_autoProject"), {
	        //**加自定义表头**//*
	        minChars: 0,
	        width: 350,
	        matchContains: "true",
	        autoFill: false,
	        dataType: 'json',
	        parse: function(data) {  
	            var rows = [];  
	            if(data == null || data.projects == null){
	            	return rows;
	            }
	            for(var i=0; i<data.projects.length; i++){    
	                rows[rows.length] = {    
	                    data:data.projects[i],              
	                    value:data.projects[i].projectName,     
	                    result:data.projects[i].projectName   
	                };  
	            }  
	            return rows;  
	        }, 
	        formatItem: function(row, i, max) {
	            return "<div style='height: 20px;font-size: 12px;'>"+row.projectName+"</div>";
	        },
	        formatMatch: function(row, i, max) {
	            return row.projectName;
	        }
		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
		    	$(this).val("");
		    	$("#reportProjectId").val("");
		    	$(this).val(data.projectName);
		    	$("#reportProjectId").val(data.id);
		    }).bind("unmatch", function() {//**没有匹配时**//*
		    	$(this).val("");
		    	$("#reportProjectId").val("");
		    });
	}
	
	
	conatctAutoComplete($("#contact1"),$("#contactId1"));
 	conatctAutoComplete($("#contact2"),$("#contactId2"));
 	conatctAutoComplete($("#contact3"),$("#contactId3"));
 	/*联系人自动匹配*/
 	function conatctAutoComplete($input,$inputId){
 		     //  var cid=$("proCustomerId").val();
 		    $input.autocomplete(encodeURI("/crmAjax/contact_findConTop8"), {
 	        //**加自定义表头**//*
 		    tableHead: "<div> <span class='col-3'>姓名 -----------手机</div>",
 	        minChars: 0,
 	        width: 230,
 	       //extraParams:{cid:$("proCustomerId").val()}, 
 	        matchContains: "true",
 	        autoFill: false,
 	        dataType: 'json',
 	        parse: function(data) {  
 	            var rows = [];  
 	            if(data == null || data.contacts == null){
 	            	return rows;
 	            }
 	            for(var i=0; i<data.contacts.length; i++){    
 	                rows[rows.length] = {    
 	                    data:data.contacts[i],              
 	                    value:data.contacts[i].chName,     
 	                    result:data.contacts[i].chName   
 	                };  
 	            }  
 	            return rows;  
 	        }, 
 	        formatItem: function(row, i, max) {
 	            return "<div style='height: 20px;font-size: 12px;'>"+row.chName+"---"+row.phone+"</div>";
 	        },
 	        formatMatch: function(row, i, max) {
 	            return row.chName;
 	        }
 		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
 		    	$(this).val("");
 		    	$inputId.val("");
 		    	$(this).val(data.chName);
 		    	$inputId.val(data.id);
 		    }).bind("unmatch", function() {//**没有匹配时**//*
 		    	$(this).val("");
 		    	$inputId.val("");
 		    });
 	}
 	
 	emailAutoComplete($("#pm"));
 	emailAutoComplete($("#saleManager"));
 	/**
 	 *选择PM 销售经理
 	 */
 	function emailAutoComplete($input){
 		     //  var cid=$("proCustomerId").val();
 		    $input.autocomplete(encodeURI("/adminajax/findAllUser"), {
 	        //**加自定义表头**//*
 		    tableHead: "<div> <span class='col-3'>邮箱</div>",
 	        minChars: 0,
 	        width: 380,
 	       //extraParams:{cid:$("proCustomerId").val()}, 
 	        matchContains: "true",
 	        autoFill: false,
 	        dataType: 'json',
 	        parse: function(data) {  
 	            var rows = [];  
 	            if(data == null || data.userList == null){
 	            	return rows;
 	            }
 	            for(var i=0; i<data.userList.length; i++){    
 	                rows[rows.length] = {    
 	                    data:data.userList[i],              
 	                    value:data.userList[i].userMail,     
 	                    result:data.userList[i].enName   
 	                };  
 	            }  
 	            return rows;  
 	        }, 
 	        formatItem: function(row, i, max) {
 	            return "<div style='height: 20px;font-size: 12px;'>"+row.userMail+"---"+row.enName+"</div>";
 	        },
 	        formatMatch: function(row, i, max) {
 	            return row.userMail;
 	        }
 		    }).result(function(e,data,value,sec){//**加选中后的回调函数**//*
 		    	$(this).val("");
 		    	$(this).val(data.userMail);
 		    }).bind("unmatch", function() {//**没有匹配时**//*
 		    	$(this).val("");
 		    });
 	}
 	

 	/* 验证输入 */
    function validationInput() {
        var reg = /[\u4E00-\u9FA5\uF900-\uFA2D]/;
        //用中文正则判断拜访内容是否有填中文
        if(reg.test($("#content").val())==false){
            dialog("请填写拜访内容","unsuccess",true,2);
            return false;
        }
        if(reg.test($("#chance").val())==false){
            dialog("请填写合作机会内容","unsuccess",true,2);
            return false;
        }
        //if(!JudgeAttachment()){return false;}//必须上传拜访照片
        return $("#reportForm").validationEngine('validate');
       // return false;
    };
	
	
});