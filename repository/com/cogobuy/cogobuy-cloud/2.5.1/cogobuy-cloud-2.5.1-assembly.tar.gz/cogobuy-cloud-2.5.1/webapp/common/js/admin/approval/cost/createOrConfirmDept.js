$(function() {
	/* 增加验证条件 */
	$("#createUserName").addClass("validate[required]");
	$("#createUserId").addClass("validate[required]");

	$("#buName").addClass("validate[required]");
	$("#buId").addClass("validate[required]");

	$("#departmentName").addClass("validate[required]");
	$("#departmentId").addClass("validate[required]");

	$("#regionName").addClass("validate[required]");
	$("#regionId").addClass("validate[required]");

	$("#currencyName").addClass("validate[required]");
	$("#currencyId").addClass("validate[required]");

	$("#departmentCostTypeName").addClass("validate[required]");
	$("#departmentCostTypeId").addClass("validate[required]");


	$("input[tag=date]").click(function() {
		WdatePicker({
			maxDate : GetTodayDateStr()
		});
	});

	/*增加显示提交按钮*/
	$(document).keydown(function(event){ 
		 if (event.ctrlKey && event.keyCode == 122) {
			 $("#allSubmit").show();
		 }
	});
	
	/* 模拟select下拉列表选择账套时赋值 */
	$(".options-select .options a").click(
			function() {
				$(this).parents(".options-select").find(".select").find("span")
						.text($(this).attr("vshow"));
				var $id = $(this).attr("vid");
				var $show = $(this).attr("vshow");
				$(this).parents(".options-select").find("input[tag=id]").val(
						$id);
				$(this).parents(".options-select").find("input[tag=show]").val(
						$show);
				var $selecttag = $(this).attr("selecttag");
				$("li [" + $selecttag + "]").hide();
				$("li [" + $selecttag + "=" + $id + "]").show();
				/* 清除下级元素值 
				var $deptinput = $("div[" + $selecttag + "_input=" + $selecttag
						+ "_input]");
				$deptinput.find("div.select span").text("");
				$deptinput.find("input").val("");*/
				if($(this).attr("type")=="cost"){
					if($(this).attr("vshow")=="餐补"){
						$("#deptMonth").addClass("validate[required]");
						//显示，隐藏
						$("#monthShow").show();
						$("#tbodyTwoShow").show();
						$("#createtbodyShow").hide();
					}else{
						$("#deptMonth").removeClass("validate[required]");
						//显示，隐藏
						$("#monthShow").hide();
						$("#tbodyTwoShow").hide();
						$("#createtbodyShow").show();
					}
				}
				$(this).validationEngine('hidePrompt');
				return false;
			});

	//初始化时模拟点击BU，使其出现对应的Dep列表
	var buId = $("#buId").val();
	$("#buList").find("a[vid="+buId+"]").trigger("click");
	var costBuId = $("#costBuId").val();
	$("#costBuList").find("a[vid="+costBuId+"]").trigger("click");
	
	/* 填单日期 */
	var createDate = new Date();// 申请日期
	$("#cYear").text(createDate.getFullYear());
	$("#cMonth").text(createDate.getMonth() + 1);
	$("#cDay").text(createDate.getDate());

	/* 点击确认按钮 */
	$("#deptconfirmbutton").click(function() {
		/* 整理表格,去空行 */
		cleanTbody($("#createtbody"));
		cleanTbody($("#tbodyTwo"));
		/* 将列表增加name,id属性 */
		addIdAndNameForInput($("#createtbody"));
		addIdAndNameForInput($("#tbodyTwo"));
		/*添加验证*/
		var type = $("#departmentCostTypeName").val();
		if(type=="餐补"){
			//添加验证
			$("#tbodyTwo").find("input[tag=show]").addClass("validate[required]");
			$("#tbodyTwo").find("input[tag=sum]").addClass("validate[required,custom[positiveNumber]]");
		}else{
			//添加验证
			$("#createtbody").find("input[tag=date]").addClass("validate[required]");
			$("#createtbody").find("input[tag=sum]").addClass("validate[required,custom[positiveNumber]]");
		}
		var error = $("#deptCreateForm").validationEngine('validate');
		if (error) {
			if(type=="餐补"){
				copyCreateToConvirmTwo();
			}else{
				copyCreateToConvirm();
			}
			fillMaillList();
			copyFileList();  
			$("#deptcreatepage").hide();
			$("#deptconfirmpage").show();
		}
		return false;
	});

	/* 点击上一步 */
	$("#upStep").click(function() {
		$("#deptcreatepage").show();
		$("#deptconfirmpage").hide();
		//去掉单据中的数据
		var typeNum = $("#collectDiv").find("div").size();//有多少种类型
	    for(var i=0;i<typeNum;i++){
			var $tr = $("#confirmTable").find("tr").eq(i+1);
			$tr.find("div").eq(0).text("");
			$tr.find("div").eq(1).text("");
	    }
	    //去掉Collect数据
	    $("#collectDiv").empty();
	});

	/* 确认提交 */
	$("#allSubmit").click(function() {
    	//去掉复制用的tr
    	$("tr[hide=hide]").remove();
    	//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#deptCreateForm").append(inputStr);
    		}
    	});
    	//去掉不需要提交的表格
    	var type = $("#departmentCostTypeName").val();
    	if(type=="餐补"){
			$("#createtbodyShow").empty();
		}else{
			$("#tbodyTwoShow").empty();
		}
    	$("#allSubmit").hide();
		$("#deptCreateForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功！","success",true,1);
				setTimeout(function(){window.location = "/approval/cost_show?costApproval.id="+id;},1000);	  
			}else{
				$("#allSubmit").show();
				dialog(returnStr,"unsuccess",true,2);
			}
	        return false;
		});
	});
});

/* 整理表格，去空行，至少保留一行 */
function cleanTbody(tbody) {
	var trNum = tbody.find("tr").size();
	for ( var i = trNum; i >= 0; i--) {
		trNum = tbody.find("tr").size();
		var tr = tbody.find("tr").eq(i);
		if (checkEmptyTr(tr)) {
			if (trNum > 1) {
				tr.remove();
			}
		}
	}
}

/* 验证空行 */
function checkEmptyTr(tr) {
	var inputNum = tr.find("input").size();
	var flag = true; // 为空
	for ( var i = 0; i < inputNum; i++) {
		var input = tr.find("input").eq(i);
		if ($.trim(input.val()) != "") {
			flag = false; // 不为空
			break;
		}
	}
	return flag;
}

/* 增加新建页面列表的name,id属性 */
function addIdAndNameForInput(tbody) {
	var $trs = tbody.find("tr");/* 获取所有tr */
	var firstName = "deptDetailList";/* 前缀名称 */
	var dateLastName = ".date";/* 日期后缀名称 */
	var dateIdFirstName = "date";/* 日期ID前缀 */
	var sumLastName = ".sum";/* 金额后缀名称 */
	var sumIdFirstName = "sum";/* 金额ID前缀 */
	var descriptionLastName = ".description";/* 描述后缀名称 */
	var dailyCostName = ".dailyCostName";/* 用途后缀名称 */
	var dailyCostNameId = "dailyCostName";/* 用途Id前缀 */
	var dailyCostCode = ".dailyCostCode";/* 用途Code后缀名称 */
	var dailyCostCodeId = "dailyCostCode";/* 用途CodeId前缀 */
	for ( var i = 0; i < $trs.size(); i++) {
		var numtag = "[" + i + "]";
		var $tr = $trs.eq(i);
		var $date = $tr.find("input[tag=date]");
		$date.attr("id", dateIdFirstName + numtag);
		$date.attr("name", firstName + numtag + dateLastName);
		var $sum = $tr.find("input[tag=sum]");
		$sum.attr("id", sumIdFirstName + numtag);
		$sum.attr("name", firstName + numtag + sumLastName);
		var $description = $tr.find("input[tag=description]");
		$description.attr("name", firstName + numtag + descriptionLastName);
		var $name = $tr.find("input[tag=show]");
		$name.attr("id", dailyCostNameId + numtag);
		$name.attr("name", firstName + numtag + dailyCostName);
		var $code = $tr.find("input[tag=id]");
		$code.attr("id", dailyCostCodeId + numtag);
		$code.attr("name", firstName + numtag + dailyCostCode);
	}
}

/* 表一：拷贝新建页面的值到确认页面，并计算金额总和 */
function copyCreateToConvirm() {
	var $trs = $("#createtbody").find("tr");/* 获取所有tr */
	var moneySum = 0;/* 金额总和 */
	var $costBuName = $("#costBuName").val();/* 费用BU名称 */
	var $costDeptName = $("#costDepartmentName").val();/* 费用部门名称 */
	var $currencyName = $("#currencyName").val();/* 币种名称 */
	var $costTypeName = $("#departmentCostTypeName").val();/* 费用用途 */
	/* 清空确认页面原有数据 */
	$("#confirmfirsttbody").empty();
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		var $date = $tr.find("input[tag=date]");
		var $sum = $tr.find("input[tag=sum]");
		moneySum = add(moneySum, $sum.val());
		var $description = $tr.find("input[tag=description]");
		var listtr = "<tr><td class=\"col-1\"><div>" + $date.val() + "</div></td><td class=\"col-2\"><div>"
				+ $costBuName + "</div></td><td class=\"col-3\"><div>" + $costDeptName
				+ "</div></td><td class=\"col-4\"><div>" + $costTypeName
				+ "</div></td><td class=\"col-5\"><div>" + $description.val()
				+ "</div></td><td class=\"col-6\"><div>" + $currencyName
				+ "</div></td><td class=\"col-7 amount\"><div>" + fmoney($sum.val(),2)
				+ "</div></td></tr>";
		$("#confirmfirsttbody").append(listtr);
	}

	/* 将金额总和填入新建页面 */
	$("#totalSum").val(moneySum);
	/* 将币种符号填入确认页面 */
	$("#moneyCode").text(getCurrencyFlag($currencyName));
	$("[moneyName=moneyName]").text($currencyName);
	/* 将总金额、费用类型填入确认页面 */
	$("[sumCost=sumCost]").text(fmoney(moneySum,2));
	$("#costTypeName").text($costTypeName);
	/* 将金额小写转换成大写填入确认页面 */
	lowToUpper(moneySum);
	/* 填写确认页面报销部门 */
	$("#approvalBuAndDept").text($("#buName").val() + "_" + $("#departmentName").val());
	/*写Collect*/
	$copyDiv = $("#collectCopy").clone(true);
	$copyDiv.find("[name*=dailyCostName]").val($costTypeName);
	$copyDiv.find("[name*=sum]").val(moneySum);
	//Collect改名
	var inputNum = $copyDiv.find("input").size();
	for(var v = 0; v < inputNum; v++){
		var $input = $copyDiv.find("input").eq(v);
		var name = $input.attr("name");
		var before= $.trim(name.split(".")[0]);
			var obefore =  $.trim(before.split("[")[0]); //避免重复添加[下标]
		var after= $.trim(name.split(".")[1]);
		var all = obefore+"["+0+"]"+"."+after;
		$input.attr("name",all);
	}
	$("#collectDiv").append($copyDiv);
}

/* 表二：拷贝新建页面的值到确认页面，并计算金额总和 */
function copyCreateToConvirmTwo() {
	var $trs = $("#tbodyTwo").find("tr");/* 获取所有tr */
	var moneySum = 0; /* 金额总和 */
	var collectNum = 0; /* collect计数 */
	
	var $month = $("#deptMonth").val(); /*月份*/
	var $costBuName = $("#costBuName").val();/* 费用BU名称 */
	var $costDeptName = $("#costDepartmentName").val();/* 费用部门名称 */
	var $currencyName = $("#currencyName").val();/* 币种名称 */
	/* 清空确认页面原有数据 */
	$("#confirmfirsttbody").empty();
	for ( var i = 0; i < $trs.size(); i++) {
		var $tr = $trs.eq(i);
		var $name = $tr.find("input[tag=show]").val();
		var code = $tr.find("input[tag=id]").val();
		var sum = $tr.find("input[tag=sum]").val();	
		var description = $tr.find("input[tag=description]").val();
		moneySum = add(moneySum, sum);
		
    	//计算Collect和
    	var has = $("#collectDiv").find("div[collectTag="+code+"]").size();
    	if(has>0){//有，则修改和
    		$div = $("#collectDiv").find("div[collectTag="+code+"]").eq(0);
    		var oldSum = $div.find("[name*=sum]").val();
    		$div.find("[name*=sum]").val(add(oldSum,sum));
    	}else{//没有，则插入
    		$copyDiv = $("#collectCopy").clone(true);
    		$copyDiv.attr("collectTag",code);
    		$copyDiv.find("[name*=dailyCostCode]").val(code);
    		$copyDiv.find("[name*=dailyCostName]").val($name);
    		$copyDiv.find("[name*=sum]").val(sum);
    		//Collect改名
    		var inputNum = $copyDiv.find("input").size();
			for(var v = 0; v < inputNum; v++){
	    		var $input = $copyDiv.find("input").eq(v);
				var name = $input.attr("name");
				var before= $.trim(name.split(".")[0]);
					var obefore =  $.trim(before.split("[")[0]); //避免重复添加[下标]
				var after= $.trim(name.split(".")[1]);
				var all = obefore+"["+collectNum+"]"+"."+after;
				$input.attr("name",all);
			}
			$("#collectDiv").append($copyDiv);
    		collectNum++;
    	};
		
		var listtr = "<tr><td class=\"col-1\"><div>" + $month + "</div></td><td class=\"col-2\"><div>"
				+ $costBuName + "</div></td><td class=\"col-3\"><div>" + $costDeptName
				+ "</div></td><td class=\"col-4\"><div>" + $name
				+ "</div></td><td class=\"col-5\"><div>" + description
				+ "</div></td><td class=\"col-6\"><div>" + $currencyName
				+ "</div></td><td class=\"col-7 amount\"><div>" + fmoney(sum,2)
				+ "</div></td></tr>";
		$("#confirmfirsttbody").append(listtr);
	}

	/* 将金额总和填入新建页面 */
	$("#totalSum").val(moneySum);
	/* 将币种符号填入确认页面 */
	$("#moneyCode").text(getCurrencyFlag($currencyName));
	$("[moneyName=moneyName]").text($currencyName);
	/* 将总金额、费用类型填入确认页面 */
	$("[sumCost=sumCost]").text(fmoney(moneySum,2));
	
	var typeNum = $("#collectDiv").find("div").size();//有多少种类型
    for(var i=0;i<typeNum;i++){
		var div = $("#collectDiv").find("div").eq(i);
		var name = div.find("[name*=dailyCostName]").val();
		var value = div.find("[name*=sum]").val();
		var $tr = $("#confirmTable").find("tr").eq(i+1);
		$tr.find("div").eq(0).text(name);
		$tr.find("div").eq(1).text(fmoney(value,2));
    }

	/* 将金额小写转换成大写填入确认页面 */
	lowToUpper(moneySum);
	/* 填写确认页面报销部门 */
	$("#approvalBuAndDept").text($("#buName").val() + "_" + $("#departmentName").val());
}

function copyFileList(){
	var html = $("#fileListForCreate").html();
	$("#fileListForConfirm").html("");
	$("#fileListForConfirm").html(html);
	$("#fileListForConfirm a[tag='del']").each(function(){
		$(this).hide();
	});
	$("#fileListForConfirm a[downFileTag=downFileTag]").bind("click",function(){
		fileDownLoad($(this));
	  	return false;
	});
}