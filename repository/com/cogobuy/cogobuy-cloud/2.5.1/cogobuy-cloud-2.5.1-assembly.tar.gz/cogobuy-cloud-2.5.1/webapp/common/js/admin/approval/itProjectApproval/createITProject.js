$(function() {
	/*隐藏确定页面*/
	$("#confirm").hide();
	/* 点击下一步 */
	$("#next").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */	
		if (error) {
            calTaxSum();/*计算估计总价*/
			switchPageForConfirm();/* 转换显示页面 -- 将新建页面隐藏、显示确认页面 */
            copyValueToConfig();/* 将新建页面的数值写入确认页面 */
            getEmailList();/* 获取邮件发送列表 */
            copyFileList();/*上传附件公用*/
		}
	});
	/* 点击上一步 */
	$("#previous").click(function() {
		$("#confirm").hide();
		$("#write").show();/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
	});
	/* 点击提交 */
	$("#submit").click(function() {
		//获取已经选择的发送邮件对象
    	var sendMail_check = $("input[type=checkbox][name='mails']");  //得到所有被选中的checkbox
    	sendMail_check.each(function(i){//循环拼装被选中项的值
    		if($(this).attr("checked")){
    			inputStr = "<input type=\"hidden\" name=\"mails\" value=\""+$(this).val()+"\" />";
    			$("#itProjectForm").append(inputStr);
    		}
    	});
		
    	$("#submit").hide();
    	$("#itProjectForm").attr("action","/approval/itProject_create");
		$("#itProjectForm").ajaxSubmit(function(returnStr) {
			var type = returnStr.split("_")[0];
			var id = returnStr.split("_")[1];
			if (type == "success") {
				dialog("成功","success",true,1);
				setTimeout(function(){window.location = "/approval/itProject_show?itProjectApproval.id="+id;},1000);
			}else {
				$("#submit").show();
				dialog(returnStr,"unsuccess",true,2);
			}	
	        return false;
			
		});
	});

});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	cleanTbody($("#detailListTbody"));
	addIdAndNameForInput($("#detailListTbody"));
}

/* 验证输入 */
function validationInput() {
	return $("#itProjectForm").validationEngine('validate');
}

/* 将新建页面的数值写入确认页面 */
function copyValueToConfig() {
    /*清空备注*/
	$("#remark_confirm").text("");
	/*清空列表*/
	$("#detailListTbody_confirm").empty();
	/*写值*/
     $("#title_confirm").text($("#title").val());
	 $("#remark_confirm").text($("#remark").val());
	 /*写表格详细值*/
		var $trs = $("#detailListTbody").find("tr");
		for ( var i = 0; i < $trs.size(); i++) {
			var $tr = $trs.eq(i);
			var trString = 
				"<tr>" +
                "<td class=\"equiment\"><div>"+$tr.find("input[tdTag=equipment]").val()+"</div></td>"
				+ "<td class=\"description\"><div>"+$tr.find("input[tdTag=description]").val()+"</div></td>"
				+ "<td class=\"\"><div>"+$tr.find("input[tdTag=quantity]").val()+"</div></td>"
				+ "<td class=\"\" style=\"text-align: center\"><div>"+$tr.find("input[tdTag=gaugePrice]").val()+"</div></td>"
                + "<td class=\"\" style=\"text-align: center\"><div>"+$tr.find("input[tdTag=gaugeSumPrice]").val()+"</div></td>" +
                "</tr>";
			   $("#detailListTbody_confirm").append(trString);
		}
          var trSum="<tr><td></td><td></td><td></td><th>合计：</th><td style='text-align: center'>"+$("#gaugeSum").val()+"</th></tr>";
          $("#detailListTbody_confirm").append(trSum);
}

/* 获取邮件发送列表 */
function getEmailList() {
	var url = "/approval/itProject_showConfirmMail";
	$("#mailList").load(encodeURI(url), function() {
		/*检测流程类型是否存在*/
		var subCodeNotExisted = $("#subCodeNotExistedForCreate").val();
		/*检测流程节点是否都有审批人*/
		var nodeNoApprovalUser = $("#nodeNoApprovalUserForCreate").val();
		if(subCodeNotExisted){
			$("#submit").hide();
			dialog("未找到流程，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else if(nodeNoApprovalUser){
			$("#submit").hide();
			dialog("存在没有审批人的节点，请发邮件至 itsd@cogobuy.com 添加流程","unsuccess",true,5);
			return false;
		}else{
			$("#submit").show();
		}
	});
}

/* 转换显示页面 -- 将确认页面隐藏、显示新建页面 */
function switchPageForConfirm() {
	$("#confirm").show();
	$("#write").hide();
}
//计算估计总价
function calTaxSum(){
    var  $trs=$("#detailListTbody").find("tr");
    var sum=0;
    for(var i=0;i<$trs.size();i++ ){
        var $tr = $trs.eq(i);
        /*数量*/
        var quantity = changeNum($tr.find("[tdTag=quantity]").val());
        /*估计单价*/
        var  gaugePrice=changeNum($tr.find("[tdTag=gaugePrice]").val());
        var gaugeSumPrice=multiply(quantity,gaugePrice);
        $tr.find($tr.find("[tdTag=gaugeSumPrice]").val(gaugeSumPrice));
        /*总价*/
        sum += gaugeSumPrice;
    }
    $("#gaugeSum").val(sum);
}

/*取回数值，没有值的为0*/
function changeNum(num){
    if($.trim(num)==''){
        return 0;
    }
    return $.trim(num);
}
