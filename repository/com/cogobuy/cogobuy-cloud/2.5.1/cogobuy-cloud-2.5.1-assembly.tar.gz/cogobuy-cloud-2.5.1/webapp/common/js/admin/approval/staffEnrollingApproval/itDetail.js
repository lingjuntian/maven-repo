/**
 * 审核通过
 * @param parent
 */
//隐藏保存按钮
$(function(){$("[tdTag='pur_save']").hide();});

  function update(e){
      //隐藏修改按钮
      $("[tdTag=it_update]").hide();
      //影藏审批按钮
      $("#pass").hide();
      //获得当前行
       var $tr=$(e).closest("tr");
      //获得下拉框币种的值
      var $currencyVal=$tr.find("[tdTag=currency]").text();
      var $currencyOption;
      //将默认下拉框的值设置为原值
      if($currencyVal!=''&&$currencyVal=='港币'){
          $currencyOption="<option value='人民币'>人民币</option>"+
          "<option value='港币' selected='selected'>港币</option>"+
          "<option value='美元'>美元</option>";
      }else if($currencyVal!=''&&$currencyVal=='美元'){
           $currencyOption="<option value='人民币'>人民币</option>"+
              "<option value='港币'>港币</option>"+
              "<option value='美元' selected='selected'>美元</option>";
      }else{
          $currencyOption="<option value='人民币' selected='selected'>人民币</option>"+
              "<option value='港币'>港币</option>"+
              "<option value='美元'>美元</option>";
      }
      var $editTr=
          "<td class='equipment'><div><input tdTag='equipment' type='text'id='equipment' name='detail.equipment' class='input-text'  maxlength='100' value="+ $tr.find("[tdTag=equipment]").text() +">" +
          "<input type='hidden' name='detail.id' tdTag=detailId value='"+$tr.find("[tdTag=detailId]").val() +"'></div></td>" +
          "<td class='remark'><div><input tdTag='remark'type='text' id='remark' name='detail.remark' class='input-text'   maxlength='150' value="+ $tr.find("[tdTag=remark]").text() +"> </div></td>" +
          "<td class='price price1' style='width:50px' tdTag='price'><div>"+ $tr.find("[tdTag=price]").text()+"</div></td>"+
          "<td class='currency'><div><select name='detail.currency' tdTag='currency' style='height:23px;font-size:13px;cursor: pointer'>" +$currencyOption+"</select></div></td> " +
          " <td class='quantity' style='width:30px' tdTag='quantity' ><div>" +$tr.find("[tdTag=quantity]").text() +"</div></td> " +
          " <td class='price'><div><input  type='text'  tdTag='actualPrice' id='actualPrice' maxlength='10' name='detail.actualPrice' class='input-text' style='width:55px ' value="+ $tr.find("[tdTag=actualPrice]").text() +"></div></td>" +
          " <td class='price' style='width:50px'><div><a style='cursor: pointer' tdTag='it_save' onclick='save(this)'>保存</a></div></td>" ;
      $tr.html($editTr);
  }

  function save(e){
      //验证填写数据
      var $form= $("#updateDetaliForm");
      $form.find("[name=detail.equipment],[name=detail.remark],[name=detail.actualPrice]").addClass("validate[required]");
      $form.find("[name=detail.actualPrice]").addClass("validate[required,custom[amountSixPoint]]");
      var $error=$form.validationEngine('validate');
      if($error==true){
           //计算总额
          calTaxSum();
          //ajax提交修改的数据
          $form.attr("action","/approval/staffEnrolling_updateDetail");
          $form.ajaxSubmit(function(returnStr){
              if(returnStr=="success"){
                  dialog("成功", "success", true, 2);
                  //获得当前行
                  var $tr=$(e).closest("tr");
                  //将当前行变为不可编辑状态
                  var $trshow= "<td class='equipment' tdTag='equipment'><div>"+$tr.find("[tdtag=equipment]").val() +
                      "<input type='hidden' tdTag=detailId  value='"+$tr.find("[tdTag=detailId]").val()+"'></div></td>" +
                      "<td class='remark' tdTag='remark' ><div>"+$tr.find("[tdTag=remark]").val()+"</div></td>" +
                      "<td class='price price1' style='width:50px'  tdTag='price'><div>"+ $tr.find("[tdTag=price]").text()+"</div></td>"+
                      "<td class='currency' tdTag='currency'><div>" +$tr.find("[tdTag=currency]").val() +"</div></td> " +
                      " <td class='quantity' style='width:30px' tdTag='quantity'><div>" +$tr.find("[tdTag=quantity]").text() +"</div></td> " +
                      " <td class='price' tdTag='actualPrice' ><div>"+$tr.find("[tdTag=actualPrice]").val()+"</div></td>" +
                      " <td class='price' style='width:50px'><div><a style='cursor: pointer' tdTag='it_update' onclick='update(this)'>修改</a></div></td>" ;
                  $tr.html($trshow);
                  $("[tdTag=it_update]").show();
                  $("#pass").show();
                  return true;
              }else{
                  dialog(returnStr, "unsuccess", true, 2);
                  return false;
              }

          });
      }
}
//计算总价
    function calTaxSum(){
        var  $trs=$("tbody").find("tr");
        var sum=0;
        for(var i=0;i<$trs.size();i++ ){
            var $tr = $trs.eq(i);
            /*数量*/
            var actualPrice=0;
             var quantity = changeNum($tr.find("[tdTag=quantity]").text());

            /*实际单价*/
            if($tr.find("[tdTag=actualPrice]").text()==''){
                actualPrice = changeNum($tr.find("[tdTag=actualPrice]").val());
            }else{
                actualPrice = changeNum($tr.find("[tdTag=actualPrice]").text());
            }
            /*总价*/
            sum += multiply(quantity,actualPrice);
        }
        $("#sum").text(sum);
        $("#sum_input").val(sum);
    }

/*取回数值，没有值的为0*/
function changeNum(num){
    if($.trim(num)==''){
        return 0;
    }
    return $.trim(num);
}


/*
 * 采购部门经理更新供应商
 */
function pur_update(e){
	//隐藏修改按钮
    $("[tdTag=pur_update]").hide();
    //影藏审批按钮
    $("#pass").hide();
    //获得当前行
     var $tr=$(e).closest("tr");
     $tr.find("[tdTag=supplier]").html($selectStr);
     $tr.find("[tdTag=pur_save]").show();
         
}
function pur_save(e){
	//验证填写数据
    var $form= $("#updateDetaliForm");
    $form.find("[name=detail.supplier]").addClass("validate[required]");
    var $error=$form.validationEngine('validate');
    if($error){
    	$("[tdTag=pur_update]").hide();
    	 //ajax提交修改的数据
        $form.attr("action","/approval/staffEnrolling_purUpdateDetail");
        $form.ajaxSubmit(function(returnStr){
        	 if(returnStr=="success"){
                 dialog("成功", "success", true, 2);
                 //获得当前行
                 var $tr=$(e).closest("tr");
                 var text="<div>"+$tr.find("[name=detail.supplier]").val()+"</div>";
                 $tr.find("[tdTag=supplier]").html(text);
                 $("[tdTag=pur_update]").show();
                 $("[tdTag=pur_save]").hide();
                 $("#pass").show();
                 return true;
             }else{
                 dialog(returnStr, "unsuccess", true, 2);
                 return false;
             }    	
        });
    }

}


/*
 * it仓管审批通过前检查是否填写了所有设备的实际价格
 */
 function full_actualPrice(){
	 var $trs=$("#tbody").find("tr");
		for(var i=0;i<$trs.size()-1;i++){
			var $tr=$trs.eq(i);
			if($tr.find("[tdTag=actualPrice]").text()==null||$tr.find("[tdTag=actualPrice]").text()==""){
				return false;
			}	
		}
		return true;	 
 }

 /*
  * it仓管审批通过前检查是否填写了所有设备的实际价格
  */
  function full_supplier(){
 	 var $trs=$("#tbody").find("tr");
 		for(var i=0;i<$trs.size()-1;i++){
 			var $tr=$trs.eq(i);
 			if($tr.find("[tdTag=supplier]").text()==null||$tr.find("[tdTag=supplier]").text()==""){
 				return false;
 			}	
 		}
 		return true;	 
  }
 
 
  /*
   * 采购经理审批通过
   */
  function sup_approval(parent,parentId,returnUrl) { 
  	if(full_supplier()){
  	  flowApproval.approval(parent,parentId,returnUrl);
  	}else{
  		 dialog("采购经理节点必须得选择所有设备的供应商才能审批通过的哦！");
  	}
  		
  } 
  
  
/*
 * it仓管审批通过
 */
function it_approval(parent,parentId,returnUrl) { 
	if(full_actualPrice()){
	  flowApproval.approval(parent,parentId,returnUrl);
	}else{
		 dialog("it_仓管检查/供应商节点必须填写所有设备的实际价格才能审批通过的噢！");
	}
		
}


