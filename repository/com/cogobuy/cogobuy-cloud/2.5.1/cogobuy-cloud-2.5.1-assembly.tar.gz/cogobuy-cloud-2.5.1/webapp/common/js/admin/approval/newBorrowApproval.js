var inventoryList;
var inventoryClassList;
$(function(){	
	/* 是否是境内人民币交易 */
	$("label[for='isrmb']").click(function(){
		var isChecked = $(this).find("input").attr("checked");
		if(isChecked){
			$(this).next(".vat").show();
		}else{
			$(this).next(".vat").hide();
		}
	});
	/* 模拟select下拉列表 */
	$(".options-select .select").click(function(event){
		event.stopPropagation();
		$(".popup-tips").fadeOut("slow");
		$(".input-box").css({zIndex:"0"});
		$(this).parents(".input-box").css({zIndex:"88"});
		var optionsObj = $(this).parent(".options-select").find(".options") ;
		$(".options-select .options").hide();
		if(optionsObj.hasClass("none")){
			optionsObj.show();
			optionsObj.removeClass("none");
		}else{
			optionsObj.hide();
			optionsObj.addClass("none");
		}
	})
	$(".options-select .options a").click(function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input").val($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input[id$=Id]").val($(this).attr("labelId"));
		if($(this).attr("tagN") == "bu"){
			$("#departmentId").val("");
			$("#department").val("");
			$("#personId").val("");
			$("#person").val("");
			$("#inventoryClass").val("");
			$("#inventoryClassId").val(""); 
			//findLedgerByBuForSelect($(this).attr("tagValue"),"ledgerForSelect");
			ajaxByBu($("#buId").val());
		}
		$(this).parents(".options-select").find(".options").hide();
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	})
	
	$(".options-select .options,.popup-tips").click(function(event) {
		event.stopPropagation();
	});
	
	$(document).click(function(event) {
		$(".options-select .options").hide();
		$(".options-select .options").addClass("none");
		$(".popup-tips").fadeOut("slow");
	});
	
	$("#dpSelect").each(function(){
    	if($(this).find("input[id!=Id]").val() == null || $(this).find("input[id!=Id]").val() == ""){
	    	$(this).find("span").text($(this).find("li:eq(1)").find("a").attr("vhidden"));
	    	$(this).find("input[id!=Id]").val($(this).find("li:eq(1)").find("a").attr("vhidden"));
	    	$(this).find("input[id$=Id]").val($(this).find("li:eq(1)").find("a").attr("labelId"));
    	}
    });

    $("input[id^=approvalTime]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}, minDate:GetTodayDateStr()});
	});
    $("input[id$=returnTime]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}, minDate:GetTodayDateStr()});
	});

    
    
	initTrEvents();
	for(var i = 0; i < 1; i++){
		var tr = $("#copyTr").clone(true);
	   	tr.attr("id", "");	
	 	tr.appendTo($("#table"));
	 	tr.show();
 	}
	
 	resetRowNO();
 	
 	
	
	$("#gotoStep2").click(function(){
    	gotoStep2();
    	return false;
    });
    
    $("#gotoStep1").click(function(){
    	gotoStep1();
    	return false;
    });

	
    commonReady();
    
   // autoDepartment("department");
    //autoInventoryClass("inventoryClass");
    //autoSales("person");
    autoCustomer();
    // initInventoryList();
});

function initInventoryList(ledger){
	var url = "/adminajax/master_findInventoryList";
	if(ledger != "" && ledger != null){
		url += "?ledger="+ledger;
	}
	$.ajax({
		type:"GET",
		url:encodeURI(url),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.inventoryList != null){
				inventoryList = data.inventoryList;
				inventoryAutoComplete($("#table [id$=inventoryCode]"));
			}
		}
	});
}

function autoCustomer(){
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findCustomerList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.customerList != null){
				$("#customerName").autocomplete(data.customerList, {
					/**加自定义表头**/
					tableHead: "<div><span style='width:40%' class='col-1'>客户编码</span> <span style='width:58%' class='col-2'>客户名称</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span  style='width:40%' class='col-1'>" + row.customerCode + "</span> " + "<span style='width:58%' class='col-2'>" + row.fullName + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.fullName;
					},
					formatResult: function(row) {
						return row.fullName;
					}
					/*formatInputResult: function(data){
                    	autoCompleteCustomer(data)					
					},*/
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					autoCompleteCustomer(data);
				}).bind("unmatch", function(){
					clearCustomerInfo();
				});
			}
		}
	});
}
function autoSales(id){
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findPersonList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.personList != null){
				$("#"+id).autocomplete(data.personList, {
					/**加自定义表头**/
					tableHead: "<div><span class='col-1'>部门名称</span> <span class='col-2'>业务员名称</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span class='col-1'>" + row.TDepartment.departmentName + "</span> " + "<span class='col-2'>" + row.personName + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.personName;
					},
					formatResult: function(row) {
						return row.personName;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#personId").val(data.id);
					$("#person").val(data.personName);
				}).bind("unmatch", function(){
					$("#personId").val("");
				});
			}
		}
	}); 
}
function autoInventoryClass(id){
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findInventoryClassList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.list != null){
				$("#"+id).autocomplete(data.list, {
					/**加自定义表头**/
					tableHead: "<div><span >产品线</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span >" + row.name + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.name;
					},
					formatResult: function(row) {
						return row.name;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#inventoryClassId").val(data.id);
					$("#inventoryClass").val(data.name);
				}).bind("unmatch",function(){
					$("#inventoryClassId").val("");
				});
			}
		}
	});
}
function autoDepartment(id){
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findDepartmentList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.departmentList != null){
				$("#"+id).autocomplete(data.departmentList, {
					/**加自定义表头**/
					tableHead: "<div><span>部门名称</span></div>",
					minChars: 0,
					width: 250,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span>" + row.departmentName + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.departmentName;
					},
					formatResult: function(row) {
						return row.departmentName;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#departmentId").val(data.id);
					$("#department").val(data.departmentName);
				}).bind("unmatch", function(){
					$("#departmentId").val("");
				});
			}
		}
	});
}

//确认订单，进入下一步
function gotoStep2(){
	var error1 = checkPartNo("table", true);
	var error2 = $("#borrowStockForm").validationEngine('validate');
	showLineTips("table", "orderNo");
	if(error1 && error2 == true){
		copyConfirmData();
		copyTableForConfirm("table");
		$("#step1").hide();
		$("#step2").show();
		copyFileList();//copy attachment list
		var url = "/approval/approval_emailList?checkUser=false&approvalType="+ $("#approvalType").val() + "&parent="+ $("#parent").val();
		$("#mailList").load(encodeURI(url), function(){
			
		});
	}
}

function copyConfirmData(){
    $("#borrowStockForm input[type=text]").each(function(){
    	var id = $(this).attr("id");
    	var $td = $("#" + id + "Td");
    	if($td[0] != null){
    		$td.text($(this).val());
    	}
    });
    
    $("#borrowStockForm textarea").each(function(){
    	var id = $(this).attr("id");
    	var $td = $("#" + id + "Td");
    	if($td[0] != null){
    		$td.text($(this).val());
    	}
    });
    $("#borrowStockForm [id$=Select]").each(function(){
    	var id = $(this).attr("id");
    	var $td = $("#" + id + "Td");
    	if($td[0] != null && $(this).find("input").val() != ""){
    		$td.text($(this).find("span").text());
    	}
    });
    $("#borrowStockForm [id$=Span]").each(function(){
    	var id = $(this).attr("id");
    	var $td = $("#" + id + "Td");
    	if($td[0] != null){
    		$td.text($(this).text());
    	}
    });
    
}
function copyTableForConfirm(tableId){
	var len = $("#" + tableId + " tr").size();
	$("#" + tableId + "Td tr:gt(0)").remove();
	for(var i = 0; i < len; i++){
		var tr = $("#" + tableId + " tr").eq(i);
		var showTr = $("#" + tableId + "Td tr:eq(0)").clone();
		showTr.find("td:eq(" + 0 + ") div").text(tr.find("[id$=item]").val());
		var j = 1;
		tr.find("input[type=text]").each(function(){
			showTr.find("td:eq(" + j + ") div").text($(this).val());
			j++;
		});
		
		showTr.appendTo("#" + tableId + "Td");
		showTr.show();
		if(i % 2 == 0){
	    	showTr.removeClass("even").removeClass("odd").addClass("even");
	    }
	    else if(i % 2 == 1){
	    	showTr.removeClass("even").removeClass("odd").addClass("odd");
	    }
	}
}
function save(){
	$("#copyTr").html("");
	$("#mailList").clone(true).appendTo("#mailsForSubmit");
	//$("#orderForm").attr("action", "/admin/orderToken_create");
	$("#borrowStockForm").ajaxSubmit(function(returnStr){
        if (returnStr != "error") {
          dialog("成功！","success",true,1);
	      setTimeout(function(){window.location = "/approval/borrowStock_list"},1000);	        
        } else if(returnStr == "error"){
         dialog("数据保存错误，请稍后重试！","unsuccess",true,1);
        }
      });
}



function commonReady(){
    /**给表单元素添加验证**/
	$("#bussinessUnit").addClass("validate[required]");
	$("#department").addClass("validate[required]");
	$("#inventoryClass").addClass("validate[required]");
    $("#customerName").addClass("validate[required]");
    $("#person").addClass("validate[required]");
    $("#approvalTime").addClass("validate[required]");
    $("#contactor").addClass("validate[required]");
    $("#telephone").addClass("validate[required]");
    $("#email").addClass("validate[required]");
    

    $("#submit").click(function(){
		save();
		return false;
    });
}
//与客户相关的开始
function autoCompleteCustomer(data){
	clearCustomerInfo();
	$("#customerId").val(data.id);
	$("#customerName").val(data.fullName);
	$("#customerName").validationEngine('hidePrompt');
}
function clearCustomerInfo(){
	$("#customerName").val("");
	$("#customerId").val("");
}
/**初始化行事件**/
function initTrEvents(){
	$("[id^=add]").click(function(){
    	addTr(this);
    	return false;
    });
    $("[id^=del]").click(function(){
    	moveTr(this);
    	return false;
    });

    
}

/** 自动计算总价格 **/
function changeSumPrice(object){
   	var tr = $(object).parents("tr");
   	var num = tr.find("[id$=unitPrice]").val()*tr.find("[id$=quantity]").val();
	tr.find("[id$=sumPrice]").val(cutZero(num.toFixed(2)));
}

function resetRowNO(){
	var len = $("#table tr").size();

	for(var i = len - 1; i >= 0; i--){
		var name = "details[" + i + "].";
		var tr = $("#table tr").eq(i);
		
		tr.find("input").each(function(){
			$(this).attr("name", name + $(this).attr("vhidden"));
			$(this).attr("id", i+$(this).attr("vhidden"));
		});
		
		tr.find("[id$=itemSpan]").each(function(){
			$(this).html(i+1);
			tr.find("[id$=item]").val(i+1);
		});
		
		tr.find("[id*=rowNo]").val(i+1);
	    tr.find("#unitPrice" + i).addClass("validate[required,max[100000],custom[positiveNumber]]");
	    tr.find("#quantity" + i).addClass("validate[required,max[10000000],custom[positiveInteger]]");
	}
	
    
	$("#borrowStockForm").validationEngine('detach');
   	$("#borrowStockForm").validationEngine('attach');
}

//添加行的方法
function addTr(object){
	var tr = $("#copyTr").clone(true);	
	tr.attr("id", "");				
    tr.insertAfter($(object).parents("tr"));
    tr.show();
    resetRowNO();
    inventoryAutoComplete(tr.find("[id$=inventoryCode]"),inventoryList);
	$("#borrowStockForm").validationEngine('hide');
}

/**删除行时消除原有的提示信息**/
function clearTrTips(tr){
	tr.find("[id*=unitPrice]").validationEngine('hidePrompt');
	tr.find("[id*=quantity]").validationEngine('hidePrompt');
}

function checkEmptyTr(tr){
	if(tr.find("[id$=inventoryCode]").val() == "" &&
		tr.find("[id$=customerInventoryCode]").val() == "" &&
		tr.find("[id$=unitPrice]").val() == "" &&
		tr.find("[id$=taxUnitPrice]").val() == "" &&
		tr.find("[id$=quantity]").val() == "" &&
		tr.find("[id$=expectDate]").val() == ""){
			return true;
		}
	return false;	
}

/**设置客户料号自动匹配框**/
function inventoryAutoComplete($input,inventoryList){
	$input.unautocomplete().autocomplete(inventoryList,{
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>物料编码</span> <span class='col-2'>客户物料号</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.partNo + "</span> " + "<span class='col-2'>" + row.cinvName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.cinvName;
		},
		formatResult: function(row) {
			return row.cinvName;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$(this).parents("tr").find("[id$=inventoryCode]").val(data.partNo);
		$(this).parents("tr").find("[id$=inventoryCode]").validationEngine('hidePrompt');
	}).bind("unmatch", function(){
		$(this).parents("tr").find("[id$=inventoryCode]").val("");
		$(this).parents("tr").find("[id$=inventoryCode]").validationEngine('hidePrompt');
	});
}
function ajaxByBu(buId){
	$("#department").unautocomplete();
	$("#person").unautocomplete();
	$("#inventoryClass").unautocomplete();
	/* 部门 */
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/findDepartmentListByBu?buId="+buId),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.departmentList != null){
				$("#department").autocomplete(data.departmentList, {
					/**加自定义表头**/
					tableHead: "<div><span>部门名称</span></div>",
					minChars: 0,
					width: 300,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span>" + row.departmentName + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.departmentName;
					},
					formatResult: function(row) {
						return row.departmentName;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#departmentId").val(data.id);
					$("#department").val(data.departmentName);
				}).bind("unmatch", function(){
					$("#departmentId").val("");
					$("#department").val("");
				}).bind("unautocomplete", function() {              	
            		select.unbind();
            		$input.unbind();
            		$(input.form).unbind(".autocomplete"); 
            		/**当unautocomplete时将select中的数据清空**/
            		cache.flush();
            	});;
			}
		}
	}); 
	/* 业务员 */
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/findPersonListByBu?buId="+buId),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.personList != null){
				$("#person").autocomplete(data.personList, {					
					tableHead: "<div><span>业务员名称</span></div>",
					minChars: 0,
					width: 300,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span>" + row.personName + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.personName;
					},
					formatResult: function(row) {
						return row.personName;
					}
				}).result(function(e,data,value,sec){
					$("#personId").val(data.id);
					$("#person").val(data.personName);
				}).bind("unmatch", function(){
					$("#personId").val("");
					$("#person").val("");
				}).bind("unautocomplete", function() {              	
            		select.unbind();
            		$input.unbind();
            		$(input.form).unbind(".autocomplete"); 
            		/**当unautocomplete时将select中的数据清空**/
            		cache.flush();
            	});;
			}
		}
	}); 
	
	$.ajax({
		type:"GET",
		url:encodeURI("/approvalajax/findProductLineByBu?buId="+buId),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.productLineList != null){
				$("#inventoryClass").autocomplete(data.productLineList, {
					/**加自定义表头**/
					tableHead: "<div><span >产品线</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span >" + row.name + "</span> ";
					},
					formatMatch: function(row, i, max) {
						return row.name;
					},
					formatResult: function(row) {
						return row.name;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#inventoryClass").val(data.name);	
					$("#inventoryClassId").val(data.id);
					setInventoryAutoComplete($("#table [id$=inventoryCode]"),data.id);					
				}).bind("unmatch",function(){
					$("#inventoryClass").val("");
					$("#inventoryClassId").val("");
				}).bind("unautocomplete", function() {              	
            		select.unbind();
            		$input.unbind();
            		$(input.form).unbind(".autocomplete"); 
            		/**当unautocomplete时将select中的数据清空**/
            		cache.flush();
            	});;
			}
		}
	}); 
}
function setInventoryAutoComplete($input, productLineId){
	 $input.unautocomplete();
	 $.ajax({
			type:"GET",
			url:encodeURI("/approvalajax/findInventorysByProductLine?productLineId="+productLineId),
			dataType:"json",
			success:function(data, textStatus){
				if(data != null && data.inventoryList != null){	
					inventoryList=data.inventoryList;
					$input.unautocomplete().autocomplete(data.inventoryList, {
						//加自定义表头
						tableHead: "<div><span class='col-1'>产品型号</span> <span class='col-2'>产品类型</span></div>",
						minChars: 0,
						width: 310,
						matchContains: "true",
						autoFill: false,
						formatItem: function(row, i, max) {
							return "<span class='col-1'>" + row.partNo + "</span> " + "<span class='col-2'>" + row.cinvName + "</span>";
						},
						formatMatch: function(row, i, max) {
							return row.partNo;
						},
						formatResult: function(row) {
							return row.partNo;
						}
					}).result(function(e,OneData,value,sec){//加选中后的回调函数
						$(this).parents("tr").find("[id$=inventoryCode]").val(OneData.partNo);
						$(this).parents("tr").find("[id$=inventoryClassId]").val(OneData.inventoryClassId);
						$(this).validationEngine('hidePrompt');						
					}).bind("unmatch",function(){
						$(this).parents("tr").find("[id$=inventoryClassId]").val("");
					}).bind("unautocomplete", function() {              	
	            		select.unbind();
	            		$input.unbind();
	            		$(input.form).unbind(".autocomplete"); 
	            		/**当unautocomplete时将select中的数据清空**/
	            		cache.flush();
	            	});;					
				}
			}
		}); 
		
	}  