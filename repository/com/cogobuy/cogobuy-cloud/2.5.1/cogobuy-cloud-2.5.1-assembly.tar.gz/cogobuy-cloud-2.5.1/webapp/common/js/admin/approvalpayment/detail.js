var commentId;
$(function(){
	
	if(typeof String.prototype.trim !== 'function') {
		  String.prototype.trim = function() {
		    return this.replace(/^\s+|\s+$/g, ''); 
		  }
	}

	$("button[id^=commentButton]").click(function(){
		commentId = $(this).attr("id");
		var content = $("#" + $(this).attr("id") + "Form").find('textarea').val();
		if(''==content.trim()){
			dialog("请输入评论内容！","unsuccess",true,1);
			return;
		}
		$("#" + $(this).attr("id") + "Form").ajaxSubmit(function(data,status){
			$("#" + commentId + "Form [name=content]").val("");
			var result = eval('(' + data + ')');
			
			if(result != null && result.commentList != null && result.commentList.length > 0){
				var $commentList = $("<ul></ul>");
				var len = result.commentList.length;
				for(var i = 0; i < len; i++){
					var comment = result.commentList[i];
					var strLi = '<li class="payment-comment">' +
                        '<span class="username" id="comment_' + comment.id + '">' + comment.user.name + '：</span>' +
                        '<span class="p-content">' + comment.content + '</span>' +
                        '<span class="time">' + disposeDate(comment.createTime) + '</span>';
                    if(result.sessionUser != null){
                    	if(result.sessionUser.id != comment.user.id){
                    		strLi += '<a href="javascript:reply(\''+result.parent+'\','+result.parentId+','+comment.id+');" title="回复" class="r reply-a">回复</a></li>';
                    	} else {
                    		strLi += '<a href="/payment/comment_delete?commentId=' + comment.id + 
                    		 '&paymentId=' + result.paymentId + '" title="删除" class="r delete-a">删除</a></li>';
                    	}
                    }
					$commentList.append(strLi);
				}
				$("#" + commentId + "List").html("");
				$("#" + commentId + "List").append($commentList);
			}
		});
	});
	
	$("#paymentPrint").bind("click",function(event){
		document.all.WebBrowser.ExecWB(6,1);
	});
	$("#printPreview").bind("click",function(event){
		document.all.WebBrowser.ExecWB(7,1);
	});
	$("#printSet").bind("click",function(event){
		document.all.WebBrowser.ExecWB(8,1);
	});
	
	
	
//	$("#paymentPrint").bind("click",function(event){
//
//		$("#paymentBody").printArea();
//	});
});

function disposeDate(value){
	if(value != null){
		return value.substring(0,10) + " " + value.substring(11);
	}
	else{
		return "";
	}
}

function reply(parent,parentId,commentId){
	if(parent=='T_Payment'){
		$("#content").val("@"+$("#comment_"+commentId).text());
	}else{
		$("#form-comment_"+parentId).show();
		$("#remark_"+parentId).val("@"+$("#comment_"+commentId).text());
	}
}

function delAttach(attachId){
	$.ajax({
    type:"GET",
    url:encodeURI("/payment/payment_delAttach"),
    data:{"attachId":attachId},
    success:function(returnStr){
    	if (returnStr == "2") {
    		$("#attach_"+attachId).remove();
	        } 
	        if(returnStr == "0"){
	           dialog("删除附件出错","unsuccess",true,2);
	           return;
	        }
    }
});
}

/**
* 改变文件类型
* @param filePath
*/
function changeAttachType(id){
$.ajax({
    type:"GET",
    url:encodeURI("/payment/payment_changeAttachType?attachId="+id),
    success:function(returnStr){
    	if (returnStr == "2") {
    		var tag = $("#attachType_"+id);
    		if(tag.hasClass("priority-yes")){
    			tag.removeClass("priority-yes");
    			tag.attr("title","标记为重要附件");
    		}else{
    			tag.addClass("priority-yes");
    			tag.attr("title","标记为普通附件");
    		}
    		return;
	        } 
	        if(returnStr == "0"){
	           dialog("设置出错","unsuccess",true,2);
	           return;
	        }
    }
});
}