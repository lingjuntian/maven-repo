/**
 * 根据帐套,查找对应的供应商,并填充供应商列表
 * @param buId
 * @param selectId
 */
function findCompanyByBuForSelect(ledger,selectId){
	$.ajax({
        type:"GET",
        url:encodeURI("/adminajax/findAllVendor?ledger="+ledger),
        dataType:"json",
        success:function(data, textStatus){
            if(data != null && data.vendorList != null){
            	$("#vendorName").unautocomplete();
                $("#vendorName").autocomplete(data.vendorList,{
                    /**加自定义表头**/
                    tableHead: "<div><span class='col-1'>编码</span> <span class='col-2'>名称</span></div>",
                    minChars: 0,
                    width: 310,
                    matchContains: "true",
                    autoFill: false,
                    formatItem: function(row, i, max) {
                        return "<div><span class='col-1'>"+row.code+"</span> <span class='col-2'>"+row.name+"</span></div>";
                    },
                    formatMatch: function(row, i, max) {
                        return row.name;
                    },
                    formatResult: function(row) {
                        return row.name;
                    }
                }).result(function(e,data,value,sec){/**加选中后的回调函数**/
                    $("#vendorName").val(data.name);
                    $("#vendorId").val(data.id);
                    $("#vendorCode").val(data.code);
                    $("#vendorBank_vendorId").val(data.id);
                    clearAccount();
                    clearTime();
                    paddingAccount(data.id, true);//根据供应商填充账号
                }).bind("unmatch", function() {/**没有匹配时**/
                	$("#vendorName").val("");
                    $("#vendorId").val("");
                    $("#vendorCode").val("");
                    $("#vendorBank_vendorId").val("");
                    clearAccount();
                    clearTime();
                });
            }
        }
    });
}	

function autoCustomer(autoInputId,valueId){
	$.ajax({
		type:"GET",
		url:encodeURI("/adminajax/master_findCustomerList"),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.customerList != null){
				$("#"+autoInputId).autocomplete(data.customerList, {
					/**加自定义表头**/
					tableHead: "<div><span style='width:40%' class='col-1'>客户编码</span> <span style='width:58%' class='col-2'>客户名称</span></div>",
					minChars: 0,
					width: 310,
					matchContains: "true",
					autoFill: false,
					formatItem: function(row, i, max) {
						return "<span  style='width:40%' class='col-1'>" + row.customerCode + "</span> " + "<span style='width:58%' class='col-2'>" + row.fullName + "</span>";
					},
					formatMatch: function(row, i, max) {
						return row.fullName;
					},
					formatResult: function(row) {
						return row.fullName;
					}
				}).result(function(e,data,value,sec){/**加选中后的回调函数**/
					$("#"+valueId).val(data.id);
					$("#"+autoInputId).val(data.fullName);
					$("#"+autoInputId).validationEngine('hidePrompt');
				}).bind("unmatch", function(){
					$("#"+autoInputId).val("");
					$("#"+valueId).val("");
				});
			}
		}
	});
}



/**
 * 根据BU查找账套,并填充selectId对应的select值
 * @param buId
 * @param selectId
 */
function findLedgerByBuForSelect(buId, selectId){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/findLedgerByBu?buId="+buId),
        dataType:"json",
        success:function(data, textStatus){
        	clearSelect(selectId,"ledger");
            if(data != null){
            	if(data.ledgerList != null){//动态填充流程
            		$.each(data.ledgerList,function(n,value) { 
           			 	var listr = "<li><a href=\"#\" ledger=\"ledger\" tagN=\"ledger\" tagValue=\""+value+"\" vhidden=\""+value+"\">"+value+"</a></li>";
           			 	$("#"+selectId).append(listr);
           	     	});
            		bindselect();
            	}
            }
        }
    });
}

/**
 * 根据BU,账套查找对应的产品线,并填充产品线列表
 * @param buId
 * @param ledger
 * @param selectId
 */
function findProductLineByBuAndLedgerForSelect(buId, ledger ,selectId){
	$.ajax({
        type:"GET",
//        url:encodeURI("/approvalajax/findProductLineByBuAndLedger?buId="+buId+"&ledgerList="+ledger),
        url:encodeURI("/approvalajax/findProductLineByBuAndLedger?buId="+buId),
        dataType:"json",
        success:function(data, textStatus){
        	$("#"+selectId).html("");//清除以前的值
        	$("#selectedPL").text("请选择");
            if(data != null){
            		var listr = "";
            		if(buId==1 || buId==8){
            			listr = "<div class=\"options-checkbox none\">"+
									"<div class=\"actions clearfix\">"+
										"<span class=\"show-text\">请选择产品线，可多选</span>"+
										"<button type=\"button\"  id=\"plSelect\" class=\"button button-options-sure\" data-display-type=\"num\" data-initial-value=\"请选择产品线\">确定</button>"+
									"</div>"+
									"<div class=\"options-list-box\">"+
									"<ul class=\"options-list clearfix\" id=\"pLinesUl\">";
            			if(data.productLineList != null){//动态填充流程
	            			$.each(data.productLineList,function(n,value) { 
	            				listr += "<li class=\"options-item\">"+
						   					"<label class=\"label\">"+
							  					"<input type=\"checkbox\" class=\"input-checkbox\" name=\"pLines\" plName=\""+value.name+"\" value=\""+value.id+":"+value.name+"\"/>"+
							  					"<span title='"+value.name+"'>"+value.name+"</span>"+
						   					"</label>"+
					   					"</li>";
	               	     	});
            			}else{
            				listr += "<li class=\"options-item\">没有相关产品线！</li>";
            			}
            			listr += "</ul></div></div>";
            		}else{
            			listr = "<div class=\"options none\">"+
                                   "<input type=\"text\" name=\"payment.inventoryClass\" id=\"inventoryClass\" />"+
                        			"<input type=\"text\" name=\"payment.inventoryClassId\" id=\"inventoryClassId\" />"+
                                    "<ul>"+
                                    	"<li><a href=\"#\" tagN=\"pl\" tagValue=\"\" vhidden=\"请选择产品线\">请选择产品线</a></li>";
            			if(data.productLineList != null){//动态填充流程
	            			$.each(data.productLineList,function(n,value) { 
	                			listr += "<li><a href=\"#\" clearTag=\"clear\" tagValue=\""+value.id+"\" vhidden=\""+value.name+"\">"+value.name+"</a></li>";
	               	     	});
            			}
            			listr += "</ul></div>";
            		}
            		$("#"+selectId).html(listr);
            		bindselect();
            }
        }
    });
}

/**
 * 根据BU,查找对应的部门,并填充部门列表
 * @param buId
 * @param selectId
 */
function findDepartmentByBuForSelect(buId,selectId){
	$.ajax({
        type:"GET",
        url:encodeURI("/approvalajax/findDepartmentListByBu?buId="+buId),
        dataType:"json",
        success:function(data, textStatus){
        	clearSelect(selectId,"dp");
            if(data != null){
            	if(data.departmentList != null){//动态填充流程
            		$.each(data.departmentList,function(n,value) { 
            			var listr = "<li><a href=\"#\" tagValue=\""+value.id+"\" vhidden=\""+value.departmentName+"\">"+value.departmentName+"</a></li>";
            			$("#"+selectId).append(listr);
           	     	});
            		bindselect();
            	}
            }
        }
    });
}	
	
/**
 * @param id  清空select
 */
function clearSelect(id, tag){
	$("#"+id).empty();
	$("#"+id).append("<li><a href=\"#\" tagN=\""+tag+"\" tagValue=\"\" vhidden=\"请选择\">请选择</a></li>");
	$("#"+id).parents(".options-select").find(".select").find("span").text("请选择");
	$("#"+id).parents(".options-select").find("input").val("");
}

/**
 * 绑定方法
 */
function bindselect(){
	$(".options-select .options a").unbind("click");
	$(".options-select .options a").bind("click",function(){
		$(this).parents(".options-select").find(".select").find("span").text($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input").val($(this).attr("vhidden"));
		$(this).parents(".options-select").find("input[id$=Id]").val($(this).attr("tagValue"));
		if($(this).attr("tagN") == "bu"){
			$("#personId").val("");
			$("#person").val("");
			$("#inventoryClass").val("");
			$("#inventoryClassId").val("");
			//$("#productLineForSelect").val("");
			var buId = $(this).attr("tagValue");
			if(buId=='1' || buId=='8'){//世晓
				$("#accountType").show();
			}else{
				initAccountType();
			}
			findLedgerByBuForSelect($(this).attr("tagValue"),"ledgerForSelect");
			findDepartmentByBuForSelect($(this).attr("tagValue"),"departmentForSelect");
			findProductLineByBuAndLedgerForSelect($(this).attr("tagValue"),null,"productLineForSelect");
		}
		if($(this).attr("ledger") == "ledger"){
			$("#vendorName").val("");
            $("#vendorId").val("");
            $("#vendorCode").val("");
            $("#vendorBank_vendorId").val("");
            findCompanyByBuForSelect($(this).attr("tagValue"),"companyForSelect");
            clearTime();
		}
		if($(this).attr("clearTag") == "clear"){
			clearTime();
		}
//		if($(this).attr("tagN") == "ledger"){
//			findProductLineByBuAndLedgerForSelect($("#buId").val(),$(this).attr("tagValue"),"productLineForSelect");
//		}
		$(this).parents(".options-select").find(".options").hide();
		$(this).parents(".options-select").find(".options").addClass("none");
		return false;
	});
}

function initAccountType(){
	var html = "<label><input class=\"input-radio\" type=\"radio\" name=\"payment.accountType\" value=\"1\" checked=\"checked\" />对公</label>"+
			   "<label><input class=\"input-radio\" type=\"radio\" name=\"payment.accountType\" value=\"0\" />对私</label>";
	$("#accountType").html(html);
	$("#accountType").hide();
}
