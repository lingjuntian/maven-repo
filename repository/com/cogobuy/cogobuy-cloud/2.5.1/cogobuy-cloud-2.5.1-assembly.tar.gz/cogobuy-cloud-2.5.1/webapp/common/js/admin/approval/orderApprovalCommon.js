function commonReady(){
    /**给表单元素添加验证**/
    $("#saleOrderNo").addClass("validate[required]");
    $("#customerName").addClass("validate[required]");

    

	ajaxInventoryList();
	
	$("#saleTypeSelect a").bind("click", function(){
		setItaxRate($("#currencySelect span").text(), $(this).text());
	});
	
	$("#currencySelect a").bind("click", function(){
		setItaxRate($(this).text(), $("#saleTypeSelect span").text());
	});

    $("#submit").click(function(){
		save();
		return false;
    });
}
//与客户相关的开始
function autoCompleteCustomer(data){
	clearCustomerInfo();
	$("#customerId").val(data.id);
	$("#customerName").val(data.fullName);
	$("#customerName").validationEngine('hidePrompt');

	var ajaxCustomerInventoryUrl = "/adminajax/master_findCustomerInventoryList"
		+ "?customerId=" + data.id;
	$.ajax({
		type:"GET",
		url:encodeURI(ajaxCustomerInventoryUrl),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.list != null){
				customerInventoryList = data.list;
				setCustomerInventoryAutoComplete($("#table [id^=customerInventoryCode]"));
			}
		}
	});    
}
function clearCustomerInfo(){
	$("#customerName").val("");
	$("#customerId").val("");
}
/**初始化行事件**/
function initTrEvents(){
	$("[id^=add]").click(function(){
    	addTr(this);
    	return false;
    });
    $("[id^=del]").click(function(){
    	moveTr(this);
    	return false;
    });

    $("[id^=expectDate]").click(function(){
		WdatePicker({onpicked:function(){$(this).validationEngine('hidePrompt');}, minDate:GetTodayDateStr()});
	});
	
	$("[id^=unitPrice]").unbind("change").change(function(event){
		changeSellPrice(this,"");
	});
    
    $("[id^=taxUnitPrice]").unbind("change").change(function(event){
		changeSellPrice(this,"tax");
	});
}

function resetRowNO(){
	var len = $("#table tr").size();

	for(var i = len - 1; i >= 0; i--){
		var name = "orderApprovalDetailList[" + i + "].";
		var tr = $("#table tr").eq(i);
		
		tr.find("input").each(function(){
			$(this).attr("name", name + $(this).attr("vhidden"));
			$(this).attr("id", $(this).attr("vhidden") + i);
		});
		tr.find("[id*=rowNo]").val(i+1);
		tr.find("#taxUnitPrice" + i).addClass("validate[required,max[100000],custom[positiveNumber]]");
	    tr.find("#unitPrice" + i).addClass("validate[required,max[100000],custom[positiveNumber]]");
	    tr.find("#quantity" + i).addClass("validate[required,max[10000000],custom[positiveInteger]]");
	    tr.find("#expectDate" + i).addClass("validate[required,past[" + GetTodayDateStr() + "],custom[date]]");
	}

	if($("#table tr").size() >= 2){
  	   $("#table tr").find(".del").show();
    }else{
      $("#table tr").find(".del").hide();
    }
    
	$("#form").validationEngine('detach');
   	$("#form").validationEngine('attach');
}

//添加行的方法
function addTr(object){ 	
	var tr = $("#copyTr").clone(true);	
	tr.attr("id", "");				
    tr.insertAfter($(object).parents("tr"));
    tr.show();
    resetRowNO();
	setInventoryAutoComplete(tr.find("[id^=inventoryCode]"));
	setCustomerInventoryAutoComplete(tr.find("[id^=customerInventoryCode]"));
	$("#form").validationEngine('hide');
}

/**删除行时消除原有的提示信息**/
function clearTrTips(tr){
	tr.find("[id*=inventoryCode]").validationEngine('hidePrompt');
	tr.find("[id*=unitPrice]").validationEngine('hidePrompt');
	tr.find("[id*=taxUnitPrice]").validationEngine('hidePrompt');
	tr.find("[id*=quantity]").validationEngine('hidePrompt');
	tr.find("[id*=expectDate]").validationEngine('hidePrompt');
}

function setItaxRate(currencyName, saleType){
	if(saleType == "国内销售" && currencyName == "人民币"){
		$("#taxRate").val("17");
	}
	else{
		$("#taxRate").val("0");
	}
	changePrice();
}

function changePrice(){
	var len = $("#table tr").size();
   	var itaxRate = $("#taxRate").val();
	for(var i = 0; i < len; i++){
		var tr = $("#table tr").eq(i);
		if(tr.find("[name*=taxUnitPrice]").val() != ""){
			var num = (tr.find("[name*=taxUnitPrice]").val())/(1+itaxRate/100);
			tr.find("[name*=unitPrice]").val(cutZero(num.toFixed(6)));
		}
	}
}

function checkEmptyTr(tr){
	if(tr.find("[id^=inventoryCode]").val() == "" &&
		tr.find("[id^=customerInventoryCode]").val() == "" &&
		tr.find("[id^=unitPrice]").val() == "" &&
		tr.find("[id^=taxUnitPrice]").val() == "" &&
		tr.find("[id^=quantity]").val() == "" &&
		tr.find("[id^=expectDate]").val() == ""){
			return true;
		}
	return false;	
}

/**设置客户料号自动匹配框**/
function setCustomerInventoryAutoComplete($input){
	$input.autocomplete(customerInventoryList, {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>物料编码</span> <span class='col-2'>客户物料号</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.inventoryCode + "</span> " + "<span class='col-2'>" + row.code + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.code;
		},
		formatResult: function(row) {
			return row.code;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		//clearInventoryInfo($(this).parents("tr"));
		$(this).parents("tr").find("[id^=inventoryCode]").val(data.inventoryCode);
		$(this).parents("tr").find("[id^=customerInventoryCode]").val(data.code);
		//$(this).parents("tr").find("[name*=partName]").val(data.cinvName);
		$(this).parents("tr").find("[id^=inventoryCode]").validationEngine('hidePrompt');
		findInventoryInfo($(this).parents("tr"), data.inventoryCode);
	}).bind("unmatch", function(){
		$(this).parents("tr").find("[id^=inventoryCode]").val("");
		$(this).parents("tr").find("[id^=inventoryName]").val("");
		$(this).parents("tr").find("[id^=inventoryCode]").validationEngine('hidePrompt');
	});
}

function ajaxInventoryList(ledger){
	var url = "/adminajax/master_findInventoryList";
	if(ledger != "" && ledger != null){
		url += "?ledger="+ledger;
	}
	$.ajax({
		type:"GET",
		url:encodeURI(url),
		dataType:"json",
		success:function(data, textStatus){
			if(data != null && data.inventoryList != null){
				inventoryList = data.inventoryList;
				setInventoryAutoComplete($("#table [id^=inventoryCode]"));
			}
		}
	});
}

function setInventoryAutoComplete($input){
	$input.unautocomplete().autocomplete(inventoryList, {
		/**加自定义表头**/
		tableHead: "<div><span class='col-1'>产品型号</span> <span class='col-2'>产品类型</span></div>",
		minChars: 0,
		width: 310,
		matchContains: "true",
		autoFill: false,
		formatItem: function(row, i, max) {
			return "<span class='col-1'>" + row.partNo + "</span> " + "<span class='col-2'>" + row.cinvName + "</span>";
		},
		formatMatch: function(row, i, max) {
			return row.partNo;
		},
		formatResult: function(row) {
			return row.partNo;
		}
	}).result(function(e,data,value,sec){/**加选中后的回调函数**/
		$(this).parents("tr").find("[id^=inventoryCode]").val(data.partNo);
		$(this).parents("tr").find("[id*=inventoryName]").val(data.cinvName);
		$(this).parents("tr").find("[id^=inventoryClassId]").val(data.inventoryClassId);
		$(this).validationEngine('hidePrompt');
		findCustomerInventoryInfo($(this).parents("tr"), data.partNo);
	}).bind("unmatch",function(){
		$(this).parents("tr").find("[id*=inventoryName]").val("");
		$(this).parents("tr").find("[id^=customerInventoryCode]").val("");
		$(this).parents("tr").find("[id^=inventoryClassId]").val("");
	});
}

function check(){
	$("#form").attr("action", "/approvalajax/orderApproval_check");
	$("#form").ajaxSubmit(function(data,status){
		var result = eval('(' + data + ')');
		if(result != null && result.orderApprovalDetailList != null && result.orderApprovalDetailList.length > 0){
			var detailList = result.orderApprovalDetailList;
			var len = detailList.length;
			for(var i = 0; i < len; i++){
				var detail = detailList[i];
				if(detail.productLineId == null){
	//					$("#inventoryCode" + i).addClass("error");
					$("#inventoryCode" + i).validationEngine("showPrompt", "您输入的厂商型号在" + $("#buName").val() + "中不存在对应的产品线", 'error', "", true);
				}else{
					$("#productLineId" + i).val(detail.productLineId);
				}
			}
		}
		if(result != null && result.flag == "error"){
			return false;
		}else{
			checkCallBack();
			/*$("#mailList").load(encodeURI(url), function(){
				
			});	*/
			return true;
		}
	});
}