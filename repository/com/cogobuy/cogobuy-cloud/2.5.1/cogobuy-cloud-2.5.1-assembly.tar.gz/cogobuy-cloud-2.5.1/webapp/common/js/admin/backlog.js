$(function(){
  $("#backlogSubmit").click(function(){
    //var isError = checkBeforeSubmit();
    var isError=false;
    if (!isError) {
      $("#backlogForm").ajaxSubmit(function(returnStr){
        if (returnStr == "success") {
          var manuId=$("#manuId").val();
          var manuName=$(".toolbar .title em").text();
          location.href='/admin/backlog_findPurchaseList?manuId='+manuId+'&manuName='+manuName;
        } else {
          dialog("数据保存错误，请检查数据正确性后重试","unsuccess",false);
        }
      });
    }
  });
  $("#uploadFile").change(function(){
    if($(this).val() != "") {
      $("#uploadForm input").remove();
      var $submitFile = $(this).clone(true);
      $(this).before($submitFile);
      $(this).attr("id", "");
      $("#uploadForm").append($(this));
      $("#uploadForm").ajaxSubmit(function(data,status){
         var result = eval('(' + data + ')');
         if(result.msg) {
           $("#uploadFile").validationEngine("showPrompt", result.msg, 'error', "", true);
         } else {
           $("#uploadFile").validationEngine("hidePrompt");
           setFileData(result.list);
         }
      });
    }
  });
  /**选择radio**/
  $(".radio label").click(function(){
    $("#message").css('display','none');
    $(".toolbar .title em").text($(this).text());
    $(".radio label").removeClass("selected");
    $(this).addClass("selected");
    $(this).parents(".form-list").find("input[type='hidden']").val($(this).attr("vhidden"));
    $("#uploadForm").attr("action","/vajax/read_backlog_excel?manuId="+$(this).attr("vhidden"));
  });
  /**点击上传按钮**/
  $("#uploadFile").click(function() {
    initValidation();
    var isError=false;
    isError = $("#backlogForm").validationEngine("validateField", "#manuId");
    if(isError){
      dialog("请选择厂商后再上传!","warning",false);
      //$("#message").css('display','block'); 
      return false;
    }
  });
  /**删除提示信息**/
  $("#view").click(function() {removeValidationMsg();});
});

/**设置文件数据**/
function setFileData(list) {
  var len = list.length;
  if(len == 0) {
    return;
  }
  for (var i = 0; i < len; i++) {
    writeRowHtml(list[i]);
  }
  //addRow();
  initValidation();
  
}
/**初始化配置**/
function initValidation(){
    $("#backlogForm").validationEngine('detach');
    $("#backlogForm").validationEngine({showArrow:true});
    //$("#backlogForm").validationEngine({ 
      //inlineValidation:false, //在这里修改 
      //success : false, 
      //failure : function() {aa()});
}
/**添加一行**/
function addRow() {
  writeRowHtml();
  initValidation();
}
/**提交前检查**/
function checkBeforeSubmit() {
  var isError = false;
  var hasDetail = false;
  $("input[id^=partNo]").each(function(){
    var idx = $(this).attr("id").substr(6);
    if(!($(this).val() == "" && $("#quantity" + idx).val() == "" && $("#purchaseOrderNo" + idx).val() == "")) {
       hasDetail = true;
       var isError1 = $("#backlogForm").validationEngine("validateField", "#partNo" + idx);
       var isError2 = $("#backlogForm").validationEngine("validateField", "#scheduleDate" + idx);
       var isError3 = $("#backlogForm").validationEngine("validateField", "#quantity" + idx);
       var isError4 = $("#backlogForm").validationEngine("validateField", "#purchaseOrderNo" + idx);
       var isError5 = $("#backlogForm").validationEngine("validateField", "#orderDate" + idx);
       var isError6 = $("#backlogForm").validationEngine("validateField", "#requestDate" + idx);
       if (isError1 || isError3 || isError4) {
         isError = true;
       }
    }
  });
  if (!hasDetail) {
    $("#itemTitle").next().validationEngine("showPrompt", "至少要有一行详细信息", 'error', "", true);
    isError = true;
  }
  return isError;
}
/**添加一行**/
function writeRowHtml(item) {
  var idx = new String(randomNum1());
  
  var $newtr = $('<tr></tr>');
  $newtr.attr("id", "prerow" + idx)
        .mouseover(function(){onmouseshow(idx)})
        .mouseout(function(){onmousehide(idx)})
        .click(function(){$(this).validationEngine("hidePrompt");});

  var $td1 = $('<td></td>');
  var $partNo = $('<input name="partNo" type="text" class="input-text code" readonly="true" class="validate[required]" />');
  $partNo.attr("id", "partNo" + idx);
  $td1.append($partNo);
  var $td2 = $('<td></td>');
  var $scheduleDate = $('<input name="scheduleDate" type="text" class="input-text lastdate" readonly="true" class="validate[required,custom[date]]" />');
  $scheduleDate.attr("id", "scheduleDate" + idx);
  $td2.append($scheduleDate);
  var $td3 = $('<td></td>');
  var $quantity = $('<input name="quantity" type="text" class="input-text num" readonly="true" class="validate[required,custom[integer]]" />');
  $quantity.attr("id", "quantity" + idx);
  $td3.append($quantity);
  var $td4 = $('<td></td>');
  var $purchaseOrderNo = $('<input name="purchaseOrderNo" type="text" class="input-text order" readonly="true" class="validate[required]" />');
  $purchaseOrderNo.attr("id", "purchaseOrderNo" + idx);
  $td4.append($purchaseOrderNo);
  var $td5 = $('<td></td>');
  var $orderDate = $('<input name="orderDate" type="text" class="input-text orderdate" readonly="true" class="validate[required,custom[date]]" />');
  $orderDate.attr("id", "orderDate" + idx);
  $td5.append($orderDate);
  var $td6 = $('<td></td>');
  var $requestDate = $('<input name="requestDate" type="text" class="input-text orderbacklog" readonly="true" class="validate[required,custom[date]]" />');
  $requestDate.attr("id", "requestDate" + idx);
  $td6.append($requestDate);
  $newtr.append($td1).append($td2).append($td3).append($td4).append($td5).append($td6);
  
  if(item) {
    $partNo.val(item.partNo);
    $quantity.val(item.quantity);
    $purchaseOrderNo.val(item.purchaseOrderNo);
    $requestDate.val(item.requestDateStr);
    $scheduleDate.val(item.scheduleDateStr);
    $orderDate.val(item.orderDateStr);
  }
  var $tab = $("#backlogTitle");
  $tab.append($newtr);
}
/**删除验证信息**/
function removeValidationMsg() {
  $("#backlogForm").validationEngine("hideAll");
}
/**产生一个随机数**/
function randomNum1() {
  return Math.round(Math.random()*10000);
}
/**显示**/
function onmouseshow(pidx){
  if ($("tr[id^=prerow]").length > 1) {
    $("#deleteimg" + pidx).show();
  }
}
/**隐藏**/
function onmousehide(pidx){
    $("#deleteimg" + pidx).hide();
}
/**日期**/
function dateSelect($obj) {
  if($obj.val() != "") {
    addRow();
  }
}
