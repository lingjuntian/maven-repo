$(function() {
	/* 点击提交*/
	$("#submit").click(function() {
		clearNull();/* 清除空行 */
		var error = validationInput();/* 验证输入 */
		if (error) {
			$("#submit").hide();
			$("#d8Form").ajaxSubmit(function(returnStr) {
				if (returnStr == "success") {
					dialog("成功","success",true,1);
					setTimeout(function(){window.location = "/approval/8d_list";},1000);	  
				}else{
					$("#submit").show();
					dialog(returnStr,"unsuccess",true,2);
				}
		        return false;
			});
		}
	});
});

/* 清除空行 、且修改相应字段的name+id属性 */
function clearNull() {
	//1.问题处理成员
	cleanTbody($("#userListTbody"));
	addIdAndNameForInput($("#userListTbody"),"main.userList");
	//4.暂时性对策
	cleanTbody($("#iviListTbody"));
	addIdAndNameForInput($("#iviListTbody"),"main.iviList");
	//5.永久性改善对策的拟定
	cleanTbody($("#cvpListTbody"));
	addIdAndNameForInput($("#cvpListTbody"),"main.cvpList");
	//6.永久性改善对策的实施及确认
	cleanTbody($("#ivpListTbody"));
	addIdAndNameForInput($("#ivpListTbody"),"main.ivpList");
	//7.预防再发生措施
	cleanTbody($("#aprListTbody"));
	addIdAndNameForInput($("#aprListTbody"),"main.aprList");
	//8.反馈时间
	cleanTbody($("#dfListTbody"));
	addIdAndNameForInput($("#dfListTbody"),"main.dfList");
}

/* 验证输入 */
function validationInput() {
	return $("#d8Form").validationEngine('validate');
}